using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;

using GIDOO_space;
using System.Data;


namespace GNPX_space{

	public partial class AHSTechGen: AnalyzerBaseV2{
		private int			stageNoPMemo = -9;
        private AHSLinkMan  AHSMan;
		private bool		debugPrint=false;

        public AHSTechGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){
            this.pAnMan=pAnMan;
        }

		private void PrepareStage( int minSize=1, bool debugPrintB=false ){

			if( stageNoP!=stageNoPMemo || AHSMan.AHSList== null ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();

                AHSMan = new AHSLinkMan( pAnMan );
				AHSMan.Initialize();
				AHSMan.Prepare_AHSLink_Man( nPlsB:1, setCondInfo:true, debugPrintB:debugPrintB );
				G6_staticFunctions.pBOARD = base.pBOARD;
			}      
		}



		
		public class U_RCC_nRCC{
			private string[] stXZ={"_","X","Z"}; 
			public int  rc;
			public int  Rtype;	// 1:RCC  2:nRCC
			public int  FreeB1;
			public int  FreeB2;

			public U_RCC_nRCC( int rc, int Rtype, int FreeB1, int FreeB2 ){
				this.rc=rc; this.Rtype=Rtype; this.FreeB1=FreeB1; this.FreeB2=FreeB2;
			}

			public override string ToString(){
				string st = $"   @ U_RCC_nRCC  rc:{rc.ToRCString()} Rtype:{Rtype}_{stXZ[Rtype]}   FreeB 1:#{FreeB1.TBScmp()} 1:#{FreeB2.TBScmp()}";
				return st;
			}
		}

		private  (int,List<U_RCC_nRCC>) Get_RCC_nRCC_List( UAnHS UA, UAnHS UB ){
			UInt128 Comm = UA.AHS_B81 & UB.AHS_B81;
			int flagRCC = 0;
			if( Comm == qZero )  return (0,null);

			List<U_RCC_nRCC>  RCCList = new();
			
			foreach( var U in Comm.IEGet_UCell(pBOARD) ){
				int FreeB1 = U.FreeB & UA.FreeB;
				int FreeB2 = U.FreeB & UB.FreeB;

				int Rtype = ((FreeB1&FreeB2)>0)? 2: 1;
				flagRCC |= Rtype;
				U_RCC_nRCC RC = new( U.rc, Rtype, FreeB1, FreeB2 );
				RCCList.Add(RC);
			}
				// RCCList.ForEach(R=>WriteLine(R));
			return  (flagRCC,RCCList);
		}



		private bool BasicCheck_sameHouse( UAnHS UAHS1, UAnHS UAHS2 ){
			// Determine that "two AHSs are completely contained within the same House."
			// In this case, the AHS app will not be established.
			if( UAHS1.hno == UAHS2.hno )  return false;		// Generated from the same house
			
			UInt128 UAHS12 = UAHS1.AHS_B81 | UAHS2.AHS_B81;
			int frame = UAHS12.Ceate_rcbFrameOr();
			// When there is only one row, column, or block in a frame,
			// it is completely contained in one house. 
			for( int k=0; k<3; k++ ){	
				if( (frame&0x1FF) .BitCount() == 1 ) return false;
				frame >>= 9;
			}
			return true;
		}

    }
}
