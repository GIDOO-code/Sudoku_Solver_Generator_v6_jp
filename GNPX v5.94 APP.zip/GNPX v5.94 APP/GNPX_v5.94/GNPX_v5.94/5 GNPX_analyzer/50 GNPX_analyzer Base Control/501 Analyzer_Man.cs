using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Media;
using System.Threading;
using static System.Diagnostics.Debug;
using static System.Math;
using System.Security.Cryptography;
using System.Windows.Interop;
using System.IO;
using System.Text;
using GIDOO_space;

namespace GNPX_space{
    using pRes=Properties.Resources;

    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
#if developv_5_1
	// Next development goal   ### �폜
	// (1) Exocet
	// (2) SK Loop
	// (3) Force Net
	// (4) Firework continuation
#endif


    // Analyzer Manager
    public class GNPX_AnalyzerMan{
		static private G6_Base  G6 => GNPX_App_Man.G6;
		static private G7_Base  G7 => GNPX_App_Man.G7;
		static public  UInt128 b081_all  = (UInt128.One<<81)-1;
        private UInt128[]    pConnectedCells81 => AnalyzerBaseV2.Connected_81;
		private UInt128[]    pHouseCells81 => AnalyzerBaseV2.House_81; 

        static private Color _Black_=Colors.Black;

		private bool		 __SimpleAnalyzerB__ => AnalyzerBaseV2.__SimpleAnalyzerB__;
        private bool         DebugSolCheckMode = G6.DebugSolCheckMode;

		public GNPX_App_Man  pGNPX_App => pGNPX_Eng.pGNPX_App;    
		
		public bool          SolInfoB{ get=>GNPX_Engin.SolInfoB; }
        public GNPX_Engin    pGNPX_Eng;

        public  int          stageNoP	=> pGNPX_Eng.stageNoP;

		public UPuzzle		 ePZL		=> pGNPX_Eng.ePZL; 
        public bool          _Not_Puzzle_{ get=>ePZL._Not_Puzzle_; set=>ePZL._Not_Puzzle_=value; }   
		public int           stageNo	=> ePZL.stageNo;     
        public List<UCell>   pBOARD		=> ePZL.BOARD;
        public int           SolCode{	set =>ePZL.SolCode=value; }
        public string        Result{	set=>ePZL.Sol_Result=value; }
        public string        ResultLong{ set=>ePZL.Sol_ResultLong=value; }


        public bool         chbx_ConfirmMultipleCells{ get=>GNPX_App_Man .chbx_ConfirmMultipleCells; }

		private int			stageNoPMemo=-1;
        public TimeSpan     SdkExecTime;

        private int[,]     Sol99sta{ get=> G6.Sol99sta; } //int[,]




        public  GNPX_AnalyzerMan( ){ }

        public  GNPX_AnalyzerMan( GNPX_Engin pGNPX_Eng ){
            this.pGNPX_Eng = pGNPX_Eng;

          //================================================================================================
          //  UAlgMethod( int pid, string MethodName, int difficultyLevel, dSolver Method, bool GenLogB=false )
          //================================================================================================
		    List<UAlgMethod> _SolverLst_000 = new();

            var SSingle = new SimpleSingleGen(this);
            _SolverLst_000.Add( new UAlgMethod( 1, "LastDigit",				1, SSingle.LastDigit ) );
            _SolverLst_000.Add( new UAlgMethod( 2, "NakedSingle",			1, SSingle.NakedSingle ) );
            _SolverLst_000.Add( new UAlgMethod( 3, "HiddenSingle",			1, SSingle.HiddenSingle ) );

            var eGLTech = new eGeneralLogicGen(this);
            _SolverLst_000.Add( new UAlgMethod( 4, " GeneralLogic",		2, eGLTech.eGeneralLogic, true) );

            var LockedCand = new LockedCandidateGen(this);
            _SolverLst_000.Add( new UAlgMethod( 5, "LockedCandidate",		2, LockedCand.LockedCandidate ) );
            
			// Algorithm selection level : simple:0 3  recommend1:4 6  recommend1:7 9  all:10 
            var LockedSet = new LockedSetGen(this);
            _SolverLst_000.Add( new UAlgMethod( 10, "LockedSet(3D)",        4, LockedSet.LockedSet3 ) );
            _SolverLst_000.Add( new UAlgMethod( 14, "LockedSet(4D)",        5, LockedSet.LockedSet4 ) );
            _SolverLst_000.Add( new UAlgMethod( 16, "LockedSet(5D)",        5, LockedSet.LockedSet5 ) );//complementary to 4D
            _SolverLst_000.Add( new UAlgMethod( 18, "LockedSet(6D)",        6, LockedSet.LockedSet6 ) );//complementary to 3D
            _SolverLst_000.Add( new UAlgMethod( 20, "LockedSet(7D)",        6, LockedSet.LockedSet7 ) );//complementary to 2D           
            _SolverLst_000.Add( new UAlgMethod( 11, "LockedSet(2D)Hidden",  3, LockedSet.LockedSet2Hidden ) );           
            _SolverLst_000.Add( new UAlgMethod( 13, "LockedSet(3D)Hidden",  4, LockedSet.LockedSet3Hidden ) );          
            _SolverLst_000.Add( new UAlgMethod( 15, "LockedSet(4D)Hidden",  5, LockedSet.LockedSet4Hidden ) );
            _SolverLst_000.Add( new UAlgMethod( 17, "LockedSet(5D)Hidden",  5, LockedSet.LockedSet5Hidden ) );//complementary to 4D
            _SolverLst_000.Add( new UAlgMethod( 19, "LockedSet(6D)Hidden",  6, LockedSet.LockedSet6Hidden ) );//complementary to 3D        
            _SolverLst_000.Add( new UAlgMethod( 21, "LockedSet(7D)Hidden",  6, LockedSet.LockedSet7Hidden ) );//complementary to 2D

            var Fish = new FishGen(this);
            _SolverLst_000.Add( new UAlgMethod( 30, "XWing",             4, Fish.XWing ) );
            _SolverLst_000.Add( new UAlgMethod( 31, "SwordFish",         5, Fish.SwordFish ) );
            _SolverLst_000.Add( new UAlgMethod( 32, "JellyFish",         5, Fish.JellyFish ) );
            _SolverLst_000.Add( new UAlgMethod( 33, "Squirmbag",         6, Fish.Squirmbag ) );//complementary to 4D  
            _SolverLst_000.Add( new UAlgMethod( 34, "Whale",             6, Fish.Whale ) );    //complementary to 3D 
            _SolverLst_000.Add( new UAlgMethod( 35, "Leviathan",         6, Fish.Leviathan ) );//complementary to 2D 

            _SolverLst_000.Add( new UAlgMethod( 40, "Finned_XWing",       5, Fish.FinnedXWing ) );
            _SolverLst_000.Add( new UAlgMethod( 41, "Finned_SwordFish",   6, Fish.FinnedSwordFish ) );
            _SolverLst_000.Add( new UAlgMethod( 42, "Finned_JellyFish",   6, Fish.FinnedJellyFish ) );
            _SolverLst_000.Add( new UAlgMethod( 43, "Finned_Squirmbag",   7, Fish.FinnedSquirmbag ) );//not complementary with fin
            _SolverLst_000.Add( new UAlgMethod( 44, "Finned_whale",       7, Fish.FinnedWhale ) );    //not complementary with fin
            _SolverLst_000.Add( new UAlgMethod( 45, "Finned_Leviathan",   7, Fish.FinnedLeviathan ) );//not complementary with fin

            _SolverLst_000.Add( new UAlgMethod( 46, "Franken/Mutant_Fish",        8, Fish.FrankenMutantFish ) );
            _SolverLst_000.Add( new UAlgMethod( 47, "Finned Franken/Mutant_Fish", 8, Fish.FinnedFrankenMutantFish ) );

            _SolverLst_000.Add( new UAlgMethod( 200, "EndoFinned_F/M_Fish",       9, Fish.EndoFinnedFMFish ) );
            _SolverLst_000.Add( new UAlgMethod( 200, "Finned_EndoFinned_F/M_Fish",9, Fish.FinnedEndoFinnedFMFish ) );

            _SolverLst_000.Add( new UAlgMethod( 201, "CannibalisticF/M_Fish",        9, Fish.CannibalisticFMFish ) );
            _SolverLst_000.Add( new UAlgMethod( 201, "Finned_Cannibalistic_F/M_Fish",9, Fish.FinnedCannibalisticFMFish ) );

            var nxgCellLink = new NXGCellLinkGen(this);
            _SolverLst_000.Add( new UAlgMethod( 50, "Skyscraper",       4, nxgCellLink.Skyscraper ) );
		 // _SolverLst_000.Add( new UAlgMethod( 51, "EmptyRectangle",   5, nxgCellLink.EmptyRectangle ) );
            _SolverLst_000.Add( new UAlgMethod( 51, "EmptyRectangleEx", 4, nxgCellLink.EmptyRectangleEx ) );	//New algorithm using bit representation

            _SolverLst_000.Add( new UAlgMethod( 52, "XY_Wing",          4, nxgCellLink.XYwing ) );
            _SolverLst_000.Add( new UAlgMethod( 53, "W_Wing",           4, nxgCellLink.Wwing ) );
												 
            _SolverLst_000.Add( new UAlgMethod( 55, "RemotePair",       4, nxgCellLink.RemotePair ) );    
            _SolverLst_000.Add( new UAlgMethod( 56, "XChain",           5, nxgCellLink.XChain ) );
            _SolverLst_000.Add( new UAlgMethod( 57, "XYChain",          5, nxgCellLink.XYChain ) ); 
        										 
            _SolverLst_000.Add( new UAlgMethod( 70, "Color_Trap",       4, nxgCellLink.Color_Trap ) );
            _SolverLst_000.Add( new UAlgMethod( 71, "Color_Wrap",       4, nxgCellLink.Color_Wrap ) );
            _SolverLst_000.Add( new UAlgMethod( 72, "MultiColor_Type1", 5, nxgCellLink.MultiColor_Type1 ) );
            _SolverLst_000.Add( new UAlgMethod( 73, "MultiColor_Type2", 5, nxgCellLink.MultiColor_Type2 ) );
        
            var AnLSTechP = new AnLSTechGen(this);
            _SolverLst_000.Add( new UAlgMethod( 80,  "SueDeCoq",             6, AnLSTechP.SueDeCoq ) );		  // original code
			_SolverLst_000.Add( new UAlgMethod( 81,  "SueDeCoqEx1",          5, AnLSTechP.SueDeCoqEx1 ) );		  //   > ver.5
			_SolverLst_000.Add( new UAlgMethod( 82,  "SueDeCoqEx2",          6, AnLSTechP.SueDeCoqEx2 ) );
			_SolverLst_000.Add( new UAlgMethod( 83,  "Franken_SDCEx3",       7, AnLSTechP.Franken_SDCEx3 ) );
			_SolverLst_000.Add( new UAlgMethod( 84,  "Finned_SueDeCoqEx1",   5, AnLSTechP.Finned_SueDeCoqEx1 ) );
		 	_SolverLst_000.Add( new UAlgMethod( 85,  "Finned_SueDeCoqEx2",   6, AnLSTechP.Finned_SueDeCoqEx2 ) );
		 	_SolverLst_000.Add( new UAlgMethod( 86,  "Finned_Franken_SDCEx3",7, AnLSTechP.Finned_Franken_SDCEx3 ) );
/*
            var SimpleXYZ = new SimpleUVWXYZwingGen(this);                      //            > Replaced with ALS version(XYZ_WingALS)
            _SolverLst_000.Add( new UAlgMethod( 90, 8, "XYZ_Wing",         5, SimpleXYZ.XYZwing ) );	// not recommended. Updated to XYZwingALS
            _SolverLst_000.Add( new UAlgMethod( 91, 8, "WXYZ_Wing",        5, SimpleXYZ.WXYZwing ) );	// not recommended. Updated to XYZwingALS
            _SolverLst_000.Add( new UAlgMethod( 92, 8, "VWXYZ_Wing",       6, SimpleXYZ.VWXYZwing ) );	// not recommended. Updated to XYZwingALS
            _SolverLst_000.Add( new UAlgMethod( 93, 8, "UVWXYZ_Wing",      6, SimpleXYZ.UVWXYZwing ) );	// not recommended. Updated to XYZwingALS
*/
            var ALSTech = new ALSTechGen(this);									// ALS version
            _SolverLst_000.Add( new UAlgMethod( 101, "XYZ_WingALS",         5, ALSTech.XYZwingALS ) );	// recommended
            _SolverLst_000.Add( new UAlgMethod( 102, "ALS_XZ",              6, ALSTech.ALS_XZ ) );
            _SolverLst_000.Add( new UAlgMethod( 103, "ALS_XY Wing",         7, ALSTech.ALS_XY_Wing ) );

		    _SolverLst_000.Add( new UAlgMethod( 105, "eALS_ChainA-U",         8, ALSTech.eALS_Chain_uniqueStemB ) );
		    _SolverLst_000.Add( new UAlgMethod( 105, "eALS_ChainA_UO",        8, ALSTech.eALS_Chain_uniqueStemB_Overlap ) );
		 // _SolverLst_000.Add( new UAlgMethod( 105, "eALS_ChainA_O",         8, ALSTech.eALS_Chain_Overlap ) );     
			_SolverLst_000.Add( new UAlgMethod( 105, "eALS_ChainA_Unlimited", 8, ALSTech.eALS_Chain_Unlimited ) );

            _SolverLst_000.Add( new UAlgMethod( 106, "ALS_DeathBlossom",    7, ALSTech.ALS_DeathBlossom ) );     
            _SolverLst_000.Add( new UAlgMethod( 107, "ALS_DeathBlossomEx",  8, ALSTech.ALS_DeathBlossomEx ) );   

			var AHSTech = new AHSTechGen(this);
			_SolverLst_000.Add( new UAlgMethod( 102, "AHS_XZ",				6, AHSTech.AHS_XZ ) );				// AHS_XZ double ver. 6.0 -

            var eNetworkTech = new eNetwork_App(this);      
            _SolverLst_000.Add( new UAlgMethod( 110,  "eNetwork_NiceLoop",   11, eNetworkTech.eNetwork_NiceLoop)); 
            _SolverLst_000.Add( new UAlgMethod( 111,  "eNetwork_NiceLoopEx", 11, eNetworkTech.eNetwork_NiceLoopEx)); 

            _SolverLst_000.Add( new UAlgMethod( 108,  "eNW_DeathBlossom",    11, eNetworkTech.eNW_DeathBlossom));
            _SolverLst_000.Add( new UAlgMethod( 120,  "eNetwork_FC_Cells",   11, eNetworkTech.eNetwork_FC_Cells));
            _SolverLst_000.Add( new UAlgMethod( 121,  "eNetwork_FC_House",   11, eNetworkTech.eNetwork_FC_House));
          //_SolverLst_000.Add( new UAlgMethod( 122,  "eNetwork_FC_Contradiction", 10, eNetworkTech.eNetwork_FC_Contradiction));

            _SolverLst_000.Add( new UAlgMethod( 130,  "eALS_Wing_2D",        11, eNetworkTech.eALS_Wing_2D ) );
            _SolverLst_000.Add( new UAlgMethod( 131,  "eALS_Wing_3D",        11, eNetworkTech.eALS_Wing_3D ) );        
            _SolverLst_000.Add( new UAlgMethod( 132,  "eALS_Wing_4D",        11, eNetworkTech.eALS_Wing_4D ) );
        
            _SolverLst_000.Add( new UAlgMethod( 206,  "eKrakenFish",         11, eNetworkTech.eKrakenFish)); 
            _SolverLst_000.Add( new UAlgMethod( 206,  "Finned_eKrakenFish",  11, eNetworkTech.Finned_eKrakenFish)); 


			var SubsetTechP = new SubsetTechGen(this);  // under development (GNPXv5.1)
			_SolverLst_000.Add( new UAlgMethod( 140, "SubsetExclusion",     6, SubsetTechP.SubsetExclusion ) );
			_SolverLst_000.Add( new UAlgMethod( 141, "SubsetExclusionALS",  7, SubsetTechP.SubsetExclusion_ALS ) );

			var Firework_TechP = new Firework_TechGen(this);  // under development (GNPXv5.1)
			_SolverLst_000.Add( new UAlgMethod( 150, "Firework_Triple",     7, Firework_TechP.Firework_Triple ) );
			_SolverLst_000.Add( new UAlgMethod( 151, "Firework_Quadruple",  7, Firework_TechP.Firework_Quadruple ) );
			_SolverLst_000.Add( new UAlgMethod( 152, "Firework_WWing",      7, Firework_TechP.Firework_WWing ) );
			_SolverLst_000.Add( new UAlgMethod( 153, "Firework_LWing",      7, Firework_TechP.Firework_LWing ) );
			_SolverLst_000.Add( new UAlgMethod( 154, "Firework_ALP",        7, Firework_TechP.Firework_ALP ) );
			_SolverLst_000.Add( new UAlgMethod( 155, "Firework_DualALP",    7, Firework_TechP.Firework_DualALP ) );


			// Exocet ... under development
			var Exocet_TechGen = new Exocet_TechGen(this);
			_SolverLst_000.Add( new UAlgMethod( 161, "Exocet_JE2",		    9, Exocet_TechGen.Exocet_JE2) );
		//	_SolverLst_000.Add( new UAlgMethod( 161, "Exocet_JE2P",		    9, Exocet_TechGen.Exocet_JE2P) ); // JE2+, JE2++ // The logic behind JE2+ is still unclear.
			_SolverLst_000.Add( new UAlgMethod( 162, "Exocet_JE1",		    9, Exocet_TechGen.Exocet_JE1) );	

			_SolverLst_000.Add( new UAlgMethod( 163, "Exocet",			    9, Exocet_TechGen.Exocet, developB:true) );		// Basic form of Senior Exocet
			_SolverLst_000.Add( new UAlgMethod( 164, "Exocet_Single",       9, Exocet_TechGen.Exocet_Single, developB:true) );
			_SolverLst_000.Add( new UAlgMethod( 160, "Exocet_SingleBase",   9, Exocet_TechGen.Exocet_SingleBase, developB:true) );


			_SolverLst_000.Add( new UAlgMethod( 165, "Exocet_FM",    	    9, Exocet_TechGen.Exocet_FM, developB:true) );	// ver. 6.1+	
		//	_SolverLst_000.Add( new UAlgMethod( 164, "Senior_Exocet_Complex", 9, Exocet_TechGen.Exocet_Complex) );	// ver. 6.1+	


			G7.g7_Develop_Exocet_difficulty = Max( _SolverLst_000.Min(p=>p.difficultyLevel), 8);

		_SolverLst_000.Sort( (a,b)=> (a.ID-b.ID) );

			pGNPX_App.SolverList_SysDef = _SolverLst_000;				
			//_SolverLst_000.ForEach( p=> WriteLine( p ) );
        }

//==========================================================
        private (int,string)  stageNo_MethodName=(-1,""); 
        private int methodCC = 0;
		public int  solutionC;

		public void stageNo_MethodName_Reset() => stageNo_MethodName=(-1,"");


		public bool IsContinueAnalysis( ){

			if( ePZL.BOARD.All(U=>U.FixedNo==0 && U.CancelB==0) ){
				WriteLine( $"\n\nGNPX Algorithm Logic Error :\n{Environment.StackTrace}\n" );
				throw new Exception( $"GNPX Algorithm Logic Error :\n{Environment.StackTrace}" ); // GNPX Algorithm Logic Error
			}


		    {//Analyzer Bug : Code style does not meet specifications
				if( ePZL is null )  return false;
				if( ePZL.Sol_ResultLong is null || ePZL.Sol_Result is null )  return false;   // ... interrupt
				if( ePZL.Sol_Result.Length < 5 ){ WriteLine( "... GNPX algorithm logic error\n{Environment.StackTrace}" ); return true; }
			}

			bool errorB = pGNPX_Eng.IsSolutionValid();	// @1022
			if( !errorB )  GNPX_Engin.AnalyzingMethod.ErrorB = true;
			if( !errorB && __SimpleAnalyzerB__ )  return false;

			GNPX_Engin.AnalyzingMethod.SuccessfulB = true;
			bool IsValid = SnapSaveGP(errorB);
			return IsValid;
		}

		public UPuzzle FirstpPZL(){
			//var pChild_PZLs = ePZL.Child_PZLs;
			if( ePZL.Child_PZLs==null || ePZL.Child_PZLs.Count==0 )  return null;
			return ePZL.Child_PZLs[0];
		}
/*
		public void Clear_Analysis_results(){
			foreach( var UC in pBOARD.Where(p=>p.No==0) ) UC.CancelB=0;
			pBOARD.ForEach( UC => UC.ECrLst=null );
		}
*/
        public bool SnapSaveGP( bool errorB, bool OmiteDuplicateSolutionB=true ){
            try{ 
                //var pChild_PZLs = ePZL.Child_PZLs;
                 ePZL.selectedIX = 0;
				 ePZL.pMethod = GNPX_Engin.AnalyzingMethod;	// pGNPX_Eng.


				// =====================================================================================================
				// Processing by solution type
				// <<< Single >>>
					if( GNPX_Engin.MltAnsSearch is false ){ //... Single Search
						ePZL.Child_PZLs.Add(ePZL); //In one-solution search, save the same Puzzle-object without copying
						G6.command_Analysis_Stop = true;
						//Clear_Analysis_results();
						return false;	//true;
					}


				// <<< Multiple >>>
					string __SolResultKey = $"{stageNoP}_{ePZL.Sol_ResultLong.Replace("\r"," ").Replace("\n"," ")}";
					var EAMethod = GNPX_Engin.AnalyzingMethod;				
					// Excluding the same solution
					if( OmiteDuplicateSolutionB && ePZL.Child_PZLs.Any(Q=>(Q.__SolResultKey==__SolResultKey)) ){					
						ePZL.ToPreStage( );
						// WriteLine( $"*** Redundant Solution Found in SnapSaveGP...  not unique solution : {__SolResultKey}" );
					} 
				
					
					// Save the copy of the solution
					else{		
						UPuzzle aPZLcopy = ePZL.Copy( stageNo_Increments:0, IDm:ePZL.Child_PZLs.Count ); //Copy at the same stage
						aPZLcopy.difficultyLevel = EAMethod.difficultyLevel;
						aPZLcopy.__SolResultKey = __SolResultKey; 
						aPZLcopy.selectedIX = ePZL.Child_PZLs.Count;
						ePZL.Child_PZLs.Add(aPZLcopy);    // Save a copy.
						solutionC++;
						ePZL.ToPreStage( );           // Return the original to the state before analysis.
					}
				// =====================================================================================================



				{ // <<< Termination by number of solutions >>>
					if( ePZL.Child_PZLs.Count>=G6.MSlvr_MaxNoAllAlgorithm ){	// Reached the limit of multiple solutions searches.
						G6.stopped_StatusMessage = pRes.msgUpperLimitBreak; // Reached the limit of multiple solution searches.
						G6.command_Analysis_Stop = true;
						//Clear_Analysis_results();
						return false;   // ... Finish analysis
					}  

					// <<< Method-specific counter initialization >>>
					var Stage_Method = ( stageNo, EAMethod.MethodName ); // tuple:(stage,name)
					if( stageNo_MethodName!=Stage_Method || stageNoP!=stageNoPMemo ){
						stageNo_MethodName = Stage_Method;
						stageNoPMemo = stageNoP;
						methodCC = 0;       // Initialization of number of solutions per algorithm
					}
					int selExt = (G6.PG6Mode=="Func_SelectPuzzle" && EAMethod.Sel_mark)? 50: 1;
					bool ContinueAnalysisB = (++methodCC < (G6.MSlvr_MaxNoAlgorithm*selExt) );
					//Clear_Analysis_results();
					return ContinueAnalysisB;  
				}



            }
            catch(Exception e){ WriteLine( $"{e.Message}\r{e.StackTrace}"); }
			//Clear_Analysis_results();
            return false;   // ... interrupt
        }


        public bool Check_TimeLimit(){
			if( G6.PG6Mode.Contains("Func_Develop") )  return false;	// No time limit during development

            if( GNPX_Engin.MltAnsSearch is false )  return false;
            TimeSpan ts =  DateTime.Now - GNPX_App_Man .MultiSolve_StartTime;
            bool timeLimit = ts.TotalSeconds >= G6.MSlvr_MaxTime;
            if(timeLimit)  G6.stopped_StatusMessage = pRes.msgUpperLimitTimeBreak;
            return timeLimit;
        }


        //==========================================================
        public (bool,int,int,int) Aggregate_CellsPZM( List<UCell> aBOARD ){
            int P=0, Z=0, M=0;
            if( aBOARD==null )  return (false,P,Z,M);
            aBOARD.ForEach( q =>{
                if(q.No>0)      P++;
                else if(q.No<0) M++;
                else            Z++;
            } );

            return  (Z==0,P,Z,M);
        }



        public (int,int[]) Execute_Fix_Eliminate( List<UCell> aBOARD ){//Confirmation process
            // return code = 0 : Complete. Go to the next stage.
            //               1 : Solved. 
            //              -1 : Error. Conditions are broken.

            if( aBOARD.All(p=> p.No!=0) )  return (1,null);     //1: Solved. 

            if( aBOARD.Any(p=>p.CancelB>0) ){                         // ..... CancelB .....
                foreach( var P in aBOARD.Where(p=>p.CancelB>0) ){
					P.Reset_FreeB( P.CancelB ); 
					P.CancelB=0;       
                    P.CellBgCr=_Black_;
                }
            }





            if( aBOARD.Any(p=>p.FixedNo>0) ){                         // ..... FixedNo .....
                foreach( var P in aBOARD.Where(p=>p.FixedNo>0) ){
                    int No = P.FixedNo;
                    if( No<1 || No>9 ) continue;
                    P.No=-No; P.FixedNo=0;
					P.Set_FreeB( 0 );	// P.FreeB=0;
                    P.CellBgCr = _Black_;
                }
            }

            {   // ..... Check Error .....
                Update_CellsState( aBOARD, false );
                foreach( var P in aBOARD.Where(p=>(p.No==0 && p.FreeBC==0)) )  P.ErrorState=9; // ..... Error .....

                int[] NChk=new int[27];
                for(int h=0; h<27; h++ ) NChk[h]=0;
                foreach( var P in aBOARD ){
                    int no = (P.No<0)? -P.No: P.No;
                    int B = (no>0)? (1<<(no-1)): P.FreeB;
                    NChk[P.r]|=B; NChk[P.c+9]|=B; NChk[P.b+18]|=B;
                }
                for(int h=0; h<27; h++ ){
                    if(NChk[h]!=0x1FF){ SolCode=-9119; return (-1,NChk); }  // -1: Error. Conditions are broken.
                }
            }
            SolCode=-1;
            return (0,null);    // 0: Complete. Go to next stage.
        }

        public void SetBG_OnError(int h){
            foreach(var P in pBOARD.IEGetCellInHouse(h)) P.Set_CellBKGColor(Colors.Violet);
        }

        public void Update_CellsState( List<UCell> aBOARD, bool setAllCandidates=true ){
			//Set all candidates : Clear all analysis results.
			List<int> To_ListInt(List<UCell> aBOARD) => aBOARD.ConvertAll(P=>P.No);

			UInt128 B81Free = aBOARD.Create_Free_BitExp81();
			UInt128 B81Fixed = B81Free ^ b081_all;

				//Utility_Display.__DBUG_Print2( To_ListInt(aBOARD), sqF:true,"Update_CellsState");

            _Not_Puzzle_ = false;
			foreach( var P in B81Free.IEGet_UCell(aBOARD) ){
				P.Reset_StepInfo();

				{//There are candidates remaining. No two digits will be the same.
					UInt128 Q = pConnectedCells81[P.rc] & B81Fixed;
					int freeB9 = Q.IEGet_rc().Aggregate(0, (p,q)=> p|1<<(Abs(aBOARD[q].No)) );
					freeB9 = (freeB9>>=1) ^ 0x1FF; 
					if( !setAllCandidates ) freeB9 &= P.FreeB; 
					if( freeB9==0 ){ _Not_Puzzle_=true; P.ErrorState=1; }//No solution

					P.Set_FreeB( freeB9 );
				}
			}
        }

        public bool Verify_Puzzle_Roule( ){
            bool    ret=true;
            if( _Not_Puzzle_ ){ SolCode=9; return false; }  // Anomaly has already been detected

			UInt128 B81Free = pBOARD.Create_Free_BitExp81();
			UInt128 B81Fixed = B81Free ^ b081_all;

            for(int h=0; h<27; h++){
                int usedB=0, errB=0;
				foreach( var P in (B81Fixed&pHouseCells81[h]).IEGet_UCell(pBOARD) ){
                    int no = Abs(P.No);
                    if(( usedB&(1<<no)) !=0 )   errB |= (1<<no); // have the same digit.
                    usedB |= (1<<no);
				}

                if(errB!=0){
                    foreach( var P in (B81Fixed&pHouseCells81[h]).IEGet_UCell(pBOARD) ){
                        int no = Abs(P.No);
                        if( (errB&(1<<no)) !=0 ){ P.ErrorState=8; ret=false; }  //mark cells with the same digit
                    }
                }
            }
/*
           for(int h=0; h<27; h++){
                int usedB=0, errB=0;
                foreach(var P in pBOARD.IEGetCellInHouse(h).Where(Q=> Q.No!=0)){
                    int no = Abs(P.No);
                    if(( usedB&(1<<no)) !=0 )   errB |= (1<<no); // have the same digit.
                    usedB |= (1<<no);
                }

                if(errB!=0){
                    foreach(var P in pBOARD.IEGetCellInHouse(h).Where(Q=> Q.No!=0)){
                        int no = Abs(P.No);
                        if( (errB&(1<<no)) !=0 ){ P.ErrorState=8; ret=false; }  //mark cells with the same digit
                    }
                }
            }
*/
			//if( ret ){ ePZL.Sol_Result = "..."; ePZL.Sol_ResultLong = "@@@"; }
            return ret;
        }

        public void ResetAnalysisResult( bool clear0 ){
            if(clear0){   // true:Initial State
              //foreach(var P in pBOARD.Where(Q=>Q.No<=0)){ P.Reset_StepInfo(); P.FreeB=0x1FF; P.No=0; }
			    foreach(var P in pBOARD.Where(Q=>Q.No<=0)){ P.Reset_StepInfo(); P.Set_FreeB(0x1FF); P.No=0; }
            }
            else{
              //foreach(var P in pBOARD.Where(Q=>Q.No==0)){ P.Reset_StepInfo(); P.FreeB=0x1FF; }
				foreach(var P in pBOARD.Where(Q=>Q.No==0)){ P.Reset_StepInfo(); P.Set_FreeB(0x1FF); }
            }
            Update_CellsState( aBOARD:pBOARD );
			ePZL.extResult = "";
        }
    }
}