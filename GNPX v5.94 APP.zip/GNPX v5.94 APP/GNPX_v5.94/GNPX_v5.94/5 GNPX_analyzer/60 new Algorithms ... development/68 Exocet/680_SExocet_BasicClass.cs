using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Documents;
using static GNPX_space.Exocet_TechGen_68;
using static GNPX_space.Firework_TechGen;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;
//using static GNPX_space.JExocet_TechGen_68;

namespace GNPX_space{
		using G6_SF = G6_staticFunctions;
    public partial class Exocet_TechGen_68: AnalyzerBaseV2{
		static char[] sep=new Char[]{ ' ', ',', '\t' };  

	// ===================================================
	// For future expansion, this is over-implemented.
	// ===================================================

	// ::: Code to support the Object extension of Target.
	// ::: If Target is a Cell, there is simpler code.
	

		public partial class  UExocet{
			static public List<UCell>   qBOARD;	
			static private UInt128[] HC81 => House_81;
			
			public string		 ExocetControl = null;

			public string		 ExoMtdName;
			public string		 ExocetNamePlus;

			public string		 ExoType => Inquiry("type").Replace("type:","");
			public bool			 Extend_Type => (ExoType=="Complex" /* | ...  */ );

			public int			 dir;			// 0:row, 1:column
			public int			 rcStem;
			public readonly int	 FreeB;
			public int			 FreeB_valid;

			public (int,int,int) h012;

			public UInt128		 Base81;
			public UInt128		 Connected_with_Base;	// Aggregate_ConnectedOr
			public UInt128		 Band81;
			public UInt128		 EscapeCells = qZero;
			public UInt128       Companion_base;
			public UInt128		 Companion = _na_;
			public UInt128		 CompanionExt;
			public List<UInt128> SLineList = new List<UInt128>();
			public UInt128       BOARD_Fixed_BaseDigits;
			public UInt128		 SLine_Expand => (SLineList.Count()>3)? SLineList[3]: qZero;
			public int			 h_expand = -1;

			public UCrossLine68	 ExG0;	
			public UCrossLine68	 ExG1;
			public UCrossLine68	 ExG2;


			public UCoverStatus[]  CoverStatusList;
			public int[]		   CL_bySize_noB;
////			public (int,int)[]	   CrossCoverLineB;

			public int hashValue_stBaseObject12 => $"{stBase} {ExG1.stObject} {ExG2.stObject}" .GetHashCode(); // Hash value of the string {Base,Object1,Object2}

			public UExocet( string ExoMtdName, int dir, int rcStem, UInt128 Base81, int freeB0, UInt128 BOARD_Free81 ){
				this.ExocetControl  = ExoMtdName;
				__Set_SEName();

				this.dir			= dir;
				this.rcStem			= rcStem;
				this.Base81			= Base81;
				this.Band81			= _Band81();
				this.FreeB			= Base81.IEGet_UCell(qBOARD).Aggregate(0, (a,uc) => a| uc.FreeB );

				this.Connected_with_Base = Base81.Aggregate_ConnectedOr();	
				this.EscapeCells	= ((HC81[rcStem/9]|HC81[rcStem%9+9]) & Band81) .DifSet(Base81);
			}

			public override string ToString( ){
				string st = $" UExocet dir:{dir} rcStem:{rcStem.ToRCString(),2} FreeB:{FreeB.TBS()}";
				st += "stCLxBase() + stExGx();";
				return st;
			}
		}
					public partial class  UExocet{		
						
					//    public int		FreeB0;	  //=> Base81.IEGet_UCell(qBOARD).Aggregate(0, (a,uc) => a| uc.FreeB_Updated() );

						public UInt128  CrossLine_012 => HC81[h012.Item1] | HC81[h012.Item2] | HC81[h012.Item3];

						public UInt128	SLine012e	=> SLineList.Aggregate(qZero, (a,U) => a|U);

						public int[]    CL_bySize_Count => CL_bySize_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();

						public string   stBase		 => $"{Base81.TBScmp()}";
						public string   stCoverLines => CoverStatusList.Where(p=>p!=null).Aggregate(" ",(a,ch)=> a+$"\n {ch.ToString()}");

						public string   stSline012 	 => $"{ExG0.SLine.TBScmp()} {ExG1.SLine.TBScmp()} {ExG2.SLine.TBScmp()}"; 
						//public string   stCrossCoverLineB => "CrossCoverLineB  one:" + CrossCoverLineB.Aggregate("", (a,b) => a+ " "+	b.Item1.TBS() ) +
						//								   "\n                  two:" + CrossCoverLineB.Aggregate("", (a,b) => a+ " "+	b.Item2.TBS() );		
						public int		WildCardB	 => CL_bySize_noB[3] ;
					

						// <<< ExocetControl --> ExoMtdName, ExocetNamePlus >>>
						private string Inquiry( string que ){					
							List<string> eLst = ExocetControl.Split(sep,StringSplitOptions.RemoveEmptyEntries).ToList();
							string?  q = eLst.FindLast(p=>p.Contains(que));	
							return (q==null)? "": q;
						}

						private void __Set_SEName(){
							ExoMtdName = Inquiry("name").Replace("name:","");

							string SE_type  = Inquiry("type").Replace("type:","");
							if( SE_type != "" ) SE_type = "_"+SE_type;
							ExocetNamePlus = ExoMtdName + SE_type;
						}

						private UInt128  _Band81( ){
							int blk = rcStem.B(), sft=(dir==0)? 1: 3;
							int blk0 = 18 + ((dir==0)? blk/3*3: blk%3);
							UInt128 Band81 = HC81[blk0] | HC81[blk0+sft] | HC81[blk0+sft*2];
							return  Band81;
						}

						public UInt128 Object81 => ((ExG1!=null)? ExG1.Object81:qZero) | ((ExG2!=null)? ExG2.Object81:qZero);

						public string st_SLine_House(){
							List<int> HSL = (new []{ExG0.hno, ExG1.hno, ExG2.hno}).ToList();
							string st = HSL.Aggregate("", (a,h) =>a+(","+h.HouseToString() )) .Substring(1);
							if( h_expand>=0)  st += $" /Ext. {h_expand.HouseToString()}";
#if DEBUG
							st += $" ({string.Join(",",HSL)}";
							if(h_expand>=0) st+=$"/{h_expand}";
							st += ")";
#endif
							return st;
						}

						public string   stCompanions => Companion.TBScmp();
						public string stExGx(){
							string st =  (ExG0==null)?  "  ExG0:n/a": $"\n  ExG0:{ExG0}";
								   st += (ExG1==null)?  "  ExG1:n/a": $"\n  ExG1:{ExG1}";
								   st += (ExG2==null)?  "  ExG2:n/a": $"\n  ExG2:{ExG2}";
							return st;
						}
					}


		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

		public partial class UCrossLine68{
			static public List<UCell>	qBOARD;

			public UExocet SExo;
			public int		sq;
			public int		hno;
			public int		rcTag	   = int.MaxValue;
			public bool		wildcardB  = false;
			public UInt128  Object81   = _na_;
			public UInt128  CrossLine  = _na_;
			public UInt128  SLine      => SExo.SLineList[sq];

			public UCrossLine68(){
				this.sq = -9999;
			}

			public UCrossLine68( UExocet SExo, int sq, int hno, UInt128 CrossLine ){
				this.SExo		= SExo;
				this.sq			= sq;
				this.hno		= hno;
				this.CrossLine  = CrossLine;
			}

			public UCrossLine68( UExocet SExo, int sq, int hno, UInt128 CrossLine, UInt128 Object ):
								this( SExo, sq, hno, CrossLine ){
				if( Object.BitCount()==1 )  this.rcTag = Object.FindFirst_rc();
				this.Object81	 = Object & qMaxB81;

				this.wildcardB = this.Object81.IEGet_UCell(qBOARD).All(u=> u.No!=0);
			}
		}

				public partial class UCrossLine68{

					public int      FreeB_Object81  => Object81.IEGet_UCell(qBOARD) .Aggregate( 0, (a,uc)=> a| (uc.FreeB&~uc.CancelB) ); 
					public int		FreeB_SLine81   => SLine.IEGet_UCell(qBOARD) .Aggregate( 0, (a,uc)=> a| (uc.FreeB&~uc.CancelB) );
						
					public string   stObject		=> Object81.TBScmp();

					public UInt128 Get_FullSight( bool withExclusion ){
						if( withExclusion ){ return Object81.IEGet_rc().Aggregate( qMaxB81, (a,rc) => a & Connected_81[rc].Reset(rc) ); }
						else{				 return Object81.IEGet_rc().Aggregate( qMaxB81, (a,rc) => a & Connected_81[rc] ); }
					}

				}



//#if false
		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
		public class UCoverStatus{
			static public UInt128[]  pBOARD_Fixed81B9;
			static public UInt128[]  pBOARD_Free81B9;

			public int	 no;
			public int   sz;
			public int	 CLH_0 = -1;	// house no. if h>100, then Cross-Line.
			public int	 CLH_1 = -1;
			public int	 CLH_2 = -1;
			private List<int>  CLH_List;

			public UCoverStatus( int no, int sz, int CLH_0, int CLH_1, int CLH_2 ){
				this.no = no;
				this.sz = sz;
				this.CLH_0=CLH_0; this.CLH_1=CLH_1;	this.CLH_2=CLH_2;

				CLH_List = new();
				if( CLH_0 >= 0 )  CLH_List.Add(CLH_0);
				if( CLH_1 >= 0 )  CLH_List.Add(CLH_1);
				if( CLH_2 >= 0 )  CLH_List.Add(CLH_2);
			}


			public override string ToString( ){
				string st = $" no:#{no+1} size:{sz}";
				       st += $"  CoverLine: {_ToStHouse(CLH_0)} {_ToStHouse(CLH_1)} {_ToStHouse(CLH_2)}";
				return st;
			
					string _ToStHouse(int hh){
						string st="";
						if( hh<0 )  st = "----";
						else{
							int h = hh%100;			
							st = ((h<9)? "r": (h<18)? "c": "b") + ((h%9)+1).ToString()
							   + ((hh<100)? "_p": (h<18)? "_x": "_*");
						}
						return st.PadRight(5);
					}
			}
		}
//#endif

#if false
		public class Develop_ErrorPattern{
			public string Situation;
			public List<int> PZLList = new();

			public Develop_ErrorPattern( string s){
				Situation = s;
			}

			public override string ToString( ){
				string st = $"* {Situation}\n   ";
				st += string.Join(", ", PZLList );
				return st;
			}
		}
#endif

	} 


}