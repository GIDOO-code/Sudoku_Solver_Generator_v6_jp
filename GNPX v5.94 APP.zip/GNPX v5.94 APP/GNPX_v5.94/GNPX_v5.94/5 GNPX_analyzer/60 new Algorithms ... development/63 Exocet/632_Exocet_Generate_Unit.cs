using GIDOO_space;
using GNPX_space;
using System;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);


    public partial class Exocet_TechGen: AnalyzerBaseV2{
		public  UInt128 Board81_Free_with_FreeB;
		private UInt128	Board81_Fixed_with_FreeB;
		private UInt128	Board81_Fixed_with_nonFreeB;
		private UInt128 Board81_FreeFix_noB;

		private IEnumerable<UExocet>  IE_Exocet_Generate_Unit( string ExoMtdName, bool debugPrint=false ){

			// ::: #1 Basic Form :::::::::::::::::::::::::::::::::::::
			foreach( UExocet Exo in IE_Exocet_BasicForm( ExoMtdName:ExoMtdName, debugPrint:false) ){	
				_BaseObj_ = Exo.Base81;
							if( Exo.dir!=1 || Exo.rcStem!=67 )  continue;	// ===== Exocet Debug =====

					{// BOARD Digits distribution ... Exocet constants used in analysis
						Board81_Fixed_with_FreeB    = BOARD_FixedB9_noB(Exo.FreeB);
						Board81_Fixed_with_nonFreeB = BOARD_Fixed81 & ~Board81_Fixed_with_FreeB;
						Board81_Free_with_FreeB     = BOARD_FreeB9_noB( Exo.FreeB );
						Board81_FreeFix_noB			= Exo.FreeB.IEGet_BtoNo().Aggregate(qZero, (a,no) => a| BOARD_Fixed81B9[no] | BOARD_Free81B9[no] );
								if(debugPrint) G6_SF.__MatrixPrint( Flag:Exo.Base81, Board81_Fixed_with_FreeB, Board81_Fixed_with_nonFreeB, Board81_FreeFix_noB,
										"Board81_Fixed_with_FreeB, Board81_Fixed_with_nonFreeB, Board81_FreeFix_noB" );
					}

				// ::: #2 CrossLine(House)  :::::::::::::::::::::::::::::::::::::
				foreach( (int,int,int)  h012 in IE_Exocet_CrossLine( Exo, debugPrint:debugPrint) ){
							//if( h012 != (05,07,18) )  continue; // ===== Exocet Debug =====
							if( h012 != (07,02,21) )  continue; // ===== Exocet Debug =====


					// ::: #3 Objects :::::::::::::::::::::::::::::::::::::
					foreach( var (ExG0,ExG1,ExG2) in IE_Exocet_Object( Exo, debugPrint:false) ){
						Exo.ExG0=ExG0; Exo.ExG1=ExG1; Exo.ExG2=ExG2;
						_BaseObj_ = Exo.Base81 | (ExG1.Object81 | ExG2.Object81 );	//( for debug. ... G6_SF.__MatrixPrint(...) )
							if( ExG1.Object81 != (qOne<<21 | qOne<<21) )  continue; // ===== Exocet Debug =====
							if( ExG2.Object81 != (qOne<<37 | qOne<<37) )  continue; // ===== Exocet Debug =====

						// ::: #4 Companion, SLine :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
						if( Set_Companion_and_Test(Exo, debugPrint:false) is false )  continue;	//###1022

						Set_Mirror(Exo, debugPrint:false);	
						if( Set_SLine_and_Test( Exo, debugPrint:false) is false )  continue;

						yield return Exo;
					}
				}
			}		
			yield break;

					void Set_Mirror( UExocet Exo, bool debugPrint=false ){
						if( Exo.ExG0.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG1, Exo.ExG2 );
						if( Exo.ExG1.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG2, Exo.ExG0 );
						if( Exo.ExG2.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG0, Exo.ExG1 );

						void Set_Mirror_sub( UExocet Exo, UCrossLine ExGA, UCrossLine ExGB ){
							ExGA.Mirror81 = House_81[ExGB.ObjectBlockNo+18] & ~(Exo.Escape81 | Exo.CrossLine_012);
							if( ExGA.Object81.BitCount()==1 )  ExGA.Mirror81 &= ~House_81[(Exo.dir,ExGA.rcTarget).DirRCtoHouse()];

							ExGB.Mirror81 = House_81[ExGA.ObjectBlockNo+18] & ~(Exo.Escape81 | Exo.CrossLine_012);
							if( ExGB.Object81.BitCount()==1 )  ExGB.Mirror81 &= ~House_81[(Exo.dir,ExGB.rcTarget).DirRCtoHouse()];

								if(debugPrint){
									G6_SF.__MatrixPrint( Flag:_BaseObj_, ExGA.Object81, ExGA.Mirror81, "ExGA.Object81, ExGA.Mirror81" );
									G6_SF.__MatrixPrint( Flag:_BaseObj_, ExGB.Object81, ExGB.Mirror81, "ExGB.Object81, ExGB.Mirror81" );
								}
						}
					}
		}
	}
}