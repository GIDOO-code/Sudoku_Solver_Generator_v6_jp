using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Documents;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

using static GNPX_space.Firework_TechGen;
//using static GNPX_space.JExocet_TechGen_68;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;

    public partial class Exocet_TechGen: AnalyzerBaseV2{

	// ===================================================
	// For future expansion, this is over-implemented.
	// ===================================================
	

		public partial class  UExocet{
			static private string[] Exocet_Standard_List = new string[]{ 
					"Exocet_JE2", "Exocet_JE2P", "Exocet_JE1", "Exocet", "Exocet_Single", "Exocet_SingleBase", "Exocet_FM"};


			static public List<UCell>   qBOARD;	
			
			public string		 ExoMtdName = "...";
			public bool			 Exocet_Standard;

			public int			 dir;			// 0:row, 1:column
			public int			 rcStem;
			public readonly int	 FreeB;

			public UInt128		 Band81    => func_Band( dir, rcStem.B() );
			public UInt128		 Band81Cross => func_Band( 1-dir, rcStem.B() );

			public (int,int,int) h012;

			public UInt128		 Base81;
			public UInt128		 Escape81;

			public UInt128       Companion_base;
			public UInt128		 Companion_cells;
			public UInt128		 Companion;

			public List<UInt128> SLineList = new List<UInt128>();
						
			public int			 wildcard_noB  => CL_bySize_noB[3] ;

			public UCrossLine	 ExG0;	
			public UCrossLine	 ExG1;
			public UCrossLine	 ExG2;

			public int			 h_expand;	// for Exocet_FM
			public UInt128		 Object81_AB => ((ExG1!=null)? ExG1.Object81: qZero) | ((ExG2!=null)? ExG2.Object81: qZero);

			public UCoverStatus[]  CoverStatusList;
			public int[]		   CL_bySize_noB;
			
			// Hash value of the string {Base,Object1,Object2}
			public int		     hashValue_stBaseObject12 => $"{stBase} {ExG1.stObject} {ExG2.stObject} {h012}" .GetHashCode(); 


			public UExocet( string ExoMtdName, int dir, int rcStem, UInt128 Base81, int freeB0, UInt128 BOARD_Free81 ){
				this.ExoMtdName  = ExoMtdName;
				this.Exocet_Standard = Exocet_Standard_List.Any(p=>p==ExoMtdName);

				this.dir			= dir;
				this.rcStem			= rcStem;
				this.Base81			= Base81;

				this.FreeB			= Base81.IEGet_UCell(qBOARD).Aggregate(0, (a,uc) => a| uc.FreeB );
				this.Escape81		= Band81 & (qOne<<rcStem | Connected_81[rcStem]);
				
				return;
			}

			public override string ToString( ){
				string st = $" UExocet dir:{dir} rcStem:{rcStem.ToRCString(),2}  Base:{stBase}  FreeB:{FreeB.TBScmp()} Band:{Band81.TBScmp()}";
				//st += "stCLxBase() + stExGx();";
				return st;
			}
		}

					public partial class  UExocet{		
						private int     __func_Band_hb(int dir, int b0) => 7<< ((dir==0)? (b0/3*3): (b0%3)*3+9);
						private UInt128 func_Band(int dir, int b0) => __func_Band_hb(dir,b0).IEGet_BtoNo(18).Aggregate(qZero, (a,h)=> a | House_81[h] );

						public UInt128	SLine012e	=> SLineList.Aggregate(qZero, (a,U) => a|U);
						public string   stBase		=> $"{Base81.TBScmp()}";

						public string   stFreeB     => $"{FreeB.TBScmp()}";
						public string   stCoverLines => CoverStatusList.Where(p=>p!=null).Aggregate(" ",(a,ch)=> a+$"\n {ch.ToString()}");
						public string   stSline012 	 => $"{ExG0.SLine.TBScmp()} {ExG1.SLine.TBScmp()} {ExG2.SLine.TBScmp()}"; 
						public string   stCompanion_cells => Companion_cells.TBScmp();
						public UInt128  CrossLine_012 => House_81[h012.Item1] | House_81[h012.Item2] | House_81[h012.Item3];


						public int[]    CL_bySize_Count => CL_bySize_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();


						//public string   stCrossCoverLineB => "CrossCoverLineB  one:" + CrossCoverLineB.Aggregate("", (a,b) => a+ " "+	b.Item1.TBS() ) +
						//								   "\n                  two:" + CrossCoverLineB.Aggregate("", (a,b) => a+ " "+	b.Item2.TBS() );		



					// ----------------------------------------------------------

						public string st_SLine_House(){
							List<int> HSL = (new []{ExG0.hno, ExG1.hno, ExG2.hno}).ToList();
							string st = HSL.Aggregate("", (a,h) =>a+(","+h.HouseToString() )) .Substring(1);
#if DEBUG
							st += $" ({string.Join(",",HSL)}";
							st += ")";
#endif
							return st;
						}


						public string stExGx(){
							string st =  (ExG0==null)?  "  ExG0:n/a": $"\n  ExG0:{ExG0}";
								   st += (ExG1==null)?  "  ExG1:n/a": $"\n  ExG1:{ExG1}";
								   st += (ExG2==null)?  "  ExG2:n/a": $"\n  ExG2:{ExG2}";
							return st;
						}
					}


		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

		public partial class UCrossLine{
			static public List<UCell>	qBOARD;

			public UExocet  SExo;
			public int		sq = -9;
			public int		hno;
			public bool		IsTargetType;
			public UInt128  Object81 = _na_;
			public int      rcTarget => Object81.FindFirst_rc();
			public UInt128  Mirror81 = _na_;
			public int		ObjectBlockNo => (Object81==_na_)? -1: Object81.FindFirst_rc().B();
			public int      FreeB_Object;		// Free Digits of Object. Includes more than just Base_Digits
			public int      noB_FixedFreeB_Object_or => Object81.IEGet_rc().Aggregate(0,(a,rc)=> a | rc.Get_FixedFreeB( ) );

			public int      FreeB_Effective_Object => Object81.Get_FreeB_Efective_or();
			public bool		wildcardB;

			public UInt128  CrossLine  = _na_;
			public UInt128  SLine      => SExo.SLineList[sq];

			public UCrossLine( UExocet SExo, int sq, int hno ){
				this.SExo		= SExo;
				this.sq			= sq;
				this.hno		= hno;
				this.CrossLine  = House_81[hno];
			}

			public UCrossLine( UExocet SExo, int sq, int hno, UInt128 CrossLine, UInt128 Object ): this( SExo, sq, hno ){
				this.Object81	  = Object & qMaxB81;
				this.IsTargetType = Object.BitCount() == 1;
				this.FreeB_Object = Object81.IEGet_UCell(qBOARD) .Aggregate( 0, (a,uc)=> a| (uc.FreeB&~uc.CancelB) ); 
				this.wildcardB = this.Object81.IEGet_UCell(qBOARD).All(u=> u.No!=0);
			}

//			public int      FreeB_Object81  => Object81.IEGet_UCell(qBOARD) .Aggregate( 0, (a,uc)=> a| (uc.FreeB&~uc.CancelB) ); 
//			public int		FreeB_SLine81   => SLine.IEGet_UCell(qBOARD) .Aggregate( 0, (a,uc)=> a| (uc.FreeB&~uc.CancelB) );
						
			public string   stObject		=> Object81.TBScmp();
			public string   stMirror		=> Mirror81.TBScmp() + Mirror81.Get_FreeBFixedDigitsString();

			public UInt128 Get_FullSight( bool withExclusion ){
				if( withExclusion ){ return Object81.IEGet_rc().Aggregate( qMaxB81, (a,rc) => a & Connected_81[rc].Reset(rc) ); }
				else{				 return Object81.IEGet_rc().Aggregate( qMaxB81, (a,rc) => a & Connected_81[rc] ); }
			}

		}




		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
		public class UCoverStatus{
			static public UInt128[]  pBOARD_Fixed81B9;
			static public UInt128[]  pBOARD_Free81B9;

			public int	 no;
			public int   sz;
			public int	 CLH_0 = -1;	// house no. if h>100, then Cross-Line.
			public int	 CLH_1 = -1;
			public int	 CLH_2 = -1;
			public List<int>  CLH_List;

			public UCoverStatus( int no, int sz, int CLH_0, int CLH_1, int CLH_2 ){
				this.no = no;
				this.sz = sz;
				this.CLH_0=CLH_0; this.CLH_1=CLH_1;	this.CLH_2=CLH_2;

				CLH_List = new();
				if( CLH_0 >= 0 )  CLH_List.Add(CLH_0);
				if( CLH_1 >= 0 )  CLH_List.Add(CLH_1);
				if( CLH_2 >= 0 )  CLH_List.Add(CLH_2);
			}


			public override string ToString( ){
				string st = $" no:#{no+1} size:{sz}";
				       st += $"  CoverLine: {_ToStHouse(CLH_0)} {_ToStHouse(CLH_1)} {_ToStHouse(CLH_2)}";
				return st;
			
					string _ToStHouse(int hh){
						string st="";
						if( hh<0 )  st = "----";
						else{
							int h = hh%100;			
							st = ((h<9)? "r": (h<18)? "c": "b") + ((h%9)+1).ToString()
							   + ((hh<100)? "/p": (h<18)? "/x": "_*");
						}
						return st.PadRight(5);
					}
			}
		}

	} 


}