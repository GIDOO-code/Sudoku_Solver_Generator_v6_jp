using System;
using System.Collections.Generic;
using System.Linq;
using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Reflection.Emit;
using System.Windows.Documents;
using System.Diagnostics;

namespace GNPX_space{
    //Advanced solving techniques
    // http://forum.enjoysudoku.com/advanced-solving-techniques-f6.html

    //Pattern Overlay Method
    // http://forum.enjoysudoku.com/pattern-overlay-method-t40180.html ...C

    //The tridagon rule
    // http://forum.enjoysudoku.com/the-tridagon-rule-t39859.html  ... C

    //Strong links within Fish Patterns:
    // http://forum.enjoysudoku.com/strong-links-within-fish-patterns-t30392.html ... A





	public class Research_trialM{
		private List< LatinSquare_9x9 >   iBoardList;
		private Research_trial RTrial;
		private CancellationTokenSource cts;

		public Research_trialM( GNPX_AnalyzerMan pAnMan,  List< LatinSquare_9x9 > iBoardList, bool filePutB, int upperLimit=2 ){
			this.iBoardList = iBoardList;
			RTrial = new Research_trial( pAnMan );

			foreach( var (P,mx) in iBoardList.WithIndex() ){
				List<string>  stList = RTrial.TrialAndErrorApp( P.SolX.ToList(), filePutB, upperLimit );
				P.validCC = (stList.Count==1)? 1: 2;
			}
		}
	}

}