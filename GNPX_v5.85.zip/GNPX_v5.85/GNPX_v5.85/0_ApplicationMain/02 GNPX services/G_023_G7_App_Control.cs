﻿using System;
using System.Windows.Media;
using System.IO;
using System.Text.Json.Serialization;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using static System.Diagnostics.Debug;


//:::::::::::::::::::::::::::::::::::::
//	ver.7
//:::::::::::::::::::::::::::::::::::::


namespace GNPX_space{
	public class G7_Base{

/*
		[XmlIgnore]  public List<UCell>  g7FinalState_TE;
		
		[XmlIgnore]  public List<UCell>  g7CurrentState; 
			//string st1 = string.Join("",pBOARD.ConvertAll(p=> Abs(p.No))).Replace("0","."). AddSpace9_81();

		[XmlIgnore]  public int[]		 g7_LSpattern = new int[10000];

		[XmlIgnore]  public bool		 g7MarkA0;					// ver.5.2- for Develop
		[XmlIgnore]  public bool		 g7Error;					// ver.5.2- for Develop
		[XmlIgnore]  public List<string> g7MarkA_MLst0 = null;	// ver.5.2- for Develop
*/

		public G7_Base(){}
	}
}


