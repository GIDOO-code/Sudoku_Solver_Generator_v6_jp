using GIDOO_space;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Policy;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	using G6_SF = G6_staticFunctions;

    public partial class Exocet_TechGen : AnalyzerBaseV2{

		private int[] Generate_house_for_CoverLines( USExocet SExo, int B_18_27=0x3FFFF, bool debugPrint=false ){
			int  dir = SExo.dir;

			int rcbFrame = (SExo.SLine012e & BOARD_Free81) .Ceate_rcbFrameOr() & B_18_27;		// FreeCells -> Frame

			UInt128 FixedinSLines = (SExo.SLine012e & BOARD_Fixed81);
			rcbFrame |= (dir==0)? FixedinSLines.IEGet_rc() .Aggregate( 0, (a,rc) => a| 1<<(rc/9) ):		// FixedCells -> Frame
							      FixedinSLines.IEGet_rc() .Aggregate( 0, (a,rc) => a| 1<<(rc%9+9) );

			List<int> house_CL = rcbFrame.IEGet_BtoHouse27().ToList();
			house_CL = house_CL.ConvertAll( cl => (cl<18 && (cl/9)!=dir)? cl+100: ((cl%100)>=18)? cl+200: cl );

			house_CL.Sort();
				if(debugPrint){
					string st = $"{string.Join( " ",house_CL)}";
					WriteLine( $"Generate_house_for_CoverLinesst: {st}" );
				}
			return house_CL.ToArray();

		}



		private void  _Information_4_Debugging( USExocet SExo ){
			UCrossLine  ExG1=SExo.ExG1, ExG2=SExo.ExG2;

			// =========================================
				string st = $"\n Exo_0 dir:{SExo.dir} rcStem:{SExo.rcStem}  baseCells:{SExo.Base81.TBScmp()}" ;
				st += $"  Object 1-2 : {ExG1.stObject} - {ExG2.stObject}";
				WriteLine( st );

			// =========================================
				string[]  Marks = new string[81];
				var (rcB1,rcB2) = SExo.Base81. BitToTupple();
				if( rcB1>=0 ) Marks[rcB1] = "b"; 
				if( rcB2>=0 ) Marks[rcB2] = "b"; 
				foreach( var rc in ExG1.Object81.IEGet_rc() )  Marks[rc] = "t1";
				foreach( var rc in ExG2.Object81.IEGet_rc() )  Marks[rc] = "t2";

				//pBOARD.__CellsPrint_withFrame( Marks,  "SEBase,ExG1,ExG2" );
				pBOARD._Dynmic_CellsPrint_withFrame( Marks,  "***" );

			// =========================================
				WriteLine( $"\n dir:{SExo.dir}  Base:{SExo.stBase}  T1:{SExo.ExG1.stObject}  T2:{SExo.ExG2.stObject}" );
				UInt128 _Flag = SExo.Base81 | ExG1.Object81 | ExG2.Object81;
				
				G6_SF.__MatrixPrint( Flag:_Flag, SExo.CrossLine_012, SExo.SLine012e, "CrossLine_012, SLine_012_Ext" );
			// =========================================
		}

		private string  __VectorPrint( UInt128 mat, int[] house_CL ){
			string st = "";
			foreach( int hh in house_CL.Where(p=>p>100) ){
				var (V,_) = mat.ToVectorH( hh%100);
				st += ((hh<9)? "r": "c") + ((hh%9)+1).ToString();
				st += ": " + V.ToBitString(9)+"@";
			}
			return st.Trim().Replace("@","\n");
		}








		private UCoverStatus __Get_CoverLine( int no, UInt128 SLine_no, int[] house_CL, bool debugPrint=false  ){
			foreach( int h in house_CL ){							// ::: 1-CoverLine
				UInt128 CLH0 = HC81[h%100];
				if( SLine_no.DifSet(CLH0) == qZero ) return  new UCoverStatus( no, 1, h, -1, -1 );
			}

			foreach( int h1 in house_CL.Where(h=>h<100) ){			// ::: 2-CoverLine
				UInt128 CLH1 = HC81[h1];
				if( (SLine_no&CLH1) == 0 )  continue;

				foreach( int h2 in house_CL){
					UInt128 CLH2 = HC81[h2%100];
					if( SLine_no.DifSet(CLH1|CLH2) == 0 ) return  new UCoverStatus( no, 2, h1, h2, -1 );
				}
			}
				
			var ha= house_CL.ToList().Where(p=>p>=100).ToList();	// ::: 3-CoverLine						
			// Compliant with requirements? : Are there any digits on all SLines?
			if( ha.Count()>=3 && ha.All( h=> (SLine_no&HC81[h-100])>qZero ) )  return  new UCoverStatus( no, 3, ha[0], ha[1], ha[2] );


			return  null;
		}



		public (int,int) SExocet_Valid_TargetPair_phase5( USExocet SExo, bool debugPrint=false ){
			UCrossLine  ExG1=SExo.ExG1, ExG2=SExo.ExG2;
			int		FreeB0 = SExo.FreeB0;
		
			int FreeB_Covered_2CL = SExo.CL_bySize_noB[2];
			int noB_Tag1 = ExG1.FreeB_Object81 & FreeB_Covered_2CL;
			int noB_Tag2 = ExG2.FreeB_Object81 & FreeB_Covered_2CL;

			var  (noB1,noB2) = (0,0);
			if( noB_Tag1>0 && noB_Tag2>0 ){
				int skip=9;
				foreach( var (no1,no2) in G6_SF.PairGenerator(noB_Tag1,noB_Tag2,skip,uniqueB:true) ){
					noB1 |= 1<<no1;
					noB2 |= 1<<no2;
				}
			}
			else if( noB_Tag1>0 )  noB1 |= noB_Tag1;
			else if( noB_Tag2>0 )  noB2 |= noB_Tag2;

			return (noB1,noB2);
		}








	#region SE_ph4_IsCovered
		public bool SE_ph4_IsCovered( USExocet SExo, bool debugPrint=false ){
			UCrossLine  ExG1=SExo.ExG1, ExG2=SExo.ExG2;
			int		FreeB0 = SExo.FreeB0;
			UInt128 Base_Object = SExo.Base81 | SExo.Object81;
				if(debugPrint) _Information_4_Debugging(SExo);

			SExo.CoverStatusList = new UCoverStatus[9];
			SExo.CL_bySize_noB   = new int[4];
			SExo.CrossCoverLineB = new (int,int)[4];

			int rcbHouse =  SExo.Extension=="Extend"? 0x7FFFFFF: 0x3FFFF;
			int[] house_CL = Generate_house_for_CoverLines( SExo, B_18_27:rcbHouse );		

			foreach( var no in FreeB0.IEGet_BtoNo() ){
				int noB = 1<<no;
				UInt128 SLine_no = SExo.SLine012e & BOARD_FreeAndFixed81B9[no];
						if(debugPrint){ 
							G6_SF.__MatrixPrint( Flag:Base_Object, BOARD_FreeAndFixed81B9[no], SExo.SLine012e, SLine_no, $"BOARD_FreeAndFixed81B9[#{no+1}] SLine012e(#{no+1}) SLine_no(#{no+1})" );
						}

				if( SLine_no==qZero ){ SExo.CL_bySize_noB[0] |= noB; }
				else{	// <<< _Get_CoverLine
					UCoverStatus UCL = __Get_CoverLine_Ext( SExo, no, SLine_no, house_CL, debugPrint:false );
					if( UCL == null )  continue;// return false;		// @@@ not covered
					SExo.CoverStatusList[no] = UCL;
					SExo.CL_bySize_noB[UCL.sz] |= noB;	// sz=3 ... Wildcard or ... Type:Extension
				}
			}


			foreach( var (SL,kx) in SExo.SLine012_List.WithIndex() )  SExo.CrossCoverLineB[kx] = SL.Get_SingleMore();
			
			int szCL = SExo.Extension=="Extend"? 3: 2;			//@@@ Extend @@@
			int FreeB_Covered_CL = SExo.CL_bySize_noB[szCL];	//�@[Att]  Bird�@Doc. Rule-1
						if(debugPrint){ 
							string  stCoverLines = SExo.CoverStatusList.Where(p=>p!=null).Aggregate(" ",(a,ch)=> a+ $"\n {ch}");
							WriteLine( $"\nCoverLines\n{stCoverLines}" );

							WriteLine( $"FreeB_Covered_2CLtest2:{FreeB_Covered_CL.TBS()}" );
							foreach( var (P,kx) in SExo.CL_bySize_noB.WithIndex() ) WriteLine( $"  SExo.CL_bySize_noB[{kx}] : {P.TBS()}" );
						} 






			int[] CL_bySize_Count = SExo.CL_bySize_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();

			if( SExo.ExocetName.Contains("JE1") ){
				int FreeB_Covered = SExo.FreeB.DifSet(SExo.CL_bySize_noB[2] | SExo.CL_bySize_noB[3]);
				if( CL_bySize_Count[3]!=1 || FreeB_Covered > 0 )  return false;
			}

			else if( SExo.ExocetNamePlus.Contains("SE_Single") ){
				int frB1 = ExG1.FreeB_Object81 & FreeB0;
				int frB2 = ExG2.FreeB_Object81 & FreeB0;

				foreach( var no in SExo.FreeB0.IEGet_BtoNo() ){
					int noB = 1<<no;
					var CLn = SExo.CoverStatusList[no];
					if( CLn==null || CLn.CLH_0>27 ){		// If CL is Cross, it is not candidates, so exclude it.
						frB1 = frB1.DifSet(noB);
						frB2 = frB2.DifSet(noB);
					}
				}
				if( (ExG1.Object81&BOARD_Free81)!=qZero && frB1==0 )  return false;		// False if it contains free cells and zero.
				if( (ExG2.Object81&BOARD_Free81)!=qZero && frB2==0 )  return false;
			}
			else{
				int szA = (SExo.Extension=="")? 2: 3;
				int FreeBa = SExo.CL_bySize_noB[szA];
			//	if( (SExo.FreeB0&FreeBa).BitCount()< 3 )  return false;
			  if( SExo.FreeB0.DifSet(FreeBa) > 0 )  return false;
	
			}

			return  true;;
		}

		private bool IsValid_CL_by_type( USExocet SExo ){
			int[] CL_bySize_noB = SExo.CL_bySize_noB;
			int[] CL_bySize_Count = CL_bySize_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();

			// :::::: Junior Exocet ::::::
			if( SExo.ExocetName.Contains("JE2") ){			// ... JE2, JE2+, JE2++
				if( CL_bySize_Count[2]<2 || CL_bySize_noB[3]>0 )  return false;
			}
			else if( SExo.ExocetName.Contains("JE1") ){		// ... JE1
				if( CL_bySize_Count[3]!=1 || SExo.FreeB .DifSet(CL_bySize_noB[2] | CL_bySize_noB[3]) > 0 )  return false;
			}

			// :::::: Senior Exocet ::::::
			else if( SExo.ExocetNamePlus=="SE_Standard" ){	// ... SE_Standard, SE_SingleBase
				if( SExo.Extension == "" ){
					if(  CL_bySize_Count[2]<2 || CL_bySize_noB[3]>0 )  return false;
				}
#if false
				else if( SExo.Extension == "Extend" ){
					if(  CL_bySize_Count[3]<2 )  return false;
					int F0 = (SExo.FreeB0 & SE_ph45_Check_ExtendCondition(SExo, debugPrint:debugPrint) ) ;
					if( F0.BitCount() < 2 )  return false;
				}
#endif
			}
			else if( SExo.ExocetNamePlus=="SE_Single" ){	// ... SE_Single
				if( CL_bySize_Count[3]!=1 || SExo.FreeB .DifSet(CL_bySize_noB[2] | CL_bySize_noB[3]) > 0 )  return false;
			}
						
			else if( SExo.ExocetNamePlus=="SE_SingleBase" ){	// ... SE_SingleBase
				if(	CL_bySize_Count[2]!=2 || CL_bySize_Count[1]>0 || CL_bySize_Count[3]>0 )  return false;
			}

			else{
				WriteLine( $"\n\n ExocetNamePlus : {SExo.ExocetNamePlus} ... \n\n" );
				throw new Exception( $"Operation Error. SExo.ExocetNamePlus : {SExo.ExocetNamePlus}");
			}

			return true;
		}


		private UCoverStatus __Get_CoverLine_Ext( USExocet SExo, int no, UInt128 SLine_no, int[] house_CL, bool debugPrint=false  ){
			int nxt=9;

			UInt128 hclSel = SLine_no & BOARD_FreeAndFixed81B9[no];
			List<int> HCL_List = house_CL.ToList().FindAll( h => (HC81[h%100]&hclSel) != qZero);

			// 1-CL
			foreach( int h0 in HCL_List.Where(h=>h<100) ){
				UInt128 CLH = HC81[h0];
							//WriteLine( $"1-cl {h0,4}" );
				if( SLine_no.DifSet(CLH) == qZero )  return  new UCoverStatus( no, 1, h0, -1, -1 );
			}

			// 2-CL
			Combination cmb2 = new(HCL_List.Count,2);

			while( cmb2.Successor(skip:nxt) ){
				int h0=HCL_List[cmb2.Index[0]], h1=HCL_List[cmb2.Index[1]];
				if( h0 >= 100 )  break;

				UInt128 CLH0 = HC81[h0%100];
				if( (SLine_no & CLH0) == qZero ){ nxt=0; continue; }
				nxt = 1;
				UInt128 CLH1 = HC81[h1%100];
							//WriteLine( $"2-cl {h0,4} {h1,4}" );
				if( SLine_no.DifSet(CLH0|CLH1) == qZero )  return  new UCoverStatus( no, 2, h0, h1, -1 );
			}
#if false
			if(  SExo.Extension=="Extend" & HCL_List.Count()>=3 ){
				Combination cmb3 = new(HCL_List.Count,3);
				while( cmb3.Successor(skip:nxt) ){
					int h0=HCL_List[cmb3.Index[0]], h1=HCL_List[cmb3.Index[1]], h2=HCL_List[cmb3.Index[2]];
							if( (h0/100!=0) || (h1/100>=1) && (h2/100>=1) )  continue;

					UInt128 CLH0 = HC81[h0%100];
					if( (SLine_no & CLH0) == qZero ){ nxt=0; continue; }
					UInt128 CLH1 = HC81[h1%100];
					if( (SLine_no & CLH1) == qZero ){ nxt=1; continue; }
					nxt=2;
					UInt128 CLH2 = HC81[h2%100];
								//WriteLine( $"3-cl {h0,4} {h1,4} {h2,4}  {stX}" );
					if( SLine_no.DifSet(CLH0|CLH1|CLH2) == qZero )  return  new UCoverStatus( no, 3, h0, h1, h2 );
				}
			}
#endif
			return  null;
		}

		private int SE_ph45_Check_ExtendCondition( USExocet SExo, bool debugPrint=false ){
			UInt128 Base_Object = SExo.Base81 | SExo.Object81;
			//debugPrint = true;

			int vno1 = _SE_ph45_Check_ExtendConditionsub(SExo,SExo.ExG1,debugPrint:debugPrint);
			int vno2 = _SE_ph45_Check_ExtendConditionsub(SExo,SExo.ExG2,debugPrint:debugPrint);

			return  (vno1|vno2);
				
				int _SE_ph45_Check_ExtendConditionsub( USExocet SExo, UCrossLine ExGM, bool debugPrint=false ){
					UInt128 SLN = SExo.SLine012e & HouseCells81[ExGM.hno];	
					if(debugPrint){
						G6_SF.__MatrixPrint( Flag:Base_Object, SExo.SLine012e, HouseCells81[ExGM.hno], SLN, $"SExo.SLine012e, HouseCells81[ExGM.hno], SLN_#" );
					}

					int noValid = 0;
					foreach( int no in SExo.FreeB0.IEGet_BtoNo() ){
						UInt128 SB = SLN & BOARD_FreeAndFixed81B9[no];
						if(debugPrint) G6_SF.__MatrixPrint( Flag:Base_Object, SLN, BOARD_FreeAndFixed81B9[no], SB, $"SLN, BOARD_FreeAndFixed81B9[no], SB_#{no+1}" );
						if( SB.BitCount() <= 2 )  noValid |= 1<<no;
					}
					return (noValid & ExGM.FreeB_Object81);
				}

		}

	#endregion SE_ph4_IsCovered


	}
}