using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;

using GIDOO_space;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6) ...  Not very elegant. Needs some code cleanup.
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		static private readonly string  spX = new string(' ',10); 
		static private readonly string  sp5 = new string(' ',5); 
        static public  readonly UInt128 qZero   = UInt128.Zero;
        static public  readonly UInt128 qOne    = UInt128.One; 
		static public  readonly UInt128 qMaxB81 = (UInt128.One<<81)-qOne;

		private int FreeB_UInt128( UInt128 X)   => (X==qZero)? 0: X.IEGet_UCell(pBOARD) .Aggregate( 0, (a,uc)=> a| uc.FreeB ); 
		private int noB_FixedFreeB_UInt128( UInt128 X)   => (X==qZero)? 0: X.IEGet_UCell(pBOARD) .Aggregate( 0, (a,uc)=> a| uc.noB_FixedFreeB ); 
//
		private UInt128		  BOARD_Fixed81;		// Bit representation of Fixed cells on the board	
//		private UInt128		  BOARD_Free81;			// Bit representation of Free  cells on the board

		private int			  stageNoPMemo = -9;

		private List<string>  extResultLst = new();

		internal bool		  debugPrint = false;

		public  Exocet_TechGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }

		public void Prepare_SExocet_TechGen(bool printB ){
            bool lkExtB = G6.UCellLinkExt;
			BOARD_Fixed81			  = pBOARD.Where(p=>p.No!=0).Select(p=>p.rc).Aggregate(qZero, (a,b) => a| qOne<<b);
//			BOARD_Free81			  = pBOARD.Create_Free_BitExp128();	// FreeCell Bit Representation		  

			G6_staticFunctions.pBOARD = base.pBOARD;
			USExocet.qBOARD			  = base.pBOARD;
			UCrossLine.qBOARD		  = base.pBOARD;
		}


		private int Get_LockedHouse( UInt128 Cells81, int no, UInt128 Exclusions81 ){  // need
			// Find House where #n in cells "Cells81" is locked.
			// Output is the bit representation of the House number.
			// (Exclude Exclusions81 from the inspection target. =0:No Exclusions)
			
			int noB = 1<<no;
			UInt128 Cells81_no = Cells81.IESelect81B_with_noB(pBOARD,noB).Aggregate(qZero, (a,uc)=> a| qOne<<uc.rc );
			int frame_Cells81_no = Cells81_no.Ceate_rcbFrameAnd();	// House number(0-26 0-8:row 9-17:column 18-26:block)

			int h_locked = 0;
			foreach( int h in frame_Cells81_no.IEGet_BtoNo(27) ){	// 27:house size(row,column,block)
				UInt128 outer_Cells = (BOARD_Free81B9[no] & HouseCells81[h] ).DifSet(Cells81 | Exclusions81);
				if( outer_Cells == qZero )  h_locked |= 1<<h;
			}

			return h_locked;
		}	
	}
}