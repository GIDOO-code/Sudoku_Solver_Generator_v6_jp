using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using System.Windows.Documents;
using GNPX_space;
using static GNPX_space.Exocet_TechGen;
using static GNPX_space.SubsetTechGen;
using System.Buffers.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Xml.Linq;
using System.Windows;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen : AnalyzerBaseV2{
		static private UInt128[] HC81 =>	HouseCells81;
		static private UInt128[] ConnC81 => ConnectedCells81;

		

		private IEnumerable<USExocet>  IE_Generate_Exocet_Unit( string ExoControl ){
			
			// ::: #Phase1 ::: 
			foreach( USExocet SExo in ph1_IE_Exocet_BasicForm( ExoControl:ExoControl, debugPrint:false) ){			
						//if( SExo.dir!=0 || SExo.rcStem!=33 )  continue;			// ===== SE_Nxt Debug =====
						//if( SExo.Base81 != (qOne<<60) )  continue;				// ===== SE_Nxt Debug =====

				int     dir = SExo.dir;
				UInt128 Escape = SExo.EscapeCells;

				// ::: #Phase2 ::: 
				foreach( (int,int,int)  h012 in ph2_IE_Exocet_CrossLine_HouseNo( SExo, debugPrint:false) ){
							//if( h012 != (15,11,12) )  continue; // ===== SE_Nxt Debug =====
					

					// ::: #Phase3 ::: 
					foreach( var _ in ph3_IE_SE_TargetObject( SExo, debugPrint:false) ){
						UCrossLine ExG0=SExo.ExG0, ExG1=SExo.ExG1, ExG2=SExo.ExG2;
							//if( ExG1.Object81 != (qOne<<47 | qOne<<47) )  continue; // ===== SE_Nxt Debug =====
							//if( ExG2.Object81 != (qOne<<39 | qOne<<39) )  continue; // ===== SE_Nxt Debug =====

							UInt128 BaseObj = SExo.Base81 | (ExG1.Object81 | ExG2.Object81 );




							// ::: Companion
							{	// --- for JE & SE
								SExo.Companion_base = SExo.Object81.IEGet_rc()
												.Aggregate(qZero, (a,rc) => a| ( (HC81[(1-dir,rc).DRCHf()] & HC81[rc.B()+18]) | HC81[(dir,rc).DRCHf()]) )
												.DifSet(Escape | SExo.Object81);
							}

							// Companion Definition, (( for standard SExocet. ))
							SExo.Companion = SExo.Companion_base & SExo.CrossLine_012;

								//G6_SF.__MatrixPrint( Flag:BaseObj, SExo.Companion_base, SExo.Companion, "SExo.Companion_base, SExo.Companion" );
								//debugPrint = true; // ===== SE_Nxt Debug =====

							int FreeB_Companion = SExo.Companion.Get_FreeB();
							if( ( SExo.FreeB & FreeB_Companion ) > 0 )  goto LClear; // @@@@@





							// ::: SLine
							UInt128 Block_Object = SExo.Object81.IEGet_rc().Aggregate(qZero, (a,rc) => a| (HC81[rc.B()+18] | SExo.Object81) );
							UInt128 Block_Object0 = SExo.Object81.IEGet_rc().Aggregate(qZero, (a,rc) => a| HC81[(dir,rc).DRCHf()] );
							ExG0.SLine = ExG0.CrossLine .DifSet( SExo.Band81 | Block_Object0 | SExo.Companion );
							ExG1.SLine = ExG1.CrossLine .DifSet( Escape | Block_Object | SExo.Companion );
							ExG2.SLine = ExG2.CrossLine .DifSet( Escape | Block_Object | SExo.Companion );
							SExo.SLine_Exp = qZero;
				
							// ::: Mirror
							ExG1.Mirror81 = qZero; ExG2.Mirror81 = qZero;
							if( ExG1.Object81.IEGet_UCell(pBOARD).Any(U=>U.No==0) ){	// ... not defined for SingleBase
								ExG1.Mirror81 = HC81[ExG2.Object81.FindFirst_rc().B()+18] & ExG2.Object81.Aggregate_ConnectedOr()
											  . DifSet( ExG1.Object81.Aggregate_ConnectedOr() | SExo.CrossLine_012 | Escape);
							}

							if( ExG2.Object81.IEGet_UCell(pBOARD).Any(U=>U.No==0) ){	// ... not defined for SingleBase
								ExG2.Mirror81 = HC81[ExG1.Object81.FindFirst_rc().B()+18] & ExG1.Object81.Aggregate_ConnectedOr()
											  . DifSet( ExG2.Object81.Aggregate_ConnectedOr() | SExo.CrossLine_012 | Escape);
							}
													
									if(debugPrint){
										G6_SF.__MatrixPrint( Flag:BaseObj, SExo.Companion, ExG0.SLine, ExG1.SLine, ExG2.SLine, "Companion, ExG0.SLine, ExG1.SLine_x, ExG2.SLine_x" );
										G6_SF.__MatrixPrint( Flag:BaseObj, ExG1.Mirror81, ExG2.Mirror81, "ExG1.Mirror81, ExG2.Mirror81" );
									}
							
						// --------------------------------------------
						if( SExo.Extension == "" )  yield return SExo;
#if false
								// --------------------------------------------
								else if( SExo.Extension == "Extend" ){	// ===== SE_Nxt Debug @@@ =====
								  //@@@ Extend @@@
									UInt128 Influence_object = SExo.Base81.IEGet_rc() .Aggregate(qZero, (a,rc) => a| ConnC81[rc] );		//All-directional connection of the Base
									UInt128 Influence_object2 = (Influence_object | SExo.Companion_base) & BOARD_Free81;				// Add Object 
											//G6_SF.__MatrixPrint( Flag:BaseObj, ExG0.SLine, Influence_object, Influence_object2, "ExG0.SLine, Influence_object Influence_object2" );	// @@@ Ext

									UInt128 Exclude81 = Escape | Block_Object | SExo.Companion;
											//G6_SF.__MatrixPrint( Flag:BaseObj, Exclude81, Escape, Block_Object, SExo.Companion, "Exclude81, Escape, Block_Object, SExo.Companion" );
									foreach( UInt128  SLine_Exp in ph7_IE_SE_Ext_AddExtendedSLine( SExo, ExG1.Object81, ExG2.Object81, Exclude81, debugPrint:false) ){  
										UInt128 Conn = Exclude81 & SLine_Exp; //Influence_object2 & SLine_Exp;
											//G6_SF.__MatrixPrint( Flag:BaseObj, Influence_object, SLine_Exp, Conn, "Influence_object, SLine_Exp, Conn" );	// @@@ Ext
										if( Conn != qZero )  continue;	//	// @@@ Ext
										SExo.SLine_Exp = SLine_Exp;

										ExG1.Mirror81 = ExG1.Mirror81 .DifSet(HouseCells81[SExo.h_exp]);
										ExG2.Mirror81 = ExG2.Mirror81 .DifSet(HouseCells81[SExo.h_exp]);

										yield return SExo;
									}
								}	
#endif
						
					LClear:	
						foreach( var UC in pBOARD.Where(p=>p.No==0) ) UC.CancelB=0;
						pBOARD.ForEach( UC => UC.ECrLst=null );
						ElementElimination_Manager_UT("Initialize");
					}
				}
			}
			yield break;


		}


		private IEnumerable<USExocet> ph1_IE_Exocet_BasicForm( string ExoControl, bool debugPrint=false ){
			// dir, StemCell => BaseCells, FreeB, SLine0, block1, block2

			for( int dir=0; dir<2; dir++ ){	// direction  0:row 1:column
				for( int rcStem=0; rcStem<81; rcStem++ ){

					// ... Base cells
					int     hBase = (dir,rcStem).DirRCtoHouse( );
					UInt128 base81 = (HouseCells81[hBase] & HouseCells81[rcStem.B()+18] & BOARD_Free81) .Reset(rcStem);
					
					// ... Single SE : Base is a single-cell and bivalue.)  @@@ BIVALUE |||
					if( ExoControl.Contains("SingleBase") ){	
						foreach( UCell UC in base81.IEGet_UCell(pBOARD).Where(uc=>uc.FreeBC==2) ){
							USExocet SExo = _Create_SExocetObject( ExoControl, dir, rcStem, qOne<<UC.rc, UC.FreeB );
							if( SExo != null )  yield return SExo;
						}
					}



					else{ // ... Normal ........................................................
						if( base81.BitCount() != 2 )  continue;					// ... Number of bits in Base. Base-cells are unfixed

						// ... Base candidates
						var (rcA,rcB) = base81.BitToTupple();					// (There are definitely two cells.)
						int  FreeB_UCA=pBOARD[rcA].FreeB,  FreeB_UCB=pBOARD[rcB].FreeB;
						// if( (FreeB_UCA & FreeB_UCB) == 0 )  continue;			// Has common digits. ... This condition is not accepted.

						// [req1] The Base Cells together contain 3 or 4 Candidates, that we call Base Candidates.
						int FreeB  = FreeB_UCA | FreeB_UCB;		
						int FreeBC = FreeB.BitCount();
#if false				
						if( !ExoControl.Contains("Extend") && (FreeBC<3 || FreeBC>5) )  continue;	
							// 2:LockedSet 5-:Hopeful predictions. ... Exocet_extend loosens restrictions.
#endif
						USExocet SExo = _Create_SExocetObject( ExoControl, dir, rcStem, base81, FreeB );
						if( SExo != null )  yield return SExo;
					}
				}
			}
			yield break;


					USExocet _Create_SExocetObject( string ExoControl, int dir, int rcStem, UInt128 Base81A,int FreeB ){
						UInt128 CrossLine0  =  HouseCells81[(1-dir,rcStem).DRCHf()] .DifSet( HouseCells81[rcStem.B()+18] );
						if( (CrossLine0 & BOARD_Free81) == qZero )  return null;

						USExocet SExo = new( ExoControl, dir, rcStem, Base81A, FreeB, BOARD_Free81 );
								if(debugPrint) WriteLine( $" CrossLine0:{CrossLine0.TBS()}" );

						return SExo;
					}
		}
	// ===================================================================================================================================

		private IEnumerable< (int,int,int) >  ph2_IE_Exocet_CrossLine_HouseNo( USExocet SExo, bool debugPrint=false ){	// Change the placement position. #####
			int  dir=SExo.dir, rcStem=SExo.rcStem, h0=0;
			int[]  h1HxList, h2HxList;

			if( dir==0 ){
				h0 = rcStem %9 + 9;
				int SC = ((rcStem+3)%9)/3*3 + 9;		// +9 : column
				h1HxList = new[]{SC+0, SC+1, SC+2 };
				
				SC = ((rcStem+6)%9)/3*3 + 9;
				h2HxList = new[]{ SC+0, SC+1, SC+2 };
			}
			else{
				h0 = rcStem/9;
				int SR = (rcStem/27*3+3)%9;
				h1HxList = new[]{ SR+0, SR+1, SR+2 };
				SR = (rcStem/27*3+6)%9;
				h2HxList = new[]{ SR+0, SR+1, SR+2 };
			}
			//SExo.h12hx = h1HxList.Aggregate(0,(a,h)=> a|(1<<h)) | h2HxList.Aggregate(0,(a,h)=> a|(1<<h));

			foreach( int kx in Enumerable.Range(0,9) ){
				var h012 = (h0, h1HxList[kx/3], h2HxList[kx%3] );
								//if(debugPrint) WriteLine( $" h012 : {h012}" );
				SExo.h012 = h012;
								//if( h012==(0,3,7) )  WriteLine( $"... h012:{h012}" ); // ===== SE_Nxt Debug @@@ =====
				yield return h012;
			}

			yield break;
		}

	}
}