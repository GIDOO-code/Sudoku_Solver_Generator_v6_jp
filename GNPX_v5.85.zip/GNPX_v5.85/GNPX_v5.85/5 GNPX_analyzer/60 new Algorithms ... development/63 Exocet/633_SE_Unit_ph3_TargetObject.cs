using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using System.Windows.Documents;
using GNPX_space;
using static GNPX_space.Exocet_TechGen;
using System.Security.Policy;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Xml.Linq;
using System.Security.AccessControl;
using System.Windows.Input;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen : AnalyzerBaseV2{

		public IEnumerable<TapleUCL> ph3_IE_SE_TargetObject( USExocet SExo, bool debugPrint=false ){
			var (h0,h1,h2) = SExo.h012;
				// The target generation order is (h0-h1), (h0-h2), (h1-h2).
				// Eliminate duplicate target generation.			


				UInt128 maskJunior = SExo.Band81 .DifSet(SExo.EscapeCells);
				UInt128 maskX = qMaxB81 .DifSet(SExo.EscapeCells);	// BOARD_Free81 .DifSet(SExo.EscapeCells)
				UInt128 maskFree, maskFixed;
			switch(SExo.ExocetNamePlus){

				case "JE1":
					maskX = maskJunior;					// Case JExocet, Target/Object is in Band.
					goto case "SE_Single";

				case "SE_Single":						// Case SExocet, Target/Object can be anywhere.
				case "SE_SingleBase":
					maskFixed = maskX & BOARD_Fixed81;	// ... Junior, Fixed
					maskFree  = maskX & BOARD_Free81;	// ... Junior, Free
					foreach( var EXG3 in ph4_IE_SE_CreateTagetObject( SExo, maskFixed, maskFree,  WC1:true,  WC2:false) )  yield return EXG3;
					foreach( var EXG3 in ph4_IE_SE_CreateTagetObject( SExo, maskFree,  maskFixed, WC1:false, WC2:true)  )  yield return EXG3;

					break;
				// ====================================================================================================================


				case "JE2":
					maskX = maskJunior;				// ... Junior, Free
					goto case "SE_Standard";

				case "SE_Standard":
					maskFixed = maskX & BOARD_Fixed81;	// ... Junior, Fixed
					maskFree  = maskX & BOARD_Free81;	// ... Junior, Free

					foreach( var EXG3 in ph4_IE_SE_CreateTagetObject( SExo, maskFree,  maskFree,  WC1:false, WC2:false)  )  yield return EXG3;

					if( SExo.Extension != "" ){
						foreach( var EXG3 in ph4_IE_SE_CreateTagetObject( SExo, maskFixed, maskFree,  WC1:true,  WC2:false) )   yield return EXG3;
						foreach( var EXG3 in ph4_IE_SE_CreateTagetObject( SExo, maskFree,  maskFixed, WC1:false, WC2:true)  )   yield return EXG3;
					}

					break;
			// ====================================================================================================================

				default:
					WriteLine( $"\n\n ExocetNamePlus : {SExo.ExocetNamePlus} ... Next development. Next development. Next development. Next development.\n\n\n" );
					throw new Exception( $"Operation Error. SExo.ExocetNamePlus : {SExo.ExocetNamePlus}");

			}

			yield break;
		}

		private IEnumerable<TapleUCL> ph4_IE_SE_CreateTagetObject( USExocet SExo, UInt128 maskCL1, UInt128 maskCL2, bool WC1=false, bool WC2=false ){
			var (h0,h1,h2) = SExo.h012;
			UInt128  CL0=HouseCells81[h0], CL1=HouseCells81[h1], CL2=HouseCells81[h2];
				//G6_SF.__MatrixPrint( Flag:SExo.Base81, SExo.Band81, CL0, CL1, CL2, "SExo.Band81, CL0, CL1, CL2," );
				//G6_SF.__MatrixPrint( Flag:SExo.Base81, SExo.Band81, CL0, CL1, CL2, "SExo.Band81, CL0, CL1_TagObj, CL2_TagObj" );

			foreach( UCrossLine UCL1 in ph5_IEGet_Set_TagObj_on_CrossLine(SExo, sq:1, hno:h1, CLX:CL1, maskCL:maskCL1, WC:WC1) ){							
				foreach( UCrossLine UCL2 in ph5_IEGet_Set_TagObj_on_CrossLine(SExo, sq:2, hno:h2, CLX:CL2, maskCL:maskCL2, WC:WC2 ) ){	// ... WC:Wildcard
						if(debugPrint) __Debug__MatrixPrint( SExo, CL0, UCL1, UCL2 );

					var (ExG0,ExG1,ExG2) = ph6_IE_SE_TargetObject( SExo, UCL1, UCL2, debugPrint:false );	//
					if( ExG0 == null )  continue;	// ### The Target/Object must cover the Base_Digits.
					yield return (ExG0,ExG1,ExG2);
				}
			}
			yield break;

					void __Debug__MatrixPrint(USExocet SExo, UInt128 CL0, UCrossLine UCL1, UCrossLine UCL2 ){
						UInt128 BaseObj = SExo.Base81 | (UCL1.Object81 | UCL2.Object81 );
						//G6_SF.__MatrixPrint( Flag:BaseObj, SExo.Band81, CL0, UCL1.Object81, UCL2.Object81, "SExo.Band81, CL0, UCL1.Object81(WC), UCL2.Object81" );
					}
		}

	
		private IEnumerable<UCrossLine> ph5_IEGet_Set_TagObj_on_CrossLine( USExocet SExo, int sq, int hno, UInt128 CLX, UInt128 maskCL, bool WC=false ){
			int	  FreeB0 = SExo.FreeB0;
						
			UInt128 BOARD_noB81	= SExo.FreeB0.IEGet_BtoNo().Aggregate(qZero, (a,no)=> a| BOARD_Free81B9[no] );
			UInt128 CLX_maskCL = CLX & maskCL;
			UInt128 CL_FreeB = CLX_maskCL & BOARD_noB81;
			if( WC &&  CLX_maskCL.BitCount()<2 )  yield break;
				//	/*if(debugPrint)*/	G6_SF.__MatrixPrint( Flag:SExo.Base81, CLX_maskCL, "CLX_maskCL" );
			
			// <<< Target >>>
			UCrossLine UCL;		
			if( WC is false ){	// WC: Wildcard
				foreach( int rc in CLX_maskCL.IEGet_rc().Where(p=> (pBOARD[p].FreeB & FreeB0)>0) ){
					yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:(qOne<<rc)) );
				}
			}

			// <<< Object >>>
			UInt128 Obj = qZero;
			int Block_Object = CLX_maskCL.IEGet_rc().Aggregate(0, (a,rc) => a | 1<<rc.B() );

			foreach( var blk in Block_Object.IEGet_BtoNo() ){
				var rcL = CLX_maskCL.IEGet_rc().Where(rc=>rc.B()==blk).ToArray();
				int sz = rcL.Count();
				if( sz==2 ){
					Obj = qOne<<rcL[0] | qOne<<rcL[1];  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
				}
				if( sz==3 ){	// The validity of size=3 has not been verified.  @@@ sollution /Exocet_examples2B.txt/ Puzzle 05/ step2
					Obj = qOne<<rcL[0]|qOne<<rcL[1];  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
					Obj = qOne<<rcL[1]|qOne<<rcL[2];  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
					Obj = qOne<<rcL[2]|qOne<<rcL[0];  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine: CLX, Object: Obj) );
					Obj = qOne<<rcL[0]|qOne<<rcL[1]|qOne<<rcL[2] ;	yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
				}
			}
			yield break;
		}


		private TapleUCL  ph6_IE_SE_TargetObject( USExocet SExo, UCrossLine UCLA, UCrossLine UCLB, bool debugPrint=false ){
			UInt128  Object1=UCLA.Object81, Object2=UCLB.Object81;


			int h0 = SExo.h012.Item1;
			UCrossLine ExG0 = new( SExo, 0, h0, CrossLine:HC81[h0]);
			UCrossLine ExG1 = UCLA;
			UCrossLine ExG2 = UCLB;

						if(debugPrint){
							UInt128 BaseTagObj = SExo.Base81 | Object1 | Object2;
							G6_SF.__MatrixPrint( Flag:BaseTagObj, ExG0.Object81, ExG0.Mirror81, "ExG0.Object ExG0.Mirror81" );
							G6_SF.__MatrixPrint( Flag:BaseTagObj, ExG1.Object81, ExG1.Mirror81, "ExG1.Object ExG1.Mirror81" );
							G6_SF.__MatrixPrint( Flag:BaseTagObj, ExG2.Object81, ExG2.Mirror81, "ExG2.Object ExG2.Mirror81" );
						}

			// ### The Target/Object must cover the Base_Digits. Here, the decision can be made in one place.
			if( !UCLA.wildcardB & !UCLB.wildcardB ){
				UInt128 TagObj = Object1 | Object2;
				int FreeB_TO = TagObj.Get_FreeB();
				if( SExo.FreeB.DifSet(FreeB_TO) > 0 )  ExG0 = null;  
			}
			else{
				if( !UCLA.wildcardB && !_Object_test(UCLA) )  ExG0 = null;		//wildcard(SingleBase) excludes _Object_test
				if( !UCLB.wildcardB && !_Object_test(UCLB) )  ExG0 = null;
			}


		// ----------------------------------------------
			SExo.ExG0=ExG0; SExo.ExG1=ExG1; SExo.ExG2=ExG2; 
			// ----------------------------------------------
			return  (ExG0,ExG1,ExG2);

					// The object must have a BaseDigits and enough of that number. 
					bool _Object_test( UCrossLine UCLx ){
						UInt128  Objectx=UCLx.Object81;
						int FreeBX = Objectx.Get_FreeB() & SExo.FreeB0;
						bool _test = FreeBX>0 && FreeBX.BitCount()>=Objectx.BitCount(); //This determination is required for Object type.
						return _test;
					}
		}






		private IEnumerable<UInt128> ph7_IE_SE_Ext_AddExtendedSLine( USExocet SExo, UInt128 ObjectAp, UInt128 ObjectBp, UInt128 Exclude81, bool debugPrint=false ){
			int		 dir=SExo.dir, rcStem=SExo.rcStem;
			UInt128  Object1=ObjectAp&qMaxB81, Object2=ObjectBp&qMaxB81;
			UInt128  Object12 = Object1 | Object2;
			UInt128  BaseTagObj = SExo.Base81 | Object1 | Object2;

			UInt128  Companion = SExo.Companion;

			// extended House.
			int house3 = (0x7FFFFFF) .DifSet( SExo.rcStem.ToRCBFrame() | (SExo.Base81 | SExo.Object81).ToRCBFrame() );
						if(debugPrint)  WriteLine( $" --- house3:{house3.ToBitString27rcb()}" ); 

			foreach( int h in house3.IEGet_BtoNo(sz:27) ){ // get House of row, column, block

				SExo.SLine_Exp = qZero;
				UInt128 SLine_Exp = HC81[h].DifSet(Companion | SExo.SLine012e); 
				if( (SExo.Object81&Companion) != qZero )  continue;

				SExo.h_exp = h;
				SExo.Companion = SExo.Companion_base & (SExo.CrossLine_012 | HC81[h]);
				SExo.SLine_Exp = SLine_Exp = SLine_Exp .DifSet(Exclude81);
						if(debugPrint) G6_SF.__MatrixPrint( Flag:BaseTagObj, SExo.SLine012e, Companion, SLine_Exp, "SExo.SLine012e, Companion, SLine_Exp" );

				yield return SLine_Exp;
			}
			yield break;			

		}

	}
}