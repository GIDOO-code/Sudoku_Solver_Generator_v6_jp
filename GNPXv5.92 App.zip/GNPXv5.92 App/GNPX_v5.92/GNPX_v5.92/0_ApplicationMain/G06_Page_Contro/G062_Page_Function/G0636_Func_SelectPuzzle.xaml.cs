﻿using GIDOO_space;
using GIDOO_space;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml.Linq;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;

namespace GNPX_space{
	using ioPath = System.IO.Path;
	using pGPGC = GNPX_Puzzle_Global_Control;
	using pRes = Properties.Resources;


// ** Power User only.
// Func_SelectPuzzle : Extract Puzzles using the specified GNPX-Algorithmn(@) from the Puzzle DB file.
// Usage :
//  (1) Double-click on a specific location on the screen to launch this Function.
//  (2) Specify the Puzzle DB file.
//  (3) Specify the GNPX-analysis-algorithm in two steps.
//    1) Select the basic algorithm by specifying the difficulty level (displayed in green).
//    2) Select the optional algorithm(@) (displayed in orange).
//  (4) Execute the selection.
//  (5) Output the multiple-choice Puzzles (you can also output while the selection is in progress).


    public partial class Func_SelectPuzzle: Page{  // only for Power User
		static public bool  EventSuppression=false;
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 

		//private string  stBOARD(List<UCell> BD) => string.Join("",BD.ConvertAll(p=> Abs(p.No))).Replace("0","."). AddSpace9_81();

		public GNPX_App_Man 		pGNPX_App;
		public GNPX_win				pGNP00win => pGNPX_App.pGNP00win;

		public GNPX_App_Ctrl        App_Ctrl => pGNPX_App.App_Ctrl;
		private G6_Base				G6 => GNPX_App_Man.G6;
		private G7_Base				G7 => GNPX_App_Man.G7;
        private GNPX_Engin			pGNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine

		public UPuzzle				ePZL{ get=>pGNPX_Eng.ePZL; set=>pGNPX_Eng.ePZL=value; } // Puzzle to analyze
		private int                 stageNo   => (ePZL is null)? 0: ePZL.stageNo;
		private GNPX_Graphics		gnpxGrp => pGNPX_App.gnpxGrp;

	    private PuzzleFile_IO		fPuzzleFile_IO => pGNPX_App.PuzzleFile_IO;
		private List<UPuzzle>		pGNPX_PUZZLE_List => pGPGC.GNPX_Puzzle_List;

	    private List<UAlgMethod>    SolverList_Dev;
		private List<UAlgMethod>    SolverList_App_Save;

		private DispatcherTimer     displayTimer;
		private object				obj = new();


		
		private string  sortMode = "ID";
		private string  dirStr   => G7.g7DirName + "AutoGen_Puzzles";
		private string  fName_MethodList = "MethodList.txt"; 

        public  CancellationTokenSource cts;
		private Stopwatch			AnalyzerLap = new();
		private string				Solving_Message;




		public Func_SelectPuzzle( GNPX_App_Man pGNPX_App ){
			this.pGNPX_App = pGNPX_App;

            InitializeComponent();
			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  

			displayTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
            displayTimer.Interval = TimeSpan.FromMilliseconds(100);
            displayTimer.Tick += new EventHandler(displayTimer_Tick);
        }

        private void displayTimer_Tick( object sender, EventArgs e){
			var lap = AnalyzerLap.Elapsed;
			var (nLap,tLap) = __remainMemo;
			lbl_analyzerLap.Content = $"Lap: {lap.TimespanToString(stUnit:true)} + {lap.RemainingTimeToString(nLap,tLap)}";

			txblk_AnalyzerResult.Text = Solving_Message;
					
			int lapMSec = ((int)AnalyzerLap.ElapsedMilliseconds) /50;
			elp_OnWork.Visibility = ((lapMSec%10)<3)? Visibility.Visible: Visibility.Hidden;
			
			lock(obj){
				var MTHD = GNPX_Engin.AnalyzingMethod;
				if( MTHD != null )  Lbl_onAnalyzing.Content = $"step: {stageNo,3} {MTHD.MethodName}";
			}
        }



		// <<< Load / Uncload >>>		
		private void Page_Loaded(object sender, RoutedEventArgs e) {
			if( numUD_DifficultyLevel == null ) return;
			G6.PG6Mode = GetType().Name;
			numUD_DifficultyLevel.Value = G6.PowerUser? 7: G6.Method_DifficultyLevel;  // for Power User debagging.
			G7.g7Max_Step = 999;	// This feature is disabled.

			SolverList_App_Save = pGNPX_App.SolverList_App;
			SolverList_Dev = pGNPX_App.SolverList_Base.Copy();  

			UAlgMethod QGenLog = SolverList_Dev.Find( P => P.MethodName.Contains("GeneralLogic") );
			if( QGenLog != null ) SolverList_Dev.Remove(QGenLog);	// GeneralLogic excluded

			SolverList_Dev.ForEach( p=> p.mark_Sel=false);

			btn_ResetMark_Click( sender, e );

			txt_FileName.Text = G6.GNPX_PuzzleFileName;
			btn_SolvePuzzle.IsEnabled =false;
			txblk_AnalyzerMessage.Text = "";

			elp_OnWork.Visibility = Visibility.Collapsed;		
        }

		private void Page_Unloaded(object sender, RoutedEventArgs e) {
			pGNPX_App.SolverList_App = SolverList_App_Save;
		}




		// <<< Puzzle File Read >>>
		private void btn_OpenPuzzleFile_Click(object sender, RoutedEventArgs e) {
            var OpenFDlog = new OpenFileDialog(){
				Multiselect = false,
				Title  = pRes.filePuzzleFile,
				Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
			};
			
			if( (bool)OpenFDlog.ShowDialog() ){
                string fName = OpenFDlog.FileName;
				var PZL_List = fPuzzleFile_IO.GNPX_PuzzleFile_Read( fName );
				pGPGC.Set_GNPX_Puzzle_List( PZL_List ); 

				if( pGPGC.GNPX_Puzzle_List!=null && pGPGC.GNPX_Puzzle_List.Count>0 ){
					string fName2 = System.IO.Path.GetFileName(fName);			
					Send_Command_to_GNPXwin( this, new Gidoo_EventHandler( eName:"PuzzleFile_Loaded", Message:fName2 ) );
					txt_FileName.Text = fName;
					G6.GNPX_PuzzleFileName = fName;

					int mcc = SolverList_Dev.Count(p => p.mark_Sel);
					btn_SolvePuzzle.IsEnabled = (mcc>0 && pGNPX_PUZZLE_List.Count>0);
				}
			}

			if( (bool)chbx_Resuming.IsChecked ){
				


			}

		}

		void __Method_CheckMark( bool sel ){
			WriteLine( $"*SolverList_Dev : {SolverList_Dev.Count} methods" );
			foreach( var (mthd,sq) in SolverList_Dev.WithIndex() ){
				if( sel && (mthd.mark_Sel is false) )  continue;
				WriteLine( $"sq:{sq,2} {mthd.NameM.PadRight(30)}  mark_Sel:{(mthd.mark_Sel? "on":"")}" );
			}
		}


		// <<< Solve and Marking : Marking Puzzles using a specified algorithm>>>
		private string fNameSave="", fNameSave2="", dirStrSave;
		private int    mSucceed;
		private (int,int) __remainMemo;

		private string Create_Destination_folder( string fullPathName ){
			List<string> folderList = fullPathName.Split(new char[]{'\\','/'}).ToList();
			int nc = folderList.Count;
			string  d0=folderList[nc-2], f0=folderList[nc-1];
			folderList.RemoveAt(folderList.Count-1);

			int m = 1;
			string  d1 = $"_S1";
			string lastFolder = folderList.Last();
			if( lastFolder.Substring(0,2) == "_S" ){
				m = int.Parse(lastFolder.Substring(2))+1;
				d1 = $"_S{m}";
			}
			folderList.Add( d1);
			string d1P = string.Join("\\",folderList);
			if( !Directory.Exists(d1P) )  Directory.CreateDirectory(d1P);

			string f1 = f0.Replace(".txt",d1+".txt");
			folderList.Add(f1);
			string f1P = string.Join("\\",folderList);

			return f1P;
		}

		private async void btn_SolvePuzzle_Click(object sender, RoutedEventArgs e) {
			cts = new CancellationTokenSource();

			txblk_AnalyzerResult.Foreground = Brushes.White;

			if( (string)btn_SolvePuzzle.Content == "Suspend" ){
				cts.Cancel();
				btn_SolvePuzzle.Content = "Solve and Marking";
				elp_OnWork.Visibility = Visibility.Hidden;
				return;
			}
				//	__Method_CheckMark( sel:false );
			txblk_AnalyzerMessage.Text = "";


			if( pGNPX_PUZZLE_List==null || pGNPX_PUZZLE_List.Count<=0 ){
				Lbl_onAnalyzing.Content = "Puzzle file not entered";
				Lbl_onAnalyzing.Foreground = Brushes.Pink;
				displayTimer.Stop();
				AnalyzerLap.Stop();
				elp_OnWork.Visibility = Visibility.Hidden;
				return;
			}

			if( SolverList_Dev.All(p => !p.mark_Sel) ){
				txblk_AnalyzerResult.Text = "Any Algorithm is not marked.";
				txblk_AnalyzerResult.Foreground = Brushes.Red;
				return;
			}

			bool MSelPzlB = G6.PG6Mode=="Func_SelectPuzzle";

		    //region Save standard conditions. Set conditions for development
			int tmpMSlvrMaxAlgorithm = G6.MSlvr_MaxNoAlgorithm;
			int tmpMSlvrMaxTime		 = G6.MSlvr_MaxTime;

			btn_SolvePuzzle.Content  = "Suspend";

			btn_ClearMark.IsEnabled  = false;

			GNPX_Engin.MltAnsSearch  = true;
			GNPX_Engin.SolInfoB      = true;

			// ::::::::::::::::::::::::::::::::::::::::::::
			int difLvl = numUD_DifficultyLevel.Value;
			SolverList_Dev.RemoveAll( p => p.difficultyLevel>difLvl && !p.mark_Sel);
			pGNPX_App.SolverList_App = SolverList_Dev;
			// ::::::::::::::::::::::::::::::::::::::::::::

			displayTimer.Start();
			AnalyzerLap.Reset();
			AnalyzerLap.Start();

			string dirFileName = Create_Destination_folder( txt_FileName.Text );

			// ::::::::::::::::::::::::::::::::::::::::::::
			int nPre=0;
			int nTested=0, mError=0;	
			var (lastID,mSucceed) = (bool)chbx_Resuming.IsChecked? Get_Restart_PuzzleID_FromFile(dirFileName): (0,0);
			// ::::::::::::::::::::::::::::::::::::::::::::


			foreach( var (aPZL,sqPZL) in pGNPX_PUZZLE_List.WithIndex() ){
				if( cts.IsCancellationRequested ){ break; }

				if( lastID>0 && Get_BaseID(aPZL.BaseName)<=lastID ){ nPre=nTested++; continue; }

				pGNPX_Eng.ePZL = aPZL;
				foreach( var p in aPZL.BOARD )  if( p.No<0 ) p.No=0;
				pGPGC.current_Puzzle_No = sqPZL;
				Send_Command_to_GNPXwin( this, new Gidoo_EventHandler( eName:"Show_AnalysisStatus" ) );

				{
					// <1> Show target puzzle
					string st0 = string.Join("",aPZL.BOARD.ConvertAll(p=>Max(p.No,0))).Replace("0",".");
								//WriteLine( $"btn_SolvePuzzle_Click st0:{st0}" );

					// <2> Solve Puzzle. Verify that its Sudoku Puzzle.
					List<string> stList = pGNPX_Eng.IsSudokuPuzzle_TE_Check( debugPrint:false );

					if( stList.Count != 1 ){  WriteLine( $" System Error. ... btn_SolvePuzzle_Click" ); continue; }

					// <3> Set Puzzle(aPZL) to Solver-Engin.
					pGNPX_Eng.Set_NewPuzzle( aPZL );

					// <4> Initialize Engin.
					pGNPX_Eng.AnMan.Update_CellsState( aPZL.BOARD );
					pGNPX_Eng.AnalyzerCounterReset();

					// <5> Initialize search flag.
					G7.g7MarkA0 = false;
					G7.g7Error  = false;				// ===== Exocet Debug =====
					G7.g7MarkA_MLst0 = new();
					G7.g7_ePZL = null;

					G6.MSlvr_MaxNoAlgorithm = 10;		//

					G6.MSlvr_MaxNoAllAlgorithm = 1000;
					G6.MSlvr_MaxTime = 50000;	//1000 #####			 // Time allowed per algorithm (ms)
					G6.stopped_StatusMessage = "";

					pGNPX_Eng.ReturnToInitial();

				    // <6> Engine start
					await Task.Run(() => pGNPX_Eng.GNPX_Solver_SolveUp(cts.Token) );
				}

			//	if( aPZL.Sol_Result!=null && aPZL.Sol_Result=="Break on step over" )  continue;		// Step limit restrictions. The limit is the specified value

				aPZL.g7MarkA = G7.g7MarkA0;
				aPZL.g7MarkA_Msg = string.Join(" ",G7.g7MarkA_MLst0 );
				if( MSelPzlB && aPZL.g7MarkA && !aPZL.g7Error){
					mSucceed++;
					Dispatcher.Invoke( () => txblk_AnalyzerMessage.Text = aPZL.Name );
					if( (bool)chbx_FileOutputOnSuccess.IsChecked )  Save_SelectedPuzzle_ToFile(dirFileName,aPZL);
				}
				if( G7.g7Error ){ mError++; aPZL.g7Error=true; }			

				this.Dispatcher.Invoke( ()=> { Solving_Message = $" Succeed : {mSucceed}\n  Failed : {mError}\n  Parsed : {++nTested} / {pGNPX_PUZZLE_List.Count}"; } );
				__remainMemo = (nTested-nPre,pGNPX_PUZZLE_List.Count-nPre);
				btn_ClearMark.IsEnabled = true;
			}

			await Task.Delay(200);
			btn_SolvePuzzle.Content="Solve and Marking";

			AnalyzerLap.Stop();
			displayTimer.Stop();
			elp_OnWork.Visibility = Visibility.Hidden;

			// Recover standard conditions.
            G6.MSlvr_MaxNoAlgorithm  = tmpMSlvrMaxAlgorithm;
            G6.MSlvr_MaxTime         = tmpMSlvrMaxTime;

			btn_SavePuzzle.IsEnabled =  GNPX_Puzzle_Global_Control.GNPX_Puzzle_List.Count( P=> P.g7MarkA ) > 0;  //　This operation is allowed only for PU
		
					int Get_BaseID( string name ){
						int n = name.IndexOf("_")+1;
						int n2 = name.IndexOf(" ")-n; 
						return  int.Parse( name.Substring(n,n2) );
					}

					void __Method_CheckMark( bool sel ){
						WriteLine( $"*SolverList_Dev : {SolverList_Dev.Count} methods" );
						foreach( var (mthd,sq) in SolverList_Dev.WithIndex() ){
							if( sel && (mthd.mark_Sel is false) )  continue;
							WriteLine( $"sq:{sq,2} {mthd.NameM.PadRight(30)}  mark_Sel:{(mthd.mark_Sel? "on":"")}" );
						}
					}	
		}

		private void btn_ClearMark_Click(object sender, RoutedEventArgs e) {
			pGNPX_PUZZLE_List.ForEach( P=> {P.g7MarkA=false; P.g7Error=false;} );
			this.Dispatcher.Invoke( ()=> Solving_Message = "" );
		}



	#region <<< Algorithm Selection >>> 

		private void CheckBox_Checked(object sender, RoutedEventArgs e){

			// --- control ---
			var  CheckBox_sender = sender as CheckBox;
			var  Name_sender = CheckBox_sender.Content as string;
			Name_sender = Name_sender.Substring(3);	

			// --- SolverList_Dev ---
			var Q = SolverList_Dev.Find(p=>p.MethodName==Name_sender);
			if( Q != null )  Q.mark_Sel = (bool)CheckBox_sender.IsChecked;
			else{ 
				Send_Command_to_GNPXwin( this, new Gidoo_EventHandler( eName:"Method is inactive" ) );
				Lbl_onAnalyzing.Content = "Method is inactive";
				Lbl_onAnalyzing.Foreground = Brushes.Pink;
				//displayTimer.Stop();
				return;
			}

			// --- Message --- 
			if( SolverList_Dev.Any(p => p.mark_Sel) ){
				txblk_AnalyzerResult.Text = "";
				txblk_AnalyzerResult.Foreground = Brushes.White;
			}

			int mcc = SolverList_Dev.Count(p => p.mark_Sel);
			if( mcc > 0 ){
				lbl_Selected_Method.Content    = $"Selected : {mcc}";
				lbl_Selected_Method.Foreground = Brushes.White;
			}
			else{
				lbl_Selected_Method.Content    = "Specify the Algorithm" ;
				lbl_Selected_Method.Foreground = Brushes.OrangeRed;
			}

			// --- Button Control ---
			btn_SolvePuzzle.IsEnabled = (mcc>0 && pGNPX_PUZZLE_List.Count>0);

			_restoration();
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = SolverList_Dev;

			return;

			// -------------------------------------------------
					void _restoration(){
						object obj = new object();

						switch(sortMode){
							case "ID":		btn_SortByID_Click( obj, null ); break;
							case "Name":	btn_SortByName_Click( obj, null ); break;
							case "Diff":	btn_SortByDifficulty_Click( obj, null ); break;
							case "Marked":	btn_SortByMarked_Click( obj, null); break;
						}
					}
		}



	
	  #region <<< Check conditions >>>

		private void btn_SortByID_Click(object sender, RoutedEventArgs e) {	
			SolverList_Dev.Sort( (a,b)=> (a.ID - b.ID) );
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = SolverList_Dev;
			sortMode="ID";
			//Set_Color( sender, e );
		}
		private void btn_SortByName_Click(object sender, RoutedEventArgs e) {
			SolverList_Dev.Sort( (a,b)=> (a.MethodName.CompareTo(b.MethodName)) );
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = SolverList_Dev;
			sortMode="Name";
			//Set_Color( sender, e );
		}
		private void btn_SortByDifficulty_Click(object sender, RoutedEventArgs e) {
			SolverList_Dev.Sort( (a,b)=> (Abs(a.difficultyLevel) - Abs(b.difficultyLevel)) );
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = SolverList_Dev;
			sortMode="Diff";
			//Set_Color( sender, e );
		}
		private void btn_SortByMarked_Click(object sender, RoutedEventArgs e) {
			SolverList_Dev.Sort( (a,b)=> (a.sortKey - b.sortKey) );
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = SolverList_Dev;
			sortMode="Marked";
			//Set_Color( sender, e );
		}

		private void btn_ResetMark_Click(object sender, RoutedEventArgs e) {
			if( numUD_DifficultyLevel==null || SolverList_Dev==null )  return;

			int difLvl = numUD_DifficultyLevel.Value;
			UAlgMethod.diffLevel = difLvl;

			SolverList_Dev.ForEach( p => p.mark_Sel=false );

			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = SolverList_Dev;
			sortMode="Reset";
			//Set_Color( sender, e );
		}
		private void numUD_DifficultyLevel_ValueChanged(object sender, GIDOOEventArgs args) {
			if( numUD_DifficultyLevel == null )  return;
			btn_ResetMark_Click( sender, new RoutedEventArgs() ); 
		}
	  #endregion << Check conditions >>>

	#endregion <<< Algorithm Selection >>> 

		private void Save_SelectedPuzzle_ToFile( string dirFileName, UPuzzle aPZL ){
			using( var fpW=new StreamWriter( dirFileName, append:true, Encoding.UTF8) ){   
				var eBN = aPZL.BaseName.Split(" "); 	// First name and ID included.
				string line = aPZL.stPZL_withSP + $" {aPZL.difficultyLevel} \"{eBN[0]} {aPZL.Name}\"";
				if( aPZL.TimeStamp!=null && aPZL.TimeStamp!="" )  line += $" \"{aPZL.TimeStamp}\"";
				fpW.WriteLine(line);
			}
		}

		private (int,int) Get_Restart_PuzzleID_FromFile( string fNameSave ){
			int  mSucceed=0;
			if( !File.Exists(fNameSave) )  return (0,0);
			string line="", lineTmp;
			using( var fpR=new StreamReader(fNameSave, Encoding.UTF8) ){
				while( (lineTmp=fpR.ReadLine()) != null ){
					//WriteLine( $"line:{lineTmp}" );
					if( lineTmp.Length <= 2 )  continue;
					line = lineTmp;
					mSucceed++;
				}
			}
			var stLine = line.Split(' ').ToList().FindAll(p=>p.Contains("ID")).First();
			int n = stLine.IndexOf("_")+1;
			int lastID = int.Parse( stLine.Substring(n) );
			return (lastID,mSucceed);
		}



		/*
				public void Save_SelectedPuzzle_ToHTMLFile( UPuzzle aPZL ){
					using( var fpW=new StreamWriter( dirStrSave+"/"+fNameSave, append:true, Encoding.UTF8) ){   
						var P = aPZL;
						string LRecord = P.stPZL_withSP + $" {P.difficultyLevel} \"{P.Name}\" \"{P.TimeStamp}\"";
						fpW.WriteLine(LRecord);
					}
				}
		*/

		private void btn_SavePuzzle_Click(object sender, RoutedEventArgs e) {
			var PZLs = GNPX_Puzzle_Global_Control.GNPX_Puzzle_List.FindAll( P=> P.g7MarkA & !P.g7Error );  //　This operation is allowed only for PU
			
			// Selected Puzzles
			int nc = GNPX_PuzzleFile_Write( fNameSave2, PZLs, append:true, blank9:false );
			txblk_AnalyzerMessage.Text = $"Selected File : {fNameSave2} ... {mSucceed} Puzzles";

			// Puzzles with errors
			var errorPZLs = GNPX_Puzzle_Global_Control.GNPX_Puzzle_List.FindAll( P=> P.g7Error );
			if( errorPZLs.Count > 0 ) {
				string fNameError = fNameSave2.Replace(".txt","_Error.txt");
				GNPX_PuzzleFile_Write( fNameError, errorPZLs, append:true, blank9:false );
				txblk_AnalyzerMessage.Text += $"Error File : {fNameError} ... {errorPZLs} Puzzles";
			}
		}

		private int GNPX_PuzzleFile_Write( string fName, List<UPuzzle> PZLs, bool append=true, bool blank9=false ){
            if( pGPGC.GNPX_Puzzle_List.Count==0 )  return 0;

			int nc = 0;
            using( StreamWriter fpW=new StreamWriter(fName,append,Encoding.UTF8) ){
				int IDsq=0;
                foreach( var P in PZLs ){
                     string line = P.stPZL_withSP + $" {P.difficultyLevel} \"{P.Name}\" \"{P.TimeStamp}\""; 
                     fpW.WriteLine(line);
					 nc++;
                }
            }
			return nc;
		}
	}	
}
