using GIDOO_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Windows.Devices.Power;
using static GNPX_space.GNPX_App_Ctrl;
using static System.Diagnostics.Debug;
using static System.Math;


namespace GNPX_space{
	using pRes = Properties.Resources;
	using pGPGC = GNPX_Puzzle_Global_Control;
    using sysWin=System.Windows;



    public partial class GNPX_App_Ctrl{
	
		private string HTMLName=null;
		public void Save_HTML_of_Puzzle( string fn59S, UPuzzle aPZL ){
			List<UCell>  pBOARD = aPZL.BOARD;

			string folder_GNPX_HTML = pRes.folder_GNPX_HTML;
			if( HTMLName==null || HTMLName== "" )  HTMLName = "GNPX_HTML" + DateTime.Now.ToString("yyyyMMdd")+".html";	
			string HTML_folder_File = folder_GNPX_HTML + "/" + HTMLName;
			string folder_GNPX_HTML_image = $"{pRes.folder_GNPX_HTML}/{fn59S}/";
			if( !Directory.Exists(pRes.folder_GNPX_HTML) ){ Directory.CreateDirectory(folder_GNPX_HTML); }
			if( !Directory.Exists(pRes.folder_GNPX_HTML_image) ){ Directory.CreateDirectory(folder_GNPX_HTML_image); }


				
			{ // Repair Output file 
				if( !File.Exists(HTML_folder_File) ){
					string html = "<!doctype html>\n<html>\n<head>\n<meta charset=\"utf-8\">\n</head>\n<body>";
					using(var fpW=new StreamWriter(HTML_folder_File, append:false, encoding:Encoding.UTF8)){
						fpW.WriteLine(html);
					}
				}
				else{		
					List<string> HTMLList = new();
					string line;
					bool RepairB=false;
					using(var fpR=new StreamReader(HTML_folder_File) ){
						while( (line=fpR.ReadLine()) !=null ){
							if( line == "</body>" ){ RepairB=true;  break; }
							HTMLList.Add(line);
						}
					}
					if( RepairB is true ){
						using(var fpW=new StreamWriter(HTML_folder_File, append:false, encoding:Encoding.UTF8)){
							HTMLList.ForEach( P => fpW.WriteLine(P) );

						}
					}
				}
			}

			{ // Save HTML content
				string styleClearBoth = "<p style=\"clear: both\"></p><br>";
				string htmlResult = (pGNPX_Eng.extResult!="")? pGNPX_Eng.extResult: pGNPX_Eng.ResultLong;
				if( htmlResult == null )  return; 

				if( htmlResult==null || htmlResult==""  )  htmlResult = aPZL.g7HTML;
				if( htmlResult!=null && htmlResult != "" ){
					htmlResult = aPZL.g7HTML;

					string methoName = aPZL.pMethod.MethodName;

					string imageFileName = Save_BOARD_BitMap_forHTML( aPZL, methoName, folder_GNPX_HTML_image );

					string htmlImage = $"<img src=\"{fn59S}/{imageFileName}\" width=\"30%\" style=\"float:left;  margin-right:8px;\" alt=\"{aPZL.pMethod.ToString().Trim()}\"><br>\n";
					if( htmlImage == null )  return; 
					htmlImage = htmlImage.Replace(" (Lv.8)                  ","");
					if( htmlResult == null )  return ;

					htmlResult = "\n<p>" + htmlResult.Replace("\n","<br>\n");
			
					string stPuzzle  = string.Join("",pBOARD.ConvertAll(p=>Max(p.No,0))).Replace("0","."). AddSpace9_81();
					string stCurrent = string.Join("",pBOARD.ConvertAll(p=>Abs(p.No))).Replace("0","."). AddSpace9_81();
				//	string htmlPuzzle = $"{styleClearBoth}\n<p class=\"newLine\">" + imageFileName.Replace(".png","") + "<br>";
					string htmlPuzzle = $"{styleClearBoth}\n<p class=\"newLine\"> {aPZL.BaseName}  <br>";
					htmlPuzzle += $"<small>\n{stPuzzle} Puzzle<br>\n{stCurrent} Current</small><br></p>\n";

					htmlResult = htmlResult.Replace("CoverLines",$"{styleClearBoth}\nCoverLines") + "</p>" ;
					htmlResult = $"{htmlPuzzle}{htmlImage}{htmlResult}\n";
					htmlResult = $"\n<div><tt>\n{htmlResult}</tt></div>";

					using(var fpW=new StreamWriter(HTML_folder_File, append:true, encoding:Encoding.UTF8)){
						fpW.WriteLine(htmlResult);

						string htmlEnd = "\n</body>\n</html>";
						fpW.WriteLine(htmlEnd);
					}
				}
			}
		}

		public string Save_BOARD_BitMap_forHTML( UPuzzle aPZL, string methoName, string dirName ){
			bool G6_sNoAssist = G6.sNoAssist;
			bool G6_sWhiteBack = G6.sWhiteBack;
			G6.sNoAssist  = true;
			G6.sWhiteBack = false;

			GNPX_Graphics    gnpxGrpA = new GNPX_Graphics(pGNPX_App);	
			RenderTargetBitmap  bmpGZeroA = new ( 338, 338, 96,96, PixelFormats.Default );
			var bmp = gnpxGrpA.GBoardPaint( bmpGZeroA, aPZL.BOARD,  sNoAssist:G6.sNoAssist, whiteBack:G6.sWhiteBack );
            var bmf = BitmapFrame.Create(bmp);

			G6.sWhiteBack = G6_sWhiteBack;
			G6.sWhiteBack = G6.sWhiteBack;

            if( !Directory.Exists(dirName) ){ Directory.CreateDirectory(dirName); }		
			
		    BitmapEncoder enc = new PngBitmapEncoder();
			enc.Frames.Add(bmf);
			string imageFileName = Create_imageFileName( methoName, dirName);
            using( Stream stream = File.Create($"{dirName}/{imageFileName}") ){
                enc.Save(stream);
            }    
			return imageFileName;

				string Create_imageFileName( string methoName, string dirName ){
					DirectoryInfo diTop = new DirectoryInfo(dirName);

					List<FileInfo>? files = null;
					if( methoName == "Exocet" ){
						files  = diTop.EnumerateFiles().ToList()
							.FindAll(P => P.Name.Contains(methoName) && !P.Name.Contains("J") && !P.Name.Contains("Single"));
					}
					else{ files  = diTop.EnumerateFiles().ToList().FindAll(P=>P.Name.Contains(methoName)); }

					int maxNo = 0;
					if( files!=null && files.Count>0 ){
						List<int> fileNo = new();
						foreach( var P in files ){
							int n = P.Name.LastIndexOf("_");
							string name1 = P.Name.Substring(n);
							string name2 = Regex.Replace(name1, @"[^0-9]", "");		
							fileNo.Add( name2.ToInt() );
						}
						//var fileNo = files.ConvertAll(p=>p.Name.Replace( @"[^0-9]", ""));
						maxNo  = fileNo.Max();
					}
					string extName = $"{methoName}_{maxNo+1}.png";
					return   extName;
				}
		}

	}
}
