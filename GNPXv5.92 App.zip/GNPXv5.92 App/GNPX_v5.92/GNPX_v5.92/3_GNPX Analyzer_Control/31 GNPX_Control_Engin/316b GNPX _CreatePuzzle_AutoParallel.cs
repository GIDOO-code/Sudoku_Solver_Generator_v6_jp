using GIDOO_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Windows.Devices.Power;
using static GNPX_space.GNPX_App_Ctrl;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using pGPGC = GNPX_Puzzle_Global_Control;
    using sysWin=System.Windows;

    public partial class GNPX_App_Ctrl{
		static private int validTCC;
		private LatinSquareGen LSG = new LatinSquareGen();




		// Parallel
		private List<LatinSquare_9x9>   GNPX_Creator_LS_Parallel_3( CancellationTokenSource cts, int LS_size ){

			try{
				Stopwatch  SW = new();
				SW.Start();
				TimeSpan ts;
				
				G6.Info_CreateMessage0 = $"* Prepare Latin Square ";

			L_CreateLS: // *:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:
				// step1
				G6.Info_CreateMessage1 = $"stage process : 1 / 5";
				G6.Info_CreateMessage2 = $"Set Parameter";

				int errorLS = 0;
				LStep1:
					if( ++errorLS > 5 )  return null;
					string[]  LS_block12347_List = new string[LS_size];
					foreach( int mx in Enumerable.Range(0,LS_size) ){
						var (_,_,stP) = LSG.Set_Parameter(randomB:true);
						LS_block12347_List[mx] = stP;
						G6.LS_P_P2 = mx+1;
					}
				// ----------------------------------------------------------------------------------


				// step2
				G6.Info_CreateMessage1 = $"stage process : 2 / 5";
				G6.Info_CreateMessage2 = $"Generate Lattin Square";

					List<LatinSquare_9x9>[] LSs_List = new List<LatinSquare_9x9>[LS_size];	
					if( LSs_List.Length == 0 )  goto LStep1;
					errorLS = 0;
					int nc=0, LS_Total=0;

					int MaxDegreeOfParallelism = (int)(Environment.ProcessorCount * G6.Processor_Utilization);
					ParallelOptions options3 = new(){ CancellationToken=cts.Token, MaxDegreeOfParallelism=MaxDegreeOfParallelism };

					Parallel.For( 0, LS_size, options3, (mx) => {
						try{
							if( cts.IsCancellationRequested )  throw new Exception("cancel");;
							RTrial = new Research_trial(pAnMan);
							List<string> solList = RTrial.TrialAndErrorApp( LS_block12347_List[mx], filePutB:false, upperLimit:int.MaxValue );
							LSs_List[mx] = solList.ConvertAll(P => new LatinSquare_9x9(P, ApplyPatternB:true, GPat81:PatGen.GPat81, debugB:false) );

							lock(obj){
								//WriteLine( $"---(nc,mx) : ({nc},{mx})" );
								ts = SW.Elapsed;

								G6.Info_CreateMessage3 = $"Created : {++nc} / {LS_size}";
							}
						}
						catch( Exception ){ return; }
					}  );
					//WriteLine("Parallel step2 end" );
					LS_Total = LSs_List.Sum(p=>p.Count);
				// ----------------------------------------------------------------------------------


				// step3
				G6.Info_CreateMessage1 = $"stage process : 3 / 5";
				G6.Info_CreateMessage2 = $"Marge Lattin Square";

					int LS_Count = 0;
					List<LatinSquare_9x9> aLS_List = new List<LatinSquare_9x9>();
				//	Parallel.ForEach( LSs_List, options, (QList) =>{
					foreach( int mx in Enumerable.Range(0,LS_size) ){
						var QList = LSs_List[mx];
						QList.Sort();;

						LatinSquare_9x9 Q = QList.Last();
						long		    preHashVal = Q.hashVal; // The hash value of the LS pattern is used to determine identical patterns.

						QList.ForEach( P=> P.validCC=0 );
						QList.ForEach( P=> {
							if( P.hashVal==preHashVal ){		// Duplicate Detection
								if( (P.validCC=Q.validCC+1) == 1 )  Q.validCC=100;	// Mark the first element of the duplicate
										// =0: Unique.
										// =1: Double overlaps. (Used to identify invalid puzzles)
										// =100: First element of the duplicate
							}
							Q = P;
							preHashVal = Q.hashVal;
						} );
						LS_Count += QList.Count;
							//WriteLine( $"---(nc,mx) : ({nc},{mx})" );
							ts = SW.Elapsed;

							G6.Info_CreateMessage3 = $"Created : {mx+1} / {LS_size}";

						QList = QList.FindAll( Q => Q.validCC<=1 ); // Exclude duplicates of 2 or more.
						aLS_List.AddRange( QList );
					} //);			
				//WriteLine("step3 end" );
				// ----------------------------------------------------------------------------------


				// step4
				G6.Info_CreateMessage1 = $"stage process : 4 / 5";
				G6.Info_CreateMessage2 = $"MMerge the entire Latin Square.";

				aLS_List.Sort();;
				LatinSquare_9x9 QT = aLS_List.Last();
				long            preHashValT = QT.hashVal; // The hash value of the LS pattern is used to determine identical patterns.

				aLS_List.ForEach( PT=> PT.validCC=0 );
				aLS_List.ForEach( PT=> {
					if( PT.hashVal==preHashValT ){
						if( (PT.validCC=QT.validCC+1) == 1 )  QT.validCC=100;	
								// =0: Unique.
								// =1: Double overlaps. (Used to identify invalid puzzles)
								// =100: Deleted LS
					}
					QT = PT;
					preHashValT = QT.hashVal;
				} );
				aLS_List = aLS_List.FindAll( QT => QT.validCC==0 ); // Exclude duplicates of 2 or more.
					
						ts = SW.Elapsed;
						G6.Info_CreateMessage3 = $"Created : {aLS_List.Count:N0} / {LS_Total:N0}";	
						//WriteLine("step4 end" );
				// ----------------------------------------------------------------------------------
		
			
				// step5
				G6.Info_CreateMessage1 = $"stage process : 5 / 5 ... Select by TE";
				G6.Info_CreateMessage2 = $"Lap Time : {ts.TimespanToString()}";		

				int validTCC = 0;
				if( aLS_List!=null && aLS_List.Count > 0 ) {
		
					SW.Restart();
				  //nc = Select_Unique_LatinSquare_Sequence(options3, SW, LS_Total, aLS_List );	// Sequence
					nc = _Select_Unique_LatinSquare_Parallel(options3, SW, LS_Total, aLS_List );	// Parallel ###

					if( nc <= 0 ){
						if( ++G6.LS_P_P1 < G6.LS_Pattern_Cntrl_P1 ){  // Force pattern change
							goto L_CreateLS;	// *:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:*:
						}
						else{	 // Force pattern change
							Send_Command_to_FCreateAuto( this, new Gidoo_EventHandler(eName:"Force_ChangePattern") );
							G6.LS_P_P0 = 0;
							G6.LS_P_P1 = 0;
						}
					}
				}
		
				aLS_List = aLS_List.FindAll( Q => Q.validCC==1 );

				aLS_List.Sort( (a,b) => a.CompareTo2(b) );	// Sorting by actual pattern
				ts = SW.Elapsed;
				G6.Info_CreateMessage2 = $"Lap Time : {ts.TimespanToString()}";
				G6.Info_CreateMessage3 = $"Valid : {validTCC:N0} / {nc:N0} / {aLS_List.Count:N0} / {LS_Total:N0}";
			
				return aLS_List;
			}
			catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }
			return null;

					int _Select_Unique_LatinSquare_Parallel( ParallelOptions options, Stopwatch SW, int LS_Total, List<LatinSquare_9x9> aLS_List ){
						int nc = 0;
						int LSSize = aLS_List.Count;
						int sz = (int)Max( Sqrt(LSSize), 1000 );

						var Grp_aLS_List = aLS_List.Select( (LSlist,n)=> new{LSlist,n}).GroupBy(x=>x.n/sz).ToList();
						validTCC = 0;
						Parallel.ForEach( Grp_aLS_List, options, QQ => {
							Research_trial RTrialQ = new(pAnMan);
							foreach( var P in QQ ){
								if( cts.IsCancellationRequested )  break; 
								if( G6.LS_PatternChangeCommand )  break;

								var stList = RTrialQ.TrialAndErrorApp( P.LSlist.SolX, filePutB: false, upperLimit: 2);
								if( stList.Count == 1 ){
									validTCC++;
									lock(obj){
										if( QuePuzzle.Count < 200 ) this.QuePuzzle.Enqueue(P.LSlist);
										if( QuePuzzle.Count > 200 ) Thread.Sleep(5000);	//Excessive production is suppressed
									}
								}
								P.LSlist.validCC = stList.Count;
							}
							lock(obj){
								nc += QQ.Count();
								G6.Info_CreateMessage3 = $"Valid : {validTCC:N0} / {nc:N0} / {aLS_List.Count:N0} / {LS_Total:N0}";

							//	if( validTCC==0 && nc>100000 )  return; // Stop if no valid patterns are found in 100,000 attempts.  ... Unconfirmed
							}
						} );

						G6.Info_CreateMessage3 = $"Valid : {validTCC:N0} / {nc:N0} / {aLS_List.Count:N0} / {LS_Total:N0}";
						return validTCC;
					}
		}

		// Sequence
		private int Select_Unique_LatinSquare_Sequence(ParallelOptions options, Stopwatch SW, int LS_Total, List<LatinSquare_9x9> aLS_List ){
			int nc=0;
			try{
				Parallel.ForEach(aLS_List, options, Q => {
					Research_trial RTrialQ = new(pAnMan);
					var stList = RTrialQ.TrialAndErrorApp(Q.SolX, filePutB: false, upperLimit: 2);
					if( stList.Count==1 )  validTCC++;
					Q.validCC = stList.Count;

					if( ++nc>50 && (nc%10) == 0) {
						lock(obj){
							TimeSpan ts = SW.Elapsed;
							G6.Info_CreateMessage2 = $"Lap Time : {ts.TimespanToString()}";
							G6.Info_CreateMessage3 = $"Valid : {validTCC:N0} / {nc:N0} / {aLS_List.Count:N0} / {LS_Total:N0}";
						}
					}
				});
			}
			catch(OperationCanceledException e) { }
			finally { /*cts.Dispose();*/ }
			G6.Info_CreateMessage3 = $"Valid : {validTCC:N0} / {nc:N0} / {aLS_List.Count:N0} / {LS_Total:N0}";
			return nc;
		}

	}

}

