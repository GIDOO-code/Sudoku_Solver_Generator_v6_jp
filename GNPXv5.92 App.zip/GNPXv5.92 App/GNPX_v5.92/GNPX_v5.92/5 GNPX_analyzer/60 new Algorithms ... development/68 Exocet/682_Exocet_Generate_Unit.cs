using GIDOO_space;
using GNPX_space;
using System;
using System.Buffers.Text;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml.Linq;
using Windows.Devices.Power;
using static GNPX_space.Exocet_TechGen_68;
using static GNPX_space.SubsetTechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.WebRequestMethods;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine68,UCrossLine68,UCrossLine68);

    public partial class Exocet_TechGen_68 : AnalyzerBaseV2{
		private IEnumerable<UExocet>  IE_Exocet_Generate_Unit( string ExoControl, bool debugPrint=false ){
			
			// ::: #1 Basic Form :::::::::::::::::::::::::::::::::::::
			foreach( UExocet Exo in IE_Exocet_Generate_BasicForm_632( ExoControl:ExoControl, debugPrint:false) ){			
				//if( Exo.dir!=0 || Exo.rcStem!=18 )  continue;	// ===== Exocet_Nxt Debug =====


				// ::: #2 Cross Line(House)  :::::::::::::::::::::::::::::::::::::
				foreach( (int,int,int)  h012 in IE_Generate_CrossLine_HouseNo_634( Exo, debugPrint:false) ){
					//if( h012 != (09,13,15) ) continue; // ===== Exocet_Nxt Debug =====
					

					// ::: #3 Objects :::::::::::::::::::::::::::::::::::::
					foreach( var _ in IE_Exocet_Generate_Object_634( Exo, debugPrint:false) ){
						UCrossLine68 ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;
							//if( ExG1.Object81 != (qOne<<04 | qOne<<13) )  continue; // ===== Exocet_Nxt Debug =====
							//if( ExG2.Object81 != (qOne<<15 | qOne<<15) )  continue; // ===== Exocet_Nxt Debug =====

						//---------------------------------------------------------------------------------
							bool IsValidObject( UExocet Exo, UCrossLine68 ExGm ){
								if( (ExGm.Object81 & BOARD_Fixed81) == qZero )  return true;

								if( (ExGm.FreeB_Object81 & Exo.FreeB).BitCount() <=1 )  return false;		//@@ 
								if( (ExGm.Object81 & BOARD_Fixed81) > qZero )  return true;
								int Frb = ExGm.Object81.Get_FreeB_or();
								return  ((Frb & Exo.FreeB) .BitCount() >= 1 );	// Less than two valid Object is inappropriate
							}

						if( IsValidObject(Exo,ExG1) is false )  continue;	
						if( IsValidObject(Exo,ExG2) is false )  continue;

						//---------------------------------------------------------------------------------
						{ // Object Condition
							// [1] If LockedSet holds, there is no need to use Exocet.
							int FreeB_Obj1 = ExG1.Object81.Get_FreeB_or();
							int FreeB_Obj2 = ExG2.Object81.Get_FreeB_or();
							if( ExG1.Object81.BitCount() == FreeB_Obj1.BitCount() )  continue;		// Object-1 is the LockedSet. 
							if( ExG2.Object81.BitCount() == FreeB_Obj2.BitCount() )  continue;		// Object-2 is the LockedSet.
							
						}

						//---------------------------------------------------------------------------------
						// Prioritize simple solutions and eliminate redundant solutions.
						if( SimpleUniqueSolutions_List.Contains(Exo.hashValue_stBaseObject12) )  continue; // ### Already solved with a simpler solution.			
																									   // 		

						_BaseObj_ = Exo.Base81 | (ExG1.Object81 | ExG2.Object81 );		//( for debug G6_SF.__MatrixPrint(...) )
						// ::: Companion :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
						// Companion is the core element of the Exocet,
							//debugPrint = true;

						{ // [1] First, compute the Companion_Base (frame)
							// CL intersecting cells: Occurs only in FM type.
							UInt128 CL0=ExG0.CrossLine, CL1=ExG1.CrossLine, CL2=ExG2.CrossLine;
							UInt128 CrossLine_Double = (CL0&CL1) | (CL1&CL2) | (CL2&CL0);
							
							UInt128	Board81_Fixed_AggrigaetFreeB =  Exo.FreeB.IEGet_BtoNo().Aggregate( qZero, (a,n) => a | BOARD_Fixed81B9[n] );
							CrossLine_Double &= Board81_Fixed_AggrigaetFreeB; 

								// #[Function] Companion_base ... Exocet_FM type is supported. 	
								UInt128 _Func_Companion_sub( int h, int rc ) => ((h<18)? ( House_81[rc/9+rc%9+9-h] | (House_81[h] & House_81[rc.B()+18])): qZero);	//<<< this is RIGHT. >>>																																			
								UInt128 _Func_Companion( UCrossLine68 ExGM ) => (ExGM.hno<18)? ExGM.Object81.IEGet_rc().Aggregate(qZero, (a,rc) => a| _Func_Companion_sub(ExGM.hno,rc) ): qZero;
					
							Exo.Companion_base = (_Func_Companion(Exo.ExG1) | _Func_Companion(Exo.ExG2)) .DifSet(Exo.EscapeCells | Exo.Object81) | CrossLine_Double; //
								//@@@  In SE_FM type, CrossLine may cross. Having BaseDigit at the crossing point violates the 2-CoverLine rule.
								//     Add the intersection to Companion.
								if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Companion_base, CrossLine_Double, "Exo.Companion_base, CrossLine_Double" );
						}





						// ::: Set SLine :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
						if( Set_SLine( Exo, debugPrint:false) is false )  continue;

						if( Exo.ExoMtdName.Contains("JE1") || Exo.ExocetNamePlus.Contains("SE_Single") ){
							// $$$@@@ Two or more Fixed Base-Digit on SLine are prohibited.  ... There may be other solutions.
							if( Exo.FreeB.IEGet_BtoNo().Any( no=> (Exo.SLine012e & BOARD_Fixed81B9[no]).BitCount()>=2) )  continue;
						}




						// ===== primary Exocet ( JE2/JE+/JE++/ Exocet/Exocet_single/Exocet_singleBase/Exocet_FM )	
						if( Exo.Extend_Type is false ){	
							UInt128 CrossLine = ExG0.CrossLine | (ExG1.hno<18? ExG1.CrossLine: qZero) | (ExG2.hno<18? ExG2.CrossLine: qZero); 
							Exo.Companion = Exo.Companion_base & CrossLine; //Exo.CrossLine_012;
									if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Companion_base, Exo.Companion, CrossLine, "Exo.Companion_base, Exo.Companion, CrossLine" );

							// Primary judgement: Exclude if companion contains Base_Digits.
							int FreeB_Companion = Exo.Companion.Get_FixedFreeB();
							if( (Exo.FreeB & FreeB_Companion) == 0 )   yield return Exo;	 // Passed the Companion-test".

							continue;
						}

#if false
		@@@ FM
							// ===== Extended Exocet ( Complex )	
							if( Exo.Extend_Type is true ){

								// ***  Next development  ***
								throw new Exception( $"Operation Error. Exo.ExocetNamePlus : {Exo.ExocetNamePlus}  ... Next development.");
										//	foreach( var QSExo in A_IE_Create_SLine_Mutant(Exo, debugPrint:false) ){
										//		Exo.Companion = Exo.Companion_base;
										//		yield return Exo;
										//	}
							}
#endif

					}

				}
			}
			yield break;
		}




				// ===== Create SLine ==============================================================================================================================
				private bool Set_SLine( UExocet Exo, bool debugPrint=false ){  // ... for Junior/Senior Exocet 
					UCrossLine68  ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2; 
					UInt128     Escape = Exo.EscapeCells;
					UInt128     Exclude3 = Escape | Exo.Companion_base | Exo.Object81;
					Exo.h_expand = -1;

					// ::: SLine
					UInt128 SLine0 = ExG0.CrossLine & ~Exclude3;					// $$$@@@ // ===== Exocet_Nxt Debug =====
					UInt128 SLine1 = ExG1.CrossLine & ~Exclude3;
					UInt128 SLine2 = ExG2.CrossLine & ~Exclude3;

					UInt128 SLine12 = (SLine1 | SLine2) & Exo.BOARD_Fixed_BaseDigits;
					var (single,more) = SLine12.Get_FreeB_Single_More();
					if( more > 0 )  return false;

								if(debugPrint){
									G6_SF.__MatrixPrint( Flag:_BaseObj_, ExG0.CrossLine, ExG1.CrossLine, ExG2.CrossLine, Exclude3,
										"ExG0.CrossLine, ExG1.CrossLine, ExG2.CrossLine, Escape" );
									G6_SF.__MatrixPrint( Flag:_BaseObj_, SLine0, SLine1, SLine2, Exo.Companion_base, "SLine0, SLine1, SLine2, Exo.Companion_base" );
								}
					
					var SLineList = (new []{SLine0, SLine1, SLine2}).ToList();
		#if false
			@@@ FM
							if( Exo.ExoType=="FM" || Exo.Extend_Type is true ){
								UInt128 BOARD_FreeFixedB9_FreeB = BOARD_FixedB9_noB(Exo.FreeB) | BOARD_FreeB9_noB(Exo.FreeB);
								if( SLineList.Any(S => (S&BOARD_FreeFixedB9_FreeB) == qZero) )  return false;		//@@@ Excludes when SLine have no Base-Digits(Free/Fixed).

								UInt128 Connected_with_Base = Exo.Connected_with_Base & BOARD_FreeB9_noB(Exo.FreeB);
								if( SLineList.Any(S => (S&Connected_with_Base) > 0) ) return false;					//@@@ Excludes Exocet-FM type when SLine and Base are connected.
							}
		#endif
					Exo.SLineList = SLineList;

					return true;
				}



		#if false
			@@@ FM
				===== Next Next =====	

					if( Exo.ExoType=="FM" || Exo.Extend_Type is true ){
						// $$$@@@ The Object is connected to own SLine and other SLines.
						//     This violates the rules of 2-CoverLine and will be excluded.
						//	   Standard Exocet does not apply.

						if( _IsConnected_AnotherSLine(Exo,Exo.ExG0) ) return false; // 0 => SLine1 or SLine2 
						if( _IsConnected_AnotherSLine(Exo,Exo.ExG1) ) return false; // 1 => SLine2 or SLine0 
						if( _IsConnected_AnotherSLine(Exo,Exo.ExG2) ) return false; // 2 => SLine0 or SLine1 
					}

						// #### Connected_Another_SLine
						bool _IsConnected_AnotherSLine( UExocet Exo, UCrossLine68 ExGM ){ 
							UInt128 Obj = ExGM.Object81;
							bool Common_Object_SLine = (ExGM.FreeB_Object81 & ExGM.FreeB_SLine81)==0;
							if( Obj==qZero || Obj==_na_ || Common_Object_SLine ) return false;  //there is no common Base candidate Digits between Object and SLine

							UInt128 SLX = (ExGM.sq==1)? (Exo.SLineList[2] | Exo.SLineList[0]):
										  (ExGM.sq==2)? (Exo.SLineList[0] | Exo.SLineList[1]): (Exo.SLineList[1] | Exo.SLineList[2]);

							UInt128 SLine_Connect_OR = Obj.Aggregate_ConnectedOr() & SLX;
							if( SLine_Connect_OR == qZero ) return false;

							foreach( int no in ExGM.FreeB_Object81.IEGet_BtoNo() ){
								UInt128 SLine_Connect_OR_no = SLine_Connect_OR & BOARD_Free81B9[no];
								// G6_SF.__MatrixPrint( Flag:_BaseObj_, SLine_Connect_OR, SLine_Connect_OR_no, $"SLine_Connect_OR, SLine_Connect_OR_no(#{no+1})" );

								if( SLine_Connect_OR_no > qZero ) return true;
							}
							return false;
						}
				}		
				
				// 9876..5.. 4...8.... ......... .9....3.. ..6.3..79 ...9...56 .395..7.. ..23..9.5 ....92.31 
			private IEnumerable<UInt128> _IE_Create_SLine_Mutant( UExocet Exo, bool debugPrint=false ){
				int     dir=Exo.dir, rcStem=Exo.rcStem, FreeB=Exo.FreeB;
				UCrossLine68  ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2; 

				int b0=rcStem.B(), b1=Exo.ExG1.Object81.Bsingle(), b2=Exo.ExG2.Object81.Bsingle();  // BlockNo of Base, Object1,2
				int     band = (dir==0)? (7<<(b0/3*3)): (0b001001001<<(b0%3));

				UInt128 Companion_base_byFreeB = BOARD_FreeB9_noB(Exo.FreeB) & Exo.Companion_base;
				int extendHouse = 0x3FFFFFF & ~( (qOne<<rcStem | Exo.Base81 | Exo.Object81).Ceate_rcbFrameOr() ); //House excluding [Stem, Base, and Object].
					//WriteLine( $"extendHouse : {extendHouse.TBSrcb()}" ); 

			//	UInt128 Cells_Connected_to_Base = Exo.Base81.Aggregate_ConnectedOr();
				foreach( int hAdd in extendHouse.IEGet_BtoNo(27) ){
					UInt128 SLine_Expand = House_81[hAdd];
					UInt128 CompanionExt = SLine_Expand & Companion_base_byFreeB;
					if( CompanionExt > 0 )  continue;				
					Exo.Companion = CompanionExt;

					Exo.h_expand = hAdd;
					if( Exo.SLineList.Count() >3 )  Exo.SLineList.RemoveAt(3);
					Exo.SLineList.Add( SLine_Expand );
						if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Companion_base, SLine_Expand, CompanionExt, "Exo.Companion_base, SLine_Expand, CompanionExt" );

					yield return SLine_Expand;

				}

				yield break;
			}

		#endif		
	}
}