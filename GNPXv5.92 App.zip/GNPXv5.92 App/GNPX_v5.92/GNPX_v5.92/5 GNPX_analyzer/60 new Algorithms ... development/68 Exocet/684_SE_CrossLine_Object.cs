using GIDOO_space;
using GNPX_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Policy;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen_68;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	using G6_SF = G6_staticFunctions;
	using TapleUCL68 = (Exocet_TechGen_68.UCrossLine68, Exocet_TechGen_68.UCrossLine68, Exocet_TechGen_68.UCrossLine68);

    public partial class Exocet_TechGen_68: AnalyzerBaseV2{

		// ... Generate CrossLine Object ...

		private IEnumerable< (int,int,int) >  IE_Generate_CrossLine_HouseNo_634( UExocet Exo, bool debugPrint=false ){
			int  dir=Exo.dir, rcStem=Exo.rcStem, b0=rcStem.B();
			int  h0 = (dir==0)? (rcStem%9+9): rcStem/9;

		// --- this code is triky, and excelent!  You can verify that it works as intended by setting "debagprint=true".
		//debugPrint=true;

		#region Franken/Mutant
			if( Exo.ExoType == "FM" ){ // ===== Franken/Mutant =====
				int  h_Bit = 0xFF & ~(1<<(b0/3) | (1<<(b0%3+3)) );					// 0xFF(8bit) = rowBlock(3bit) / columnBlock(3bit) + Block(2bit)
					 //h_Bit = h_Bit & 0x3F;				// $$$@@@ SE_Mutant is not confirmed. Changed to Franken only.
				int  b_Bit = 0x1FF & ~( (0b111<<(b0/3*3) | 0b1001001<<(b0%3)) );	// block

				int[]  hList = h_Bit.IEGet_BtoNo(8).Where(p=> p>=0).ToArray();
				int[]  bList = (b_Bit<<18).IEGet_BtoNo(27).Where(p=> p>=0).ToArray();
						if(debugPrint){
							WriteLine( $" rcStem:{rcStem}  b0:{b0}" );
							WriteLine( $" h_Bit:{h_Bit.ToBitString(18,withDot:true)}  b_Bit:{b_Bit.ToBitString(27,withDot:true)}" ); 
							WriteLine( $" hList {string.Join(",",hList)}" );
							WriteLine( $" bList {string.Join(",",bList)}\n" );
						}

				Combination cmb = new(hList.Count(),2);
				int nxt=999;
				while( cmb.Successor(skip:nxt) ){
					int n1=hList[cmb.Index[0]], n2=hList[cmb.Index[1]];
					if( n1>=6 && n2>=6 )  continue;			// // $$$@@@ Combination of two HouseBlocks is excluded.
						
			//if( (n1/3==0 && n2/3==0) || (n1/3==1 && n2/3==1) ) continue;		// $$$@@@ To exclude SEs other than FM, uncomment.

					int[] h1X = (n1<=5)? (new int[]{n1*3,n1*3+1,n1*3+2}): bList;
					int[] h2X = (n2<=5)? (new int[]{n2*3,n2*3+1,n2*3+2}): bList;
						if(debugPrint)  WriteLine( $"h1X h2X  {n1}-{n2}   {string.Join(",",h1X)}    {string.Join(",",h2X)}" );

					int sz1=h1X.Length, sz2=h2X.Length;
					for( int h1n=0; h1n<sz1; h1n++){
						int h1=h1X[h1n];
						for( int h2n=0; h2n<sz2; h2n++ ){
							int h2=h2X[h2n];
							if( (BOARD_Free81 & (House_81[h1] & House_81[h2])) != qZero ) continue;
							if( (BOARD_Free81 & ((House_81[h1] | House_81[h2]) & House_81[h0])) != qZero ) continue;
							Exo.h012 = (h0, h1, h2 );
								if(debugPrint) WriteLine( $" h012 : {Exo.h012}" );
							yield return  Exo.h012;
						}
					}
				}
			}
		#endregion Franken/Mutant

		#region stabdard
			else{ // =============== standard ===============
				int  h_Bit = (dir==0)? (0b111000&~(1<<(b0%3)+3)): 0b111&~(1<<b0/3);
				List<int[]>  hno_List = h_Bit.IEGet_BtoNo(18).Where(p=> p>=0).ToList() .ConvertAll(n=>new int[]{n*3,n*3+1,n*3+2});

				int[] h1X=hno_List[0], h2X=hno_List[1];
				foreach( int kx in Enumerable.Range(0,3*3) ){
					Exo.h012 = (h0, h1X[kx/3], h2X[kx%3] );
						if(debugPrint) WriteLine( $" h012 : {Exo.h012}" );
					yield return  Exo.h012;
				}
			}
		#endregion stabdard

			 yield break;
		}







		private IEnumerable<TapleUCL68> IE_Exocet_Generate_Object_634( UExocet Exo, bool debugPrint=false ){
			var (h0,h1,h2) = Exo.h012;
				// The target generation order is (h0-h1), (h0-h2), (h1-h2).
				// Eliminate duplicate target generation.			

			UInt128 maskJunior = Exo.Band81 .DifSet(Exo.EscapeCells);
			UInt128 maskX	   = qMaxB81    .DifSet(Exo.EscapeCells);	// BOARD_Free81 .DifSet(Exo.EscapeCells)
			UInt128 maskFree, maskFixed;


			switch(Exo.ExocetNamePlus){
				case "JE1":
					maskX = maskJunior;					// Case JExocet, Target/Object is in Band.
					goto case "SE_Single";

				case "SE_Single":						// Case SExocet, Target/Object can be anywhere.
				case "SE_SingleBase":
					if( (Exo.Object81&~Exo.Band81) > qZero )  break;	//@@@ in JE1,SE_Single,SE_SingleBase type, Object is in Band.
					maskFixed = maskX & BOARD_Fixed81;	// ... Junior, Fixed
					maskFree  = maskX & BOARD_Free81;	// ... Junior, Free
					foreach( var EXG3 in IE_Exocet_Generate_Object_sub( Exo, maskFixed, maskFree,  WC1:true,  WC2:false) )  yield return EXG3;
					foreach( var EXG3 in IE_Exocet_Generate_Object_sub( Exo, maskFree,  maskFixed, WC1:false, WC2:true)  )  yield return EXG3;
					break;
			// ====================================================================================================================

				case "JE2":
					maskX = maskJunior;					// ... Junior, Free
					goto case "SE";

				case "SE":
				case "SE_FM":
					maskFixed = maskX & BOARD_Fixed81;	// ... Junior, Fixed
					maskFree  = maskX & BOARD_Free81;	// ... Junior, Free
					foreach( var EXG3 in IE_Exocet_Generate_Object_sub( Exo, maskFree,  maskFree,  WC1:false, WC2:false) )	yield return EXG3;
					break;
			// ====================================================================================================================
			
				default:
					string stException = $"\n\n ExocetNamePlus : \"{Exo.ExocetNamePlus}\" "
									   + "... Next development. Next development. Next development. Next development.\n"
									   + Environment.StackTrace;
					WriteLine( $"\n\n {stException}" );
					throw new Exception( $"Operation Error. Exo.ExocetNamePlus : {Exo.ExocetNamePlus}");
			}

			yield break;
		}



// ==================================================================================================================================
// ==================================================================================================================================

		private IEnumerable<TapleUCL68> IE_Exocet_Generate_Object_sub( UExocet Exo, UInt128 maskCL1, UInt128 maskCL2, bool WC1=false, bool WC2=false, bool debugPrint=false ){
			var (h0,h1,h2) = Exo.h012;
			UInt128  ProhibitedArea = (Exo.Base81 | (qOne<<Exo.rcStem)).Aggregate_ConnectedOr(); // @@@ For FM. Object has a prohibited area.
				//G6_SF.__MatrixPrint( Flag:Exo.Base81, Exo.Base81, ProhibitedArea, "Exo.Base81, ProhibitedArea" );

			UInt128  CL0=House_81[h0], CL1=House_81[h1], CL2=House_81[h2];
						//G6_SF.__MatrixPrint( Flag:Exo.Base81, Exo.Band81, CL0, CL1, CL2, "Exo.Band81, CL0, CL1, CL2," );
						//G6_SF.__MatrixPrint( Flag:Exo.Base81, Exo.Band81, CL0, CL1, CL2, "Exo.Band81, CL0, CL1_TagObj, CL2_TagObj" );
							
			foreach( UCrossLine68 UCL1 in _IESet_Object_on_CrossLine(Exo, sq:1, hno:h1, CLX:CL1, maskCL:maskCL1, WC:WC1) ){	// ... WC:Wildcard
				if( (ProhibitedArea&UCL1.Object81) > qZero) continue;	
				if( WC2 && UCL1.Object81.BitCount()>1 )  continue;		// $$$@@@ The counterpart Object of Wildcard is a single Cell.


				foreach( UCrossLine68 UCL2 in _IESet_Object_on_CrossLine(Exo, sq:2, hno:h2, CLX:CL2, maskCL:maskCL2, WC:WC2 ) ){	// ... WC:Wildcard
					if( (ProhibitedArea&UCL2.Object81) > qZero) continue;
					if( WC1 && UCL2.Object81.BitCount()>1 )  continue;	// $$$@@@ The counterpart Object of Wildcard is a single Cell.
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL0, UCL1.Object81, UCL2.Object81, "Exo.Band81, CL0, UCL1.Object81(WC), UCL2.Object81" );

						var (ExG0,ExG1,ExG2) = _Test_and_Set_Object( Exo, UCL1, UCL2, debugPrint:false );
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, CL0, ExG0.CrossLine, ExG1.CrossLine, ExG2.CrossLine, "CL0, ExG0.CrossLine, ExG1.CrossLine, ExG2.CrossLine" );

	
					// :==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:
						int FreeBObject = Exo.Object81.Get_FixedFreeB();
						if( Exo.FreeB.DifSet(FreeBObject) > 0 )  continue;	 // Violation of Exocet's establishment conditions.
					// :==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:


					if( ExG0 == null )  continue;	// ### The Target/Object must cover the Base_Digits.
					yield return (ExG0,ExG1,ExG2);
				}
			}
			yield break;

			// ===================================================================================================================
					IEnumerable<UCrossLine68> _IESet_Object_on_CrossLine( UExocet Exo, int sq, int hno, UInt128 CLX, UInt128 maskCL, bool WC=false ){
						int	  FreeB0 = Exo.FreeB;
						


						UInt128 CLX_maskCL = CLX & maskCL;
						UInt128 CL_FreeB = CLX_maskCL & BOARD_with_Base_Free;
						if( WC &&  CLX_maskCL.BitCount()<2 )  yield break;
							//	/*if(debugPrint)*/	G6_SF.__MatrixPrint( Flag:Exo.Base81, CLX_maskCL, "CLX_maskCL" );
			
						// <<< Target >>>
						UCrossLine68 UCL;		
						UInt128 Obj = qZero;
						if( WC is false ){	// WC: Wildcard
							foreach( int rc in CLX_maskCL.IEGet_rc().Where(p=> (pBOARD[p].FreeB & FreeB0)>0) ){
								Obj = qOne<<rc;
								if( _Test_Object_Basic_Property(Exo, Obj) )  yield return  (UCL=new(Exo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
							}
						}

						// <<< Object >>>
						Obj = qZero;
						int Block_Object = CLX_maskCL.IEGet_rc().Aggregate(0, (a,rc) => a | 1<<rc.B() );

						foreach( var blk in Block_Object.IEGet_BtoNo() ){
							var rcL = CLX_maskCL.IEGet_rc().Where(rc=>rc.B()==blk).ToArray();
							int sz = rcL.Count();
							if( sz==2 ){
								Obj = qOne<<rcL[0] | qOne<<rcL[1]; 
								if( _Test_Object_Basic_Property(Exo, Obj) )  yield return (UCL=new(Exo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
							}
							if( sz==3 ){	// The validity of size=3 has not been verified.  @@@ sollution /Exocet_examples2B.txt/ Puzzle 05/ step2
								// Case where the object is 3 cells
								Obj = qOne<<rcL[0] | qOne<<rcL[1]; 
								if( _Test_Object_Basic_Property(Exo, Obj) )  yield return  (UCL=new(Exo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );

								Obj = qOne<<rcL[1] | qOne<<rcL[2]; 
								if( _Test_Object_Basic_Property(Exo, Obj) )  yield return  (UCL=new(Exo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );

								Obj = qOne<<rcL[2] | qOne<<rcL[0];  
								if( _Test_Object_Basic_Property(Exo, Obj) )  yield return  (UCL=new(Exo, sq:sq, hno:hno, CrossLine: CLX, Object: Obj) );

								Obj = qOne<<rcL[0] | qOne<<rcL[1] | qOne<<rcL[2];
								if( _Test_Object_Basic_Property(Exo, Obj) )  yield return  (UCL=new(Exo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
							}
						}
						yield break;

								bool _Test_Object_Basic_Property( UExocet Exo, UInt128 obj ){														
									UInt128 objFixed = obj & BOARD_Fixed81;

									if( objFixed != qZero ){										// Objects must not contain fixed digits
										int FreeBFixed = objFixed.Get_FixedFreeB();
										if( (FreeBFixed & Exo.FreeB) > 0 )  return false;
									}
									else{  //if( objFixed == qZero )
										int objFreeB = obj.Get_FreeB_or();	
										if( obj.BitCount() == objFreeB.BitCount() ) return false;	// $$$@@@ Locked set is not compatible with "Object"
									}

									return  true;
								}
					}

					TapleUCL68 _Test_and_Set_Object( UExocet Exo, UCrossLine68 UCLA, UCrossLine68 UCLB, bool debugPrint=false ){
						UInt128  Object1=UCLA.Object81, Object2=UCLB.Object81;

						int h0 = Exo.h012.Item1;
						UCrossLine68 ExG0 = new( Exo, 0, h0, CrossLine:House_81[h0]);
						UCrossLine68 ExG1 = UCLA;
						UCrossLine68 ExG2 = UCLB;

						// ### The Target/Object must cover the Base_Digits.
						if( !UCLA.wildcardB & !UCLB.wildcardB ){	// Neither object is single (wildcard is not defined).
							UInt128 TagObj = Object1 | Object2;
							int FreeB_TO = TagObj.Get_FixedFreeB();
							if( Exo.FreeB.DifSet(FreeB_TO) > 0 )  ExG0 = null;  
						}
						else{
							if( !UCLA.wildcardB && !_Object_test(UCLA) )  ExG0 = null;	// wildcard(SingleBase) excludes _Object_test
							if( !UCLB.wildcardB && !_Object_test(UCLB) )  ExG0 = null;
						}


						// ----------------------------------------------
						// 
						Exo.ExG0=ExG0; Exo.ExG1=ExG1; Exo.ExG2=ExG2;	// Set information in the parent object(Exo).
						// ----------------------------------------------
						return  (ExG0,ExG1,ExG2);

							// The object must have a BaseDigits and enough of that number. 
							bool _Object_test( UCrossLine68 UCLx ){
								UInt128  Objectx=UCLx.Object81;
								int FreeBX = Objectx.Get_FixedFreeB() & Exo.FreeB;
								bool _test = FreeBX>0 && FreeBX.BitCount()>=Objectx.BitCount(); //This determination is required for Object type.
								return _test;
							}
					}
		}
		
		

	}
}