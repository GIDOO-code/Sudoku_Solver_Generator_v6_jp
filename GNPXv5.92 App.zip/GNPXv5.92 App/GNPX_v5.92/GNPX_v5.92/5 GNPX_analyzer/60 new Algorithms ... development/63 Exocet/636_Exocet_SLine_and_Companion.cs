using GIDOO_space;
using GNPX_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Policy;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;

using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		private bool Set_Companion_and_Test( UExocet Exo, bool debugPrint=false ){  // Companion is the core element of the Exocet,	
			UCrossLine ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;
				// #[Function] Companion_base ... Exocet_FM type is supported. 	

					// Fsub(h,rc) => Sum of [direction perpendicular to h of rc] and [within block in h direction]
				  //UInt128 _Func_Companion_sub( int h, int rc ) => ((h<18)? ( House_81[rc/9+rc%9+9-h] | (House_81[h] & House_81[rc.B()+18])): qZero);																																		
					UInt128 _Func_Companion_sub( int h, int rc ) => ((h<18)? ( /*House_81[rc/9+rc%9+9-h] |*/ (House_81[h] & House_81[rc.B()+18])): qZero);	//<<< this is RIGHT. >>>																																			
			
					// F(h,rc) => Sum of Fsub(h,rc) of Object elements
					UInt128 _Func_Companion( UCrossLine ExGM ) => (ExGM.hno<18)? ExGM.Object81.IEGet_rc().Aggregate(qZero, (a,rc) => a| _Func_Companion_sub(ExGM.hno,rc) ): qZero;
			

			// ::: Companion ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
			UInt128 CL0=ExG0.CrossLine, CL1=ExG1.CrossLine, CL2=ExG2.CrossLine;
			UInt128 CrossLine_Overlap = ( (CL0&CL1) | (CL1&CL2) | (CL2&CL0) ) & Board81_Fixed_with_FreeB; // Exo.FreeB.IEGet_BtoNo().Aggregate( qZero, (a,n) => a | BOARD_Fixed81B9[n] );


			// Remove Escape and Object from the F sum of two Objects CrossLine_Overlap
			Exo.Companion_base = ((_Func_Companion(Exo.ExG1) | _Func_Companion(Exo.ExG2)) & ~(Exo.Escape81 | Exo.Object81_AB) ) | CrossLine_Overlap;	
				if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Companion_base, CrossLine_Overlap, "Exo.Companion_base, CrossLine_Overlap" );

			// ===== primary Exocet ( JE2/JE+/JE++/ Exocet/Exocet_single/Exocet_singleBase/Exocet_FM )	
			if( Exo.Exocet_Standard ){	
				UInt128 CrossLine = ExG0.CrossLine | (ExG1.hno<18? ExG1.CrossLine: qZero) | (ExG2.hno<18? ExG2.CrossLine: qZero); 
				Exo.Companion = Exo.Companion_base & CrossLine; //Exo.CrossLine_012;
						if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Companion_base, Exo.Companion, CrossLine, "Exo.Companion_base, Exo.Companion, CrossLine" );

				// Primary judgement: Exclude if companion contains Base_Digits.
				Exo.Companion &= (Board81_Fixed_with_FreeB | Board81_Free_with_FreeB);
				int FreeB_Companion = Exo.Companion .Get_FixedFreeB();
				if( (Exo.FreeB & FreeB_Companion) > 0 )    return false; // Passed the Companion-test".
			}
			return true;
		}


		// ===== Create SLine ==============================================================================================================================
		private bool Set_SLine_and_Test( UExocet Exo, bool debugPrint=false ){  // ... for Junior/Senior Exocet 
			UCrossLine  ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2; 
			UInt128     Exclude_3Elements = Exo.Escape81 | Exo.Companion_base | Exo.Object81_AB;
			Exo.h_expand = -1;

			// ::: SLine
			UInt128 SLine0 = ExG0.CrossLine & ~Exclude_3Elements;
			UInt128 SLine1 = ExG1.CrossLine & ~Exclude_3Elements;
			UInt128 SLine2 = ExG2.CrossLine & ~Exclude_3Elements;

			UInt128 SLine12 = (SLine1 | SLine2);
				if(debugPrint){
					G6_SF.__MatrixPrint( Flag:_BaseObj_, ExG0.CrossLine, ExG1.CrossLine, ExG2.CrossLine, Exclude_3Elements,
						"ExG0.CrossLine, ExG1.CrossLine, ExG2.CrossLine, Exclude_3Elements" );
					G6_SF.__MatrixPrint( Flag:_BaseObj_, SLine0, SLine1, SLine2, Exo.Companion_base, "SLine0, SLine1, SLine2, Exo.Companion_base" );
				}
					
			var SLineList = (new []{SLine0, SLine1, SLine2}).ToList();
			Exo.SLineList = SLineList;
			return true;
		}

	}
}