﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Windows.Media;


namespace GNPX_space{

		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
		//   under development (ver 5.9)
		//   Running tests on a variety of issues for a while now.
		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

			// next ToDo (ver 6.1-)
			//  AHS-Link
			//  1)Incorporating AHS into Chain ("Grouped NiniceLLoop", "ForceChain", ...) 

    public partial class AHSTechGen: AnalyzerBaseV2{
		private List<UAnHS> AHSListX;

		public bool AHS_XZ( ){
			PrepareStage( debugPrintB:false );

            if( AHSMan.AHSList==null || AHSMan.AHSList.Count<=3 ) return false;
			AHSListX = AHSMan.AHSList.FindAll(P => P.CellSize>=3);

			Combination cmb = new( AHSListX.Count(),2 );
			while( cmb.Successor() ){

				UAnHS UAHS1 = AHSListX[cmb.Index[0]];
				UAnHS UAHS2 = AHSListX[cmb.Index[1]];
							//if( UAHS1.stFreeB != "49"  )  continue;	// for debug
							//if( UAHS2.stFreeB != "1349" )  continue;
							//WriteLine( $"\n{UAHS1}\n{UAHS2}" );

				if( BasicCheck_sameHouse(UAHS1, UAHS2) is false )  continue;

				var(flagRCC,RCCList) = Get_RCC_nRCC_List( UAHS1, UAHS2 );




				// ::: AHS_XZ :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
				//	at least 1 X and at least 1 Z
				//		=> Elements that invalidate Z can be excluded.
				//		   If Z is excluded, AHSs will be short of cells.
				if( flagRCC == 3 ){	// Contains both X and Z	

					UInt128 UX = RCCList.FindAll(R=>R.Rtype==1).Aggregate( qZero, (a,R) => a | qOne<<R.rc );
					UInt128 UZ = RCCList.FindAll(R=>R.Rtype==2).Aggregate( qZero, (a,R) => a | qOne<<R.rc );
					int     elimFreeB = UAHS1.FreeB | UAHS2.FreeB;

					foreach( var UC in UZ.IEGet_UCell(pBOARD) ){ UC.CancelB = UC.FreeB.DifSet(elimFreeB); }
					if( pBOARD.All(U=>U.CancelB==0) )  goto  LClear;

					AHSXZ_SolResult( "", UAHS1, UAHS2, UX, UZ, elimFreeB );

					if( !pAnMan.IsContinueAnalysis() )  return true;

				LClear:	
					Clear_Analysis_results();
				}



				// ::: AHS_XZ_Double  :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
				//	at 2 X  => eliminate all digits referencing Z in AHS.
				if( flagRCC>0 && RCCList.Count( R => R.Rtype==1) >= 2 ){

					UInt128 UX = RCCList.FindAll(R=>R.Rtype==1).Aggregate( qZero, (a,R) => a | qOne<<R.rc );
					UInt128 UZ = RCCList.Aggregate( qZero, (a,R) => a | qOne<<R.rc );
					
					int     elimFreeB = UAHS1.FreeB | UAHS2.FreeB;				
					foreach( var UC in UZ.IEGet_UCell(pBOARD) ){ UC.CancelB = UC.FreeB.DifSet(elimFreeB); }

					UInt128 nRCC_1 = UAHS1.AHS_B81 .DifSet(UX|UZ);
					UInt128 nRCC_2 = UAHS2.AHS_B81 .DifSet(UX|UZ);
					foreach( var UC in nRCC_1.IEGet_UCell(pBOARD) ){ UC.CancelB = UC.FreeB .DifSet(UAHS1.FreeB); }
					foreach( var UC in nRCC_2.IEGet_UCell(pBOARD) ){ UC.CancelB = UC.FreeB .DifSet(UAHS2.FreeB); }

					if( pBOARD.Any(U=>U.CancelB==0) ){
						AHSXZ_SolResult( "double", UAHS1, UAHS2, UX, UZ, elimFreeB );
						if( !pAnMan.IsContinueAnalysis() )  return true;
					}

				LClear:	
					Clear_Analysis_results();
				}
			}
            return false;



			
					void AHSXZ_SolResult( string MType, UAnHS UA, UAnHS UB, UInt128 UX, UInt128 UZ, int elmFreeB ){
						string st = "AHS-XZ "+MType;
						Result = st;
            
						if( SolInfoB ){
							var RCCCrl = Color.Multiply(SolBkCr3,0.5f) + Color.Multiply(SolBkCr4,0.5f);
							UA.AHS_B81.IE_SetNoBBgColorNSel( pBOARD, UA.FreeB, AttCr, SolBkCr3 );
							UB.AHS_B81.IE_SetNoBBgColorNSel( pBOARD, UB.FreeB, AttCr, SolBkCr4 );
							UX.IE_SetNoBBgColorNSel( pBOARD, elmFreeB, AttCr, RCCCrl );
							UZ.IE_SetNoBBgColorNSel( pBOARD, elmFreeB, AttCr, SolBkCr );

							string st1 = $"AHS1: {UA.AHS_B81.TBScmp()} #{UA.FreeB.TBScmp()}";
							string st2 = $"AHS2: {UB.AHS_B81.TBScmp()} #{UB.FreeB.TBScmp()}";
							string stR = $"X(RCC): {(UX|UZ).TBScmp()}  X: {UX.TBScmp()}  Z: {UZ.TBScmp()}";
							
							string stE = pBOARD.Where(u=>u.CancelB>0).Aggregate( "", (a,u) => a+ $" {u.rc.ToRCString()}#{u.CancelB.TBScmp()}" );
							stE = stE.ToString_SameHouseNoCompEx();			// (ver.6.0- Compressed Representation of RCN

							ResultLong = $"{st}\n {st1}\n {st2}\n {stR}\n\n {stE} is negative";
							Result	   = $"{st} {st1.Replace(" ","")} {st2.Replace(" ","")}";
						}
					}
        }
    }
}
 