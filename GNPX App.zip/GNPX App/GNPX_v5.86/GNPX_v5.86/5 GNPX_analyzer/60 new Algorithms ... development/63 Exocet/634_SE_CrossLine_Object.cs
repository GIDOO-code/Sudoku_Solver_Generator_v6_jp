using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using System.Windows.Documents;
using GNPX_space;
using static GNPX_space.Exocet_TechGen;
using System.Security.Policy;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Xml.Linq;
using System.Security.AccessControl;
using System.Windows.Input;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		// ... Generate CrossLine Object ...

		private IEnumerable< (int,int,int) >  IE_Generate_CrossLine_HouseNo( USExocet SExo, bool debugPrint=false ){	// Change the placement position. #####
			int  dir=SExo.dir, rcStem=SExo.rcStem, h0=0;
			List<int>  h1HxList, h2HxList;

			if( dir==0 ){
				h0 = rcStem %9 + 9;
				int SC = ((rcStem+3)%9)/3*3 + 9;	// +9 : column
				h1HxList = new[]{SC+0, SC+1, SC+2}.ToList();
				
				SC = ((rcStem+6)%9)/3*3 + 9;
				h2HxList = new[]{SC+0, SC+1, SC+2}.ToList();
			}
			else{
				h0 = rcStem/9;
				int SR = (rcStem/27*3+3)%9;
				h1HxList = new[]{SR+0, SR+1, SR+2}.ToList();
				SR = (rcStem/27*3+6)%9;
				h2HxList = new[]{SR+0, SR+1, SR+2}.ToList();
			}

			foreach( int kx in Enumerable.Range(0,3*3) ){
				var h012 = (h0, h1HxList[kx/3], h2HxList[kx%3] );
								if(debugPrint) WriteLine( $" h012 : {h012}" );
				SExo.h012 = h012;
				yield return h012;
			}

			yield break;
		}


		private IEnumerable<TapleUCL> IE_SE_Generate_Object( USExocet SExo, bool debugPrint=false ){
			var (h0,h1,h2) = SExo.h012;
				// The target generation order is (h0-h1), (h0-h2), (h1-h2).
				// Eliminate duplicate target generation.			

			UInt128 maskJunior = SExo.Band81 .DifSet(SExo.EscapeCells);
			UInt128 maskX = qMaxB81 .DifSet(SExo.EscapeCells);	// BOARD_Free81 .DifSet(SExo.EscapeCells)
			UInt128 maskFree, maskFixed;
			switch(SExo.ExocetNamePlus){

				case "JE1":
					maskX = maskJunior;					// Case JExocet, Target/Object is in Band.
					goto case "SE_Single";

				case "JE2":
					maskX = maskJunior;					// ... Junior, Free
					goto case "SE";
				// ====================================================================================================================

				case "SE_Single":						// Case SExocet, Target/Object can be anywhere.
				case "SE_SingleBase":
					maskFixed = maskX & BOARD_Fixed81;	// ... Junior, Fixed
					maskFree  = maskX & BOARD_Free81;	// ... Junior, Free
					foreach( var EXG3 in IE_SE_Generate_Object_sub( SExo, maskFixed, maskFree,  WC1:true,  WC2:false) )  yield return EXG3;
					foreach( var EXG3 in IE_SE_Generate_Object_sub( SExo, maskFree,  maskFixed, WC1:false, WC2:true)  )  yield return EXG3;
					break;

				case "SE":
				case "SE_Mutant":
					maskFixed = maskX & BOARD_Fixed81;	// ... Junior, Fixed
					maskFree  = maskX & BOARD_Free81;	// ... Junior, Free
					foreach( var EXG3 in IE_SE_Generate_Object_sub( SExo, maskFree,  maskFree,  WC1:false, WC2:false)  )  yield return EXG3;
					break;
				// ====================================================================================================================
				
				default:
					WriteLine( $"\n\n ExocetNamePlus : {SExo.ExocetNamePlus} ... Next development. Next development. Next development. Next development.\n\n\n" );
					throw new Exception( $"Operation Error. SExo.ExocetNamePlus : {SExo.ExocetNamePlus}");

			}

			yield break;

		}


// ====================================================================================================================
// ====================================================================================================================

		private IEnumerable<TapleUCL> IE_SE_Generate_Object_sub( USExocet SExo, UInt128 maskCL1, UInt128 maskCL2, bool WC1=false, bool WC2=false, bool debugPrint=false ){
			var (h0,h1,h2) = SExo.h012;
			UInt128  CL0=HouseCells81[h0], CL1=HouseCells81[h1], CL2=HouseCells81[h2];
						//G6_SF.__MatrixPrint( Flag:SExo.Base81, SExo.Band81, CL0, CL1, CL2, "SExo.Band81, CL0, CL1, CL2," );
						//G6_SF.__MatrixPrint( Flag:SExo.Base81, SExo.Band81, CL0, CL1, CL2, "SExo.Band81, CL0, CL1_TagObj, CL2_TagObj" );

			foreach( UCrossLine UCL1 in _IESet_Object_on_CrossLine(SExo, sq:1, hno:h1, CLX:CL1, maskCL:maskCL1, WC:WC1) ){							
				foreach( UCrossLine UCL2 in _IESet_Object_on_CrossLine(SExo, sq:2, hno:h2, CLX:CL2, maskCL:maskCL2, WC:WC2 ) ){	// ... WC:Wildcard
						if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, SExo.Band81, CL0, UCL1.Object81, UCL2.Object81, "SExo.Band81, CL0, UCL1.Object81(WC), UCL2.Object81" );
							
					var (ExG0,ExG1,ExG2) = _Test_and_Set_Object( SExo, UCL1, UCL2, debugPrint:false );	//


				// :==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:
					int FreeBObject = SExo.Object81.Get_FreeB();
					if( SExo.FreeB.DifSet(FreeBObject) > 0 )  continue;	 // Violation of Exocet's establishment conditions.
				// :==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:==:


					if( ExG0 == null )  continue;	// ### The Target/Object must cover the Base_Digits.
					yield return (ExG0,ExG1,ExG2);
				}
			}
			yield break;

			// ===================================================================================================================
					IEnumerable<UCrossLine> _IESet_Object_on_CrossLine( USExocet SExo, int sq, int hno, UInt128 CLX, UInt128 maskCL, bool WC=false ){
						int	  FreeB0 = SExo.FreeB0;
						
						UInt128 BOARD_noB81	= BOARD_Free81B9_noB( SExo.FreeB0 );

						UInt128 CLX_maskCL = CLX & maskCL;
						UInt128 CL_FreeB = CLX_maskCL & BOARD_noB81;
						if( WC &&  CLX_maskCL.BitCount()<2 )  yield break;
							//	/*if(debugPrint)*/	G6_SF.__MatrixPrint( Flag:SExo.Base81, CLX_maskCL, "CLX_maskCL" );
			
						// <<< Target >>>
						UCrossLine UCL;		
						UInt128 Obj = qZero;
						if( WC is false ){	// WC: Wildcard
							foreach( int rc in CLX_maskCL.IEGet_rc().Where(p=> (pBOARD[p].FreeB & FreeB0)>0) ){
								Obj = qOne<<rc;
								if( !Exclude_by_Single_type(SExo, WC, Obj) )  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
							}
						}

						// <<< Object >>>
						Obj = qZero;
						int Block_Object = CLX_maskCL.IEGet_rc().Aggregate(0, (a,rc) => a | 1<<rc.B() );

						foreach( var blk in Block_Object.IEGet_BtoNo() ){
							var rcL = CLX_maskCL.IEGet_rc().Where(rc=>rc.B()==blk).ToArray();
							int sz = rcL.Count();
							if( sz==2 ){
								Obj = qOne<<rcL[0] | qOne<<rcL[1]; 
								if( !Exclude_by_Single_type(SExo, WC, Obj) )  yield return (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
							}
							if( sz==3 ){	// The validity of size=3 has not been verified.  @@@ sollution /Exocet_examples2B.txt/ Puzzle 05/ step2
								Obj = qOne<<rcL[0]|qOne<<rcL[1]; 
								if( !Exclude_by_Single_type(SExo, WC, Obj) )  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );

								Obj = qOne<<rcL[1]|qOne<<rcL[2]; 
								if( !Exclude_by_Single_type(SExo, WC, Obj) )  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );

								Obj = qOne<<rcL[2]|qOne<<rcL[0];  
								if( !Exclude_by_Single_type(SExo, WC, Obj) )  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine: CLX, Object: Obj) );

								Obj = qOne<<rcL[0]|qOne<<rcL[1]|qOne<<rcL[2];
								if( !Exclude_by_Single_type(SExo, WC, Obj) )  yield return  (UCL=new(SExo, sq:sq, hno:hno, CrossLine:CLX, Object:Obj) );
							}
						}
						yield break;

								bool Exclude_by_Single_type( USExocet SExo, bool WC, UInt128 obj ){
									if( !WC || !SExo.ExocetNamePlus.Contains("Single") )  return false;								
									int FreeBFixed = obj.IEGet_UCell(pBOARD).Aggregate(0, (a,U)=> a| (1<<Abs(U.No)-1) );  // Since Object is fixed, be calculated using this formula.
									if( (FreeBFixed & SExo.FreeB0) > 0 )  return true;		
									return  false;
								}
					}

					TapleUCL _Test_and_Set_Object( USExocet SExo, UCrossLine UCLA, UCrossLine UCLB, bool debugPrint=false ){
						UInt128  Object1=UCLA.Object81, Object2=UCLB.Object81;

						int h0 = SExo.h012.Item1;
						UCrossLine ExG0 = new( SExo, 0, h0, CrossLine:HC81[h0]);
						UCrossLine ExG1 = UCLA;
						UCrossLine ExG2 = UCLB;

									if(debugPrint){
										UInt128 BaseTagObj = SExo.Base81 | Object1 | Object2;
										G6_SF.__MatrixPrint( Flag:BaseTagObj, ExG0.Object81, ExG0.Mirror81, "ExG0.Object ExG0.Mirror81" );
										G6_SF.__MatrixPrint( Flag:BaseTagObj, ExG1.Object81, ExG1.Mirror81, "ExG1.Object ExG1.Mirror81" );
										G6_SF.__MatrixPrint( Flag:BaseTagObj, ExG2.Object81, ExG2.Mirror81, "ExG2.Object ExG2.Mirror81" );
									}

						// ### The Target/Object must cover the Base_Digits. Here, the decision can be made in one place.
						if( !UCLA.wildcardB & !UCLB.wildcardB ){
							UInt128 TagObj = Object1 | Object2;
							int FreeB_TO = TagObj.Get_FreeB();
							if( SExo.FreeB.DifSet(FreeB_TO) > 0 )  ExG0 = null;  
						}
						else{
							if( !UCLA.wildcardB && !_Object_test(UCLA) )  ExG0 = null;		//wildcard(SingleBase) excludes _Object_test
							if( !UCLB.wildcardB && !_Object_test(UCLB) )  ExG0 = null;
						}


					// ----------------------------------------------
						SExo.ExG0=ExG0; SExo.ExG1=ExG1; SExo.ExG2=ExG2; 
						// ----------------------------------------------
						return  (ExG0,ExG1,ExG2);

							// The object must have a BaseDigits and enough of that number. 
							bool _Object_test( UCrossLine UCLx ){
								UInt128  Objectx=UCLx.Object81;
								int FreeBX = Objectx.Get_FreeB() & SExo.FreeB0;
								bool _test = FreeBX>0 && FreeBX.BitCount()>=Objectx.BitCount(); //This determination is required for Object type.
								return _test;
							}
					}
		}
		
		

	}
}