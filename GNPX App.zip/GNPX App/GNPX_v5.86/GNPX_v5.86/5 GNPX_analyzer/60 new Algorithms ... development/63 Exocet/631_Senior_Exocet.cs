using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using System.Windows.Documents;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen;
using System.Diagnostics;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Windows.Media.Animation;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@

	// Important note
	//  Code based on flawed logic can still lead to correct results.
	//  Correctness of the output does not necessarily imply correctness of the logic.
	//  If the results are wrong, the code is wrong.
	//
	// In  GNPX(v6-), the solution to the puzzle is found through T&E.
	//  Any incorrect output is detected immediately.

	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{
	//	static public PrimitiveContainer UPC = new PrimitiveContainer();

		private UInt128 ObjectSq(UInt128 obj, int sq ) => obj | ((UInt128)sq)<<100;


		private string ExoControl;
		public bool Junior_Exocet_JE2( ) => Exocet_General( ExoControl:"name:JE2" );
		public bool Junior_Exocet_JE1( ) => Exocet_General( ExoControl:"name:JE1" );

		public bool SExocet()			 => Exocet_General( ExoControl:"name:SE"  );
		public bool SExocet_Single()	 => Exocet_General( ExoControl:"name:SE type:Single"  );
		public bool SExocet_SingleBase() => Exocet_General( ExoControl:"name:SE type:SingleBase"  );
		public bool SExocet_Mutant()	 => Exocet_General( ExoControl:"name:SE type:Mutant"  ); 


		// [TBD]  Senior Exocet Extend
		// [TBD]  Mirror behavior in Senior Exocet

        public bool Exocet_General( string ExoControl ){

			// ::: Prepare :::
			if( stageNoP != stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
				Prepare_SExocet_TechGen( printB:false );	//debugPrint );
			}

			ElementElimination_Manager_UT("Initialize");	
			foreach( var SExo in IE_Exocet_Generate_Unit(ExoControl) ){


				//if( SExo.FreeB.DifSet(SExo.Object81.Get_FreeB()) > 0 )   WriteLine( $"##### SExo.FreeB:{SExo.FreeB.TBS()}  SExo.Object81.Get_FreeB();{SExo.Object81.Get_FreeB().TBS()}" );



					// ::: SLine Is covered? :::
					if( SE_Is_Covered_with_SLine(SExo,debugPrint:false) is false )  continue;
						if( IsValid_CL_by_type(SExo) is false ) goto LClear;	

						if( SExo.FreeB.DifSet(SExo.Object81.Get_FreeB()) > 0 )   WriteLine( $"##### SExo.FreeB:{SExo.FreeB.TBS()}  SExo.Object81.Get_FreeB();{SExo.Object81.Get_FreeB().TBS()}" );

			/*
									if( SExo.SEtype=="Mutant" ){
										int noBnCover = SExo.CL_bySize_noB[9];
										int noB1_nCover = SExo.ExG1.Object81.Get_FreeB() & noBnCover;
										int noB2_nCover = SExo.ExG2.Object81.Get_FreeB() & noBnCover;
										if( noB1_nCover>0 && noB2_nCover>0 )  continue;
									}
			*/
						// ::: Check roule
						bool solFound = SE_ph5_Exclude_Test( SExo );
						if( !solFound || pBOARD.Any(uc=> uc.No==0 && uc.FreeB0==0) ) goto LClear; 

						if( pBOARD.All(uc=> uc.No!=0 || uc.CancelB==0) ) goto LClear; 

						// ::: Results report
						SE_ph6_Result( SExo, debugPrint:false );	//debugPrint );
						if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid

					// ::: Final processing 
				LClear:	
					foreach( var UC in pBOARD.Where(p=>p.No==0) ) UC.CancelB=0;
					pBOARD.ForEach( UC => UC.ECrLst=null );
					ElementElimination_Manager_UT("Initialize");
			}
			return false;			
		}

		private void SE_ph6_Result( USExocet SExo, bool debugPrint ){
			string  ExocetName=SExo.ExocetName, ExocetNamePlus=SExo.ExocetNamePlus;

			UCrossLine ExG1=SExo.ExG1, ExG2=SExo.ExG2;
			var		 (rcBase1,rcBase2) = SExo.Base81.Get_rc1_rc2();
			
			int FreeB0 = SExo.FreeB0;
			UInt128	 SLine1=ExG1.SLine, SLine2=ExG2.SLine;

			// <<<<< Result ...  coloring, create message  >>>>>
			try{
				SolCode = 2;

			  // ::: Base
				SExo.Base81.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr );	

			  // ::: Object, Companion, Mirror
				Color cr = SolBkCr2G;
				int FB0 = FreeB0;
				if( (ExocetName.Contains("JE1") || SExo.ExocetNamePlus.Contains("_Single")) && SExo.ExG1.wildcardB && ExG1.Object81 !=_na_){
					SExo.ExG1.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
				}

				if( ExocetNamePlus.Contains("SE_SingleBase") ){
					if( SExo.ExG1.phantomObjectB ) SExo.ExG1.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
					if( SExo.ExG2.phantomObjectB ) SExo.ExG2.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
				}
				else{
					SExo.ExG1.Object81.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr2G );
					if(ExG2.Object81!=_na_)  SExo.ExG2.Object81.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr2G ); 			
				}

				SExo.ExG1.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
				SExo.ExG2.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 

				if(SExo.Companion!=_na_) SExo.Companion.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr2A );
				
				if( ExG1.Mirror81!=_na_) ExG1.Mirror81.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr6 );
				if( ExG2.Mirror81!=_na_) ExG2.Mirror81.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr6 );

			// ::: SLine
				if( SExo.SLineList.Count()>3 )  SExo.SLineList[3].IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr3A );	
				SExo.SLineList[0].IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr4 );
				SExo.SLineList[1].IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr3 );
				SExo.SLineList[2].IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr3 );

			// ::: Report
				string stBase  = $"B:{SExo.Base81.TBScmp()}#{SExo.FreeB0.ToBitStringN(9)} Companion:{SExo.stCompanions}";
				string stObjL1 = $"T1:{ExG1.stObject} M1:{ExG1.stMirror81}";
				string stObjL2 = $"T2:{ExG2.stObject} M2:{ExG2.stMirror81}";
				
				string stBaseL  = $"   Base: {SExo.Base81.TBScmp()}#{SExo.FreeB0.ToBitStringN(9)}";
				string stObjL1L = $"Object1: {ExG1.stObject}  Mirror1:{ExG1.stMirror81}";
				string stObjL2L = $"Object2: {ExG2.stObject}  Mirror2:{ExG2.stMirror81}";
				string stWildcard = (SExo.WildCardB!=0)? $"Wildcard: #{SExo.WildCardB.ToBitStringN(9)}": "";
				string stSLine  = $"   SLine: {SExo.st_SLine_House()}";

				string stExocetP = (SExo.SEtype=="")? ExocetNamePlus: $"{ExocetName}_{SExo.SEtype}";
				Result     = $"��{stExocetP} {stBase} T1:{ExG1.stObject} T2:{ExG2.stObject}";
				
				string stL = $"{stBaseL}\n   {stObjL1L}\n   {stObjL2L}\n  {stSLine}\n   Companion:{SExo.stCompanions}";
				ResultLong = $"Senior Exocet_{stExocetP}\n   {stL}";

				extResult  = $"Senior Exocet_{stExocetP}\n  @dir:{SExo.dir}  @Stem:{SExo.rcStem.ToRCString()}\n\n   {stL}";
				
				if( SExo.ExocetName.Contains("JE1") || SExo.ExocetNamePlus.Contains("_Single") ){
					ResultLong += $"\n   {stWildcard}";
					extResult  += $"\n   {stWildcard}";
				}

				extResult += $"\n\n CoverLines (p:Parallel x:Cross){SExo.stCoverLines}";
				extResult += $"\n {SExo.stCrossCoverLineB}";

				extResult += $"\n\n{new string('-',80)}\n Explanation of candidate digits exclusion\n";
				
				string stE = string.Join( "\n", extResultLst );
					int n1=stE.Length, n2;
					do{
						stE = stE.Replace("@\n@","@");
						if( n1==(n2=stE.Length) ) break;
						n1 = n2;
					}while(true);
				extResult += stE.Replace("+\n","+").Replace("@","\n").Replace("\n\n","\n").Replace("\n","\n  ");
					if(debugPrint)  WriteLine( "@@"+extResult );
			}
			catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }

			return;
					
		}
	}
}