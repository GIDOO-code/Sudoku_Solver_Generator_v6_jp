using System;
using System.Collections.Generic;
using System.Linq;
using static System.Math;

using GIDOO_space;
using static GNPX_space.Firework_TechGen;
using System.Windows.Documents;
using static GNPX_space.Exocet_TechGen;
using System.Runtime.InteropServices;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Buffers.Text;
//using static GNPX_space.JExocet_TechGen;

namespace GNPX_space{
		using G6_SF = G6_staticFunctions;
    public partial class Exocet_TechGen: AnalyzerBaseV2{
		static char[] sep=new Char[]{ ' ', ',', '\t' };  


	// ===================================================
	// For future expansion, this is over-implemented.
	// ===================================================

	// ::: Code to support the Object extension of Target.
	// ::: If Target is a Cell, there is simpler code.
	

		public partial class  USExocet{
			static public List<UCell>   qBOARD;	
			static private UInt128[] HC81 =>	HouseCells81;
			
			public string		 ExocetControl = null;

			public string		 ExocetName;
			public string		 ExocetNamePlus;
			public string		 SEtype => Inquiry("type").Replace("type:","");

			public int			 dir;			// 0:row, 1:column
			public int			 rcStem;
			public (int,int,int) h012;

			public UInt128		 Base81;
			public UInt128		 Band81;
			public UInt128		 EscapeCells = qZero;
			public UInt128       Companion_base;
			public UInt128		 Companion = _na_;
			public UInt128		 CompanionExt;
			public List<UInt128> SLineList = new List<UInt128>();
			public UInt128		 SLine_Exp => (SLineList.Count()>3)? SLineList[3]: _na_;

			public UCrossLine	 ExG0;	
			public UCrossLine	 ExG1;
			public UCrossLine	 ExG2;


			public UCoverStatus[]  CoverStatusList;
			public int[]		   CL_bySize_noB;
			public (int,int)[]	   CrossCoverLineB;

			public USExocet( string ExocetName, int dir, int rcStem, UInt128 Base81, int freeB0, UInt128 BOARD_Free81 ){
				this.ExocetControl  = ExocetName;
				__Set_SEName();

				this.dir			= dir;
				this.rcStem			= rcStem;
				this.Base81			= Base81;
				this.Band81			= _Band81();

				this.EscapeCells	= ((HC81[rcStem/9]|HC81[rcStem%9+9]) & Band81) .DifSet(Base81);

				UInt128 SLine_Exp	= qZero;
			}

			public override string ToString( ){
				string st = $" USExocet dir:{dir} rcStem:{rcStem.ToRCString(),2} FreeB:{FreeB.TBS()}";
				st += "stCLxBase() + stExGx();";
				return st;
			}
		}
					public partial class  USExocet{		
						public int		FreeB		=> Base81.IEGet_UCell(qBOARD).Aggregate(0, (a,uc) => a| uc.FreeB );

						public int		FreeB0		=> Base81.IEGet_UCell(qBOARD).Aggregate(0, (a,uc) => a| uc.FreeB_Updated() );

						public UInt128  CrossLine_012 => HC81[h012.Item1] | HC81[h012.Item2] | HC81[h012.Item3];

						public UInt128	SLine012e	=> SLineList.Aggregate(qZero, (a,U) => a|U);
						public int		house012_or;
						public int      h_exp;

						public int[]    CL_bySize_Count => CL_bySize_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();

						public string   stBase		 => $"{Base81.ToRCStringComp()}";
						public string   stCoverLines => CoverStatusList.Where(p=>p!=null).Aggregate(" ",(a,ch)=> a+$"\n {ch.ToString()}");
						public string   stCrossCoverLineB => "CrossCoverLineB  one:" + CrossCoverLineB.Aggregate("", (a,b) => a+ " "+	b.Item1.TBS() ) +
														   "\n                 two:" + CrossCoverLineB.Aggregate("", (a,b) => a+ " "+	b.Item2.TBS() );		
						public int		WildCardB	 => CL_bySize_noB[3] ;
					

						// <<< ExocetControl --> ExocetName, ExocetNamePlus >>>
						private string Inquiry( string que ){					
							List<string> eLst = ExocetControl.Split(sep,StringSplitOptions.RemoveEmptyEntries).ToList();
							string?  q = eLst.FindLast(p=>p.Contains(que));	
							return (q==null)? "": q;
						}

						private void __Set_SEName(){
							ExocetName = Inquiry("name").Replace("name:","");

							string SE_type  = Inquiry("type").Replace("type:","");
							if( SE_type != "" ) SE_type = "_"+SE_type;
							ExocetNamePlus = ExocetName + SE_type;
						}

						private UInt128  _Band81(){
							int blk = rcStem.B(), sft=(dir==0)? 1: 3;
							int blk0 = 18 + ((dir==0)? blk/3*3: blk%3);
							UInt128 Band81 = HC81[blk0] | HC81[blk0+sft] | HC81[blk0+sft*2];
							return  Band81;
						}

						public UInt128 Object81 => ExG1.Object81 | ExG2.Object81;

						public string st_SLine_House(){
							int[] HSL = new []{ExG0.hno, ExG1.hno, ExG2.hno};
							string st = ((dir==0)? $"c": "r") + string.Join( "",HSL.ToList().ConvertAll(p=>p%9+1) );
							
							if( SLine_Exp!= qZero )  st += $" /Ext. {h_exp.HouseToString()}";
							return st;
						}
						public string   stCompanions => Companion.TBScmp();
						public string stExGx(){
							string st =  (ExG0==null)?  "  ExG0:n/a": $"\n  ExG0:{ExG0}";
								   st += (ExG1==null)?  "  ExG1:n/a": $"\n  ExG1:{ExG1}";
								   st += (ExG2==null)?  "  ExG2:n/a": $"\n  ExG2:{ExG2}";
							return st;
						}
					}


		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

		public partial class UCrossLine{
			static public List<UCell>	qBOARD;

			public USExocet SExo;
			public int		sq;
			public int		hno;
			public int		rcTag	   = int.MaxValue;
			public bool		wildcardB  = false;
			public UInt128  Object81   = _na_;
			public bool		phantomObjectB = false;
			public UInt128  CrossLine  = _na_;
			public UInt128  SLine      => SExo.SLineList[sq-1];

			public UInt128  Mirror81F  = _na_;
			public UInt128  Mirror81   = _na_;
			public int		FreeB_SLine = 0;

			public UCrossLine(){
				this.sq = -9999;
			}

			public UCrossLine( USExocet SExo, int sq, int hno, UInt128 CrossLine ){
				this.SExo		= SExo;
				this.sq			= sq;
				this.hno		= hno;
				this.CrossLine  = CrossLine;
			}

			public UCrossLine( USExocet SExo, int sq, int hno, UInt128 CrossLine, UInt128 Object ):
								this( SExo, sq, hno, CrossLine ){
				if( Object.BitCount()==1 )  this.rcTag = Object.FindFirst_rc();
				this.Object81	= Object & qMaxB81;

				this.wildcardB = this.Object81.IEGet_UCell(qBOARD).All(u=> u.No!=0);
			}
		}

				public partial class UCrossLine{
					public int		Get_Target_FreeB_Updated_Or() => Object81.IEGet_rc().Aggregate( 0x1FF, (a,rc) => a | qBOARD[rc].FreeB_Updated() );
					//public UInt128  Object81 => UInt128.One<<rcTag;		// For compatibility. Will sort it out eventually.

					public int      FreeB_Object81  => Object81.IEGet_UCell(qBOARD) .Aggregate( 0, (a,uc)=> a| uc.FreeB_Updated() ); 
					public int      FreeB_Mirror81  => Mirror81.IEGet_UCell(qBOARD) .Aggregate( 0, (a,uc)=> a| uc.FreeB ); 
					public int      FreeB_Mirror81withFixed => Mirror81F.IEGet_UCell(qBOARD) .Aggregate( 0, (a,uc)=> a| uc.FreeB_Updated_withFixed() ); 

					public string   stObject		=> Object81.TBScmp();
					public string   stMirror81		=> Mirror81.TBScmp();


					public UInt128 Get_FullSight( bool withExclusion ){
						if( withExclusion ){ return Object81.IEGet_rc().Aggregate( qMaxB81, (a,rc) => a & ConnectedCells81[rc].Reset(rc) ); }
						else{				 return Object81.IEGet_rc().Aggregate( qMaxB81, (a,rc) => a & ConnectedCells81[rc] ); }
					}

				}




		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
		public class UCoverStatus{
			public int	 no;
			public int   sz;
			public int	 CLH_0 = -1;	// house no. if h>100, then Cross-Line.
			public int	 CLH_1 = -1;
			public int	 CLH_2 = -1;

			public UCoverStatus( int no, int sz, int CLH_0, int CLH_1, int CLH_2 ){
				this.no = no;
				this.sz = sz;
				this.CLH_0=CLH_0; this.CLH_1=CLH_1;	this.CLH_2=CLH_2;
			}

			public override string ToString( ){
				string st = $" no:#{no+1} size:{sz}";
				       st += $"  CoverLine: {_ToStHouse(CLH_0)} {_ToStHouse(CLH_1)} {_ToStHouse(CLH_2)}";
				return st;
			
					string _ToStHouse(int hh){
						string st="";
						if( hh<0 )  st = "----";
						else{
							int h = hh%100;			
							st = ((h<9)? "r": (h<18)? "c": "b") + ((h%9)+1).ToString()
							   + ((hh<100)? "_p": (h<18)? "_x": "_*");
						}
						return st.PadRight(5);
					}
			}
		}

	} 


}