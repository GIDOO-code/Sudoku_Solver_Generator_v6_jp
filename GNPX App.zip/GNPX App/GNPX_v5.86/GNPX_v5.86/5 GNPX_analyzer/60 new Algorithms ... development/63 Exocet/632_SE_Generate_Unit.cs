using GIDOO_space;
using GNPX_space;
using System;
using System.Buffers.Text;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml.Linq;
using Windows.Devices.Power;
using static GNPX_space.Exocet_TechGen;
using static GNPX_space.SubsetTechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen : AnalyzerBaseV2{
		private IEnumerable<USExocet>  IE_Exocet_Generate_Unit( string ExoControl, bool debugPrint=false ){
			
			// ::: #Phase1 :::::::::::::::::::::::::::::::::::::
			foreach( USExocet SExo in IE_Exocet_BasicForm( ExoControl:ExoControl, debugPrint:false) ){			
						//if( SExo.dir!=0 || SExo.rcStem!=80 )  continue;			// ===== SE_Nxt Debug =====
						//if( SExo.Base81 != (qOne<<60) )  continue;				// ===== SE_Nxt Debug =====

				int     dir = SExo.dir;
				UInt128 Escape = SExo.EscapeCells;

				// ::: #Phase2 :::::::::::::::::::::::::::::::::::::
				foreach( (int,int,int)  h012 in IE_Generate_CrossLine_HouseNo( SExo, debugPrint:false) ){
						//if( h012 != (17,11,12) )  continue; // ===== SE_Nxt Debug =====
						//if( h012 == (15,11,12) )  WriteLine( h012 );

					// ::: #Phase3 :::::::::::::::::::::::::::::::::::::
					foreach( var _ in IE_SE_Generate_Object( SExo, debugPrint:false) ){
						UCrossLine ExG0=SExo.ExG0, ExG1=SExo.ExG1, ExG2=SExo.ExG2;
							//if( ExG1.Object81 != (qOne<<56 | qOne<<65) )  continue; // ===== SE_Nxt Debug =====
							//if( ExG2.Object81 != (qOne<<48 | qOne<<48) )  continue; // ===== SE_Nxt Debug =====

						_BaseObj_ = SExo.Base81 | (ExG1.Object81 | ExG2.Object81 );	//( for debug G6_SF.__MatrixPrint(...) )




						// ::: Companion :::::::::::::::::::::::::::::::::::::
						SExo.Companion_base = SExo.Object81.IEGet_rc()
										.Aggregate(qZero, (a,rc) => a| ( (HC81[(1-dir,rc).DRCHf()] & HC81[rc.B()+18]) | HC81[(dir,rc).DRCHf()]) )
										.DifSet(Escape | SExo.Object81);

						SExo.Companion = SExo.Companion_base & SExo.CrossLine_012;
								if(debugPrint) G6_SF.__MatrixPrint( Flag:_BaseObj_, SExo.Companion_base, SExo.Companion, "SExo.Companion_base, SExo.Companion" );
								//debugPrint = true; // ===== SE_Nxt Debug =====

						int FreeB_Companion = SExo.Companion.Get_FreeB();
						if( ( SExo.FreeB & FreeB_Companion ) > 0 )  continue;		// ... Primary judgement by companion ...
											//	if( ( SExo.FreeB & FreeB_Companion ) > 0 ){		// ... Primary judgement by companion ...
											//		foreach( var UC in pBOARD.Where(p=>p.No==0) ) UC.CancelB=0;
											//		pBOARD.ForEach( UC => UC.ECrLst=null );
											//		ElementElimination_Manager_UT("Initialize");
											//		continue;
											//	}



						// ::: SLine :::::::::::::::::::::::::::::::::::::
						if( SExo.SEtype != "Mutant" ){	// ... for JE, SE 
							_Create_SLine( SExo, debugPrint:false );
							yield return SExo;
						}

						else{							// ... Mutant
							foreach( var QSExo in _IE_Create_SLine_Mutant(SExo, debugPrint:false) )  yield return SExo;
						}
					}
				}
			}
			yield break;
		}


		// ===== Create SLine ==============================================================================================================================
		private void _Create_SLine( USExocet SExo, bool debugPrint=false ){  // ... for JE, SE 
			UCrossLine  ExG0=SExo.ExG0, ExG1=SExo.ExG1, ExG2=SExo.ExG2; 
			UInt128     Escape = SExo.EscapeCells;
			//UInt128     _BaseObj_ = SExo.Base81 | (ExG1.Object81 | ExG2.Object81 );

			// ::: SLine
			UInt128 Block_Object0 = SExo.Object81.IEGet_rc().Aggregate(qZero, (a,rc) => a| HC81[(SExo.dir,rc).DRCHf()] );
			UInt128 Block_Object  = SExo.Object81.IEGet_rc().Aggregate(qZero, (a,rc) => a| (HC81[rc.B()+18] | SExo.Object81) );
					
			UInt128 SLine0 = ExG0.CrossLine .DifSet( SExo.Companion | Block_Object0 | SExo.Band81 );
			UInt128 SLine1 = ExG1.CrossLine .DifSet( SExo.Companion | Block_Object  | Escape );
			UInt128 SLine2 = ExG2.CrossLine .DifSet( SExo.Companion | Block_Object  | Escape );
			SExo.SLineList.Clear();
			SExo.SLineList.AddRange( new []{SLine0, SLine1, SLine2} );
				
			// ::: Mirror
			ExG1.Mirror81 = qZero; ExG2.Mirror81 = qZero;
			if( ExG1.Object81.IEGet_UCell(pBOARD).Any(U=>U.No==0) ){	// ... not defined for SingleBase
				ExG1.Mirror81 = HC81[ExG2.Object81.FindFirst_rc().B()+18] & ExG2.Object81.Aggregate_ConnectedOr()
								. DifSet( ExG1.Object81.Aggregate_ConnectedOr() | SExo.CrossLine_012 | Escape);
			}

			if( ExG2.Object81.IEGet_UCell(pBOARD).Any(U=>U.No==0) ){	// ... not defined for SingleBase
				ExG2.Mirror81 = HC81[ExG1.Object81.FindFirst_rc().B()+18] & ExG1.Object81.Aggregate_ConnectedOr()
								. DifSet( ExG2.Object81.Aggregate_ConnectedOr() | SExo.CrossLine_012 | Escape);
			}
													
					if(debugPrint){
						G6_SF.__MatrixPrint( Flag:_BaseObj_, SExo.Companion, ExG0.SLine, ExG1.SLine, ExG2.SLine, "Companion, ExG0.SLine, ExG1.SLine_x, ExG2.SLine_x" );
						G6_SF.__MatrixPrint( Flag:_BaseObj_, ExG1.Mirror81, ExG2.Mirror81, "ExG1.Mirror81, ExG2.Mirror81" );
					}
		}		


		// 9876..5.. 4...8.... ......... .9....3.. ..6.3..79 ...9...56 .395..7.. ..23..9.5 ....92.31 
		private IEnumerable<USExocet> _IE_Create_SLine_Mutant( USExocet SExo, bool debugPrint=false ){
			int     dir=SExo.dir, rcStem=SExo.rcStem, FreeB=SExo.FreeB;

			int b0=rcStem.B(), b1=SExo.ExG1.Object81.Bsingle(), b2=SExo.ExG2.Object81.Bsingle();  // BlockNo of Base, Object1,2
			int     band = (dir==0)? (7<<(b0/3*3)): (0b001001001<<(b0%3));

			UInt128 BOARD_FreeB81 = BOARD_Free81B9_noB(SExo.FreeB0) & SExo.Companion_base;
			int extendHouse = 0x3FFFFFF & ~( (qOne<<rcStem | SExo.Base81 | SExo.Object81).Ceate_rcbFrameOr() );
				//WriteLine( $"extendHouse : {extendHouse.TBSrcb()}" ); 

		//	if( band.IsHit(b1) && band.IsHit(b1) ){		// two Objects are in Band
				//int exH = _Get_HouseMutant(dir,band,b0);// & ~Object_FRame;
				foreach( int hAdd in extendHouse.IEGet_BtoNo(27) ){
					UInt128 SLine_Ext = HC81[hAdd];
					UInt128 CompanionExt = SLine_Ext & BOARD_FreeB81; 
					if( CompanionExt > 0 )  continue;				

					_Set_SLine_SE(SExo, debugPrint:false );

					SExo.h_exp = hAdd;
					SExo.SLineList.Add( SLine_Ext );
					if(debugPrint){	G6_SF.__MatrixPrint( Flag:_BaseObj_, SExo.SLine012e, SExo.Companion_base, SExo.Companion, "Companion, ExG0.SLine, ExG1.SLine_x, ExG2.SLine_x" );
					}

					yield return SExo;
				}
		//	}

		//	else{}

			yield break;
		}
				void _Set_SLine_SE( USExocet SExo, bool debugPrint=false ){
					UInt128 SLine0 = SExo.ExG0.CrossLine & ~SExo.Band81;
					UInt128 SLine1 = SExo.ExG1.CrossLine & ~SExo.Band81;
					UInt128 SLine2 = SExo.ExG2.CrossLine & ~SExo.Band81;
					SExo.SLineList.Clear();
					SExo.SLineList.AddRange( new []{ SLine0, SLine1, SLine2 });
						if(debugPrint) G6_SF.__MatrixPrint( Flag:_BaseObj_, SExo.ExG0.SLine, SExo.ExG1.SLine, SExo.ExG2.SLine, 
										"SExo.ExG0.SLine, SExo.ExG1.SLine, SExo.ExG2.SLine," );
				}

		
	}
}