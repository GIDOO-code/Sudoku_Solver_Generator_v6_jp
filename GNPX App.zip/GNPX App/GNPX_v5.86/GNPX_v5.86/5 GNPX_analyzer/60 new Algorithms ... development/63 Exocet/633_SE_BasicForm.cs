using GIDOO_space;
using GNPX_space;
using System;
using System.Buffers.Text;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen;
using static GNPX_space.SubsetTechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen : AnalyzerBaseV2{

		private IEnumerable<USExocet> IE_Exocet_BasicForm( string ExoControl, bool debugPrint=false ){
			// dir, StemCell => BaseCells, FreeB, SLine0, block1, block2

			for( int dir=0; dir<2; dir++ ){	// direction  0:row 1:column
				for( int rcStem=0; rcStem<81; rcStem++ ){

					// ... Base cells
					int     hBase = (dir,rcStem).DirRCtoHouse( );
					UInt128 base81 = (HouseCells81[hBase] & HouseCells81[rcStem.B()+18] & BOARD_Free81) .Reset(rcStem);
					
					// ... Single SE : Base is a single-cell and bivalue.)  @@@ BIVALUE |||
					if( ExoControl.Contains("SingleBase") ){	
						foreach( UCell UC in base81.IEGet_UCell(pBOARD).Where(uc=>uc.FreeBC==2) ){
							USExocet SExo = _Create_SExocetObject( ExoControl, dir, rcStem, qOne<<UC.rc, UC.FreeB );
							if( SExo != null )  yield return SExo;
						}
					}

					else{ // ... Normal ........................................................
						if( base81.BitCount() != 2 )  continue;					// ... Number of bits in Base. Base-cells are unfixed

						// ... Base candidates
						var (rcA,rcB) = base81.BitToTupple();					// (There are definitely two cells.)
						int  FreeB_UCA=pBOARD[rcA].FreeB,  FreeB_UCB=pBOARD[rcB].FreeB;
						// if( (FreeB_UCA & FreeB_UCB) == 0 )  continue;			// Has common digits. ... This condition is not accepted.

						// [req1] The Base Cells together contain 3 or 4 Candidates, that we call Base Candidates.
						int FreeB  = FreeB_UCA | FreeB_UCB;		
						int FreeBC = FreeB.BitCount();
					
						if( FreeBC<3 || FreeBC>5 )  continue;	
							// 2:LockedSet 6-:Hopeful predictions. ... Exocet_extend loosens restrictions.

						USExocet SExo = _Create_SExocetObject( ExoControl, dir, rcStem, base81, FreeB );
						if( SExo != null )  yield return SExo;
					}
				}
			}
			yield break;

		// ===================================================================================================================================
				USExocet _Create_SExocetObject( string ExoControl, int dir, int rcStem, UInt128 Base81A,int FreeB ){
					UInt128 CrossLine0  =  HouseCells81[(1-dir,rcStem).DRCHf()] .DifSet( HouseCells81[rcStem.B()+18] );
					if( (CrossLine0 & BOARD_Free81) == qZero )  return null;

					USExocet SExo = new( ExoControl, dir, rcStem, Base81A, FreeB, BOARD_Free81 );
							if(debugPrint) WriteLine( $" CrossLine0:{CrossLine0.TBS()}" );

					return SExo;
				}
		}
	}

}