﻿using System.Windows;

namespace GNPX_FileConverter {
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application {
    }

}
