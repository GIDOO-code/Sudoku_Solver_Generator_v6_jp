﻿using Microsoft.Win32;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace GNPX_FileConverter {
    using ioPath = System.IO.Path;

    public partial class MainWindow : Window {
        private List<string> SLines;
        private List<string> SLines_cv;
        private string fName;

        private ScrollViewer _scrollViewer1;
        private ScrollViewer _scrollViewer2;

        public MainWindow( ) {
        InitializeComponent();
        }

        private void btn_Source_Click(object sender, RoutedEventArgs e) {
        var openFile = new OpenFileDialog {
            Multiselect = false,
            Title = "Source File",
            Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        };

        if((bool)openFile.ShowDialog()) {
        fName = openFile.FileName;
        txb_Source.Text = fName;

        SLines = new List<string>();
        using(StreamReader fRead = new StreamReader(fName)) {
        string line;
        while((line = fRead.ReadLine()) != null) {
        SLines.Add(line);
        }
        }
        lbl_records.Content = $"{SLines.Count} records";
        ListView_Puzzle.ItemsSource = SLines;

        SLines_cv = new List<string>();
        int n = 0;
        foreach(var line in SLines) {
        int solX = line.IndexOf("sol:");
        string line2 = $"{line.Substring(0, 89)} 99 \"{txb_ID.Text}_{++n} {line.Substring(solX, 89)}\"";
        SLines_cv.Add(line2);
        }
        ListView_Puzzle_cv.ItemsSource = SLines_cv;
        }
        }

        private void btn_FilePut_Click(object sender, RoutedEventArgs e) {
        string fName2 = $"{ioPath.GetDirectoryName(fName)}/{ioPath.GetFileNameWithoutExtension(fName)}_A{ioPath.GetExtension(fName)}";
        using(StreamWriter wd = new StreamWriter(fName2)) {
        foreach(var p in SLines_cv) {
        wd.WriteLine(p);
        }
        }

        }


        #region  Scroll synchronization
        private void ListView_Puzzle_Loaded(object sender, RoutedEventArgs e) {
        _scrollViewer1 = GetDescendantByType<ScrollViewer>(ListView_Puzzle);
        if(_scrollViewer1 != null)
            _scrollViewer1.ScrollChanged += ScrollViewer1_ScrollChanged;
        }

        private void ListView_Puzzle_cv_Loaded(object sender, RoutedEventArgs e) {
        _scrollViewer2 = GetDescendantByType<ScrollViewer>(ListView_Puzzle_cv);
        if(_scrollViewer2 != null)
            _scrollViewer2.ScrollChanged += ScrollViewer2_ScrollChanged;
        }

        private void ScrollViewer1_ScrollChanged(object sender, ScrollChangedEventArgs e) {
        // If the scroll position is the same, do not process (to prevent infinite loops).
        if(_scrollViewer2 != null && _scrollViewer2.VerticalOffset != _scrollViewer1.VerticalOffset) {
        _scrollViewer2.ScrollToVerticalOffset(_scrollViewer1.VerticalOffset);
        }
        }

        private void ScrollViewer2_ScrollChanged(object sender, ScrollChangedEventArgs e) {
        if(_scrollViewer1 != null && _scrollViewer1.VerticalOffset != _scrollViewer2.VerticalOffset) {
        _scrollViewer1.ScrollToVerticalOffset(_scrollViewer2.VerticalOffset);
        }
        }

        // A helper method for retrieving elements of a specified type from a visual tree.
        private static T GetDescendantByType<T>(DependencyObject element) where T : DependencyObject {
        if(element == null)
            return null;
        if(element is T t)
            return t;

        for(int k = 0; k < VisualTreeHelper.GetChildrenCount(element); k++) {
        var result = GetDescendantByType<T>(VisualTreeHelper.GetChild(element, k));
        if(result != null)
            return result;
        }
        return null;
        }
        #endregion  Scroll synchronization

    }
}