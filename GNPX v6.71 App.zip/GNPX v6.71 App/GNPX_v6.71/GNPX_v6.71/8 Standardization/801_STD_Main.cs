using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Printing;
using System.Printing.IndexedProperties;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography;
using System.Windows.Documents;
using System.Windows.Navigation;

using GIDOO_space;


using static System.Diagnostics.Debug;
using static System.Math;

namespace STD_SDK{

    public partial class  standardization_Man{
        static int[,] permIdx = { {0,1,2}, {0,2,1}, {1,0,2}, {1,2,0}, {2,0,1}, {2,1,0} };
        private void __sp() => WriteLine( new string('-',60) );

        public Standard_Form STD_form;

        public string PuzzleStandardCode => STD_form.PuzzleStandardCode;

        public override string ToString( ) => STD_form.ToString();

        public string Standard_Report() => STD_form.Standard_Report();


        // -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

        public standardization_Man( ){ }


        public  Standard_Form Standardization( string stPuzzle ){
            int[]? boardSrc = stPuzzle.stringToIntArray();
            return Standardization( boardSrc );
        }

        public  Standard_Form Standardization( int[,] boardSrc_2D ){
            int[] boardSrc = boardSrc_2D.Cast<int>().ToArray();
            return Standardization( boardSrc );
        }


        public  Standard_Form Standardization( int[] boardSrc, bool debugPrint=false ){
            int kx=0;  
            List<Trans_para> TP_List_1 = [ new(boardSrc), new( Transpose_Board(boardSrc) ) ];
            TP_List_1[1].transpos = 1;
                if(debugPrint){ __sp(); kx=0; TP_List_1.ForEach( P => P.board.PrintBoard( $"TP_List_1[{kx++}] {P}") ); }

            List<Trans_para>  TP_List_2 = Step2_Eval_R1C123( TP_List_1, debugPrint:debugPrint );
            List<Trans_para>  TP_List_3 = Step3_Eval_R1CBnd23C456789( TP_List_2, debugPrint:debugPrint );      
            List<Trans_para>  TP_List_4 = Step4_Eval_R23( TP_List_3, debugPrint:debugPrint );
            List<Trans_para>  TP_List_5 = Step5_Eval_RBnd23( TP_List_4, debugPrint:debugPrint );
            
         // List<Standard_Form> STD_form_List = Step6_Eval_Numerical_standardization_Serial( TP_List_5, boardSrc, debugPrint:debugPrint );
            List<Standard_Form> STD_form_List = Step6_Eval_Numerical_standardization_Parallel( TP_List_5, boardSrc, debugPrint:debugPrint );
           
            if( STD_form_List==null || STD_form_List.Count==0 ){
                //throw new Exception("Invalid Puzzle", null);
                return null;
            }
            STD_form_List.Sort( );

            STD_form = STD_form_List[0];
            return STD_form_List[0];
        }
    }


}