using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Timers;

using DLX_V2;

using GIDOO_space;

using GNPX_space;

using static System.Diagnostics.Debug;
using static System.Math;


namespace STD_SDK{
    public partial class standardization_Man{
        static public (int,int) progressCounters; 

        public void STD_Application_1( string fName, List<v7_UPuzzle_Base> puzzle_A_List, CancellationToken ct ){

            int index = 0;
            var indexLock = new object();
            var FileLock = new object();

            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string outFname = $"{fName}_PuzzleStandardCode_{timestamp}.csv";

            File.WriteAllText(outFname, "PuzzleNo, Puzzle, StandardPuzzle, PuzzleStandardCode\n", Encoding.UTF8);

            int nc=0, nCount=puzzle_A_List.Count;
            var options = new ParallelOptions { CancellationToken=ct };
            foreach( var (vs7_Pzl,k) in puzzle_A_List.WithIndex() ){
                if( ct.IsCancellationRequested )  break;
                standardization_Man STDman = new();
                STDman.Standardization( vs7_Pzl.stPuzzle );

                string PuzzleStandardCode = STDman.STD_form.PuzzleStandardCode;
                string stPzlA = vs7_Pzl.ToString();

                string stPzlS = STDman.STD_form.stStandardPuzzle;
                string line = $"{k+1}, \"{stPzlA}\", \"{stPzlS}\", \"{PuzzleStandardCode}\"\n";
                    
                File.AppendAllText(outFname, line);
                nc++;
                progressCounters = (nc,nCount);
            }

            return;
        }
    }
}