using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Navigation;

using GIDOO_space;

using static System.Diagnostics.Debug;
using static System.Math;

namespace STD_SDK{

    public class Trans_para{
        public int[]   board = null;
        public List<int>  board_1D_01 => board.Cast<int>().ToList().ConvertAll(n=>(n>0?1:0));

        public int     transpos;             // 0: None / 1: Transposed
        public int     RowBndIdx;            // 0-5
        public int[]   RowIdx = new int[3];  // [3] 0-5
        public int     ColBndIdx;            // 0-5
        public int[]   ColIdx = new int[3];  // [3] 0-5
              
        public Trans_para(){ }

        public Trans_para( int[] board=null ) => this.board=board;

        public Trans_para Copy(){
            Trans_para TPcopy = (Trans_para)this.MemberwiseClone();
            if( board  != null ) TPcopy.board  = (int[])board.Clone(); 
            if( RowIdx != null ) TPcopy.RowIdx = (int[])RowIdx.Clone(); 
            if( ColIdx != null ) TPcopy.ColIdx = (int[])ColIdx.Clone(); 
            return TPcopy;
        }

        public void CopyTo( Trans_para TPto ){
            if( TPto == null )  return;
            TPto.transpos = transpos;
            TPto.RowBndIdx = RowBndIdx;
            TPto.ColBndIdx = ColBndIdx;
            for( int k=0; k<3; k++ ){
                TPto.RowIdx[k] = RowIdx[k];
                TPto.ColIdx[k] = ColIdx[k];
            }    
        }

        public void Clear(){
            transpos = 0;
            RowBndIdx = ColBndIdx = 0;
            RowIdx = new int[3];
            ColIdx = new int[3];
        }


        public override string ToString( ) {
            string st = $" transpos: {transpos}";
            st += $"  Row: {RowBndIdx} ({string.Join(",",RowIdx)}) / Col: {ColBndIdx} ({string.Join(",",ColIdx)})";
            return st;
        }

        public void Set_TP_RandomTP( Random rnd ) {
            transpos = rnd.Next(2);
            RowBndIdx = rnd.Next(6);
            ColBndIdx = rnd.Next(6);
            for(int k=0; k<3; k++){
                RowIdx[k] = rnd.Next(6);
                ColIdx[k] = rnd.Next(6);
            }
        }
    }


    
        
    public partial class Standard_Form: IComparable{
        private string[] stExchange = { "None", "Line2 <-> Line3", "Line1 <-> Line2", "Rotation (1,2,3->(2,3,1)", "Rotation (1,2,3)->(3,1,2)", "Line1 <-> Line3" };
        private string[] stBandExchange = { "None", "Band2 <-> Band3", "Band1 <-> Band2", "Rotation (1,2,3->(2,3,1)", "Rotation (1,2,3)->(3,1,2)", "Band1 <-> Band3" };

        public Trans_para TP;
        public UInt128   PuzzleCode;

        public int[]     original_Puzzle;
        public int[]     standard_5_Placement_norm ;
        public int[]     standard_6_norm_Solution ;
        public int[]     standard_Puzzle_Solution;   
        public int[]     standard_Puzzle;
            
        public int[]     Standard_Digits;

        public int[]     normalize_digConv;   // [10] Mapping table for Block 1 Normalization

        public string    stStandardPuzzle => string.Join("",standard_Puzzle).Replace("0",".").ToStringWithSpace();

        public string    stPuzzleSolution2 => string.Join("",standard_Puzzle).ToStringWithSpace(27).Replace("0","");
                        
        private string   _stPuzzleStandardBitCode;
        public string    stDigitsConv;
        public string    PuzzleStandardCode;

        public TimeSpan  lapsTime;

        private object obj = new();

        public Standard_Form( int[] boardSrc, Trans_para TP=null ){
            this.original_Puzzle = boardSrc;
            this.TP = TP;
            if( TP == null ) this.TP = new Trans_para(boardSrc);
        }

        public int CompareTo( object obj ){
            Standard_Form STD = (Standard_Form)obj;
            return string.Compare( this.PuzzleStandardCode, STD.PuzzleStandardCode);
        } 
        public  void  Set_PuzzleStandardCode(){
            _stPuzzleStandardBitCode = _Get_RowOctalPuzzleCode(standard_Puzzle);
            stDigitsConv = string.Join("",normalize_digConv);
            PuzzleStandardCode = $"{stPuzzleSolution2} {_stPuzzleStandardBitCode}"; 

                    string _Get_RowOctalPuzzleCode( int[] board ){
                        string stOctalCode = "0o";
                        lock(obj){
                            for( int r=0; r<9; r++ ){
                                int rc0=r*9, rc1=rc0+9, rowBit=0, w=0;
                                for( int rc=rc0; rc<rc1; rc++ ){
                                    w = (w<<1) | ((board[rc]>0)? 1: 0);
                                    if( rc%3 == 2 ){ rowBit= (rowBit*10+w); w=0; }
                                }
                                stOctalCode += $" {rowBit:D3}";
                            }
                        }
                        return stOctalCode;
                    }
                /*  --- Block-order coding was not adopted.
                    string _Get_BlockOctalPuzzleCode( int[] board ){
                        string stOctalCode = "0o";
                        lock(obj){
                            for( int b=0; b<9; b++ ){
                                int startR=(b/3)*3, startC=(b%3)*3, blockBit=0;

                                for( int r=startR; r<startR+3; r++ ){
                                    int rowBit = 0;
                                    for( int c=startC; c<startC+3; c++ ){ rowBit = (rowBit<<1) | ((board[r*+c]>0)? 1: 0);}
                                    blockBit = (blockBit<<3) | rowBit;
                                }
                                stOctalCode += $" {blockBit:D3}";
                            }
                        }
                        return stOctalCode;
                    }
                */
        } 


        public override string ToString(){
            string st = new string('=', 80)+"\n";
            st += "【 Sudoku Standardization 】\n\n";
#if DEBUG
            st += $"@@@TP : {TP.RowBndIdx},{TP.RowIdx[0]},{TP.RowIdx[1]},{TP.RowIdx[2]} / {TP.ColBndIdx},{TP.ColIdx[0]},{TP.ColIdx[1]},{TP.ColIdx[2]} / {TP.transpos}";	
#endif
            st += $"[Matrix Transposition] : {(TP.transpos==1? "Diagonal Flip" : "None")}\n\n";
                
            st += $"[Row Band Exchange]  : #{TP.RowBndIdx} {stBandExchange[TP.RowBndIdx]}\n";
            if( TP.RowIdx !=null ){
                st += $"[Inner Row Exchange] : ├─ Row Band[0]-#{TP.RowIdx[0]}(1-3) -> {stExchange[TP.RowIdx[0]]}\n";
                st += $"                       ├─ Row Band[1]-#{TP.RowIdx[1]}(4-6) -> {stExchange[TP.RowIdx[1]]}\n";
                st += $"                       └─ Row Band[2]-#{TP.RowIdx[2]}(7-9) -> {stExchange[TP.RowIdx[2]]}\n\n";
            }
            st += $"[Col Band Exchange]  : #{TP.ColBndIdx} {stBandExchange[TP.ColBndIdx]}\n";
            if( TP.ColIdx !=null ){
                st += $"[Inner Col Exchange] : ├─ Col Band[0]-#{TP.ColIdx[0]}(1-3) -> {stExchange[TP.ColIdx[0]]}\n";
                st += $"                       ├─ Col Band[1]-#{TP.ColIdx[1]}(4-6) -> {stExchange[TP.ColIdx[1]]}\n";
                st += $"                       └─ Col Band[2]-#{TP.ColIdx[2]}(7-9) -> {stExchange[TP.ColIdx[2]]}\n";
            }
            st += new string('-', 70)+"\n";

            st += $"Block-1 Digit Normalization : (123456789) -> ({stDigitsConv})\n";
            st += $"Puzzle Standard Code : {PuzzleStandardCode}\n";
            st += new string('=', 80)+"\n";
            return st; 
        }


               
        public string Standard_Report( string title="" ){
            string st = $"{title}\n{this.ToString()}";

            string stRep = GLX_Lib.PrintBoard( original_Puzzle, standard_5_Placement_norm, standard_6_norm_Solution, standard_Puzzle_Solution, standard_Puzzle,
                "Original_Puzzle Placement_norm norm_Solution digits_exchange, Standard_Puzzle" );

            WriteLine( st );
            return (st+"\n"+stRep);
        }
    }
}