using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Timers;

using DLX_V2;

using GIDOO_space;

using static System.Diagnostics.Debug;
using static System.Math;

namespace STD_SDK{
    public partial class standardization_Man{
        static private readonly int[,] permIndex = { {0,1,2}, {0,2,1}, {1,0,2}, {1,2,0}, {2,0,1}, {2,1,0} };
        private Object obj = new();



      #region Swapping routine

        public int[] Transpose_Board( int[] board ){
            int[] boardClone = new int[81];
            for( int r=0; r<9; r++ ){
                for( int c=0; c<9; c++ )  boardClone[c*9+r] = board[r*9+c];
            }
            return boardClone;
        } 

        public int[] Transpose_Board( Trans_para TP){
            int[] boardClone = new int[81];
            for( int r=0; r<9; r++ ){
                for( int c=0; c<9; c++ )  boardClone[c*9+r] = TP.board[r*9+c];
            }
            TP.board = boardClone;
            return boardClone;
        }       
        public void Swap_BandPIdx( Trans_para TP, string rcType, bool secondSwap=false, bool debugPrint=false){
            // Destructive operation on the TP. The TP has been copied externally.
            int[] bdSrc = TP.board;
            int[] bdDst = (int[])TP.board.Clone(); // 
            int TP_RowBndIdx=TP.RowBndIdx, TP_ColBndIdx=TP.ColBndIdx;
            
            int    BandPIdx = (rcType=="row")? TP.RowBndIdx: TP.ColBndIdx;
            if( secondSwap )  BandPIdx %= 2;

            int Func_Perm( int permIX, int kx) => permIndex[permIX,kx/3]*3 + (kx%3);           

            if( rcType == "row" ){          // row band
                for( int r=0; r<9; r++ ){
                    int rFr = Func_Perm(BandPIdx,r);
                    for( int c=0; c<9; c++ )  bdDst[r*9+c] = bdSrc[rFr*9+c];
                }
            }
            else if( rcType == "col" ){    // column band
                for( int c=0; c<9; c++ ){
                    int cFr = Func_Perm(BandPIdx,c);
                    for( int r=0; r<9; r++ )  bdDst[r*9+c] = bdSrc[r*9+cFr ];
                }
            }
            TP.board = bdDst;

            bool __debugPrint = false;  //debugPrint
                if(__debugPrint){
                    WriteLine( $"\n--- [{(rcType=="row"? "row": "column")}band #{BandPIdx}]  ---\n   {bdDst.To_Line_String()}");
                    bdDst.PrintBoard();
                }
        }

        public void Swap_BInnerPIdx( Trans_para TP, string rcType, int targetBand, bool secondSwap=false, bool debugPrint=false){
            // Destructive operation on the TP. The TP has been copied externally.
            int[] bdSrc = TP.board;
            int[] bdDst = (int[])TP.board.Clone();
            int    innerPermIdx = (rcType=="row")? TP.RowIdx[targetBand]: TP.ColIdx[targetBand];
            if( secondSwap )  innerPermIdx %= 2;

            int sourcePos = targetBand*3;
            if( rcType == "row" ){          // row
                int[] fromRowIdx = new int[3];
                for( int k=0; k<3; k++ )  fromRowIdx[k] = sourcePos + permIndex[innerPermIdx, k];

                for( int k=0; k<3; k++ ){
                    int srcR = fromRowIdx[k];
                    int desR = sourcePos+k;
                    for( int c=0; c<9; c++ )  bdDst[desR*9+c] = bdSrc[srcR*9+c];
                }
            }
            else if( rcType == "col" ){     // column
                int[] fromColIdx = new int[3];
                for( int k=0; k<3; k++ )  fromColIdx[k] = sourcePos + permIndex[innerPermIdx, k];

                for( int k=0; k<3; k++ ){
                    int srcC = fromColIdx[k];
                    int desC = sourcePos+k;

                    for( int r=0; r<9; r++ )  bdDst[r*9+desC] = bdSrc[r*9+srcC];
                }
            }
            TP.board = bdDst;

            bool __debugPrint = false;  //debugPrint
                if(__debugPrint){
                    string st = $"\n--- [{(rcType=="row"? "row": "column")} band #{targetBand+1} / #{innerPermIdx} ---";
                    st += $"\n   {bdDst.To_Line_String()}\n   {bdDst.To_Line_String()}";
            
                    WriteLine( st );
                    bdSrc.PrintBoard("source");
                    bdDst.PrintBoard("destination");
                }
        }

      #endregion Swapping routine




      #region Normalization of clues positions         
        private List<Trans_para> Step2_Eval_R1C123( List<Trans_para> TP_List_1, bool debugPrint=false ){
            int  ToBlock(int rc) => rc/27*3+(rc%9)/3;

            List<Trans_para> TP_List_2 = new();
            int  minVal = int.MaxValue;
            foreach( Trans_para TP in TP_List_1 ){
                for( int rc=0; rc<81; rc+=3 ){
                    int blk = ToBlock(rc);
                    int[] board_1D_rc = TP.board_1D_01.Skip(rc).Take(3).ToArray();

                    for( int prmX=0; prmX<6; prmX++){
                        int val=0;
                        for( int k=0; k<3; k++ ){
                            val = val<<1 | board_1D_rc[ permIdx[prmX,k] ];
                        }

                        if( val < minVal ){ minVal=val; TP_List_2.Clear(); }
                        if( val == minVal ){
                            
                            Trans_para TPcopy = TP.Copy();
                
                            TPcopy.RowBndIdx = blk/3 *2;
                            TPcopy.RowIdx[0] = (rc/9)%3 *2;
                            TPcopy.ColBndIdx = blk%3 *2;
                            TPcopy.ColIdx[0] = prmX;

                            TP_List_2.Add( TPcopy );
                        }
                    }
                }
            }

            bool debugPrint2 = false; // @@@@@

            foreach( var (TP,kx) in TP_List_2.WithIndex() ){
                if( TP.RowBndIdx>0 )  Swap_BandPIdx(   TP, rcType:"row",    debugPrint:debugPrint2 );
                if( TP.RowIdx[0]>0 )  Swap_BInnerPIdx( TP, rcType:"row", 0, debugPrint:debugPrint2 );
                if( TP.ColBndIdx>0 )  Swap_BandPIdx(   TP, rcType:"col",    debugPrint:debugPrint2 );
                if( TP.ColIdx[0]>0 )  Swap_BInnerPIdx( TP, rcType:"col", 0, debugPrint:debugPrint2 );
            }

            if(debugPrint){ __sp(); int kx=0; TP_List_2.ForEach( P => P.board.PrintBoard( $"TP_List_2[{kx++}] {P}") ); }
            return TP_List_2;
        }

        private List<Trans_para> Step3_Eval_R1CBnd23C456789( List<Trans_para> TP_List_2, bool debugPrint=false ){
            List<Trans_para> TP_List_3 = new();
            int  minVal = int.MaxValue;
            foreach( Trans_para TP in TP_List_2 ){
                List<int> board_1D_01 = TP.board_1D_01;     

                int[] board_1D_2 = board_1D_01.Skip(3).Take(3).ToArray();       
                var (val2,prm2List) = _eval_1d( board_1D_2 );

                int[] board_1D_3 = board_1D_01.Skip(6).Take(3).ToArray();
                var (val3,prm3List) = _eval_1d( board_1D_3 );

                int val2A = (val2<<3) | val3;
                int val3A = (val3<<3) | val2;

                int val23Min = Min(val2A,val3A);
                if( val23Min > minVal )  continue;
                if( val23Min < minVal ){ minVal = val23Min; TP_List_3.Clear(); }

                if( val2A == minVal ){
                    foreach( int prm2X in prm2List ){
                        foreach( int prm3X in prm3List ){  
                            Trans_para TPcopy = TP.Copy();
                            TPcopy.ColIdx[1] = prm2X;
                            TPcopy.ColIdx[2] = prm3X;
                            TP_List_3.Add( TPcopy );
                        }
                    }
                }
                if( val3A == minVal ){
                    foreach( int prm3X in prm3List ){
                        foreach( int prm2X in prm2List ){ 
                            Trans_para TPcopy = TP.Copy();
                            TPcopy.ColBndIdx++;
                            TPcopy.ColIdx[1] = prm3X;
                            TPcopy.ColIdx[2] = prm2X;
                            TP_List_3.Add( TPcopy );
                        }
                    }
                }
            }
            foreach( var TP in TP_List_3 ){
                if( TP.ColBndIdx%2==1 ) Swap_BandPIdx(   TP, rcType:"col", secondSwap:true, debugPrint:debugPrint );
                if( TP.ColIdx[1]>0 )    Swap_BInnerPIdx( TP, rcType:"col", 1, debugPrint:debugPrint );
                if( TP.ColIdx[2]>0 )    Swap_BInnerPIdx( TP, rcType:"col", 2, debugPrint:debugPrint );
            }

            if(debugPrint){ __sp(); int kx=0; TP_List_3.ForEach( P => P.board.PrintBoard( $"TP_List_3[{kx++}] {P}") ); }
            return TP_List_3;

                    (int,List<int>) _eval_1d( int[] board_1D_01 ){
                        int valMin = int.MaxValue;
                        List<int> prmXList = new();
                        for( int prmX=0; prmX<6; prmX++){
                            int val=0;
                            for( int k=0; k<3; k++ ){ val = val<<1 | board_1D_01[ permIdx[prmX,k] ]; }
                            if( val < valMin ){ valMin=val; prmXList.Clear(); }
                            if( val == valMin ) prmXList.Add(prmX);
                        }
                        return (valMin,prmXList);
                    }
        }

        private List<Trans_para> Step4_Eval_R23( List<Trans_para> TP_List_3, bool debugPrint=false ){
            List<Trans_para> TP_List_4 = new();

            int  minVal = int.MaxValue;
            foreach( var (TP,kx) in TP_List_3.WithIndex() ){
                List<int> board_1D_01 = TP.board_1D_01;   

                int[] board_1D_2 = board_1D_01.Skip(9).Take(9).ToArray();
                var val2= _intArrayToVal( board_1D_2, 9 );
                int[] board_1D_3 = board_1D_01.Skip(18).Take(9).ToArray();
                var val3= _intArrayToVal( board_1D_3, 9 );

                int val2A = (val2<<9) | val3; 
                int val3A = (val3<<9) | val2; 
                int val = Min(val2A,val3A);

                if( val < minVal ){ minVal = val; TP_List_4.Clear(); }
                if( val2A == minVal ){ 
                    Trans_para TPcopy = TP.Copy();
                    TP_List_4.Add( TPcopy );
                }
                if( val3A == minVal ){ 
                    Trans_para TPcopy = TP.Copy();
                    TPcopy.RowIdx[0]++;
                    TP_List_4.Add( TPcopy );
                }
            }

            foreach( var TP in TP_List_4 ){
                if( TP.RowIdx[0]%2==1 ) Swap_BInnerPIdx( TP, rcType:"row", 0, secondSwap:true, debugPrint:debugPrint );
            }

            if(debugPrint){ __sp(); int kx=0; TP_List_4.ForEach( P => P.board.PrintBoard( $"TP_List_4[{kx++}] {P}") ); }
            return TP_List_4;

                    int _intArrayToVal( int[] board_1D_01, int size ){
                        // Columns 1–9 are fixed.
                        int val=0;
                        for( int k=0; k<size; k++ ){ val = val<<1 | board_1D_01[k]; }
                        return val;
                    }
        }

        private List<Trans_para> Step5_Eval_RBnd23( List<Trans_para> TP_List_4, bool debugPrint=false ){
            List<Trans_para> TP_List_5 = new();

            long minVal = long.MaxValue;
            foreach( var TP in TP_List_4 ){
                int[] board_1D_1 = TP.board_1D_01.Skip(27).Take(27).ToArray();
                var (val1,prm1List) = Eval_Band( board_1D_1 );
                int[] board_1D_2 = TP.board_1D_01.Skip(54).Take(27).ToArray();
                var (val2,prm2List) = Eval_Band( board_1D_2 );

                long val1A = val1<<27 | val2; 
                long val2A = val2<<27 | val1; 
                long val = Min(val1A,val2A);

                if( val < minVal ){ minVal = val; TP_List_5.Clear(); }

                if( val1A == minVal ){ 
                    foreach( int prm1X in prm1List ){
                        foreach( int prm2X in prm2List ){  
                            if( val1A == minVal ){
                                Trans_para TPcopy = TP.Copy();
                                TPcopy.RowIdx[1] = prm1X;
                                TPcopy.RowIdx[2] = prm2X;
                                TP_List_5.Add( TPcopy );
                            }
                        }
                    }
                }

                if( val2A == minVal ){ 
                    foreach( int prm1X in prm1List ){
                        foreach( int prm2X in prm2List ){  
                            if( val2A == minVal ){
                                Trans_para TPcopy = TP.Copy();
                                 TPcopy.RowBndIdx++;
                                TPcopy.RowIdx[1] = prm2X;
                                TPcopy.RowIdx[2] = prm1X;
                                TP_List_5.Add( TPcopy );
                            }
                        }
                    }
                }
            }

            foreach( var TP in TP_List_5 ){
                if( TP.RowBndIdx%2==1 ) Swap_BandPIdx(   TP, rcType:"row", secondSwap:true, debugPrint:debugPrint );
                if( TP.RowIdx[1]>0 )    Swap_BInnerPIdx( TP, rcType:"row", 1, debugPrint:debugPrint );
                if( TP.RowIdx[2]>0 )    Swap_BInnerPIdx( TP, rcType:"row", 2, debugPrint:debugPrint );
            }

            if(debugPrint){ __sp(); int kx=0; TP_List_5.ForEach( P => P.board.PrintBoard( $"TP_List_5[{kx++}] {P}") ); }
            return TP_List_5;

                    (long,List<int>)  Eval_Band( int[] board_1D_01 ){
                        int valMin = int.MaxValue;
                        List<int> prmXList = new();
                        for( int prmX=0; prmX<6; prmX++){
                            int val = 0;
                            for( int k=0; k<3; k++ ){
                                int rc = permIdx[prmX,k]*9;
                                for( int c=0; c<9; c++ ){ val = val<<1 | board_1D_01[rc+c]; }
                            }
                            if( val < valMin ){ valMin=val; prmXList.Clear(); }
                            if( val == valMin ) prmXList.Add(prmX);
                        }

                        return  ((long)valMin,prmXList);
                    }
        }
      
      #endregion Normalization of clues positions



      #region Normalization of clue digits using DLX
        private List<Standard_Form> Step6_Eval_Numerical_standardization_Serial( List<Trans_para> TP_List_5, int[] boardSrc, bool debugPrint=false ){
            List<Standard_Form> STD_form_List = new();

            DLX_V2.SudokuSolver SDK_Solver = new();
           
            foreach( var TP in TP_List_5 ){
        
                var STD_form = new Standard_Form( boardSrc, TP );
                int[] board5 = TP.board.Cast<int>().ToArray();
                    STD_form.standard_5_Placement_norm  = board5;
                
                var solutions = SDK_Solver.Solve( board5, maxSolutions:2 /*,ct*/);   //ct:undefine	
                  
                int[] board6 = solutions[0]; 
                
                    STD_form.standard_6_norm_Solution  = board6;
                
                int[]  digConv = new int[9];
                for( int kx=0; kx<9; kx++ ) digConv[ board6[kx/3*9+kx%3]-1 ] = kx+1;
                    STD_form.normalize_digConv = digConv.ToArray();
                
                int[] board7 = new int[81];
                for( int rc=0; rc<81; rc++ ) board7[rc] = digConv[ board6[rc]-1 ];
                
                    STD_form.standard_Puzzle_Solution = board7;
                
                int[] board8 = (int[])board7.Clone();
                for( int rc=0; rc<81; rc++ ) if( TP.board[rc]==0 ) board8[rc] = 0;
                    STD_form.standard_Puzzle = board8;
                
                    STD_form.Set_PuzzleStandardCode();
                    //STD_form.Standard_Report();
                
                    STD_form_List.Add( STD_form );
                    //WriteLine( STD_form );
            }


            if(debugPrint){ __sp(); int kx=0; STD_form_List.ForEach( P => P.TP.board.PrintBoard( $"STD_form_List[{kx++}] {P}") ); }
            return STD_form_List;
        }



        private static class STD_SudokuSolverPool{
            private static readonly ThreadLocal<SudokuSolver> ThreadLocalSolver = new( () => new SudokuSolver() );
            public static DLX_V2.SudokuSolver Current => ThreadLocalSolver.Value;
        }


        private List<Standard_Form> Step6_Eval_Numerical_standardization_Parallel( List<Trans_para> TP_List_5, int[] boardSrc, bool debugPrint=false ){
            List<Standard_Form> STD_form_List = new();

            // DLX_V2.SudokuSolver SDK_Solver = new();
            int index = 0;
            var indexLock = new object();

            using (var cts = new CancellationTokenSource()){
                CancellationToken ct = cts.Token;
                var options = new ParallelOptions { CancellationToken=ct };
        

            // ========================================================
                Parallel.ForEach( TP_List_5, options, (TP, state) =>{
                        if( ct.IsCancellationRequested){ state.Stop(); return; }

                    var STD_form = new Standard_Form( boardSrc, TP );
                    int[] board5 = TP.board.Cast<int>().ToArray();
                        STD_form.standard_5_Placement_norm  = board5;


                  // --- DLX Solver ---
                    int myIndex;                            //@@@
                    lock(indexLock){ myIndex=index++; }     //@@@

                    // Just fetch the per-thread solver; reuse is automatic.
                    var solver = STD_SudokuSolverPool.Current;                      //@@@
                    var solutions = solver.Solve( TP.board, maxSolutions:2, ct );   //@@@
                    if( solutions.Count != 1 )  return;//@@@



                  // --- Set Standard Form ---
                    int[] board6 = solutions[0];
                        STD_form.standard_6_norm_Solution  = board6;
                
                    int[]  digConv = new int[9];
                    for( int kx=0; kx<9; kx++ ) digConv[ board6[kx/3*9+kx%3]-1 ] = kx+1;
                        STD_form.normalize_digConv = digConv.ToArray();
                
                    int[] board7 = new int[81];
                    for( int rc=0; rc<81; rc++ ) board7[rc] = digConv[ board6[rc]-1 ];
                        STD_form.standard_Puzzle_Solution = board7;
                
                    int[] board8 = (int[])board7.Clone();
                    for( int rc=0; rc<81; rc++ ) if( TP.board[rc]==0 ) board8[rc] = 0;
                        STD_form.standard_Puzzle = board8;
                        STD_form.Set_PuzzleStandardCode();
                        //STD_form.Standard_Report();

                    lock(obj){
                        STD_form_List.Add( STD_form );
                        //WriteLine( STD_form );
                    }   
                

                });
                //==========================================================
            }

            if(debugPrint){ __sp(); int kx=0; STD_form_List.ForEach( P => P.TP.board.PrintBoard( $"STD_form_List[{kx++}] {P}") ); }
            return STD_form_List;
        }

      #endregion Normalization of clue digits using DLX
    }
}