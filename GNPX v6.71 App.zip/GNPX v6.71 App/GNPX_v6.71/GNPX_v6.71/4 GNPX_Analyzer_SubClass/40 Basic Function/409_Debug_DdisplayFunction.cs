﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
//using GIDOO_Lib;
//using OpenCvSharp;
using GNPX_space;

using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

// ##########################################
//
//      Display function for debugging
//
// ##########################################


namespace GIDOO_space{
    public static class Utility_Display{
        static public char[] _sep={' ',',','\t'};
        static public char[] _sepC={','};
        static public string _backupDir="backupDir";

		static public void GNPX_StreamWriter( string fName, string line, bool append=true ){
		    using( var fpW=new StreamWriter( fName, append:true, Encoding.UTF8) ){
                fpW.WriteLine(line);
            }
		}

		static public void GNPX_StreamWriter_WithTime( string fName, string message, bool append=true ){
			using(var fpW=new StreamWriter(fName,append,Encoding.UTF8)){
                fpW.WriteLine($"{DateTime.Now}  {message}");
            }
		}


	#region __DBUG_Print2
		static public string  __DBUG_Print2( this List<UCell> UB, bool sqF, string st="" ){
		  //return __DBUG_Print2( UB.ConvertAll(p=>Abs(p.No)), sqF, st:st );
			return __DBUG_Print2( UB.ConvertAll(p=>p.No), sqF, st:st );	
		}
		

		static public string __DBUG_Print2( this List<int> X, bool sqF, string st="" ){
			return __DBUG_Print2( X.ToArray(), sqF, st:st );
		}
        static public string __DBUG_Print2( this int[] X, bool sqF, string st="" ){
            string   stL="", stL2="  ", stL3="";
			if(sqF)  stL = $"{st}\n";

			for( int rc=0; rc<81; rc++ ){
				int no = X[rc];
				if( (rc%9) == 0 ){ stL += (rc/9+1).ToString("     ##0:"); stL3=""; }
				stL  += " "+ ToNumStringPM(no);
				stL3 += " "+ ToNumStringPM(Max(no,0));
				stL2 += ToNumStringP(no);

				if( (rc%9) == 8 ){ stL+= $"   {stL3}\n"; stL2 += " "; stL3=""; }
			}
			WriteLine( $"{stL}\n{stL2}" );
			return stL;

					string ToNumStringP( int no ) => (no>0)? no.ToString(): ".";
					string ToNumStringPM( int no ) => (no==0)? " .": (no>0)? no.ToString(" #" ): no.ToString("##" );
        }


        static public string __DBUG_Print2( int[,] pSol99, bool sqF, string st="" ){
            string   stL="", stL2="  ", stL3="";
			if(sqF)  stL = $"{st}\n";

			for( int rc=0; rc<81; rc++ ){
				int no = pSol99[rc/9,rc%9];
				if( (rc%9) == 0 ){ stL += (rc/9+1).ToString("     ##0:"); stL3=""; }
				stL  += " "+ ToNumStringPM(no);
				stL3 += " "+ ToNumStringPM(Max(no,0));
				stL2 += ToNumStringP(no);

				if( (rc%9) == 8 ){ stL+= $"   {stL3}\n"; stL2 += " "; stL3=""; }
			}
			WriteLine( $"{stL}\n{stL2}" );
			return stL;

					string ToNumStringP( int no ) => (no>0)? no.ToString(): ".";
					string ToNumStringPM( int no ) => (no==0)? " .": (no>0)? no.ToString(" #" ): no.ToString("##" );
		}

		static public string __DBUG_Print3( int no, UInt128 B81, bool sqF=false, string st="" ){
			string stL = $"{st}\n";
			for( int rc=0; rc<81; rc++ ){
				if( (rc%9) == 0 )  stL += $" row{(rc/9)+1}";
				int b = (int)((B81>>rc) & 0b1);
				stL += (b==0)? " .": $" {no+1}";
				if( (rc%9) == 8 )  stL += "\n";
			}
			WriteLine( stL );
			return stL;
		}
		#endregion






		static 	public void _Dynamic_CellsPrint_withFrame( this List<UCell> Cells, string[] Marks, string message="", int width=9 ){
			WriteLine(message);
			//	string stLine3 = new string('-', (width+3)*3-1 );
			//string stLine = $"*{stLine3}*{stLine3}*{stLine3}*";

			string[][] stDD = new string[9][];
			int[]	   colSize = new int[9]; 
			for( int r=0; r<9; r++ )  stDD[r] = ___D_CellToLinet_wF(r*9,Cells, Marks,  width:width);
			
			string  stLine = "*";
			for( int c=0; c<9; c++ ){
				int sz=0;
				for( int r=0; r<9; r++ )  sz = Max( sz, stDD[r][c].Length );
				colSize[c] = sz;
				stLine += new string('-',sz+4);
				stLine += (c%3==2)? "*": "-";
			}


			for(int r=0; r<9; r++){
				if( (r%3)==0 ) WriteLine(stLine);
				string st = "| ";
				for( int c=0; c<9; c++ ){
					int n = colSize[c]+1;
					st += " " + stDD[r][c].PadRight(n);
					st += (c%3==2)? " | ": "   ";
				}
				WriteLine(st);
			}
			WriteLine(stLine);
			return;

					string[]  ___D_CellToLinet_wF( int r0, List<UCell> Cells, string[] Marks, int width=9 ){
						string[] stD = new string[9];
						string st="";
						for(int c=0; c<9; c++){
							string stCell = "";
							UCell P = Cells[r0+c];
							if( P.No!=0 ){
								int no = P.No;
								stCell += (no<0)? $"-<{Abs(no)}>-": $"{Abs(no)}";  
							}
							else{ stCell += P.FreeB.TBSnD(); }
							if( Marks!=null && Marks.Length==81 ){
								string stMark = Marks[r0+c];
								if( stMark!=null && stMark!="" )  stCell += " "+stMark;
							}
							stD[c] = stCell;
						}
						st += " |";
						return stD;
					}
/*
	Sample for debugging

file:E: ------ \GNPX_ExecutionSpace\GNPX_1_SAMPLE2_v6.txt
 Puzzle sq:1 stage:1 Method:01 HiddenSingle  IsSolutionValid ... error ...
*-------------------------------*-------------------------------*------------------------------*
|  13458     123458     12359   |  13568      134568     1346   |  15679     126789     1289   | 
|  1358      5          1359    |  1358       1          6      |  3         189        189    | 
|  6         12458      125     |  8          14568      146    |  156       2          128    | 
*-------------------------------*-------------------------------*------------------------------*
|  8         135        3       |  12356      1356       7      |  16        16         6      | 
|  1         137        9       |  1367       1367       1369   |  7         1469       4      | 
|  5         1578       157     |  3          157        19     |  1         19         2      | 
*-------------------------------*-------------------------------*------------------------------*
|  134       8          1237    |  12378      13478      4      |  137       12478      5      | 
|  134       12347      7       |  9          8          12346  |  137       4          124    | 
|  1345      123457     123567  |  123678     134678     12346  |  1379      124789     12489  | 
*-------------------------------*-------------------------------*------------------------------*
*/
		}

	}
}
