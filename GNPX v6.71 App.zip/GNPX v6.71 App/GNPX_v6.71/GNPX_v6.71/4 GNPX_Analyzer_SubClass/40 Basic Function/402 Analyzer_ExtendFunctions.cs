using System;
using System.Collections.Generic;
using System.Linq;
using static System.Math;
using static System.Diagnostics.Debug;

using System.Security.Policy;
using System.Runtime.CompilerServices;
//using System.Drawing;
using GIDOO_space;
using System.Windows.Media;
using System.Windows.Annotations;

namespace GNPX_space{   
    using SWMColor = System.Windows.Media.Color;

    //========== Extended Function ==========
    static public class StaticFunctions{ 
        static private char[] _sep=new Char[]{ ' ', ',', '\t' };
        static private char[] _sepSharp=new Char[]{ '#' };
        static public bool rcbHitCheck( this int X, int Y ){
            if( X/9==Y/9 )  return true;    //row
            if( X%9==Y%9 )  return true;    //column
            if( (X/27*3+(X%9)/3) == (Y/27*3+(Y%9)/3) )  return true;  //block
            return false;
        }

		static public int dir_rc_toHouse( int dir, int rc ) => (dir==0)? rc/9: rc%9+9;
      #region ToString_SameHouseComp

/*
        static public void testc() {
            string[] test = {"r3 c5", "r4 r6", "c2 c4", "r1c1 r1c2", " r1c5 r2c5 ", "r1c5 r2c5 r9c9 r1c1 r1c2 r2c8",  "r1c1 r1c2 r1c5 r2c5", };
                
            foreach( var p in test ){
                WriteLine("");
                WriteLine( $"p:{p} ToString_SameHouseComp :{p.ToString_SameHouseComp()}" );
            }
        }
*/
        static public string ToString_SameHouseComp( this string stOrg ){  // new version  
            List<string> stLst = stOrg.Split(_sep, StringSplitOptions.RemoveEmptyEntries).ToList();
            if( stLst.Count<=1 ) return stOrg.Trim();          

            var stLst2 = stLst.ConvertAll( P => new _C4Group(P, rcOpt:true) ) ;
            bool changed=false, changedT=false;
            if( stLst2.Count>=2 ){
                do{
                    changed=false;
                    var stGroup = stLst2.GroupBy( P => P.val1 );

                    foreach( var grp in stGroup ){ 
                        if( grp.Count() <= 1 )  continue;
                        string stW = grp.Aggregate( "", (a,b)=>a+b.val2 );
                        stLst2.RemoveAll( q=> q.val1==grp.Key );
                        stLst2.Add( new _C4Group(grp.Key, stW) );
                        changed = true;
                        changedT = true;
                    }
                }while(changed);
            }

            if( stLst2.Count>=2 ){
                do{
                    changed=false;
                    var stGroup = stLst2.GroupBy( P => P.val2 );

                    foreach( var grp in stGroup ){ 
                        if( grp.Count() <= 1 )  continue;
                        string stW = grp.Aggregate( "", (a,b)=>a+b.val1 );
                        stLst2.RemoveAll( q=> q.val2==grp.Key );
                        stLst2.Add( new _C4Group( stW, grp.Key) );
                        changed = true;
                        changedT = true;
                    }
                }while(changed);
            }

            string st = stOrg.Trim();
            if( changedT ){
                stLst = stLst2.ConvertAll( p => p.ToRCString() );
                stLst.Sort();
                st = string.Join( " ", stLst );
            }   

            if( st.Substring(0,2) == "rr" )  WriteLine( st );
            return st;
        }

		static public string ToString_SameHouseNoCompEx( this string stOrg ){  // new version        
            if( !stOrg.Contains("#") )    return stOrg;

			string st2 = stOrg.ToString_SameHouseNoComp();
            List<string> RCNList = stOrg.Split(_sep, StringSplitOptions.RemoveEmptyEntries).ToList();
			
					List<string> keyList = RCNList.ConvertAll(p=> { int n=p.IndexOf("#"); return (n<0)? "@": p.Substring(n);} );
					keyList = keyList.Distinct().ToList();

			string st0 = "";
			foreach( var keyNo in keyList ){
				var st1_List = RCNList.FindAll(p => p.Contains(keyNo));
				var st2_List = st1_List.ConvertAll(p => p.Replace(keyNo,""));
				string st3 = string.Join(" ", st2_List);
				string st5 = st3.ToString_SameHouseComp();
				st0 += " "+st5.Replace(" ",keyNo+" ") + keyNo;
			}
            return st0.Trim();
        }
        static public string ToString_SameHouseNoComp( this string stOrg ){  // new version        
            if( !stOrg.Contains("#") )    return stOrg;

            List<string> stLst = stOrg.Split(_sep, StringSplitOptions.RemoveEmptyEntries).ToList();
            if( stLst.Count<=1 ) return stOrg.Trim();          

            var stLst2 = stLst.ConvertAll( P => new _C4Group(P) ) ;
            bool changed=false, changedT=false;
            do{
                changed=false;
                var stGroup = stLst2.GroupBy( P => P.val1 );

                foreach( var grp in stGroup ){ 
                    if( grp.Count() <= 1 )  continue;
                    string stW = grp.Aggregate("",(a,b)=>a+b.val2 );
                    stLst2.RemoveAll( q=> q.val1==grp.Key );
                    stLst2.Add( new _C4Group(grp.Key, stW) );
                    changed = true;
                    changedT = true;
                }
            }while(changed);
            if( !changedT )  return stOrg;

            stLst = stLst2.ConvertAll( p => p.ToString() );
            stLst.Sort();
            string st = string.Join( " ", stLst );
            return st.Trim();
        }

        private class _C4Group{
            public string val1{ get; set; }
            public string val2{ get; set; }
                
            public _C4Group( string val1, string val2 ){ this.val1=val1; this.val2=val2; }

            public _C4Group( string stA ){ string[] A=stA.Split('#'); this.val1=A[0]; this.val2=A[1]; }
            public _C4Group( string stA, bool rcOpt ){
                this.val1 = stA.Substring(1,1);
                this.val2 = stA.Substring(3,1);
            }
            public override string ToString( ) => $"{val1}#{val2}";
            public string ToRCString( )        => $"r{val1}c{val2}";
        }


        static public string ToRCString( this List<UCell> UCellList ){
            string st="";
            UCellList.ForEach( p =>{  st += $" {p.rc.ToRCString()}"; } );
            st = st.ToString_SameHouseComp();
            return st;
        }

        private class _ClassNSS{
            public int sz;
            public string stP1;
            public string stP2="  ";

            public _ClassNSS( int sz, string stP1, string stP2 ){
                this.sz=sz; this.stP1=stP1; this.stP2=stP2;
            }
            public _ClassNSS( string st ){
                try{
                    sz=1; 
                    if(st.Length>=2) stP1=st.Substring(0,2);
                    if(st.Length>=4) stP2=st.Substring(2,2);
                }
                catch(Exception ){ }
            }
        }
     
     #endregion



        static public UInt128 Create_Free_BitExp81( this List<UCell> Us ) => Us.Where(u=>u.No==0) .Aggregate( UInt128.Zero, (a,u) => a| UInt128.One<<u.rc );

        static public UInt128[] Create_b081B9( this List<UCell> Us, bool withFixedB=false ){			//..... FreeB_SP
            UInt128[] B128 = new UInt128[9];
            foreach( var U in Us.Where(P=>P.FreeB>0) ){
                UInt128 Urc128 = UInt128.One<<U.rc;
				foreach( int no in U.FreeB.IEGet_BtoNo() )  B128[no] |= Urc128;
            }
			if( withFixedB ){
				foreach( var U in Us.Where(u=>u.No!=0) ) B128[Abs(U.No)-1] |= UInt128.One<<U.rc;
			}
				// for( int no=0; no<9; no++ ){
				//	 WriteLine( $" Create_b081B9 no:#{no+1} B128:{B128[no].ToBitString81N()}" );
				// }
            return B128;
        }

        static public UInt128[] Create_FixedBitExp81_9( this List<UCell> Us ){			//..... Free with #no
            UInt128[] B128 = new UInt128[9];
			foreach( var U in Us.Where(u=>u.No!=0) ) B128[Abs(U.No)-1] |= UInt128.One<<U.rc;
            return B128;
        }


        // TBS : ToBitString

		static public string TBS( this int num, int ncc=9 )  => num.ToBitString(ncc);
// 		static public string TBS( this int num, int ncc=9, string separator="" )   => ToBitStringN( (uint)num, ncc, separator );	
		static public string TBScmp( this int num )  => num.ToBitStringN(9);
		static public string TBSM27( this int num )  => num.ToBitStringMod9(27);
		static public string TBSnD( this int num )  => num.ToBitString(9, withDot:false );			// 4 development

		static public string TBSrcb( this int num, bool digittB=true ) => num.ToBitString27rcb( digitB:true ); 	// for development



        static public string ToBitString( this int num, int ncc=9, bool withDot=true )  => ToBitString( (uint)num, ncc, withDot:withDot );
		static public string ToBitStringMod( this int num, int ncc=9 )  => ToBitStringMod( (uint)num, ncc );
		static public string ToBitStringMod9( this int num, int ncc=9 )  => ToBitStringMod9( (uint)num, ncc );
       

		
	// For debugging purposes only
		static public string ToBitStringN( this int num, int ncc=9, string separator="" )   => ToBitStringN( (uint)num, ncc, separator );
        static public string ToBitStringNZ( this int num, int ncc )  => ToBitStringNZ( (uint)num, ncc );



        static public string ToBitString( this uint num, int ncc=9, bool withDot=true ){
            uint numW = num;
            string st="";
			string stDot = withDot? ".": "";
            for(int k=0; k<ncc; k++ ){
                st += ((numW&1)!=0)? (k+1).ToString(): stDot;
                numW >>= 1;
            }
            return st;
        }
        static public string ToBitStringMod( this uint num, int ncc=9 ){
            uint numW = num;
            string st="";
            for(int k=0; k<ncc; k++ ){
                st += ((numW&1)!=0)? ((k%10)+1).ToString(): ".";
                numW >>= 1;
            }
            return st;
        }
        static public string ToBitStringMod9( this uint num, int ncc=9 ){
            uint numW = num;
            string st="";
            for(int k=0; k<ncc; k++ ){
                st += ((numW&1)!=0)? ((k%9)+1).ToString(): ".";
				if( k%9 == 8 ) st += " ";
                numW >>= 1;
            }
            return st;
        }


	
		static public string TBS27cmpN( this int num, bool digitB=true ) => ToBitString27rcb_Omit_null( num );

		static public string TBS27cmp( this int num, bool digitB=true ) => ToBitString27rcb( num, digitB:true);


        static public string ToBitString27rcb( this int num, bool digitB=true ){
            string st = "";
				if(digitB) st = $"r{(num&0x1FF).TBScmp()} c{((num>>9)&0x1FF).TBScmp()} b{(num>>18).TBScmp()}";
				else       st = $"r{(num&0x1FF).ToBitString(9)} c{((num>>9)&0x1FF).ToBitString(9)} b{(num>>18).ToBitString(9)}";
            return st;
        }

		static public string ToBitString27rcb_Omit_null( this int num ){
			string st = "";
			int w=0;
			if( (w=(num&0x1FF))>0 )		  st +=  $" r{w.TBScmp()}";
			if( (w=((num>>9)&0x1FF))>0 )  st +=  $" c{w.TBScmp()}";
			if( (w=((num>>18)&0x1FF))>0 ) st +=  $" b{w.TBScmp()}";
			return st.Trim();
		}


		static public string ToBitString36rcbn( this long Lnum, bool digitB=true ){
			string st = "";
				int noB9 = (int)(Lnum&0x1FF);	
				if(digitB) st += $" nrcb:#{noB9.TBScmp()}";
				else       st += $" rcb:";
				st +=  $" {((int)((Lnum>>9)&0x7FFFFFF)).ToBitString27rcb(digitB)}";
			return st;
		}

        static public string ToBitStringN( this uint num, int ncc, string separator="" ){
            uint numW = num;
				List<int> Q=new();
				for(int k=0; k<ncc; k++ ){
					if((numW&1)!=0) Q.Add(k+1);
					numW >>= 1;
				}
				string st = "-";
				if(Q.Count>0)  st = string.Join(separator,Q);
            return st;
        }

        static public string ToBitStringNor( this uint num, int ncc ){
            uint numW = num;
				string st="";
				for(int k=0; k<ncc; k++ ){
					if((numW&1)!=0 ){
						if(st=="") st = (k+1).ToString();
						else st += " or "+(k+1).ToString();
					}
					numW >>= 1;
				}
				if(st=="")  st = "*";
            return st;
        }
        static public string ToBitStringNZ( this uint num, int ncc ){
            uint numW = num;
            string st="";
            for(int k=0; k<ncc; k++ ){
                if((numW&1)!=0) st += (k+1).ToString();
                numW >>= 1;
            }
            return st;
        } 
        static public string ToBitString( this ulong LNum, int n9=4 ){
            string st = "";
            ulong LNumW = LNum;
            for(int k=0; k<n9; k++ ){
                int LNumInt = (int)(LNumW&0x1FF);
                st += LNumInt.ToBitString(9)+" /";
                LNumW >>= 9;
            }
            return st;
        }

        static public string ToRCString( this int rc ){
			int rcAbs = Abs(rc); 
			string st = $"r{rcAbs/9+1}c{(rcAbs%9)+1}";
			if( rc<0 )  st = "-" + st;
            return st;
        }
        static public string ToRCString_NPM( this int rc ){
			int rcReal = rc%100; 
			string st = (rc>=100 )? "-": "";  // "-":Fixed-cell
            st += $"r{rcReal/9+1}c{(rcReal%9)+1}";
			if( rc<0 )  st = " n/a";
            return st;
        }

  
        static public string HouseToString( this int h, string noSt=" " ){
            string st="";
            if(h<0)            st += "---";
            if(h>=0 && h<9)    st += "r"+(h+1)+noSt;
            if(h>=9 && h<18)   st += "c"+(h-9+1)+noSt;
            if(h>=18)          st += "b"+(h-18+1)+noSt;
            return st.Trim();
        }

        //========== bit expression→Number  ==========   
        static public int BitToNum( this int val, int sz=9 ){
			int mask = (sz==9)? 0x1FF: ((sz>0 && sz<31)? (1<<sz)-1: 0); 
			int valMask = val & mask;
            if( valMask.BitCount()!=1) return -1;
            for(int k=0; k<sz; k++ ){ if( valMask==(1<<k)) return k; }
            return -1;
        }

        static public List<int> BitToNumList( this int FreeB, bool from0=false ){    
            List<int> Lst = new List<int>();
            int x=FreeB, n=(from0? -1: 0);
            while(x>0){
                n++;
                if( (x&1)>0 ) Lst.Add(n);
                x >>= 1;
            }
            return Lst;
        }

        //========== bit expression→2 Numbers ==========   
        static public (int,int) BitToTupple( this int noB ){
            if(noB.BitCount()!=2) return (-1,-1);
			var L = noB.BitToNumList();
			return (L[0]-1,L[1]-1);
        }

		static public int B( this int rcx ) => (rcx/27*3+(rcx%9)/3);


		static public int ToBlock( this int rcx ){ return (rcx/27*3+(rcx%9)/3); }

    #region Enumerators
        static public IEnumerable<UCell> IEGetCellInHouse( this List<UCell> pBOARD, int h, int FreeB=0x1FF ){
            //Find the cells with digits X(FreeB) in house.
            int r=0, c=0, tp=h/9, fx=h%9;
            for(int nx=0; nx<9; nx++ ){
                switch(tp ){
                    case 0: r=fx; c=nx; break; //row(h:0-8)
                    case 1: r=nx; c=fx; break; //column(h:9-17)
                    case 2: r=(fx/3)*3+nx/3; c=(fx%3)*3+nx%3; break; //block(h:18-26)
                }
                UCell P = pBOARD[r*9+c];
                P.nx = nx;  
                if((P.FreeB&FreeB)>0) yield return P;
            }
        }

        static public void IE_SetNoBBgColor( this UInt128 BX, List<UCell> pBOARD, int noBX, SWMColor AttCr, SWMColor Cr ){ 
			if( BX == UInt128.Zero ) return; 
            foreach( var p in BX.IESelect81B_with_noB(pBOARD,noBX) ) pBOARD[p.rc].Set_CellColor_BkgColor_noBit(noBX,AttCr,Cr); 
        }

        static public void IE_SetNoBBgColorNSel( this UInt128 BX, List<UCell> pBOARD, int noBX, SWMColor AttCr, SWMColor Cr ){ 
			if( BX == UInt128.Zero ) return; 
            foreach( var p in BX.IESelect81B_with_noB(pBOARD,0x1FF) ) pBOARD[p.rc].Set_CellColor_BkgColor_noBit(noBX,AttCr,Cr); 
        }

		static public void IE_SetNoBBgColor_All( this UInt128 BX, List<UCell> pBOARD, int noBX, SWMColor AttCr, SWMColor Cr ){ 
			if( BX==UInt128.Zero || BX==UInt128.MaxValue ) return; 
            foreach( var p in BX.IEGet_UCell(pBOARD) ) pBOARD[p.rc].Set_CellColor_BkgColor_noBit(noBX,AttCr,Cr); 
        }
        static public void IE_SetNoBBgColor( this List<UCell> LstUCell, List<UCell> pBOARD, int noBX, SWMColor AttCr, SWMColor Cr ){ 
			if( LstUCell==null || LstUCell.Count==0 ) return;
            LstUCell.ForEach( p => pBOARD[p.rc].Set_CellColor_BkgColor_noBit( noBX, AttCr, Cr) );
        }

        static public IEnumerable<int> IEGet_BtoNo( this int noBin, int sz=9 ){
            for(int no=0; no<sz; no++ ){ if( (noBin&(1<<no))>0 )  yield return no; }
            yield break;
        }

        static public IEnumerable<int> IEGet_BtoHouse27( this int tfbContainer ){
            int P = tfbContainer;
            for(int m=0; m<27; m++ ){ if( (P&(1<<m)) > 0 )  yield return m; }
            yield break;
        }
        static public string Connect<T>( this IEnumerable<T> list, string separator ){
    	    return string.Join(separator,list);
        }


    #endregion

    }
		
}