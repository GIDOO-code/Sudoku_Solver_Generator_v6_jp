using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using System.Xml.Serialization;

using GIDOO_space;
using GNPX_space.Properties;

namespace GNPX_space {
    //ALS(Almost Locked Set) 
    // ALS is a state where there are "n+1 candidate digits" in "n cells" belonging to the same house. 
    // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page26.html

	// *==*==*==*==*==*==*==*==*==*
	//		version 5.1 
	// *==*==*==*==*==*==*==*==*==*

    public class UAnLS: USubset{

		public UAnLS             preALS = null;
        public (UAnLS,int)       preALS_no = (null,-9);
		public List<(UAnLS,int)> ConnectedALS;
		public int				 rc => base.b081.BitToNum(81);

        public UAnLS(){ }

        public UAnLS( UAnLS UA ): base( 0, UA.FreeB, UA.UCellList ){
            this.FreeB_SP = UA.FreeB_SP;
        }

        public UAnLS( int ID, int FreeB, List<UCell> UCellList ): base( ID, FreeB, UCellList ){}

		public UAnLS( int ID, UCell U ):  base( ID, U.FreeB, new[]{U}.ToList() ){}
        public bool IsPureALS(){
            //Pure ALS : not include locked set of proper subset
            if( CellSize<=2 ) return true;
            for( int sz=2; sz<CellSize-1; sz++ ){
                var cmb=new Combination(CellSize,sz);
                while(cmb.Successor()){
                    int fb=0;
                    for(int k=0; k<sz; k++ )  fb |= UCellList[cmb.Index[k]].FreeB;
                    if( fb.BitCount()==sz ) return false;
                }
            }
            return true;
        }


		public override string ToString(){
            string st = $"\nUAnLS << ID:{ID} >>  [ CellSize:{CellSize} Level:{Level} ] ";
            st += $"  :{FreeB.ToBitString(9)}  FreeB_SP:{FreeB_SP.ToBitString(9)}\n";
            st += $" rcbFrame:{(rcbFrame).ToBitString27rcb()}";
			st += $" IsInsideBlock:{(IsInsideBlock? "@":"-")}";
            st += $"         b081:{b081.ToBitString81()}\n";
			st += $"connectedB81:{connectedB81.ToBitString81()}";

            for(int k=0; k<UCellList.Count; k++){
                st += "\n\t\t------";
				UCell P = UCellList[k];
                st += $" rc:{P.rc.ToRCString()}";
                st += $" FreeB:{P.FreeB.ToBitString(9)}";
				st += $" FreeB_SP:{P.FreeB_SP.ToBitString(9)}";			               
				st += $" // rcbFrame: {P.rcbFrame.ToBitString27rcb(digitB:false)}";
            }
            return st;
        }

        public new string ToStringA(){
            string stPre = (preALS==null)? "(null)": preALS.b081.TBScmp();
			string st = $"<> UAnLS ID:{ID} sz:{CellSize} Lv:{Level}  {stPre} --> {b081.TBScmp()} #{FreeB.TBScmp()}";
			//$"FreeB:{FreeB.ToBitString(9)} rc:{ToStringRCN()}";
            return  st;
        }

		public new string ToString_Free_SP(){
			string st = $"UAnLS << ID:{ID} >>  [ CellSize:{CellSize} Level:{Level} ]";
			st += $"  FreeB:{FreeB.ToBitString(9)}  FreeB_SP:{FreeB_SP.ToBitString(9)}\n";
			st += $"         b081 {b081.ToBitString81N()}\n";
			for(int k=0; k<UCellList.Count; k++){
				st += "\t\t------";
				int rcW = UCellList[k].rc;
				st += $" rc:{rcW.ToRCString()}";
                st += $" FreeB:{UCellList[k].FreeB.ToBitString(9)}";
				st += $" FreeB_SP:{UCellList[k].FreeB_SP.ToBitString(9)}";
				st += $" rcb:b{(rcbBlk).ToBitString(9)}";
				st += $" c{rcbCol.ToBitString(9)}";
				st += $" r{rcbRow.ToBitString(9)}";
				//st += $" connectedB81:{connectedB81.ToBitString81N()}";
			  	st += "\n";
			}
            return st;
        }
	}

}
