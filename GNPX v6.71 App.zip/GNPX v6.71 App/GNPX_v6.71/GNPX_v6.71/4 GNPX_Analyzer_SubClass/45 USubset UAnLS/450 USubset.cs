using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using System.Xml.Serialization;

using GIDOO_space;
using GNPX_space.Properties;

namespace GNPX_space {

	// *==*==*==*==*==*==*==*==*==*
	//		version 6 
	// *==*==*==*==*==*==*==*==*==*

    public partial class USubset: IComparable{
        static private UInt128 qZero  = UInt128.Zero;
        static private UInt128 qOne   = UInt128.One; 

		static public  AnalyzerBaseV2	qAnalyzer;
        static public  UInt128[]		pHouseCells81 => GNPX_Utilitie.HouseCells81;
        static public  UInt128[]		pConnectedCells81 => GNPX_Utilitie.Connected_81;

        static private protected bool	_withID_=false;
        static public void Set_withID_( bool withID ) => _withID_ = withID;  // for DEBUG 



        public int           ID;
        public int		 	 CellSize;      //CellsSize 
        public int		 	 FreeB;         //Subset element digits
						 	 
        public int		 	 Level;         //FreeDigits-CellsSize
        public List<UCell>   UCellList = new List<UCell>();    //Subset Cells
		public long		 	 hashValue;
        protected int	 	 sortkey;       
  
		private UInt128[]  	 _connectedCells_b081B9;
						   
        public  UInt128      b081;
        private UInt128[]    _b081B9;           // <- B981in
        public UInt128[]     b081B9 => _b081B9?? (_b081B9=UCellList.Create_b081B9() );
						   
		public UInt128[]   	 connected_b081B9 => _connectedCells_b081B9?? (_connectedCells_b081B9 = Create_connectedCells_b081B9() );
        public UInt128       connectedB81;  	

		public USubset(){ }

		public USubset( int ID, List<UCell> pBOARD, UInt128 B81 ):
			this( ID, B81.Get_FreeB_or(), B81.IEGet_UCell(pBOARD).ToList() ){
		}
		public USubset( int ID, int FreeB, List<UCell> UCellList ){
            this.ID        = ID;
            this.CellSize  = UCellList.Count;

			if( FreeB<=0 ){ FreeB = UCellList.Aggregate(0, (p,q) => p |q.FreeB ); }
            this.FreeB     = FreeB;
            this.UCellList = UCellList;
            this.Level     = FreeB.BitCount()-CellSize;
            this.sortkey   = this.FreeB.GetHashCode();
			this.hashValue = Get_HashValue();
	
            // --- initialSettings ---
            this.b081     = this.UCellList.Aggregate( UInt128.Zero, (p,q) => p | qOne<<q.rc );
			this.connectedB81 = UCellList.Aggregate( UInt128.Zero, (p,q)=> p| pConnectedCells81[q.rc] );
			
            _Set_BitExpression( );

				// --------------------------------------
					void _Set_BitExpression( ){
						FreeB_SP = 0;
						rcbFrame = 0;
							//if( UCellList.Count>2 ) WriteLine("");
						UCellList.ForEach( P =>{
							FreeB_SP  |= P.FreeB;
							rcbFrame |=	P.rcbFrame;		//Func_rcbFrame(P);
							foreach( int no in P.FreeB.IEGet_BtoNo() )  b081B9[no] |= qOne<<P.rc;
								//if( UCellList.Count>2 ) WriteLine( $"P{P}  rcbFrame:{rcbFrame.ToBitString27rcb()}" );
						} );

						rcbb081B9And = new int[9];
						rcbb081B9Or = new int[9];
						foreach( int no in FreeB.IEGet_BtoNo() ){
							rcbb081B9And[no] = b081B9[no].Ceate_rcbFrameAnd( );
							rcbb081B9Or[no]  = b081B9[no].Ceate_rcbFrameOr( );
						}
					}
		}

	}






	 public partial class USubset: IComparable{

        public int              rcbFrame = 0x7FFFFFF;				// Defined when creating an instance.
      
        public int              rcbRow{ get=> rcbFrame&0x1FF; }      //row expression
        public int              rcbCol{ get=> (rcbFrame>>9)&0x1FF; } //column expression
        public int              rcbBlk{ get=> (rcbFrame>>18)&0x1FF; }//block expression

		public bool				IsInsideBlock => rcbBlk.BitCount()==1;

        public int              houseNo_Row{ get => (rcbRow.BitCount()==1)? rcbRow.BitToNum(): -1; }
        public int              houseNo_Col{ get => (rcbCol.BitCount()==1)? rcbCol.BitToNum()+9: -1; }
        public int              houseNo_Blk{ get => (rcbBlk.BitCount()==1)? rcbBlk.BitToNum()+18: -1; }

		// ------------------------------------------------
		private int[]		    _rcbAnd9;
		public int[]		    rcbAnd9 => _rcbAnd9?? (_rcbAnd9=Create_rcbFrameAndB9());

		public ULogical_Node    ULG_node => new( FreeB, b081 );

		public int  Create_rcbFrameAndB9( int no ){
			int noB=1<<no;
			int _rcbAnd = UCellList.Where(p=>(p.FreeB&noB)>0)							// Select cells with no as an element.
						 .Aggregate(0x7FFFFFF, (a,b) => a & b.rc.rcbFrame_Value() );	// house(rcb) common to all elements.
			if( _rcbAnd==0x7FFFFFF ) return 0;
			return _rcbAnd;
		}
		public int[]  Create_rcbFrameAndB9(){ 
			int[] _rcbAnd9Tmp = new int[9]; 
			for( int no=0; no<9; no++ )  _rcbAnd9Tmp[no] = Create_rcbFrameAndB9(no);
			return _rcbAnd9Tmp;
		}

		// ------------------------------------------------

        public int              FreeB_SP;         // changed during analysis
        public int[]            rcbb081B9And; 
        public int[]            rcbb081B9Or; 
        public int              RCC=0;

        public List<(USubset,int)> ConnectedSubset;	//[ATT] ... The second term is a bit representation.  //@@@
        public (USubset,int)       preSubset_no = (null,-9);											  //@@@



		public long		Get_HashValue() => UCellList.Aggregate( (long)0, (a,b) => a^b.Get_hashValue() );
	  //private int		Func_rcbFrame(UCell P)  => 1<<(P.b+18) | 1<<(P.c+9) | (1<<P.r);
        public int CompareTo( object obj ){  // for IComparable. ... don't delete
            USubset UB = obj as USubset;
            if( this.Level!=UB.Level ) return (this.Level-UB.Level);
            if( this.CellSize!=UB.CellSize )   return (this.CellSize-UB.CellSize);

            if( this.FreeB!=UB.FreeB ) return ( this.sortkey-UB.sortkey );

            int bitW = this.b081.CompareTo(UB.b081);
            if( bitW != 0 ) return bitW;

            return  0;
        }
/*
		public int CompareTo( object obj ){
            UAnLS Q = obj as UAnLS;
			if( Q==null ) return 0;
			if( this.Level != Q.Level ) return (this.Level-Q.Level);
			if( this.Size  != Q.Size )  return (this.Size-Q.Size);
            if( this.FreeB !=Q.FreeB )  return (this.FreeB-Q.FreeB);
            return (this.ID-Q.ID);
        }
*/





        public UInt128 ToBitExpression128( int filter_FreeB ){
            UInt128 BP128 = UInt128.Zero;
            foreach( var P in  UCellList.Where( p=>(p.FreeB&filter_FreeB)>0 ) ) BP128 |= UInt128.One<<P.rc;
            return BP128;
        }

		public void RestoreFreeBwk( ) => UCellList.ForEach( P => P.FreeB_SP=P.FreeB ); 
		private UInt128[] Create_connectedCells_b081B9( ){			//..... FreeB_SP
            UInt128[] B128 = new UInt128[9];
			foreach( int no in FreeB.IEGet_BtoNo() ){
				int noB = 1<<no;
				UInt128 Utmp = UInt128.MaxValue;
				foreach( var U in UCellList ){
					if( (U.FreeB&noB) != 0 )  Utmp &= pConnectedCells81[U.rc];
				}
				B128[no] = Utmp;
			}
            return B128;
        }

		public int  rcbAnd9_wk( int no ){
			int noB=1<<no;
			int rcbAnd = UCellList.Where(p=>(p.FreeB_SP&noB)>0).						// Select cells with no as an element.
						 Aggregate(0x7FFFFFF, (a,b) => a & b.rc.rcbFrame_Value() );		// house(rcb) common to all elements.
			if( rcbAnd==0x7FFFFFF ) return 0;
				//UCellList.ForEach( p=> WriteLine( $"b.rc:{p.rc.rcbFrame_Value().rcbToBitString27()}" ) );
				//WriteLine( $"rcbAnd:{rcbAnd.rcbToBitString27()}" );
			return rcbAnd;
		}

		public UInt128[] Get_ConnectedCellsB9( int noB9=0x1FF ){
			UInt128[] connectedCellsB9= new UInt128[9];
			foreach( int no in noB9.IEGet_BtoNo() ){
				connectedCellsB9[no] = b081B9[no].IEGet_rc().Aggregate(UInt128.Zero, (p,q)=> p| pConnectedCells81[q] );
			}
			return connectedCellsB9;
		}
        
        public int Get_RCC_AnLS_AnLS( UAnLS UA ){
            int FreeB_AB = this.FreeB & UA.FreeB;
            if( FreeB_AB==0 )  return 0;  // no common digit

            int RCC_BitExp = 0;
            foreach( var no in FreeB_AB.IEGet_BtoNo() ){
				if( (this.rcbAnd9[no] & UA.rcbAnd9[no]) == 0 )  continue;
                RCC_BitExp |= (1<<no); 
			}
			return RCC_BitExp;
        }


#region ToStrng
		public override string ToString(){
            string st = $"\nUSubSet << ID:{ID} >>  [ CellSize:{CellSize} Level:{Level} ] ";
            st += $"  :{FreeB.ToBitString(9)}  FreeB_SP:{FreeB_SP.ToBitString(9)}\n";
            st += $" rcbFrame:{(rcbFrame).ToBitString27rcb()}";
			st += $" IsInsideBlock:{(IsInsideBlock? "@":"-")}";
            st += $"         b081:{b081.ToBitString81()}\n";
			st += $"connectedB81:{connectedB81.ToBitString81()}";

					//int rcbFX = 0;
            for(int k=0; k<UCellList.Count; k++){
                st += "\n------";
				UCell P = UCellList[k];
                st += $" rc:{P.rc.ToRCString()}";
                st += $" FreeB:{P.FreeB.ToBitString(9)}";
				st += $" FreeB_SP:{P.FreeB_SP.ToBitString(9)}";			               
				st += $" // rcbFrame: {P.rcbFrame.ToBitString27rcb(digitB:false)}";
            }
            return st;
        }

        public string ToStringA(){
            string st = $"<> USubset ID:{ID} CellSize:{CellSize} Level:{Level}  FreeB:{FreeB.ToBitString(9)} rc:{ToStringRCN()}";
            return  st;
        }

        public string ToStringRCN( ){
            string st="";
            UCellList.ForEach( p =>{  st += $" {p.rc.ToRCString()}"; } );
            st = st.ToString_SameHouseComp()+" #"+FreeB.ToBitStringN(9);
            return st;
        }
        public string ToStringRC( ){
            string st="";
            UCellList.ForEach( p =>{  st += $" {p.rc.ToRCString()}"; } );
            st = st.ToString_SameHouseComp();
            return st;
        }
		public  string ToString_Free_SP(){
			string st = $"USubset << ID:{ID} >>  [ CellSize:{CellSize} Level:{Level} ]";
			st += $"  FreeB:{FreeB.ToBitString(9)}  FreeB_SP:{FreeB_SP.ToBitString(9)}\n";
			st += $"         b081 {b081.ToBitString81N()}\n";
			for(int k=0; k<UCellList.Count; k++){
				st += "------";
				int rcW = UCellList[k].rc;
				st += $" rc:{rcW.ToRCString()}";
				st += $" FreeB_SP:{UCellList[k].FreeB_SP.ToBitString(9)}";
				st += $" rcb:b{(rcbBlk).ToBitString(9)}";
				st += $" c{rcbCol.ToBitString(9)}";
				st += $" r{rcbRow.ToBitString(9)}";
				//st += $" connectedB81:{connectedB81.ToBitString81N()}";
			  	st += "\n";
			}
            return st;
        }
#endregion ToString

	}

}
