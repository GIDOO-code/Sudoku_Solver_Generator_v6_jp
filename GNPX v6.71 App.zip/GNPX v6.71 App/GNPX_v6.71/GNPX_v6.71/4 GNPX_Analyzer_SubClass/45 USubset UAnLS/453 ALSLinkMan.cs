using GIDOO_space;
using System;
using System.Linq;
using System.Runtime.CompilerServices;
using static System.Diagnostics.Debug;
using static System.Math;


namespace GNPX_space {

    public class ALSLinkMan: AnalyzerBaseV2{
        private int             pALSSizeMax => G6.ALSSizeMax;
        public List<UAnLS>      ALSList;
		static int			    ALS_plus_done = 0;

        public List<Link_Cell_Subset>[] LinkCeAlsLst;   //Cell->ALS
        public bool             ALS2ALS_Link;   //ALS ->ALS

        public ALSLinkMan( GNPX_AnalyzerMan pAnMan ){
            this.pAnMan = pAnMan;
			this.Initialize();
		}

		public void Initialize(){
            ALSList       = null;
            LinkCeAlsLst  = null;
            ALS2ALS_Link  = false;
			ALS_plus_done = 0;
        }

        public int Prepare_ALSLink_Man( int ALS_plus, int maxSize=5, bool setCondInfo=false, bool debugPrint=false ){
			if( ALSList !=null && ALS_plus_done>=ALS_plus )  return ALSList.Count;
			ALS_plus_done = Max( ALS_plus_done, ALS_plus);
			int _ALS_plus = Max( G6.AnLS? 3: 1, ALS_plus );

            ALSList = Create_ALSList( ALS_plus:_ALS_plus, minSize:1, maxSize );
            return ALSList.Count;  
		}


		private bool IsPureALS2( UAnLS UAn ){
			if( UAn.CellSize == 1 ) return  true;

            UInt128  rcBT = UAn.b081;
			foreach( var P in UAn.UCellList ){
                int FreeB_another = (rcBT&~(qOne<<P.rc)).Get_FreeB_or();
                if( (P.FreeB & ~FreeB_another) == P.FreeB )  return false;  // It is not related to any other cell.
			}

			if( UAn.CellSize >= 3 ){
				for( int n=2; n<UAn.CellSize; n++ ){
					Combination cmb = new( UAn.CellSize, n );
					while(cmb.Successor()){
						int fb = 0;
						for( int k=0; k<n; k++ )  fb |= UAn.UCellList[ cmb.Index[k] ].FreeB;
						if( fb.BitCount() == n )  return false;
					}
				}
			}   
			return true;
		}


		private List<UAnLS> Create_ALSList( int ALS_plus, int minSize, int maxSize ){
            int ALSSizeMax = G6.ALSSizeMax;
            List<UAnLS>  _tmpALSList = new();

            int frame_Board_free = BOARD_Free81.Ceate_rcbFrameOr();
            foreach( int h in frame_Board_free.IEGet_BtoNo(27) ){
                UInt128  h_Board_free = BOARD_Free81 & HouseCells81[h];
                int hSize = h_Board_free.BitCount();
                if( hSize<1 ) continue;

                int szMax = Min(hSize,8-ALS_plus);
                szMax = Min(szMax,pALSSizeMax);						// ALS size maximum value
                for( int sz=minSize; sz<=szMax; sz++ ){				// ALS size: Number of cells that make up ALS
                    Combination_81B cmb81 = new( hSize, sz, h_Board_free );
                    while( cmb81.Successor() ){						// generate a combination
                        int FreeB = cmb81.valueBT.Get_FreeB_or();
						int FreeBC = FreeB.BitCount();
                        if( FreeBC<=sz || FreeBC>(sz+ALS_plus) ) continue;       
               
                        List<UCell> UCellList = cmb81.valueBT.IEGet_UCell(pBOARD).ToList();
                        UAnLS UA = new UAnLS( 0, FreeB, UCellList );					 
                        if( !UA.IsPureALS() ) continue;					// Pure ALS : not include _LockedSet.
						if( !IsPureALS2(UA) ) continue;
							
						_tmpALSList.Add(UA);
                    }
                }
            }
                                                                                                                                                                                                                                                                                                         
            _tmpALSList = _tmpALSList.DistinctBy(p=>p.b081).ToList();
            _tmpALSList.Sort( (a,b) => a.CompareTo(b) );
            int ID=0;
            _tmpALSList.ForEach(P=> P.ID=ID++ );
            return _tmpALSList;  
        }


        public IEnumerable<UAnLS> IEGetCellInHouse( int lvl, int noB, UInt128 Area128 ){
            foreach( var P in ALSList.Where(p=>p.Level==lvl) ){
                if( (P.FreeB&noB)==0 )         continue;
                if( (P.b081 & ~Area128 ).IsNotZero() ) continue;
                yield return P;
            }
        }

        //RCC
        public int  Get_AlsAlsRcc( UAnLS UA, UAnLS UB ){    
			int _ToRCC(int val, int ix) => (val>0)? 1<<ix: 0; 

			int FreeB = UA.FreeB & UB.FreeB;
			int RCC = FreeB.IEGet_BtoNo().Aggregate(0, (p,no) => p|= _ToRCC( UA.rcbAnd9[no] & UB.rcbAnd9[no] , no) );

            return RCC;
        }


        // Link between Cell#n --> ALS
        //  ALS turns to _LockedSet when Cell#n is true.
        public void QSearch_Cell2ALS_Link( ){
            Prepare_ALSLink_Man(1);
            if( LinkCeAlsLst!=null ) return ;
            if( ALSList==null || ALSList.Count<2 )  return;
            LinkCeAlsLst = new List<Link_Cell_Subset>[81];

            foreach( var PA in ALSList ){
                //debug WriteLine( $"\n{PA}");
                foreach ( var no in PA.FreeB.IEGet_BtoNo() ){
                    int noB=(1<<no);
                    UInt128 H = UInt128.MaxValue;
                    foreach( var P in PA.UCellList.Where(q=>(q.FreeB&noB)>0)){
                        H = H & Connected_81[P.rc];
                    }
                    if( H.IsZero() ) continue;
                  
                    foreach ( var P in H.IESelect81B_with_noB(pBOARD,noB) ){
                        var Q = new Link_Cell_Subset(P,PA,no);
                        if( LinkCeAlsLst[P.rc]==null )  LinkCeAlsLst[P.rc]=new List<Link_Cell_Subset>();
                        LinkCeAlsLst[P.rc].Add(Q);

                        // if P#no is true, PA(ALS) turns to _LockedSet.
                        //debug WriteLine( $"no:#{no+1} Q.UC:{Q.UC}" );
                    }
                }
            }
        }

        public void QSearch_ALS2ALS_Link( ){        // <-- eALS_Chain
            Prepare_ALSLink_Man( ALS_plus:1, setCondInfo:true, debugPrint:false);

            if( ALS2ALS_Link ) return;
            ALS2ALS_Link=true;

            var cmb = new Combination( ALSList.Count, 2 );
            while( cmb.Successor() ){

                UAnLS UA = ALSList[cmb.Index[0]];
                UAnLS UB = ALSList[cmb.Index[1]];
				WriteLine( $"\n --UA{UA}\n --UB{UB}" );

                int RCC = Get_AlsAlsRcc( UA, UB );    // improved! <- Get_AlsAlsRcc( UA, UB );
                if( RCC==0 ) continue;

                if( UA.ConnectedALS is null ) UA.ConnectedALS = new();
                UA.ConnectedALS.Add( (UB,RCC) );	//[ATT] ... The second term is a bit representation.

                if( UB.ConnectedALS is null ) UB.ConnectedALS = new();
                UB.ConnectedALS.Add( (UA,RCC) );	//[ATT] ... The second term is a bit representation.
            }
		}


        public (UInt128,UInt128) Get_RCC_bitExp( int RCC, UAnLS UA, UAnLS UB, bool debugPrint=false ){
            if( RCC==0 )  return (UInt128.Zero,UInt128.Zero);  // no common digit

			UInt128 RCC_UA_BitExp=UInt128.Zero, RCC_UB_BitExp=UInt128.Zero;
            foreach( var no in RCC.IEGet_BtoNo() ){	
                RCC_UA_BitExp |= UA.b081B9[no];
				RCC_UB_BitExp |= UB.b081B9[no];
			}
			if(debugPrint){
				WriteLine( $" UA:{UA.b081.ToBitString81()}  UB:{UA.b081.ToBitString81()}" );
				for( int no=0; no<9; no++){
					WriteLine( $"  {no+1}:{UA.b081B9[no].ToBitString81()}   {UA.b081B9[no].ToBitString81()}" );
				}
			}
			return (RCC_UA_BitExp,RCC_UB_BitExp);
        }
    } 

}
