
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Security.Cryptography.X509Certificates; 
using System.Security.Cryptography;
using System.Xml.Linq;


namespace GNPX_space {

    public class AHSLinkMan: AnalyzerBaseV2{
        private int                 pAHSSizeMax => G6.ALSSizeMax;	// Use ALSSizeMax
        public List<UAnHS>          AHSList;
		static int					ALS_plus_done = 0;
		static int					_maxSize_ = 0;

        public bool                 AHS2AHS_Link;   //AHS ->AHS
		public int					stage_nPlus = 0;

        public AHSLinkMan( GNPX_AnalyzerMan pAnMan ){
            this.pAnMan = pAnMan;
			this.Initialize();
		}

		public void Initialize(){
            AHSList       = null;
//            LinkCeAlsLst = null;
            AHS2AHS_Link = false;
			stage_nPlus  = 0;
			ALS_plus_done  = 0;
			_maxSize_ = 0;
        }

		private bool IsHit_stage_nPlus( int ALS_plus ){
			if( stageNoP != (stage_nPlus>>4) ){ stage_nPlus = stageNoP<<4; return false; }
			if( (stage_nPlus & (1<<ALS_plus)) == 0 )  return false;
			stage_nPlus = (stage_nPlus<<4) | (1<<ALS_plus);
			return true;
		}


        public int Prepare_AHSLink_Man( int nPlsB, int maxSize=5, bool setCondInfo=false, bool debugPrint=false ){
			{
				if( AHSList !=null && AHSList.Count>3 && ALS_plus_done>=nPlsB && _maxSize_>=maxSize )  return AHSList.Count;
				ALS_plus_done = Max( ALS_plus_done, nPlsB);
				_maxSize_ = Max( _maxSize_, maxSize ); 
			}
		
            AHSList = Create_AHSList( noBMax:8, debugPrint:debugPrint );


            if(debugPrint)  AHSList.ForEach( (P,kx) => WriteLine( $"{kx} {P}") );

            return AHSList.Count;  
		}


		private bool IsPureAHS2( UAnHS UAn ){
			if( UAn.CellSize == 1 ) return  true;
			UInt128  rcBT = UAn.AHS_B81;
			foreach( var P in UAn.AHS_B81.IEGet_UCell(pBOARD) ){
				int FreeB_another = (rcBT&~(qOne<<P.rc)).Get_FreeB_or();
                if( (P.FreeB & ~FreeB_another) == P.FreeB )  return false;  // It is not related to any other cell.
			}

			if( UAn.CellSize >= 3 ){
				List<UCell> UCellList = UAn.AHS_B81.IEGet_UCell(pBOARD).ToList();
				for( int n=2; n<UAn.CellSize; n++ ){
					Combination_81B cmb = new( UAn.CellSize, n, rcBT );
					while(cmb.Successor()){
						int fb = 0;
						for( int k=0; k<n; k++ )  fb |= UCellList[ cmb.Index[k] ].FreeB;
						if( fb.BitCount() == n ){
							//WriteLine( UAn );
							return false;
						}
					}
				}
			}
			return true;
		}

		private List<UAnHS> Create_AHSList( int noBMax, bool debugPrint=false ){
			// maxLevel : max class number of AHS ( 1..maxLevel )
			// size : number of digits

            List<UAnHS>  _tmpAHSList = new() ;

			for(int h=0; h<27; h++ ){       // house 0-8(row) 9-17(column) 18-26(block)
				List<(UInt128,int)> BF9H = new();
				for( int no=0; no<9; no++ ){
					var Q = BOARD_Free81B9[no] & HouseCells81[h];
					if( Q != qZero )  BF9H.Add( (Q,1<<no) );
				}
				if( BF9H.Count() <=0 )  continue;

				int noBMaxT = Min(noBMax, BF9H.Count() );
				var QH = BOARD_Free81 & HouseCells81[h];

				for( int size_noB=1; size_noB<=noBMaxT; size_noB++ ){
					int  sz_nPls = size_noB +1;

					Combination cmb = new( BF9H.Count() , size_noB );
					int nxt = 99;
					while( cmb.Successor(skip:nxt) ){
						int FreeB = 0;
						UInt128 Psigma = qZero;
						for( int k=0; k<size_noB; k++ ){
							nxt = k;
							var (P,noB) = BF9H[cmb.Index[k]];
							Psigma |= P;									// cells pattern 
							FreeB  |= noB;									// digits pattern
							if( Psigma.BitCount() > sz_nPls )  goto nextCmb;
						}
						UAnHS UAHS = new( 0, size_noB, FreeB, Psigma, h );
						if( UAHS.Level>sz_nPls )  goto nextCmb;				// *.Level = CellSize - noBSize;

						UInt128 freeCell = QH & ~Psigma;
						if( freeCell == qZero )  goto nextCmb;
							if(debugPrint) WriteLine( $"  --> {UAHS}" );
						_tmpAHSList.Add( UAHS );

					nextCmb:
						continue;
					}
				}
			}

			_tmpAHSList.RemoveAll(p => p.Level==0 );
			_tmpAHSList = _tmpAHSList.DistinctBy(p =>p.rcB_FreeB_key).ToList();
            _tmpAHSList.Sort( (a,b) => a.CompareTo(b) );
            int ID=0;
            _tmpAHSList.ForEach(P=> P.ID=ID++ );
			if(debugPrint)  _tmpAHSList.ForEach( p=> WriteLine(p));

            return _tmpAHSList;  
        }

    } 

}