﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Windows.Documents;
using System.Xml.Linq;

using GIDOO_space;

using STD_SDK;

using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space{

    // *** Puzzle Management ***
    // In GNPX, the concept of a "puzzle" encompasses the following two aspects:
    //  1) Management of a collection of puzzles
    //  2) Analysis of individual puzzles
    // Since the first aspect involves handling a large number of puzzles, a lightweight approach is desirable.
    // On the other hand, the second aspect—"puzzle analysis"—requires managing the diverse, unique characteristics of each individual puzzle.
    // For these reasons, the design of GNPXv7- employs separate classes to handle these two functions.
    

    public class UPuzzle{
        private UInt128[]    pConnectedCells81 => GNPX_Utilitie.Connected_81;

		// -------------------------------
        public Trans_para    TP;        // Scheduled for deletion
		// -------------------------------





        public v7_UPuzzle_Base v7B_Puzzle;

        public int          ID => v7B_Puzzle.ID; 
        public string       stPZL_withSP;   // v7 @@@


		public string        BaseName => v7B_Puzzle.stPuzzleName ;



        public UPuzzle		 pre_PZL  = null;			// parents.
        public int           selectedIX = -1;           // 

        public List<UPuzzle> Child_PZLs = new();	    // children




		public int           stageNo;				// stage No.
    //  public int           stageNoP => __stageNo100 + stageNo;				// stage No.
        public List<UCell>   BOARD;						// Board cells(81 cell)  Defined in List for use the Linq functions.

        public int           SolCode;           // v7 @@@ Scheduled for deletion
        public UAlgMethod?   pMethod = null;			// Analytical method  
        public string        Name; // Name
        public int           difficultyLevel;   // v7 diffculty @@@


        public string        Sol_Result;				// Solution description
        public string        Sol_ResultLong;			// Solution description(Long)
        public string        extResult;					// Solution description(ext.)
		public string        Sol_ResultHTML;			// Solution HTML

        public string        __SolResultKey => $"{stageNo}_{Sol_ResultLong.Replace("\n"," ")}";



        public UPuzzle( v7_UPuzzle_Base v7B_Puzzle ){
            this.v7B_Puzzle = v7B_Puzzle;

            int[] board = v7B_Puzzle.Get_board();
            int rc = 0;
            this.BOARD = board.ToList().ConvertAll( n=> new UCell(rc++,n) );
            this.TP    = new(board);

            this.stageNo = 0;        
            this.extResult = "";
            this.Sol_ResultLong = "";
			this.Sol_ResultHTML = "";
        }


        public UPuzzle Copy( ){
            UPuzzle PZLcpy = (UPuzzle)this.MemberwiseClone();
            PZLcpy.BOARD = new List<UCell>();
            foreach( var q in BOARD ) PZLcpy.BOARD.Add(q.Copy());
            return PZLcpy;
        }
        
        public void ToInitial( bool resetAll=true ){
            this.BOARD.ForEach( p => p.Reset_result(resetAll:resetAll) );
            this.difficultyLevel = -1;   // -1:InitialState　0:Manual
        //    this.pMethod         = null; // Analytical method
            this.Sol_Result      = "";   // Solution description
            this.Sol_ResultLong  = "";   // Solution description(Long)
            this.extResult       = "";   // Solution description(ext.) 
        }





		public void Randomize_PuzzleDigits( ){
            int[] ranNum = Enumerable.Range(0,9).ToArray();
			Random.Shared.Shuffle(ranNum);

            foreach( var q in BOARD.Where(p=>p.No!=0) ){
				int nm=q.No, nm2=ranNum[Abs(nm)-1]+1;
                q.No = (nm>0)? nm2: -nm2;
            }
		} 

        public void ToPreStage( ) => ToInitial( resetAll:false );



    }
}