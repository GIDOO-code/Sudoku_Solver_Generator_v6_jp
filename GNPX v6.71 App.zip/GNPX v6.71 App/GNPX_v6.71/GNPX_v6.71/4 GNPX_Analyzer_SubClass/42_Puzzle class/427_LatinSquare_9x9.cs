﻿using GIDOO_space;

namespace GNPX_space {

    public class LatinSquare_9x9 : IComparable {
        public long hashVal;
        public int[] SolX;
        public int validCC = 0;
        public string stSolX => string.Join("", SolX).Replace("0", ".");

        public string stSolX9 => string.Concat(_Split(stSolX, 9));
        public IEnumerable<string> _Split(string stP, int size, string stringToInsert=" " ){
            for( int k=0; k<stP.Length; k+=size)  yield return stP.Substring(k, size) + stringToInsert;
            yield break;
        }



        public LatinSquare_9x9(string stSolX ){
            string stSolX2 = stSolX.Replace(".", "0");
            this.SolX = stSolX2.stringToInt().ToArray();
            this.hashVal = this.SolX.Get_hashValue_int81();
        }


        public LatinSquare_9x9(List<int> SolXList ){
            this.SolX = SolXList.ToArray();
            this.hashVal = this.SolX.Get_hashValue_int81();
        }

        public LatinSquare_9x9(int[] SolX ){
            this.SolX = SolX;
            this.hashVal = this.SolX.Get_hashValue_int81();
        }


        public string __stSolXp => string.Join(" ", SolX).Replace("0", ".");
        public string stSolX9p => string.Concat(_Split(__stSolXp + " ", 18));

        //public string stSolX9pp => string.Concat( _Split( _Split(__stSolXp+" ",6)+" ", 21) );	
        public string stSolX9pp => stSolX9ppFunc();
        public string stSolX9ppFunc(  ){
            var x0 = "_" + string.Join("_", SolX).Replace("0", "."); 
            var x1 = _Split(x0, 6 );
            var x2= " " + string.Concat(x1).Trim();
            var x3 = _Split(x2, 21, stringToInsert:"\n");
            x3 = _Split(x2, 66, stringToInsert:"\n");
            var st = string.Concat(x3).Replace("_"," ");

        //    string st = string.Concat(_Split(stSolX9p, 6))+"b";
        //    st = string.Concat(_Split(st + " ", 21));
            return st;
        }



        public LatinSquare_9x9(string line, bool ApplyPatternB = false, int[] GPat81 = null ){
            SolX = new int[81];
            if(ApplyPatternB){
                for(　int rc = 0; rc < 81; rc++)  SolX[rc] = (GPat81[rc] == 0) ? 0 : line[rc].ToInt();
            }
            this.hashVal = SolX.Get_hashValue_int81();
        }

        public LatinSquare_9x9(string stSolX, bool ApplyPatternB = false, int[] GPat81 = null, bool debugB = false ){
            SolX = stSolX.Replace(".", "0").stringToInt().ToArray();
            if(ApplyPatternB ){
                for( int rc=0; rc<81; rc++ ){ 
                    if(GPat81[rc] == 0)  SolX[rc] = 0;
                }
            }
            this.hashVal = SolX.Get_hashValue_int81();

            if(debugB) SolX.__DBUG_Print2(sqF: true, $"LatinSquare_9x9  hv:{hashVal}");
        }

        public int CompareTo(object obj ){
            LatinSquare_9x9 LS = (LatinSquare_9x9)obj;
            return (this.hashVal == LS.hashVal) ? 0: (this.hashVal<LS.hashVal)? -1: 1;
        }

        public int CompareTo2(object obj ){
            LatinSquare_9x9 LS = (LatinSquare_9x9)obj;
            for( int k=0; k<81; k++ ){
                if( this.SolX[k] == LS.SolX[k] )  continue;
                return (this.SolX[k] - LS.SolX[k]);
            }
            return 0;
        }

        public override string ToString(  ){
            string stL = string.Join("", SolX).Replace("0", ".");
            //string st = $"hv:{hashVal} {stL.Substring(0,20)}";
            string st = $"hv:{hashVal} {stSolX}  validCC:{validCC}";
            return st;
        }
    }
}