﻿using System;
using System.Collections.Generic;
using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Linq;
using System.Windows.Documents;
using System.Xml.Linq;
using GNPX_DLX3;

namespace GNPX_space{
    using Standard_Form = STD_SDK.Standard_Form;

    // Single-purpose puzzle class
    // As of version 7, the single-purpose class has been separated from the puzzle class used for actual operations (the "working class").
    // The single-purpose class consists of an 81-digit sequence of numbers and a small number of properties; 
    // it generates a "working class" instance whenever necessary.

    public partial class v7_UPuzzle_Base{
        static private DLX_V2.SudokuSolver SDK_Solver = new();				// DLX Solver for SUDOKU.

        public int        ID;
        public string     stPuzzle;               // *** puzzle entity
        public string?    stPuzzleName;


        public  bool?     IsValid;

        public int        hasgValue;
        public int        difficulty;

        public UAlgMethod method_MostDiffcul;


        // -------------------------------------------------------------------
        public string?   PuzzleStandardCode;    // Puzzle Standard Code;
        public Standard_Form? Std_Frm;



        private int[]?    _Solution;
        public  int[]?    Solution => _Solution!?? (_Solution=Get_Solution());  // Generated only once when needed.



        public v7_UPuzzle_Base( ){
            this.stPuzzle = new string('0',81);
            this.difficulty = 0;
        }

        public v7_UPuzzle_Base( string stPuzzle, int difficulty, string stPuzzleName="" ){
            this.stPuzzle     = stPuzzle.Replace(" ","").Replace(".","0");
            this.stPuzzleName = stPuzzleName;
            this.hasgValue    = stPuzzle.GetHashCode();

         // WriteLine( $"\n   Puzzle: {stPuzzle.ToStringWithSpace()}\n Solution: {string.Join("",Solution).ToStringWithSpace()}");
        }

        public  v7_UPuzzle_Base( int[] board ) => this.stPuzzle = string.Join("",board);   

        public override string ToString( ) => stPuzzle.Replace("0",".").ToStringWithSpace();

        public string   stPuzzle_forFile => $"{stPuzzle}, {difficulty}, {stPuzzleName}";





        // -----------------------------------------------------------
        public int[]?    Get_board() => stPuzzle.stringToIntArray();

        private int[]   Get_Solution(){
            int[] board = Get_board();
            if( board.ToList().Count(p=>p>0) < 17 )  return null;
            var solutions = SDK_Solver.Solve( board, maxSolutions:int.MaxValue  );   //ct:undefine
            IsValid = solutions.Count==1;
            return  solutions[0];
        }

    }





    // Additional functionality for special processing
    public partial class v7_UPuzzle_Base{
		public bool		g7MarkA;				// for develop (ver 5.2+)
		public bool		g7Error;
		public string	g7MarkA_Msg=null;		// for develop (ver 5.2+)
    }

}