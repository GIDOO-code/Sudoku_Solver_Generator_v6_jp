using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System;

namespace GNPX_space{

    public partial class UCellLink: IComparable{
        static public UInt128[] Connected_81 => GNPX_Utilitie.Connected_81;

        static public List<UCell>   pBOARD;
        public int               h;
        public int               hB;
        public int               sw;      // 1:Strong 2:Weak
        public readonly int      no;
        public UInt128           link81B;
        
        public readonly UCell?   UCe1;
        public readonly UCell?   UCe2;
        public int               rc1;
        public int               rc2;

    //    public bool              used;

        public UInt128           rc1B{ get => UInt128.One<<rc1; }
        public UInt128           rc2B{ get => UInt128.One<<rc2; }

        public UInt128           connectedArea => Connected_81[rc1] | Connected_81[rc2];

        public int               hashVal;
        public bool              BVFlag => UCe1.FreeBC==2 && UCe2.FreeBC==2;    // bivalued Link
        public bool              LoopFlag;  // Last Link

        public UCellLink(){}

        public UCellLink( int h, int no, UInt128 link81B, int sw ){
            this.h=h; this.no=no; this.link81B=link81B; this.sw=sw;
            (rc1,rc2) = link81B.BitToTupple();
            UCe1 = pBOARD[rc1]; UCe2 = pBOARD[rc2];
            hashVal = link81B.GetHashCode() | ((no*10+sw).GetHashCode());

            int hBframe = link81B.ToRCBFrame();
            hB = 0;
            if( (hBframe & 0x1FF).BitCount() == 1 )        hB |= (hBframe & 0x1FF);
            if( (hBframe & (0x1FF)<<9).BitCount() == 1 )   hB |= (hBframe & (0x1FF)<<9);
            if( (hBframe & (0x1FF)<<18).BitCount() == 1 )  hB |= (hBframe & (0x1FF)<<18);
        }

        public int CompareTo( object obj ){
            UCellLink? Q = obj as UCellLink;
            if( this.sw != Q.sw  ) return (this.sw-Q.sw);
            if( this.no != Q.no  ) return (this.no-Q.no);
            if( this.rc1 !=Q.rc1 ) return (this.rc1-Q.rc1);
            return (this.rc2-Q.rc2);
        }

        public override bool Equals( object obj ){
            UCellLink? Q = obj as UCellLink;
            if( Q==null )  return true;
            return (this.sw==Q.sw && this.no!=Q.no && this.rc1!=Q.rc1 && this.rc2!=Q.rc2);
        }

        public override string ToString(){
            string st= $"sw:{sw}  no:#{no+1} (rc1-rc2):{rc1.ToRCString()} - {rc2.ToRCString()} {link81B.TBS()}";
            st += $"  h:{hB.ToBitString27rcb_Omit_null()}"; 
            return st;
        }
    }

}