﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Windows.Media;

using GIDOO_space;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
    //Sudoku's cell definition.
        [Serializable]
    public partial  class UCell{ //Basic Cell Class
        static private readonly Color CrBlack_ = Colors.Black; 
        static public GNPX_AnalyzerMan pAnMan;

        public readonly int    rc;      // cell position(0-80)
        public readonly int    r;       // row
        public readonly int    c;       // column
        public readonly int    b;       // block
	 	public readonly int    rcbFrame;	


        public int			ErrorState; // 0:-  1:Fixed 　8:Violation  9:No solution
        public int			No;         // >0:Puzzle  =0:Open  <0:Solution
        public int			FreeB{ get; set; }   // Bit expression of candidate digits

        public int			FixedNo;    // Fixed digit. Obtaine by an algorithm and reflecte to the board status by management processing
        public int			CancelB;    // Digits to eliminate(bit expression). Same process as above.

        public List<EColor> ECrLst;     // Display color of cell digits. Obtaine by an algorithm.
        
		private object		obj = new object();

        public		UCell( ){}
        public		UCell( int rc, int No, int FreeB=0 ){
            this.rc=rc; this.r=rc/9; this.c=rc%9; this.b=_ToBlock(rc);  //rc/27*3+(rc%9)/3;
			this.rcbFrame = _ToRCBFrame(rc);	// => (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9);rc.ToRCBFrame( );
            this.No=No; this.FreeB=FreeB;   
            this.ECrLst=null;
            this.FreeB_original = FreeB;
        }
        public override string ToString(){
            string st2 = $" UCell rc:{rc:pApCrBr}[r{r+1}c{c+1}]  No:#{No}";
            st2 += $" FreeB:{FreeB.ToBitString(9)}";
			st2 += $" FreeB_SP:{FreeB_SP.ToBitString(9)}";
            st2 += $" FixedNo:{FixedNo.ToString()}";
            st2 += $" CancelB:{CancelB.ToBitString(9)}";
            return st2;
        }

		private string __stNoFreeB => (No==0)? FreeB.TBScmp(): Abs(No).ToString();

		public string ToString_RCN() => $"{rc.ToRCString()}#{__stNoFreeB}"; 
	}




	public partial  class UCell{ //Basic Cell Class
		public int      nx;         // (Working variable used in algorithm)	
		public int      FreeB_SP;	// Working variable used in algorithm
        private readonly int		FreeB_original;


        public int      FreeBC{ get=>FreeB.BitCount(); }   //Number of candidate digits.
		public int		noB_FixedFreeB => (No!=0)? 1<<(Abs(No)-1): FreeB;
 
		private int		_ToBlock(int rc) => rc/27*3+(rc%9)/3;

		private int		_ToRCBFrame( int rc) => (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9);  //rc.ToRCBFrame( );
		


	    public int		Get_hashValue() => ((rc<<9) | FreeB).GetHashCode();


        public void		Reset_StepInfo(){
            ErrorState = 0;
            CancelB    = 0;
            FixedNo    = 0;

            this.ECrLst= null;
        }

        public UCell Copy( ){
			lock(obj){
				UCell UCcpy = (UCell)this.MemberwiseClone();
				try{
					if( !(ECrLst is null) ){
						UCcpy.ECrLst = new List<EColor>();
						ECrLst.ForEach( p=> UCcpy.ECrLst.Add(new EColor(p) ));
					}
				}
				catch(Exception e){}
				return UCcpy;
			}
        }	





        public void Reset_result( bool resetAll=false ){
            CancelB=FixedNo=0; ECrLst=null;
            if( resetAll ) FreeB=0;
        }
        public void Reset_All(){
            CancelB=FixedNo=FreeB=0; ECrLst=null;
            if( No < 0 )  No = 0;
        }


        public void ECrLst_Add( EColor EC ){
            if( ECrLst==null) ECrLst=new List<EColor>();
            if( !ECrLst.Contains(EC) )  ECrLst.Add(EC);

            if( EC.CrDigBkgd == Color.FromArgb(0xFF,0xFF,0xFF,0x00) )  WriteLine( $"EC:{EC}" );
        }

        //  EColor( Color ClrCellBkg, int noB, Color CrDig, Color CrDigBkgd )
        public void Set_CellBkgColor( Color CellClrBkg ){ 
            ECrLst_Add( new EColor(CellClrBkg,0x1FF,CrBlack_,CrBlack_) );
        }

        public void Set_CellDigitsColor_noBit( int noB, Color clr ){
            if( (FreeB&noB) == 0 )  return;
            ECrLst_Add( new EColor( CrBlack_, noB, clr, CrBlack_ ) );
        }
        public void Set_CellDigitsColorRev_noBit( int noB, Color clrRev ){
            if( (FreeB&noB) == 0 )  return;
            ECrLst_Add( new EColor( CrBlack_, noB, CrBlack_, clrRev) );
        }

        public void Set_CellFrameColor( Color CrCelFrame ){
            ECrLst_Add( new EColor( CrCelFrame:CrCelFrame) );
        }

        public void Set_CellColor_BkgColor_noBit( int noB, Color clr, Color clrBkg ){
            ECrLst_Add( new EColor( clrBkg, noB, clr, CrBlack_) );
        }
        public void Set_CellDigitsBkgColorRev_noBit( int noB, Color clrRev, Color clrBkg ){
            if( (FreeB&noB) == 0 )  return;
            ECrLst_Add( new EColor( clrBkg, noB, CrBlack_, clrRev) );
        }


        public string ToStringN(){
            string st2 = $" UCell rc:{rc:pApCrBr}[r{r+1}c{c+1}]  no:#{No}";
            st2 += $" FreeB:{FreeB.ToBitString(9)}";
			st2 += $" FreeB_SP:{FreeB_SP.ToBitString(9)}";
            st2 += $" CancelB:{CancelB.ToBitString(9)}";
            return st2;
        }
        public string ToStringN2(){
            string st2 = $" UCell {rc.ToRCString()} #{No}";
            st2 += $" FreeB:{FreeB.ToBitString(9)}";
			st2 += $" FreeB_SP:{FreeB_SP.ToBitString(9)}";
            st2 += $" CancelB:{CancelB.ToBitString(9)}";
            return st2;
        }

    }
}