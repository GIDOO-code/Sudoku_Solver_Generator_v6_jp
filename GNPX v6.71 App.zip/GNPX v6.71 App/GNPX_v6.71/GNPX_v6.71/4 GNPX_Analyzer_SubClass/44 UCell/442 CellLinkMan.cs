using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System;


namespace GNPX_space{
    
    public partial class CellLinkMan: AnalyzerBaseV2{
        public  List<UCellLink>?     CellLinks;//cell Link
        public  List<UCellLink>[]?   CellLinks_rc;//cell Link

        public CellLinkMan( GNPX_AnalyzerMan pAnMan ){
            this.pAnMan = pAnMan;
        }
     
        public void  PrepareCellLink( bool debugPrint=false ){
           Search_Links( debugPrint );
        }

        private int Search_Links( bool debugPrint ){
            UCellLink.pBOARD = pBOARD;
            CellLinks = new();
            CellLinks_rc = new List<UCellLink>[81];

            CellLinks = new();
            foreach( int no in Enumerable.Range(0,9) ){
                UInt128  BD_Free_no = BOARD_Free81B9[no];
                if( BD_Free_no == qZero )  continue;

                int rcFrame = BD_Free_no.ToRCBFrame();
                foreach( int h in rcFrame.IEGet_BtoNo(27) ){
                    UInt128 Q = BD_Free_no & HouseCells81[h];
                    int sw = (Q.BitCount()==2)? 1: 2;   // 1:Strong 2:Weak

                    Combination_81B cmb81B = new(Q.BCC(), 2, Q);
                    while( cmb81B.Successor()){  _Set_Links(h,no,cmb81B.valueBT,sw); }
                }
            }

            CellLinks = CellLinks.DistinctBy(p=>p.hashVal).ToList();
            foreach( int rc in Enumerable.Range(0,81) ){
                if( CellLinks_rc[rc] == null )  continue;
                CellLinks_rc[rc] = CellLinks_rc[rc].DistinctBy(p=>p.hashVal).ToList();
                    if( debugPrint ) CellLinks_rc[rc].ForEach(q=>WriteLine(q));
            }
 
            return CellLinks_rc.Count();

                    void _Set_Links( int h, int no, UInt128 link81B, int sw ){
                        var (rc1,rc2) = link81B.BitToTupple();
                        if( rc2 < 0 )  return;
                        if( CellLinks_rc[rc1] is null ) CellLinks_rc[rc1] = new();
                        if( CellLinks_rc[rc2] is null ) CellLinks_rc[rc2] = new();

                        UCellLink Q = new(h,no,link81B,sw);
                        CellLinks.Add(Q);
                        CellLinks_rc[rc1].Add(Q);
                        CellLinks_rc[rc2].Add(Q);
                    }
        }



        public IEnumerable<UCellLink> IEGetRcNoBTypB( int rc, int noB, int sw ){
            // typB=1:strong  link =2:weak link  =3:strong & weak link
            if( CellLinks_rc[rc] == null ) yield break;
            foreach( var LK in CellLinks_rc[rc] ){
                if( ((1<<LK.no)&noB)>0 && ((LK.sw&sw)>0) ) yield return LK;
            }
            yield break;
        }

    }
}