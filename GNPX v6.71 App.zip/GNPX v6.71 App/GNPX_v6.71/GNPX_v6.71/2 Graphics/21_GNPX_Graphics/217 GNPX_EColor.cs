using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows;
using System.Windows.Controls;

using System.Windows.Media;
using System.Windows.Media.Imaging;

using System.Windows.Shapes;

using GIDOO_space;
using System.Threading;

//Reverse sample code
//http://msdn.microsoft.com/ja-jp/ff363212#05

//[C#/XAML] Draw graphics with WPF
//http://code.msdn.microsoft.com/windowsdesktop/CVBXAML-WPF-Windows-WPF-0738a600

namespace GNPX_space{

    public class EColor{
        static private readonly Color CrBlack_= Colors.Black;
        static private readonly Color _ClrTracer_ = Color.FromArgb(0xFF,0x1,0x2,0x4);

        public Color CrCelBkgd  = CrBlack_;
        public Color CrCelFrame = CrBlack_; 
        public int   noB;                   // Specify colors for each candidate digits in the cell.
        public Color CrDig      = CrBlack_;
        public Color CrDigBkgd  = CrBlack_;


        public EColor(){ }
        public EColor( Color ClrCellBkg, int noB, Color CrDig, Color CrDigBkgd ){
            this.CrCelBkgd=ClrCellBkg;
            this.noB=noB; this.CrDig=CrDig; this.CrDigBkgd=CrDigBkgd;
        }
			
        public EColor( EColor E ){
            CrCelBkgd=E.CrCelBkgd; noB=E.noB; CrDig=E.CrDig; CrDigBkgd=E.CrDigBkgd; CrCelFrame=E.CrCelFrame;
        }

        public EColor( Color CrCelFrame ){ this.CrCelFrame=CrCelFrame; }

        static public bool operator==( EColor A, EColor B ){
            try{
                if( B is null )  return false;
                bool eq = A.noB==B.noB && A.CrDig==B.CrDig && A.CrDigBkgd==B.CrDigBkgd && A.CrCelBkgd==B.CrCelBkgd;
                return eq;
            }
            catch(NullReferenceException ex){ WriteLine(ex.Message+"\n"+ex.StackTrace); return true; }
        }
        static public bool operator!=( EColor A, EColor B ){
            try{
                if( B is null )  return true;
                bool eq = A.noB!=B.noB || A.CrDig!=B.CrDig || A.CrDigBkgd!=B.CrDigBkgd || A.CrCelBkgd!=B.CrCelBkgd;
                return eq;
            }
            catch(NullReferenceException ex){ WriteLine(ex.Message+"\n"+ex.StackTrace); return true; }
        }
        public override string ToString(){
            string st = $" no:{noB.TBS()} CellBkg:{CrCelBkgd} DigClr:{CrDig} DigBkgClr:{CrDigBkgd}";
            return st;
        }

    }
  
}
