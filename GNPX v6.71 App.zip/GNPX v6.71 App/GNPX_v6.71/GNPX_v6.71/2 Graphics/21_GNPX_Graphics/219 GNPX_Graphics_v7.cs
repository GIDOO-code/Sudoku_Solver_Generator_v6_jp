using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Diagnostics.Debug;
using static System.Math;

//Reverse sample code
//http://msdn.microsoft.com/ja-jp/ff363212#05

//[C#/XAML] Draw graphics with WPF
//http://code.msdn.microsoft.com/windowsdesktop/CVBXAML-WPF-Windows-WPF-0738a600

using GIDOO_space;

namespace GNPX_space{
	using pApCrBr = App_ColorBrush;   
	using pApEnv  = App_Environment;
 
  #region develop_new_Algorithm 
    public partial class GNPX_Graphics{

        public GFormattedText Get_GFont_with_Scale(int fSize){
            GFont gFntnn = new GFont("Courier", fSize, FontWeights.DemiBold, FontStyles.Normal);
            GFormattedText GFnn = new GFormattedText(gFntnn);
            return GFnn;
        }

        public RenderTargetBitmap Create_Cell_Image_Light_with_Scale(UCell P, double scale){
            Brush br = pApCrBr.br_CeBg_ZNo;
            int szM = (int)(35 * scale);
            var bmp = new RenderTargetBitmap(szM, szM, 96, 96, PixelFormats.Default);
            int FreeBmask = G6.FreeBmask;

            int fontSize = (int)(12 * scale);
            GFormattedText GFnn = Get_GFont_with_Scale(fontSize);
            int lngSize = (int)(12 * scale);

            var drawVisual = new DrawingVisual();
            using (var DC = drawVisual.RenderOpen()){
                DC.DrawRectangle(br, null, new Rect(0, 0, bmp.Width, bmp.Height));
                foreach (int no in P.FreeB.IEGet_BtoNo()){
                    int noB=(1<<no), x=(no%3)*12, y=(no/3)*12;

                    Color crBg = Colors.White, cr = Colors.Navy;
                    if( (FreeBmask&(1<<no)) > 0) { crBg=pApCrBr._ColorsLst2[no]; cr=Colors.White; }

                    Brush brBg = new SolidColorBrush(crBg);
                    Rect re = new Rect(x, y, 12, 12);
                    DC.DrawRectangle(brBg, null, re); // background colored squares

                    Point pt = new Point(x + 3, y);
                    br = new SolidColorBrush(cr);
                    DC.DrawText(GFnn.GFText((no + 1).ToString(), br), pt);
                }
            }
            bmp.Render(drawVisual);
            return bmp;
        }
    }

  #endregion develop_new_Algorithm 
}
