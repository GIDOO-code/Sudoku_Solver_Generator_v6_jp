using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Diagnostics.Debug;
using static System.Math;

//Reverse sample code
//http://msdn.microsoft.com/ja-jp/ff363212#05

//[C#/XAML] Draw graphics with WPF
//http://code.msdn.microsoft.com/windowsdesktop/CVBXAML-WPF-Windows-WPF-0738a600

using GIDOO_space;
using System.Linq.Expressions;

namespace GNPX_space{
	using pApCrBr = App_ColorBrush;   
	using pApEnv  = App_Environment;
 
    public partial class GNPX_Graphics{
        static private readonly Color CrBlack_ = Colors.Black; 
        static private readonly Color CrWhite_ = Colors.White; 
        static private GFont gFnt12 = new GFont("ＭＳ　ゴシック",12,FontWeights.Medium,FontStyles.Normal);
        static private GFormattedText GF8 = new GFormattedText( gFnt12 );
        static private CultureInfo CulInfoJpn=CultureInfo.GetCultureInfo("ja-JP"); 
        static public  bool overlaped;
		private G6_Base	 G6 => GNPX_App_Man.G6;

        private GNPX_win pGNP00win;
        private GNPX_App_Man  pGNPX_App;
        //private Dictionary<string,Color> pColorDic; 
        
        static private int    LineWidth;  
        static private int    CellSize;  
        static private int    CellSizePlus; 
                              
        static private Brush  brBL;  
        static private Brush  brBoad;
        static private Brush  brFNo;
        static private Brush  brPNo;    
        static private Brush  brMNo;    
        static private Brush  brZNo; 


		public GNPX_Graphics( ){ }
        public GNPX_Graphics( GNPX_App_Man  pGNPX_App ){
            this.pGNPX_App = pGNPX_App;
            this.pGNP00win = pGNPX_App.pGNP00win;

            LineWidth     = pApEnv.lineWidth;
            CellSize      = pApEnv.cellSize;
            CellSizePlus  = CellSize + LineWidth;
            
            brBL   = pApCrBr.br_BoardLine;
            brBoad = pApCrBr.br_Board;
            brFNo  = pApCrBr.br_CellForeNo;
            brPNo  = pApCrBr.br_CeBg_PNo; 
            brMNo  = pApCrBr.br_CeBg_MNo; 
            brZNo  = pApCrBr.br_CeBg_ZNo; 
        }



        public RenderTargetBitmap GBoardPaint( RenderTargetBitmap bmp, List<UCell> qBDL, string GSmodeX="", 
											   bool sNoAssist=false, bool whiteBack=false, bool finalStateB=false ){
            if(qBDL==null || bmp==null)  return null;

            if(whiteBack){	//###@@@
                brBL = brFNo = Brushes.Black; 
                brBoad = brPNo = brMNo=brZNo = Brushes.White;
            }

            //MS Gothic
            GFont gFnt32 = new GFont( "Courier", 32, FontWeights.DemiBold, FontStyles.Normal );
            GFormattedText GF32 = new GFormattedText( gFnt32 );           
            Point pt = new Point();

            try{
                overlaped = false; 
                var drawVisual = new DrawingVisual();
                using( DrawingContext DC=drawVisual.RenderOpen() ){
                
                    //Initialize
                    DC.DrawRectangle(brBoad,null,new Rect(0,0,bmp.Width,bmp.Height));

                    if( qBDL.Any(p=>p.No!=0) ){ 
                      #region Draw digit on board
                        // PuzzleCell(No>0) SolvedCell(No<0)
                        Rect Rrct = new Rect(0,0, CellSize,CellSize);
                        foreach( UCell P in qBDL.Where(p=>p.No!=0) ){
                            int r=P.r, c=P.c;
                            pt.X = LineWidth + c*CellSizePlus + (c/3);
                            pt.Y = LineWidth + r*CellSizePlus + (r/3);
                                              
                            Brush br = (P.No>0)? brPNo: brMNo;
							if( P.ECrLst!=null )  br = new SolidColorBrush( P.ECrLst.Last().CrCelBkgd );

							if( finalStateB ){
								if( P.ECrLst!=null )   br = Brushes.Bisque;
								else if( P.ECrLst!=null )  br = new SolidColorBrush( P.ECrLst.Last().CrCelBkgd );
							}

                            Rrct.X=pt.X+1; Rrct.Y=pt.Y+1;
                            DC.DrawRectangle(br,null,Rrct);
                  
                            string NoStr = Abs(P.No).ToString();
                            pt.X+=10; pt.Y+=2;
                            DC.DrawText(GF32.GFText(NoStr,brFNo),pt);
                        }
                       
                        //Unsolved
                        if(sNoAssist){
                            RenderTargetBitmap　Rbmp;
                            foreach( UCell P in qBDL.Where(p=>p.No==0) ){
                                int r=P.r, c=P.c;
                                pt.X = LineWidth + c*CellSizePlus + (c/3);
                                pt.Y = LineWidth + r*CellSizePlus + (r/3);
                                Rrct.X=pt.X+1; Rrct.Y=pt.Y+1;

                                if( G6.digitColoring){ Rbmp = Create_Cell_Image_Light_with_Scale(P,1.0); }
                                else{                  Rbmp = CreateCellImage(P, true); }

                                DC.DrawImage(Rbmp,Rrct);
                            }
						
                        }

                      #endregion
                    }

                  #region Draw line on board

                    Pen   pen, pen1=new Pen(brBL,1), pen2=new Pen(brBL,2);               
                    Point ptS, ptE;
                    int hh=1;
                    for(int k=0; k<10; k++ ){
                        ptS=new Point(0,hh); ptE=new Point(CellSize*10-2,hh);
                        pen = ((k%3)==0)? pen2: pen1;
                        DC.DrawLine(pen,ptS,ptE);
                        hh += CellSizePlus + (k%3)/2;
                    }

                    hh=1;
                    for(int k=0; k<10; k++ ){
                        ptS=new Point(hh,0); ptE=new Point(hh,CellSize*10-2);
                        pen = ((k%3)==0)? pen2: pen1;
                        DC.DrawLine(pen,ptS,ptE);
                        hh += CellSizePlus + (k%3)/2;
                    }
                  #endregion

                }    

                bmp.Clear();        
                bmp.Render(drawVisual);
            }catch(Exception ex){ WriteLine( $"{ex.Message}\n{ex.StackTrace}" ); }

            return bmp;
        }



        public RenderTargetBitmap CreateCellImage( UCell P, bool candDisp ){
            Color clrFrame      = CrBlack_;

            var bmp = new RenderTargetBitmap(35,35, 96,96, PixelFormats.Default);

            EColor? pEC;
            var drawVisual=new DrawingVisual();
            using( var DC=drawVisual.RenderOpen() ){
      //  try{
              // ----- Backgroud Color, frame Color -----
                Color Cr_Ce_BG = pApCrBr.cr_Board;
                if( P.FixedNo != 0 )       Cr_Ce_BG = pApCrBr.cr_CeBg_Fix;
                else if( P.CancelB != 0 )  Cr_Ce_BG = pApCrBr.cr_CeBg_Cancel;
                else if( P.ECrLst != null ){
                    pEC = P.ECrLst.FindLast(p => (p.CrCelBkgd!=CrBlack_) );
                    if( pEC is not null )  Cr_Ce_BG = pEC.CrCelBkgd;
                }
                Brush br = new SolidColorBrush(Cr_Ce_BG);
                DC.DrawRectangle( br, null, new Rect( 0,0, bmp.Width, bmp.Height) );

    			// ----- overlap ----
                if( P.ECrLst!=null ){
                    // ----- overlap ----
                    var X = P.ECrLst.GroupBy(p=>p.CrCelBkgd).ToList();
                    if( X!=null && X.Count(q=> ((Color)q.Key)!=CrBlack_)>=2 ){
						Brush brR = Brushes.Green;
                        Pen   pn  = new Pen(brR,3);					// 4    : thickness
                        Point ennterPt  = new Point(3,3);			// (4,4): center point
                        DC.DrawEllipse( null, pn, ennterPt, 3,3 );	// 4,4  : radiusX,radiusY 
                        GNPX_Graphics.overlaped = true;
                    }

                    // ----- Frame -----
                    pEC = P.ECrLst.FindLast(p => (p.CrCelFrame!=CrBlack_) );
                    if( pEC is not null ){
                        br = new SolidColorBrush(pEC.CrCelFrame);
                        Pen pn = new Pen(br,4);
                        DC.DrawRectangle( null, pn, new Rect( 0,0, bmp.Width-0, bmp.Height-0) );
                    }
                }

              // Draw small digits -------------------------------------------------------------
                int  FreeB_Drawn = P.FreeB;
                foreach( int no in P.FreeB.IEGet_BtoNo() ){
                    int   noB=(1<<no), noP=no+1, x=(no%3)*12, y=(no/3)*12;
                    Point pt = new Point(x+3,y);                   

                    Color  CrDig=CrBlack_, CrDigBkgd=CrBlack_;
                    if( P.FixedNo>0 && (P.FixedNo==(no+1)) )  CrDigBkgd=pApCrBr.cr_RevFix;       
                    else if( (P.CancelB&noB) > 0 )            CrDigBkgd=pApCrBr.cr_RevCancel; 
                    else if( P.ECrLst != null ){
                        pEC = P.ECrLst.FindLast(p => (p.noB&noB)>0 && (p.CrDigBkgd!=CrBlack_) );
                        if( pEC is not null )  CrDigBkgd=pEC.CrDigBkgd; 

                        pEC = P.ECrLst.FindLast(p => (p.noB&noB)>0 && (p.CrDig!=CrBlack_) );
                        if( pEC is not null )  CrDig=pEC.CrDig; 
                    }
                    else  CrDig = pApCrBr.cr_CellForeNo;

                    if( CrDig   != CrBlack_ ){   CrDigBkgd=CrBlack_; FreeB_Drawn&=~noB; }
                    if( CrDigBkgd != CrBlack_ ){ CrDig=CrWhite_;   FreeB_Drawn&=~noB; }

                    if( CrDigBkgd != CrBlack_ ){
                        Brush brBg = new SolidColorBrush(CrDigBkgd);
                        Rect  re =new Rect(x+1,y,12,12); 
                        DC.DrawRectangle( brBg, null, re );
                    }
                    if( CrDig != CrBlack_ ){  
                        br = new SolidColorBrush(CrDig);
                        DC.DrawText(GF8.GFText( $"{no+1}", br ), pt);
                    }
                }

                // Candidate digits with no color specified ------------------------------------
                if( FreeB_Drawn > 0 ){ 
                    Color CrDg = pApCrBr.cr_CellForeNo;
                    foreach( int no in FreeB_Drawn.IEGet_BtoNo() ){
                        int   noB=(1<<no), noP=no+1, x=(no%3)*12, y=(no/3)*12;
                        Point pt = new Point(x+3,y);     
                        br = new SolidColorBrush(CrDg); // digit drawing color Brush
                        DC.DrawText(GF8.GFText( $"{no+1}", br ), pt);
                    }
                }
           // }
           // catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}\n" ); }

            }
            // Render ====================================================================================
            bmp.Render(drawVisual);
            return bmp;
        }
    }
}
