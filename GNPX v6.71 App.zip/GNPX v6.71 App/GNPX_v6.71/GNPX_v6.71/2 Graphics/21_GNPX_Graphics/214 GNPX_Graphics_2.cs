using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Diagnostics.Debug;
using static System.Math;

//Reverse sample code
//http://msdn.microsoft.com/ja-jp/ff363212#05

//[C#/XAML] Draw graphics with WPF
//http://code.msdn.microsoft.com/windowsdesktop/CVBXAML-WPF-Windows-WPF-0738a600

using GIDOO_space;

namespace GNPX_space{
	using pApCrBr = App_ColorBrush;   
	using pApEnv  = App_Environment;
 
    public partial class GNPX_Graphics{
        
        public RenderTargetBitmap Create_Cell_Image_Light( UCell P, int noX ){
            Color crFix  = pApCrBr.cr_CellFixed;
            Color crFree = pApCrBr.cr_CellForeNo;
            Brush br     = pApCrBr.br_CeBg_ZNo2;
            var bmp = new RenderTargetBitmap(35,35, 96,96, PixelFormats.Default);

            var drawVisual=new DrawingVisual();
            using(var DC=drawVisual.RenderOpen()){
                DC.DrawRectangle( br, null, new Rect( 0,0, bmp.Width, bmp.Height) );
                foreach( int no in P.FreeB.IEGet_BtoNo() ){
                    int noP=no+1, x=(no%3)*12, y=(no/3)*12;
                    Color cr = (noP==noX)? crFix: crFree; 
                    Point pt = new Point(x+3,y);
                    br = new SolidColorBrush(cr);
                    DC.DrawText(GF8.GFText( noP.ToString(), br ), pt);
                }
            }          
            bmp.Render(drawVisual);
            return bmp;
        }

        public int GB_Pattern_Paint( Canvas can, /*colorListWPF CRL,*/ int[,] GPat ){
            int   csz  = pApEnv.cellSize/2;
            int   cszP = csz+1;
            Point ptS, ptE;
            Brush brBoad = pApCrBr.br_Board;
            Brush br = pApCrBr.br_CeBg_PNo;

            can.Children.Clear();
            Rectangle rct=new Rectangle();
            rct.Fill=brBoad; rct.Height=can.Width; rct.Width=can.Height;
            can.Children.Add(rct);

			int nCell = 0;
            for(int r=0; r<9; r++ ){
                for(int c=0; c<9; c++ ){
                    if(GPat[r,c]==0) continue;
					nCell++;
                    Rectangle rcPatt = new Rectangle();
                    rcPatt.Fill=br;
                    ptS = new Point(c*cszP+c/3+2,r*cszP+r/3+2);
                    rcPatt.Margin = new Thickness(ptS.X, ptS.Y,0.0,0.0);
                    rcPatt.Height = rcPatt.Width=csz;
                    can.Children.Add(rcPatt);
                }
            }

            //===== Draw line on board =====
            Brush brBL = pApCrBr.br_BoardLine;
            int wd, hh;

            hh=1;
            for(int k=0; k<10; k++ ){
                ptS=new Point(0,hh); ptE=new Point(csz*10-4,hh);
                wd = ((k%3)==0)? 2: 1;
                Line Ln = Line_Plotter(ptS,ptE,brBL,wd,0);
                can.Children.Add(Ln);
                hh += cszP+(k%3)/2;
            }

            hh=1;
            for(int k=0; k<10; k++ ){
                ptS = new Point(hh,0); ptE=new Point(hh,csz*10-4);
                wd = ((k%3)==0)? 2: 1;
                Line Ln = Line_Plotter(ptS,ptE,brBL,wd,0);
                can.Children.Add(Ln);
                hh += cszP+(k%3)/2;
            }
            return nCell;
        }
        
        public RenderTargetBitmap GB_Pattern_Digit( RenderTargetBitmap bmp, int[] SDK81){
            int[,] GPat = new int[9,9];
            for(int rc=0; rc<81; rc++ ){
                int n=SDK81[rc];
                GPat[rc/9,rc%9]=(n>9)? 0: n;
            }
            GB_Pattern_Digit(bmp,GPat);
			return bmp;
        }

        public RenderTargetBitmap GB_Pattern_Digit( RenderTargetBitmap bmp, int[,] GPat){
            int   LWid = pApEnv.lineWidth/2;
            int   csz  = pApEnv.cellSize/2;
            int   cszP = csz+1;

            bmp.Clear();
            GFont gFnt16 = new GFont( "Courier", 16, FontWeights.Normal, FontStyles.Normal );
            GFormattedText GF16 = new GFormattedText( gFnt16 );

            var drawVisual = new DrawingVisual();
            using( DrawingContext DC=drawVisual.RenderOpen() ){           
                Brush br=new SolidColorBrush(Colors.DarkBlue);
                Point pt=new Point();
                for(int rc=0; rc<81; rc++ ){
                    int r=rc/9, c=rc%9;
                    int No = GPat[r,c];
                    if(No==0)  continue;
                    pt.X = c*19+c/3+6;
                    pt.Y = r*19+r/3+2;
                    DC.DrawText( GF16.GFText(No.ToString(),br), pt );
                }
            } 
            bmp.Render(drawVisual);
			return bmp;
        }

        public Line Line_Plotter( Point ptS, Point ptE, Brush br, int wd/*width*/, int sCode/*line type*/ ){
            try{  
                Line ln = new Line();
                ln.Stroke=br; ln.StrokeThickness = wd;
                ln.X1=ptS.X; ln.Y1=ptS.Y; ln.X2=ptE.X; ln.Y2=ptE.Y;
                
			    switch(sCode){
				    case 0: break; //line
				    case 1: ln.StrokeDashArray = new DoubleCollection{4,4}; break;	        //dotted line
				    case 2: ln.StrokeDashArray = new DoubleCollection{4,2,2,2}; break;	    //dash-dotted line
				    case 3: ln.StrokeDashArray = new DoubleCollection{4,2,2,2,2,2}; break;	//Two-dot chain line
                    case 4: ln.StrokeDashArray = new DoubleCollection{4,2}; break;	        //dotted line
			    }
                return ln;
            }
            catch(Exception ex){ WriteLine( ex.Message+"\n"+ex.StackTrace ); }
            return null;
		}
    }
}
