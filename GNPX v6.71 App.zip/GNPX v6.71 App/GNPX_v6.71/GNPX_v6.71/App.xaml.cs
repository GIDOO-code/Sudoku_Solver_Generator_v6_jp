﻿using System.Windows;

namespace GNPX_proj {
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application {
    }
}
