﻿using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using pRes = Properties.Resources;
    public partial class PuzzleFile_IO{


        // @@@  Additional functions for this solution are turned off.


		public void btn_FavoriteFileOutput( bool fType81=true ){//, bool SolSet=false, bool SolSet2=false ){
/* @@@
            if( SolSet ){
                var tokSrc = new CancellationTokenSource();		//procedures for suspension
                pGNPX_Eng.AnMan.Update_CellsState( pGNPX_Eng.ePZL.BOARD );
				pGNPX_Eng.GNPX_SolvCompletely(tokSrc.Token);
            }
*/

            var (difLvl,_) = pGNPX_Eng.Get_difficultyLevel();          
            string line = "";  
            if( fType81 ){
				line = $"{ePZL.stPZL_withSP} {ePZL.difficultyLevel} \"{ePZL.Name}\"";
               // if( SolSet&&SolSet2 ) line += $" \"{SetSolution(ePZL,SolSet2:true,SolAll:true)}\"";
            }
            
            string fNameFav = "SDK_Favorite.txt";
			Utility_Display.GNPX_StreamWriter( fNameFav, line, append:true ); 
        }

/* @@@
		private string SetSolution( UPuzzle aPZL, bool SolSet2, bool SolAll=false ){
            string solMessage="";
            ePZL = aPZL;

            if( SolAll || ePZL.difficultyLevel<=0 || ePZL.Name=="" ){
                foreach( var p in aPZL.BOARD )  if( p.No<0 ) p.No=0;

                pGNPX_Eng.AnMan.Update_CellsState( aPZL.BOARD );
                pGNPX_Eng.AnalyzerCounterReset();

                var tokSrc = new CancellationTokenSource();　        //for suspension
				pGNPX_Eng.GNPX_SolvCompletely(tokSrc.Token); 
                if( G7.ResultCode_SolverEngin<0 ){
                    ePZL.difficultyLevel = -999;
                    ePZL.Name = "unsolvable";
                }
                else{
                    if(ePZL.difficultyLevel<=1 || ePZL.Name==""){
                        var (difficult,pzlName) = pGNPX_Eng.Get_difficultyLevel( );
                        if(ePZL.difficultyLevel<=1)  ePZL.difficultyLevel = difficult;
                        if(ePZL.Name=="")     ePZL.Name = pzlName;
                    }
                }
            }     
            solMessage = "";
            if(SolSet2) solMessage += pGNPX_Eng.DGView_MethodCounterToString();　//適用手法を付加
            solMessage = solMessage.Trim();

            return solMessage;
        }
*/

        public void Save_Puzzle_ToFile( v7_UPuzzle_Base bPzl, string fNameS="Puzzle_" ){

            string fName = fNameS + DateTime.Now.ToString("yyyyMMdd") + ".txt";
			string dirStr = $"../GNPX_ExecutionSpace/{pRes.folder_AutoGen_Puzzles}";

			if( !Directory.Exists(dirStr) ){ Directory.CreateDirectory(dirStr); }
			using( var fpW=new StreamWriter( dirStr+"/"+fName, append:true, Encoding.UTF8) ){   
				string line = $"{bPzl.stPuzzle_forFile}";
                        //If nothing is added, add the number of hints.
                        //if( line.Length == 89 )  line += $" \"{bPzl.Get_board().Count(p=>p>0)} cells\"";   
                fpW.WriteLine(line);
			}

		}

        public void Save_LS_Puzzle_ToFile( int nc, string stLS, string stLSsol ){
            string fName = $"LS_{nc}_Puzzle" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
			string dirStr = $"../GNPX_ExecutionSpace/{pRes.folder_AutoGen_Puzzles}";

			if( !Directory.Exists(dirStr) ){ Directory.CreateDirectory(dirStr); }
			using( var fpW=new StreamWriter( dirStr+"/"+fName, append:true, Encoding.UTF8) ){   
				fpW.WriteLine( $"{stLS.ToStringWithSpace()}  sol:{stLSsol.ToStringWithSpace().Trim()}" );
			}
		}

    }
}