﻿using System;
using System.Collections.Generic;
using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Linq;
using System.Windows.Documents;
using System.Xml.Linq;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Controls;

namespace GNPX_space{
   using pRes=Properties.Resources;
	using pGPDM = GNPX_Puzzle_Database_Manager;



    public partial class PuzzleFile_IO{

		public GNPX_App_Man	 pGNPX_App;
        private  GNPX_Engin	 pGNPX_Eng => pGNPX_App.GNPX_Eng;
		public UPuzzle		 ePZL{ get=> pGNPX_Eng.ePZL; set=> pGNPX_Eng.ePZL=value; }  

        public GNPX_Puzzle_Analysis_Support    Pzl_Analysis_Supp;                      //Puzzle Generator  
	//	public GNPX_Engin       GNPX_Eng;                      //Analysis Engine




		public PuzzleFile_IO( GNPX_App_Man pGNPX_App ){
            this.pGNPX_App = pGNPX_App;
        }



		// ===== Read_Puzzle ============================================================
        public List<v7_UPuzzle_Base> GNPX_PuzzleFile_Read( string fName ){
            char[] sep=new Char[]{ ' ', ',', '\t' };        
            string line, puzzleName="";

            bool withTitle = false;
			List<v7_UPuzzle_Base> puzzleList = new();
            using( StreamReader fRead=new StreamReader(fName) ){

				int ID=0;
                while( (line=fRead.ReadLine()) !=null ){
                    if( ID == 0 ){
                        if( line.Contains("PuzzleNo") ){ withTitle=true; continue; }
                        if( withTitle ){
                            int k = line.IndexOf(",");
                            line = line.Substring(k+1);
                        }
                    }

                    if( line=="" ) continue;
					if( line[0]=='-' )  continue;   // Supports the "comment" identifier in puzzle files.
					if( line[0]=='/' )  continue;
                    if( line[0]=='#' )  continue;

                    // Supports the format "Contain a blank every 9 digits" and similar type.
                    int n81 = _Find_81Digits(line);
                    if( n81>81 ){
                        string st = line.Substring(0,n81).Replace(" ","").Replace(".","0");
                        if( st.Length==81 && st.All(char.IsDigit) ){ line = string.Concat(st, line.AsSpan(n81)); }
                    }

                    string[] eLst = line.SplitEx(sep);  // The string ". .." is processed as a single unit.
					if( eLst.Length==0 )  continue;
                    // --------------------------------------------------------

                    int    nc = eLst.Length;
                    string name="";
                    int    difLvl=99;
                    if( eLst[0].Length>=81 ){
                        try{
							if( nc>=2 && eLst[1].IsNumeric() ) difLvl = eLst[1].ToInt();
							if( nc>=3 ){					   name   = eLst[2]; }  
                            string st = eLst[0].Replace(".", "0").Replace("-", "0").Replace(" ", "");
                            List<UCell> _board = _stringToBDL(st);
                            string      _timeStamp =  _Find_TimeStamp( eLst );
							v7_UPuzzle_Base  _puzzle = new v7_UPuzzle_Base( st, difficulty:difLvl, name);
                            puzzleList.Add( _puzzle );
                        }
                        catch{ continue; }                   
                    }
                }
			}
			return puzzleList;

					int _Find_81Digits( string st ){
						int n=0, m=0;
						foreach( var p in st ){ m++; if( p!=' ' && (char.IsDigit(p) || p=='.') && (++n>=81) )  break; }
						return (n==81)? m: 0;
					}   

					string _Find_TimeStamp( string[] eList ){
						string TimeStamp="";
						foreach( var e in eList){ if( DateTime.TryParse(e,out _) ){ TimeStamp=e; break; } }
						return TimeStamp;
					}

					List<UCell> _stringToBDL( string stOrg ){
						string st = stOrg.Replace(".", "0").Replace("-", "0").Replace(" ", "");
						try{               
							List<UCell> B = new List<UCell>();
							int rc=0;
							for(int k=0; rc<81; ){
								if(st[k]=='+'){ k++; B.Add(new UCell(rc++,-( st[k++].ToInt())) ); }
								else{
									while(!st[k].IsNumeric()) k++;
									B.Add( new UCell(rc++, st[k++].ToInt() ) );
								}
							}
							return B;
						}
						catch(Exception e){
							WriteLine($"_stringToBDL \nstOrg:{stOrg} \n   st:{st}");
							WriteLine( $"string error:{e.Message}\n{e.StackTrace}");
						}
						return null;
					}
	        }





		// ===== Write_Puzzle ============================================================
        public void GNPX_PuzzleFile_Write( string fName, bool append ){
            if( pGPDM.v7_GNPX_Puzzle_Count==0 )  return;

            using( StreamWriter fpW=new StreamWriter(fName,append,Encoding.UTF8) ){
                foreach( var P in pGPDM.v7_GNPX_Puzzle_List ){
                    fpW.WriteLine( P.stPuzzle_forFile );
                }
            }
		}

/*
        public void Save_Puzzle_ToFile( v7_UPuzzle_Base bPzl, string fNameS="Puzzle_" ){

            string fName = fNameS + DateTime.Now.ToString("yyyyMMdd") + ".txt";
			string dirStr = $"../GNPX_ExecutionSpace/{pRes.folder_AutoGen_Puzzles}";

			if( !Directory.Exists(dirStr) ){ Directory.CreateDirectory(dirStr); }
			using( var fpW=new StreamWriter( dirStr+"/"+fName, append:true, Encoding.UTF8) ){   
				string line = $"{bPzl.stPuzzle_forFile}";
                        //If nothing is added, add the number of hints.
                        //if( line.Length == 89 )  line += $" \"{bPzl.Get_board().Count(p=>p>0)} cells\"";   
                fpW.WriteLine(line);
			}

		}



        public void Save_LS_Puzzle_ToFile( int nc, string stLS, string stLSsol ){
            string fName = $"LS_{nc}_Puzzle" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
			string dirStr = $"../GNPX_ExecutionSpace/{pRes.folder_AutoGen_Puzzles}";

			if( !Directory.Exists(dirStr) ){ Directory.CreateDirectory(dirStr); }
			using( var fpW=new StreamWriter( dirStr+"/"+fName, append:true, Encoding.UTF8) ){   
				fpW.WriteLine( $"{stLS.ToStringWithSpace()}  sol:{stLSsol.ToStringWithSpace().Trim()}" );
			}
		}
*/
	}
}