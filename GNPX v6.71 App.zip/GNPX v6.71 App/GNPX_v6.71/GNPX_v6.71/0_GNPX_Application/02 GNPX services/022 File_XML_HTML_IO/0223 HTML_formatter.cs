using GIDOO_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using static GNPX_space.GNPX_Puzzle_Analysis_Support;
using static System.Diagnostics.Debug;
using static System.Math;


namespace GNPX_space{
	using pRes = Properties.Resources;
	using pGPDM = GNPX_Puzzle_Database_Manager;
    using sysWin=System.Windows;

    public partial class PuzzleFile_IO{

		private int    _stageNoPMemo = -1;

		public void Save_HTML_of_Puzzle( GNPX_Engin pGNPX_Engin, string fn59S, UPuzzle aPZL ){
			List<UCell>  pBOARD = aPZL.BOARD;
		
			string folder_GNPX_HTML = $"{G6.DirName_GNPX_ExecutionSpace}/GNPX_HTML";

			string folder_GNPX_HTML_image = folder_GNPX_HTML + $"/{fn59S}";
			string HTMLName = "GNPX_HTML" + DateTime.Now.ToString("yyyyMMdd")+".html";	
			string HTML_folder_File       = folder_GNPX_HTML + $"/{HTMLName}";

			if( !Directory.Exists(folder_GNPX_HTML) ){ Directory.CreateDirectory(folder_GNPX_HTML); }
			if( !Directory.Exists(folder_GNPX_HTML_image) ){ Directory.CreateDirectory(folder_GNPX_HTML_image); }

			Repair_Output_file( HTML_folder_File );
			{ // Save HTML content
				string styleClearBoth = "<p style=\"clear: both\"/>";
				string HR = (pGNPX_Eng.extResult!="")? pGNPX_Eng.extResult: pGNPX_Eng.ResultLong;
				if( HR == null )  return; 

				if( HR==null || HR==""  )  HR = pGNPX_Eng.ResultHTML;
				if( HR!=null && HR != "" ){

					string methodName = aPZL.pMethod.MethodName;
					string imageFileName = Save_BOARD_BitMap_forHTML( aPZL, methodName, folder_GNPX_HTML_image );

					string html_Image = $"<img src=\"{fn59S}/{imageFileName}\" width=\"30%\" style=\"float:left;  margin-right:8px;\" alt=\"{aPZL.pMethod.ToString().Trim()}\"><br>\n";
					if( html_Image == null )  return; 
					if( HR == null )  return ;
					HR = $"\n<p>\n{HR.Replace("\n","<br>\n")}</p>";

						string st_Puzzle  = string.Join("",pBOARD.ConvertAll(p=>Max(p.No,0))).Replace("0","."). AddSpace9_81();
						string st_Current = string.Join("",pBOARD.ConvertAll(p=>Abs(p.No))).Replace("0","."). AddSpace9_81();
						string html_Puzzle = $"{styleClearBoth}<p class=\"newLine\"/>{aPZL.BaseName}<br>";
					
						html_Puzzle += $"\n{st_Puzzle} Puzzle<br>\n{st_Current} Current<br></p>\n";
					
					HR = $"{html_Puzzle}{html_Image}{HR}\n";

					int stageNoP = pGNPX_Engin.stageNoP;
					// @ Only for the first of each stage, output detailed information to HTML.
					if( stageNoP != _stageNoPMemo )  HR = HR.Replace("@HTML_Delete@","");	// Delete the "Deletion Command".
					_stageNoPMemo = stageNoP;

					HR = $"\n<div><tt>\n<p>{HR}{styleClearBoth}";
					HR = Convert_spaces_to_HTML_Plus(HR);
					HR = HR.Replace("@HTML@", $"{styleClearBoth}" );
					HR = $"{HR}\n<br><hr>\n</tt></div>";

					using(var fpW=new StreamWriter(HTML_folder_File, append:true, encoding:Encoding.UTF8)){
						fpW.WriteLine(HR);
						string htmlEnd = "\n</body>\n</html>";
						fpW.WriteLine(htmlEnd);
					}
				}
			}
			return;

				string Convert_spaces_to_HTML_Plus( string stA ){
					int kx = stA.IndexOf("@HTML_Delete@");
					if( kx != -1 )	stA = stA.Substring(0,kx);

					kx = stA.IndexOf("@HTML@");
					if( kx<0 )  return stA;
					string stB0 = stA.Substring(0,kx);
					string stB1 = stA.Substring(kx);
					string stB2 = stB1.Replace("_","&nbsp;");
					stB2 = $"<p class=\"newLine\"/>{stB2}";
					return stB0+stB2;
				}
		}




		// If the output HTML file does not exist, the header section will be output to a file.
		// If it exists, the content up to just before the footer section will be output to a file.
		private void Repair_Output_file( string HTML_folder_File ){ // Repair Output file 
			if( !File.Exists(HTML_folder_File) ){
				string html = "<!doctype html>\n<html>\n<head>\n<meta charset=\"utf-8\">\n</head>\n<body>";
				using(var fpW=new StreamWriter(HTML_folder_File, append:false, encoding:Encoding.UTF8)){
					fpW.WriteLine(html);
				}
			}
			else{		
				List<string> HTMLList = new();
				string? line;
				bool RepairB=false;
				using(var fpR=new StreamReader(HTML_folder_File) ){
					while( (line=fpR.ReadLine()) !=null ){
						if( line == "</body>" ){ RepairB=true;  break; }
						HTMLList.Add(line);
					}
				}
				if( RepairB is true ){
					using(var fpW=new StreamWriter(HTML_folder_File, append:false, encoding:Encoding.UTF8)){
						HTMLList.ForEach( P => fpW.WriteLine(P) );

					}
				}
			}
		}





		// Create a bitmap image using the puzzle object, method name, and folder. And output it to a file.
		// Generate a file that does not conflict with existing files in the folder.
		// Return the generated filename.
		private string Save_BOARD_BitMap_forHTML( UPuzzle aPZL, string methodName, string dirName ){
			bool G6_sNoAssist  = G6.sNoAssist;
			bool G6_sWhiteBack = G6.sWhiteBack;
			G6.sNoAssist  = true;
			G6.sWhiteBack = false;

			GNPX_Graphics    gnpxGrpA = new GNPX_Graphics(pGNPX_App);	
			RenderTargetBitmap  bmpGZeroA = new ( 338, 338, 96,96, PixelFormats.Default );
			var bmp = gnpxGrpA.GBoardPaint( bmpGZeroA, aPZL.BOARD,  sNoAssist:G6.sNoAssist, whiteBack:G6.sWhiteBack );
            var bmf = BitmapFrame.Create(bmp);

			G6.sNoAssist  = G6_sNoAssist;
			G6.sWhiteBack = G6_sWhiteBack;

            if( !Directory.Exists(dirName) ){ Directory.CreateDirectory(dirName); }		
			
		    BitmapEncoder enc = new PngBitmapEncoder();
			enc.Frames.Add(bmf);
			string imageFileName = Create_imageFileName( methodName, dirName);
            using( Stream stream = File.Create($"{dirName}/{imageFileName}") ){
                enc.Save(stream);
            }    
			return imageFileName;

				string Create_imageFileName( string methodName, string dirName ){
					DirectoryInfo diTop = new DirectoryInfo(dirName);

					List<FileInfo>? files = null;
					if( methodName == "Exocet" ){
						files  = diTop.EnumerateFiles().ToList()
							.FindAll(P => P.Name.Contains(methodName) && !P.Name.Contains("J") && !P.Name.Contains("Single"));
					}
					else{ files  = diTop.EnumerateFiles().ToList().FindAll(P=>P.Name.Contains(methodName)); }

					int maxNo = 0;
					if( files!=null && files.Count>0 ){
						List<int> fileNo = new();
						foreach( var P in files ){
							int n = P.Name.LastIndexOf("_");
							string name1 = P.Name.Substring(n);
							string name2 = Regex.Replace(name1, @"[^0-9]", "");		
							fileNo.Add( name2.ToInt() );
						}
						//var fileNo = files.ConvertAll(p=>p.Name.Replace( @"[^0-9]", ""));
						maxNo  = fileNo.Max();
					}
					string extName = $"{methodName}_{maxNo+1}.png";
					return   extName;
				}
		}

	}
}
