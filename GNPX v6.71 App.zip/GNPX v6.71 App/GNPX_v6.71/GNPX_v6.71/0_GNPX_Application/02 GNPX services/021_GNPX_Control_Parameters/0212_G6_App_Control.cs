﻿using System.Windows.Media.Imaging;
using System.Xml.Serialization;

using System.Windows.Media.Imaging;
using System.Xml.Serialization;

namespace GNPX_space {
    public class G6_Base {
        // ===== Ver.6 Service =====================

        public  string assemblyName;
        public  string releaseVersion;

        [XmlIgnore] public string SDK_Methods_XMLFileName = "SDK_Methods_XMLV7.xml"; // (Ver.6 was planned, but this was introduced first.)
        [XmlIgnore] public string OperationalMode = "NormalOperation";      // Initializing / NormalOperation
        [XmlIgnore] public string DirName_GNPX_ExecutionSpace = "../GNPX_ExecutionSpace/";

        [XmlIgnore] public RenderTargetBitmap bmpGZero;
        public string GNPX_CurrentPath = "";
        [XmlIgnore] public string GNPX_PuzzleFileName = "";
        [XmlIgnore] public string Dir_SDK_Methods_XMLFileName;
        [XmlIgnore] public string PG6Mode = "--";

        [XmlIgnore] public string taskCompInfo;
        [XmlIgnore] public int FreeBmask = 0;

        [XmlIgnore] public string OnWork = "";      // "":free "on executing"

        //[XmlIgnore]  public int    _SolverState = 0;
        //[XmlIgnore]  public int    SolverState { get=>_SolverState;
        //										 set{ _SolverState=value; WriteLine( $"Statte:({_SolverState},{EnginState})" ); } }
    //    [XmlIgnore] public int SolverState{ get; set; }// = 0;
        [XmlIgnore] public int EnginState = 0;

        [XmlIgnore] public bool Set_Solution_Info;

        public DateTime StartTime = DateTime.Now;
        public DateTime StartTime_v600 = new();
        public string   stopped_StatusMessage;
        public bool     MousePposition_at_Startup;
        public bool     command_Analysis_Stop;
        public string   windows_Animation = "chase"; //""  //There is no setting to turn it off.
        public bool     AutoDisplayOnErrorOccurs = false;
        [XmlIgnore] public bool LinkedMove = true;

        public string Canceled = "";
        public bool Found_level_Solution = false;

        public bool slowPlayback = true;
        [XmlIgnore] public bool sNoAssist = false;
        [XmlIgnore] public bool digitColoring = false;
        [XmlIgnore] public bool sWhiteBack = false;      // false
        [XmlIgnore] public bool FinalStateWhiteBack = false;
        [XmlIgnore] public bool MethodWinShow = false;
        [XmlIgnore] public string?  VerifyingPuzzle = null;

		public bool ConfirmMultipleCells;


        public int G60_PuzzleMinDifficulty = 1;

        public int Method_DifficultyLevel = 4;
        public int Method_RecommendLevel = 4;
        //		public string Method_SelectionMode		= "Difficulty";

        public int MSlvr_MaxLevel = 8;
        public int MSlvr_MaxNoAlgorithm = 5;
        public int MSlvr_MaxNoAllAlgorithm = 400;
        public int MSlvr_MaxTime  = 10;      //sec
        public int RecommendLevel = 20;     // Restricted within the program. Cannot be changed at runtime
        [XmlIgnore] public string LastSuccessfullMethod = "";
        [XmlIgnore] public string Additional_Message = "";
        [XmlIgnore] public int  TE_AbsoluteTimeLimit = 100000;   // msec (There are puzzles that take 500 milliseconds or longer.)
        [XmlIgnore] public bool TE_AbsoluteTimeLimitB; //  msec

        public bool chk_analysisStop_at_levels_2;
        public int  Use_eALS = 1;

        public List<string> st_methodList = null;

        // ---------------------------------------------------
        // <<< Func_Specify_SolverOption >>>
        public bool Cell = true;
        public bool AIC = true;
        public bool ALS = true;
        public bool ALSXZ = false;
        public bool AnLS = false;
        public bool eALS = false;
        public string ForceLx = "ForceL2";
        public bool UCellLinkExt = true;
        public bool ForceChain_on = false;

        public int NiceLoopMax = 10;
        public int QSearchMaxGen = 20;
        public int CannibalisticMin = 3;
        public int KrakenFishSizeMin = 3;
        public int ALSSizeMax = 5;
        public int ALSChainSizeMax = 8;

        public bool GeneralLogic_on = false;
        public bool GeneralLogic_StopSearch = true;
        public int  nud_GenLogMaxSize = 3;
        public int  nud_GenLogMaxRank = 1;

        public int  nud_MSLSMaxSize = 8;
        public int  nud_MSLSMaxRank = 0;
        public int  nud_NL_POM_pattern_Max = 3;

        // <<< Func_Solver >>>
        [XmlIgnore] public bool AnalysisResult = false;
        [XmlIgnore] public string stResult = "";




        // <<< Func_CreateAuto >>>
        public double Processor_Utilization = 0.3;
        [XmlIgnore] public int SolutionCounter = 0;

        public int[] GenPar00 = new int[]{0,100, 0,100, 20 };
        [XmlIgnore] public string GenMessage;



        public int NoOfPuzzlesToCreate = 5;
        public int Puzzle_LevelLow = 1;
        public int Puzzle_LevelHigh = 7;
        [XmlIgnore] public bool Search_AllSolutions = false;
        public bool Digits_Randomize = true;
        public bool Save_CreatedPuzzle = false;
        public bool CbxNextLSpattern = false;    // Change Latin-Square Pattern on Success	
        public bool ResultShow = true;
        [XmlIgnore] public string Info_LS_Generator = "";
        [XmlIgnore] public string Info_CreateMessage0 = "";
        [XmlIgnore] public string Info_CreateMessage1 = "";
        [XmlIgnore] public string Info_CreateMessage2 = "";
        [XmlIgnore] public string Info_CreateMessage3 = "";

        public int retNZ;                           // The original purpose is unclear and needs to be clarified and changed.

        public int GenLStyp;
        public bool GenLS_turbo;
        public int CellNumMax;
        [XmlIgnore] public int LoopCC = 0;
        [XmlIgnore] public int TLoopCC = 0;
        [XmlIgnore] public int PatternCC = 0;

        public int RandomSeedVal_000;
        //		public int  RandomSeedVal;
        public int PatSel0X;

        [XmlIgnore] public int LS_P_P0 = 0;
        [XmlIgnore] public int LS_P_P1 = 0;
        [XmlIgnore] public int LS_P_P2 = 0;
        [XmlIgnore] public string LS_Queue = "";
        [XmlIgnore] public bool LS_PatternChangeCommand = false;    //... Redundant


        public int LS_Pattern_Cntrl_P2 = 100;   // 100 - 500 -


        public bool Only_LS = false;
        public bool chbx_ShowProofMultiPaths = true;
        public bool chbx_LinkExtension = true;
        [XmlIgnore] public int[,] Sol99sta = new int[9, 9];


        // <<< Func_CreateAllPuzzle >>>

        // <<< Func_CreateAuto2 >>>
        public int   CreateAuto2_type;
        public bool  CreateAuto2_Save_auto;
        [XmlIgnore] public int[] CreateAuto2_Puzzlis = new int[14]; //[0]17 - [13]30 


        // <<< Func_Transform >>>
        [XmlIgnore] public bool DigitsChangeMode = false;
        [XmlIgnore] public int Cell_rc;



        // <<< Power User / Power Mode >>>
        public string folderName_XXX = "imgXXX";    // HTML image file_name
        public int zPowerUserCC = 2;//25;
        [XmlIgnore] public bool zPowerUser => (zPowerUserCC>0);
        [XmlIgnore] public bool zSolver_PowerMode = false;


		
		// <<< XmlSerializer >>>		
		[XmlIgnore] public XmlSerializer xmlSerializer = new XmlSerializer(typeof(G6_Base));


		public G6_Base(){}

	#region Solver I/O
		// <<< for output >>>
		public void Set_methodList( List<UAlgMethod> SolverList_Tmp ){
			st_methodList = new();
		    SolverList_Tmp.ForEach( P=>{ 
				string st = (P.IsChecked? "": "-") + P.MethodName.TrimStart(' ');
				if( P.Sel_mark )  st += " *Sel_Manual";
				st_methodList.Add(st);
            } );
		}

		// <<< for input >>>	
		public void Set_SolverList_CheckUncheck( List<UAlgMethod> SolverList_Tmp ) {
			if( st_methodList == null )  return;

			SolverList_Tmp.ForEach( P=> P.IsChecked=true );

			foreach( var P in st_methodList ){
				string stP = P.Trim();

				bool Sel_ManualB = stP.Contains("*Sel_Manual");
				stP = stP.Replace(" *Sel_Manual","").Trim();

				bool IsCheckedB = !(stP.Trim()[0]=='-');	// 202601
				stP = stP.Replace("-","").Trim();

				UAlgMethod Q = SolverList_Tmp.Find( x=> x.MethodName.Trim()==stP);
				if( Q is UAlgMethod ){
					Q.IsChecked  = IsCheckedB;
					Q.Sel_mark   = Sel_ManualB;
				}
			}

		}
	#endregion Solver I/O


		public override string ToString( ){
			string st = "";
			//.....................
			return st;
		}
	}
}


