﻿using System;
using System.Windows.Media;
using System.IO;
using System.Text.Json.Serialization;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using static System.Diagnostics.Debug;


//:::::::::::::::::::::::::::::::::::::
//	ver.7
//:::::::::::::::::::::::::::::::::::::


namespace GNPX_space{
	public class G7_Base{

      #region ===== Solver_Engin =====
        public bool	  MltAnsSearch;
        public bool   Set_Solution_Info;    
		public string AdditionalMessage;
		//public int    ResultCode_SolverEngin;
		public UAlgMethod AnalyzingMethod;

	  #endregion ===== Solver_Engin =====





      #region Scheduled for organization
        [XmlIgnore]  public List<UCell>  g7FinalState_TE;
		[XmlIgnore]  public List<UCell>  g7CurrentState; 
		[XmlIgnore]  public List<string> TandE_solList = null;

        // ------------------------------------
		[XmlIgnore]  public bool	 	 Sel_mark_Solved = false;
		[XmlIgnore]  public bool		 g7MarkA0;					// ver.5.2- for Develop
		[XmlIgnore]  public bool		 g7Error;					// ver.5.2- for Develop
		[XmlIgnore]  public List<string> g7MarkA_MLst0 = null;		// ver.5.2- for Develop
      #endregion Scheduled for organization





		public G7_Base(){ }
	}
}


