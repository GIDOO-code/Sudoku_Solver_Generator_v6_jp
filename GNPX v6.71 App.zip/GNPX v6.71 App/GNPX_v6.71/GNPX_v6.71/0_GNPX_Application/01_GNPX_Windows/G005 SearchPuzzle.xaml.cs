﻿using GIDOO_space;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace GNPX_space{
	using ioPath = System.IO.Path;
	using pGPDM = GNPX_Puzzle_Database_Manager;
	using pRes = Properties.Resources;
	using sysWin = System.Windows;


    public partial class GNPX_SearchPuzzle: Window{
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 
		static private G6_Base G6 => GNPX_App_Man.G6;
		private PuzzleFile_IO  fPuzzleFile_IO => pGNPX_App.fPuzzleFile_IO;

        private GNPX_win	   pGNP00win;
		       
		private GNPX_App_Man   pGNPX_App;
		private List<v7_UPuzzle_Base>  v7_GNPX_Puzzle_List => pGPDM.v7_GNPX_Puzzle_List;
		private List<string>   stPzls;

		private string		   pfName;

        public GNPX_SearchPuzzle( GNPX_win pGNP00win ){
			this.pGNP00win = pGNP00win;
            pGNPX_App = pGNP00win.GNPX_App;
			InitializeComponent();		

            this.MouseLeftButtonDown += (sender, e) => this.DragMove();
			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man ); 
        }
					
		private void Send_SetPuzzleOnBoard( ) {
			Gidoo_EventHandler se = new Gidoo_EventHandler(eName: "Show_AnalysisStatus");  //Report
			Send_Command_to_GNPXwin(this, se);
		}

		private void btn_Close_Click(object sender, RoutedEventArgs e) => this.Visibility = Visibility.Hidden;


		private void devWin_Loaded(object sender, RoutedEventArgs e ){
			pfName = G6.Dir_SDK_Methods_XMLFileName;
			txb_PuzzleFileName.Text = G6.GNPX_PuzzleFileName;
			// pGNPX_App.SolverList_App = pGNPX_App.ReadXMLFile_AnalysisConditions_MethodList();

			btn_Search_Puzzle.IsEnabled = false;
			if( v7_GNPX_Puzzle_List!=null && pGPDM.v7_GNPX_Puzzle_Count>0 )  Show_PuzzleList();
		}

		private void Show_PuzzleList(){
			stPzls = new List<string>();
			foreach( var (p,nx) in v7_GNPX_Puzzle_List.WithIndex() ){
				string stx = $"{nx+1,3}: {p.stPuzzle_forFile}";
				stPzls.Add(stx);
			}
			PuzzleList.ItemsSource = stPzls;
			if( stPzls==null || stPzls.Count==0 )   return;
			btn_Search_Puzzle.IsEnabled = true;
		}

		private void btn_OpenPuzzleFile_Click(object sender, RoutedEventArgs e ){
            var OpenFDlog = new OpenFileDialog(){
				Multiselect = false,
				Title  = pRes.filePuzzleFile,
				Filter = "All files (*.*)|*.*|txt files (*.txt)|*.txt"
			};
			
			if( (bool)OpenFDlog.ShowDialog() ){
                string fName = OpenFDlog.FileName;
				G6.Dir_SDK_Methods_XMLFileName = fName;
				txb_PuzzleFileName.Text = fName;
				var PZL_List = fPuzzleFile_IO.GNPX_PuzzleFile_Read( fName );
				pGPDM.Set_v7_GNPX_Puzzle_List(PZL_List); 

				if( v7_GNPX_Puzzle_List!=null && v7_GNPX_Puzzle_List.Count>0 ) Show_PuzzleList();
				
				Gidoo_EventHandler se2 = new Gidoo_EventHandler( eName:"SetPuzzle_no", ePara0:1 );  //Report
				Send_Command_to_GNPXwin( this, se2 );
			}
		}

		private void btn_Search_Puzzle_Click(object sender, RoutedEventArgs e ){
			if( stPzls==null || stPzls.Count==0 )  return;
			string key = txb_Seach_Key.Text.Trim();

			StringComparison StringComparison = StringComparison.OrdinalIgnoreCase;

			var matchList = stPzls.FindAll(p=> p.Contains(key,StringComparison) ).ToList();
			PuzzleList.ItemsSource = matchList;
			lbl_SearchResult.Content = $"{matchList.Count} / {v7_GNPX_Puzzle_List.Count} found";
		}

		private void btn_Search_Reset_Click(object sender, RoutedEventArgs e ){
			txb_Seach_Key.Text = "";
			Show_PuzzleList();
		}

		public void PuzzleList_SelectionChanged(object sender, sysWin.Controls.SelectionChangedEventArgs e ){
			if( sender==null || v7_GNPX_Puzzle_List==null )  return;

			var Q = (string)PuzzleList.SelectedItem;
			if( Q is null )  return;

			if( ((ListBox)sender).Name == "PuzzleList" ){
				int n = Q.IndexOf(":");
				int nx = int.Parse(Q.Substring(0,n));
				pGPDM.v7_current_Puzzle_No = nx-1;
				Send_SetPuzzleOnBoard();
			}
		}

		private void txb_Seach_Key_PreviewKeyDown(object sender, sysWin.Input.KeyEventArgs e ){
			if( e.Key == sysWin.Input.Key.Enter )		 btn_Search_Puzzle_Click(sender,null);
			else if( e.Key == sysWin.Input.Key.Escape )  btn_Search_Reset_Click(sender,null);
		}

		private void txb_Seach_Key_PreviewMouseDown(object sender, sysWin.Input.MouseButtonEventArgs e ){
			if( txb_Seach_Key.Text == "Search key" )  txb_Seach_Key.Text = "";
		}


    }
}
