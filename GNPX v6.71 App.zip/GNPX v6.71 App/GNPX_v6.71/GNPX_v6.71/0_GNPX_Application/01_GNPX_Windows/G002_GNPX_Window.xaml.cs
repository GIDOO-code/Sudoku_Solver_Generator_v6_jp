﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

using DLX_V2;

using GIDOO_space;

using GNPX_DLX2;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{

	using pGPDM  = GNPX_Puzzle_Database_Manager;
    using pRes   = Properties.Resources;
    using sysWin = System.Windows;

    public partial class GNPX_win: sysWin.Window{
		public event GNPX_EventHandler Send_Command_to_Func_Transform; 
		public event GNPX_EventHandler Send_Command_to_Func_SolveMulti; 
		public event GNPX_EventHandler Send_Command_to_Func_SolveSingle; 

		static public bool    EventSuppression=false;

		static private G6_Base G6 => GNPX_App_Man.G6;
		static private G7_Base G7 => GNPX_App_Man.G7;

		[DllImport("USER32.dll", CallingConvention = CallingConvention.StdCall)]		// ... Required for SetCursorPos
        static private extern void SetCursorPos(int X,int Y);							//Move the mouse cursor to Control

        private sysWin.Point     WinPrePos;

    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==
        public  GNPX_App_Man     GNPX_App;
		public  GNPX_Puzzle_Analysis_Support Pzl_Analysis_Supp => GNPX_App.Pzl_Analysis_Supp;

		private Func_Option		 objFunc_Option => (Func_Option)GNPX_App.objFunc_Option;

        private GNPX_Engin       pGNPX_Eng => GNPX_App.GNPX_Eng;   
		private UPuzzle			 engPzl    => pGNPX_Eng.ePZL;
		

		public  GNPX_WindowSub	 GNPX_WindowSub;
		public	GNPX_SearchPuzzle SearchPZL_Win = null;

        private int              WOpacityCC = 0;
//		private int				 FadeoutCC = 0;

//		private object obj = new();

		private DispatcherTimer  startingTimer;
        private DispatcherTimer  endingTimer;
        private DispatcherTimer  animationTimer;   
        private DispatcherTimer  bruMoveTimer;
        private DispatcherTimer  timerShortMessage;


    // ----- Extend -----
        private ExtendResultWin ExtResultWin;


    #region Application start/end
        public GNPX_win(){    
		
            try{
                InitializeComponent();  

						//===============================================
						// https://www.umayadia.com/cssample/sample0000/Sample136GetAppPath.htm
						//string appPath = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
						//G6.GNPX_CurrentPath = appPath;
						//===============================================
				
				GNPX_vsrsion.Content = App_Environment.GNPXvX;
				GNPX_App = new GNPX_App_Man(this);
				lbl_ShortMessage.Visibility = Visibility.Hidden;

				v7_UPuzzle_Base bPzl = new( new string('0',81), 0 );
				G60_PB.Set_Puzzle( new UPuzzle(bPzl), setImage:true );	// Blank Puzzle Display
				frame_GNPX_Func.Navigate( GNPX_App.objFunc_File );

              //var rdbLst = Extension_Utility.GetControlsCollection<RadioButton>(this);


			#region Timer
				timerShortMessage = new DispatcherTimer(DispatcherPriority.Normal);
				timerShortMessage.Interval = TimeSpan.FromMilliseconds(50);
				timerShortMessage.Tick += new EventHandler(timerShortMessage_Tick);


				
				startingTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
				startingTimer.Interval = TimeSpan.FromMilliseconds(70);
				startingTimer.Tick += new EventHandler(startingTimer_Tick);
				this.Opacity=0.0;
				startingTimer.Start();

				endingTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
				endingTimer.Interval = TimeSpan.FromMilliseconds(70);
				endingTimer.Tick += new EventHandler(endingTimer_Tick);

				animationTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
				animationTimer.Interval = TimeSpan.FromMilliseconds(200);//50
				animationTimer.Tick += new EventHandler(animationTimer_Tick);

				bruMoveTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
				bruMoveTimer.Interval = TimeSpan.FromMilliseconds(20);
				bruMoveTimer.Tick += new EventHandler(bruMoveTimer_Tick);

				FollowMove_timer = new DispatcherTimer(DispatcherPriority.Normal, this.Dispatcher );
				FollowMove_timer.Interval = TimeSpan.FromMilliseconds(10);
				FollowMove_timer.Tick += new EventHandler(FollowMove_timer_Tick);
			#endregion Timer

				//   Frame-Navigation
				// frame_GNPX_Func.Navigate( GNPX_App.objFunc_Solve );
				animationTimer.Start();

				// ===== Message =====
				string stDevelop = "--- Toward Version 7 ---\nDevelopment of new features will be temporarily halted.\nThe system's functionality will be rebuilt.";
				shortMessage( stDevelop, new Point(20,180), crBG:Colors.Navy, cr:Colors.White, tm:5000 );	

            }
            catch( Exception ex ){ WriteLine( $"{ex.Message}\n{ex.StackTrace}"); }
        }





        private void Window_Loaded( object sender, RoutedEventArgs e ){
			G6.OperationalMode = "Initializing";		// Initializing / NormalOperation

            EventSuppression = true;

			//   Frame-Navigation
			frame_GNPX_Func.Navigate( GNPX_App.objFunc_Solve );
			frame_GNPX_Func.Navigate( GNPX_App.objFunc_File );		//@@ Show first



			GNPX_App.SolverList_GNPX = GNPX_App.fPuzzleFile_IO.ReadXMLFile_AnalysisConditions_MethodList();


			Assembly	 assembly	  = Assembly.GetExecutingAssembly();
			AssemblyName assemblyName = assembly.GetName();
			G6.assemblyName   = assemblyName.Name;          // Simple name of an assembly
			G6.releaseVersion = assemblyName.Version?.ToString();

			G6.StartTime			= DateTime.Now;
			G6.sNoAssist			= false;
			G6.digitColoring		= false;
			G6.CellNumMax			= Max( G6.CellNumMax, 17 );

			nUD_MinDifficulty.Value = G6.G60_PuzzleMinDifficulty;

			double val  = G6.Processor_Utilization;
			val = Min( Max(val,0.2), 0.9 );
			G6.Processor_Utilization =  val;

			G6.OperationalMode = "NormalOperation";		// Initializing / NormalOperation

			chbx_ShowCandidate.IsChecked = G6.sNoAssist;

			{
				#if DEBUG
					G6.RandomSeedVal_000 = 1;
				#else
					G6.RandomSeedVal_000 = 0;
				#endif
				Pzl_Analysis_Supp.Set_RandomSeed(G6.RandomSeedVal_000);
			}


			{ // For advanced users only. Not covered in the manual.
				int moonAge = DateTime.Now.Get_MoonAge();
				G6.windows_Animation = (moonAge==14 | moonAge==14 | moonAge==14)? "chase": ""; 	// Something happens at AFL.
			  //G6.windows_Animation = (moonAge==13 | moonAge==14 | moonAge==15)? "chase": ""; 	// Something happens at AFL. (AFL:Almost Full Moon)

				btn_FinalState.Visibility    = G6.zPowerUser? Visibility.Visible: Visibility.Hidden;
				chb_MinDifficulty.Visibility = G6.zPowerUser? Visibility.Visible: Visibility.Hidden;
				nUD_MinDifficulty.Visibility = G6.zPowerUser? Visibility.Visible: Visibility.Hidden;

				if( G6.zPowerUserCC < 20 ){
					if(  G6.StartTime_v600==new DateTime() )  G6.StartTime_v600 = G6.StartTime;
					else if( DateTime.Now.Subtract(G6.StartTime_v600).TotalDays <= 10 )  G6.zPowerUserCC = 10;
				}
				if( G6.zPowerUserCC<2 && moonAge==14 )  G6.zPowerUserCC=10;		// ver7.0-
				G6.zPowerUserCC = Max( --G6.zPowerUserCC, 0 );
			}

			lbl_PU.Opacity = Min(G6.zPowerUserCC,10) / 10.0;
			btn_FinalState.Opacity = Min(G6.zPowerUserCC,0) / 5.0;
			lblPuzzleFileName.Opacity = Min(G6.zPowerUserCC,0)/5.0;

			btn_Page_Clicked( btnP_File, new RoutedEventArgs() );
			//WriteLine($"{System.Environment.WorkingSet:N0}");
        }

        private void Window_Unloaded( object sender, RoutedEventArgs e ){
            Environment.Exit(0);
        }


		// =====================================================================
		// [Att] "G60_PB_Mouse_..." must not be deleted.
			private void G60_PB_MouseEnter(object sender, MouseEventArgs e ){
				// WriteLine( "========================= G60_PB_MouseEnter" );
				G60_PB.Focus();
			}

			private void G60_PB_MouseUp(object sender, MouseButtonEventArgs e ){
				// WriteLine( "========================= G60_PB_MouseUp" );
				if( G6.PG6Mode != "Func_Transform" )  return;
				int rc = G6.Cell_rc;
				if( rc<0 || rc>80 ) return;
				Send_Command_to_Func_Transform( this, new Gidoo_EventHandler( "Cell_Clicked", ePara0:rc ) );
			}
		// =====================================================================

	#endregion Application start/end 



	#region Operation services using timers
	  // <<< Start/end Timer >>>   
        private void appExit_Click( object sender, RoutedEventArgs e ){
            GNPX_App.fPuzzleFile_IO.WriteXMLFile_AnalysisConditions_MethodList();
            WOpacityCC=0;
            endingTimer.IsEnabled = true;
            endingTimer.Start();
        }

        private void startingTimer_Tick( object sender, EventArgs e){
            WOpacityCC++;
            if( WOpacityCC >= 40 ){ this.Opacity=1.0; startingTimer.Stop(); }
            else{
				this.Opacity = WOpacityCC/40.0;
			}
        }
        private void endingTimer_Tick( object sender, EventArgs e){
            if( (++WOpacityCC)>20 )  Environment.Exit(0);   //Application.Exit();
            double dt = Max( 1.0-WOpacityCC/20.0, 0.0 );
            this.Opacity = dt = dt*dt;
			foreach( sysWin.Window w in Application.Current.Windows )  w.Opacity = dt;
        }
        
        private void __bruMoveSub(){ 
            Thickness X=G60_PB.Margin;
			G60_PB.Margin=new Thickness(X.Left+2,X.Top+2,X.Right,X.Bottom);
            bruMoveTimer.Start();
        }
		
        private void bruMoveTimer_Tick( object sender, EventArgs e){
			Thickness X = G60_PB.Margin;   //◆bruMoveTimer.Start();			
			G60_PB.Margin = new Thickness(X.Left-2,X.Top-2,X.Right,X.Bottom);
			Thread.Sleep(50);
            bruMoveTimer.Stop();
        }       

				  // <<< Animation >>>
					private int  opaCum = 0;
					private int  memoSec = 0;
					private void animationTimer_Tick( object sender, EventArgs e ){   //#@
						int sec = DateTime.Now.Second;
						if( memoSec != sec ){
							memoSec = sec;
							opaCum = (++opaCum) % 100;  
							double angle = 2.0 * Math.PI * (opaCum/100.0);
							GNPXv6_main.Opacity = 0.3 + Sin(angle) * 0.2;
						}
					}

      // <<< ShortMessage >>>
	    private void timerShortMessage_Tick( object sender, EventArgs e ){
            lbl_ShortMessage.Visibility = Visibility.Hidden;
            timerShortMessage.Stop();
        }
		public void shortMessage( string st, sysWin.Point pt, Color crBG, Color cr, int tm ){
			if( tm==9999 ) timerShortMessage.Interval = TimeSpan.FromSeconds(5);
			else           timerShortMessage.Interval = TimeSpan.FromMilliseconds(tm);   

			this.Dispatcher.Invoke( ()=>{
				lbl_ShortMessage.Content = st;
				lbl_ShortMessage.Foreground = new SolidColorBrush(cr);
				lbl_ShortMessage.Background = new SolidColorBrush(crBG);
				lbl_ShortMessage.Margin = new Thickness(pt.X,pt.Y,0,0);
				lbl_ShortMessage.Visibility = Visibility.Visible;
			} );
			
			timerShortMessage.Start();
        }
	#endregion Timer





	#region Location 
        private class Location_TimePos{
            public DateTime dt;
            public Point    pt;
            public Location_TimePos( DateTime d, Point p ){ dt=d; pt=p; }
			public override string ToString() => $"dt:{dt} pt:{pt}";
		}
		private DispatcherTimer  FollowMove_timer = new DispatcherTimer();

		private Queue<Location_TimePos> win_dtpt_List = new Queue<Location_TimePos>();

		private void Window_MouseDown( object sender, MouseButtonEventArgs e ){
            if( e.Inner(G60_PB) )    return; //◆			
            this.DragMove();
        }

		private void GNPXwin_LocationChanged( object sender,EventArgs e ){ //Synchronously move open window
			if( G6.windows_Animation == "" ){
				Point shift = new Point(this.Left-WinPrePos.X, this.Top-WinPrePos.Y);
				foreach( sysWin.Window w in Application.Current.Windows )  _GNPXwin_LocationChanged_base(w,shift);

					void _GNPXwin_LocationChanged_base( sysWin.Window w, Point PtShift ){
						if( w==null || w.Owner==this || w==this )  return;
						if( w.Name=="devWin" && !G6.LinkedMove )   return;
						w.Left += PtShift.X;
						w.Top  += PtShift.Y;
					}	
				
			}	
	
			else if( G6.windows_Animation == "chase" ){	
				if( WinPrePos.X==0 && WinPrePos.Y==0 )  WinPrePos = new(this.Left,this.Top);
				
				Location_TimePos LTP;
				var   dt = DateTime.Now;
				Point PtShift = new(this.Left-WinPrePos.X,this.Top-WinPrePos.Y);

				if( win_dtpt_List.Count>0 ){
					LTP = win_dtpt_List.Peek();
					if( (dt-LTP.dt).TotalMilliseconds<10 )  return; // The time interval is short.            
					if( PtShift.X==0 && PtShift.Y==0 )		return;	// Close distance.
				}
				LTP = new(dt,PtShift);
				win_dtpt_List.Enqueue(LTP);
				if( win_dtpt_List.Count>0 )  FollowMove_timer.Start();
			}

			WinPrePos = new (this.Left,this.Top);
		}


		private void FollowMove_timer_Tick( object sender, EventArgs e ){
			if( win_dtpt_List.Count == 0 ){ FollowMove_timer.Stop(); return; } 
			
			Location_TimePos LTP = win_dtpt_List.Peek();
			int timeControl = (win_dtpt_List.Count>20)? 100: 100+50/win_dtpt_List.Count*5;
			if( (DateTime.Now-LTP.dt).TotalMilliseconds<timeControl ) return;

			LTP =  win_dtpt_List.Dequeue();
			foreach( sysWin.Window w in Application.Current.Windows ) GNPXwin_LocationChanged_chase( w, LTP.pt );				

			if( win_dtpt_List.Count <= 0 )  FollowMove_timer.Stop();

					void GNPXwin_LocationChanged_chase( sysWin.Window w, Point PtShift){
						if( w==null || w.Owner==this || w==this )  return;
						if( w.Name=="devWin" && !G6.LinkedMove )   return;

						w.Left += PtShift.X;
						w.Top  += PtShift.Y;
						//w.Topmost=true;
					}	
		}

    #endregion Location



		private void btnP_Extensions_MouseDoubleClick(object sender, MouseButtonEventArgs e ){
			if( btnP_Extensions.Opacity < 0.5 ){
				btnP_Extensions.Opacity = 1.0;
				btnP_Extensions.Width = 60;
				frame_GNPX_Func.Navigate( GNPX_App.objFunc_ExtensionsPage );
			}
			else{
				btnP_Extensions.Opacity = 0.001;
				btnP_Extensions.Width = 10;
				frame_GNPX_Func.GoBack();
			}
			e.Handled = true;
		}





	// @@@@@ Event @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	#region Event

		private void Send_InitialState__to_Func_Solvers(){
			Send_Command_to_Func_SolveMulti( this, new Gidoo_EventHandler( "ToInitialState" ) );
			Send_Command_to_Func_SolveSingle( this, new Gidoo_EventHandler( "ToInitialState" ) );
		}

        public void GNPX_Event_Handling_man( object sender, Gidoo_EventHandler e ){ 
			v7_UPuzzle_Base aPZL = pGPDM.v7_current_Puzzle;

			// ::::::::: In other thread control, "Dispatcher.Invoke" is need! ::::::::::

			switch(e.eName){//			switch( e.eName.ToLower() ){
			
				case "Vibrate!": __bruMoveSub(); break;

				case "PuzzleFile_Clear":				
				case "PuzzleFile_Loaded":
					G60_Get_PreNxtPrg( 0, initialB:true ); 
					if( e.Message!=null ){
						this.Dispatcher.Invoke( () => {
							lblPuzzleFileName.Content="File : "+e.Message;
							lblPuzzleFileName.Opacity = Min(G6.zPowerUserCC,5)/5.0;

							if( SearchPZL_Win != null )SearchPZL_Win.Visibility = Visibility.Hidden;
							SearchPZL_Win = null;
						} );
					}
					break;
		
				case "SetPuzzle_no": 
					pGPDM.v7_current_Puzzle_No = e.ePara0-1;
					G60_Get_PreNxtPrg(0);
					break;

				case "SetPuzzleOnBoard": 
					G60_PB.Set_Puzzle( new UPuzzle(aPZL), setImage:true );	// @@@ v6
					this.Dispatcher.Invoke( () => Display_ExtResultWin( ) );
					break;

				case "LatinSquareGenerated":
				case "PuzzleCreated":
					// Updates and displays of the main board (UC_PB_GBoard) 
					this.Dispatcher.Invoke(() => {
						pGPDM.v7_current_Puzzle_No = int.MaxValue;
						G60_PB.Set_Puzzle( new UPuzzle(aPZL), setImage:true );
						G60_Get_PreNxtPrg( pm:1 );
						DIsplay_PuzzleList_Index( int.MaxValue );
					} );
					if( G6.ResultShow )  pGPDM.v7_current_Puzzle_No = int.MaxValue;
					break;


				case "Solved":
					this.Dispatcher.Invoke( () => Display_ExtResultWin( ) );
					break;


				case "Show_AnalysisStatus":
					Clear_FinalState();

					G60_PB.Set_Puzzle( engPzl, setImage:true );
					this.Dispatcher.Invoke( () => {	
						int nn = pGPDM.v7_current_Puzzle_No;
						DIsplay_PuzzleList_Index( nn );//   int.MaxValue );
						Display_ExtResultWin( );
					} );
					break;

				case "Save_HTML_of_Puzzle":
	//				if( G7.g7_ePZL!=null ) Pzl_Analysis_Supp.Save_HTML_of_Puzzle( pGNPX_Eng, G6.folderName_XXX, G7.g7_ePZL );
					break;

				case "G6_Changed":
					Visibility PU_Visibility = G6.zPowerUser? Visibility.Visible: Visibility.Hidden;
					btn_FinalState.Visibility = PU_Visibility;	
					chb_MinDifficulty.Visibility = PU_Visibility;
					nUD_MinDifficulty.Visibility = PU_Visibility;
					break;

				case "InvalidPuzzle":  /*_isValidPuzzle();*/ break;  //#@

				case "ShortMessage": shortMessage( e.gsm.Message, e.gsm.Pt, e.gsm.color, Colors.White, e.gsm.msec ); break;
				case "SystemError":  shortMessage( e.Message, new sysWin.Point(400,180), Colors.Orange, Colors.White, 3000 );	break;
			}
			return;


		}

		private void Display_ExtResultWin( ){
            if( engPzl.extResult==null || engPzl.extResult.Length<2 ){
				if( ExtResultWin!=null && ExtResultWin.Visibility==Visibility.Visible ){
				    ExtResultWin.Visibility = Visibility.Collapsed;		//Close();    
                //    ExtResultWin = null;   
				}
				return;
			}
            else{        	
              //WriteLine( $"Display_ExtResultWin {DateTime.Now} {pPZL.extResult}" );    
                if( ExtResultWin != null ){
					ExtResultWin.Visibility = Visibility.Collapsed;//	Close();
					//ExtResultWin.Close(); ExtResultWin=null;
				}
                ExtResultWin = new ExtendResultWin(this);
                ExtResultWin.Visibility = Visibility.Visible;
				ExtResultWin.Width = this.Width;
				ExtResultWin.Left  = this.Left;
				ExtResultWin.Top   = this.Top+this.Height;

                ExtResultWin.Show();
			    ExtResultWin.SetText(engPzl.extResult);
#if G7develop
				if(G6.zPowerUser){	// for G7 / under development	
					if( G6.AutoDisplayOnErrorOccurs	&& engPzl!=null && engPzl.Sol_Result!=null && engPzl.Sol_Result.Contains("error") ){
						this.Dispatcher.Invoke( () => btn_FinalState_Click(this,new RoutedEventArgs() ) );
					}
				}
#endif
            }
		
	///		G7.g7CurrentState = engPzl.BOARD;
		/*
			if( GNPX_WindowSub!=null && GNPX_WindowSub.Visibility==Visibility.Visible ){
				btn_FinalState_Click( this, new RoutedEventArgs() );
			}
		*/
		}	

	#endregion Event








	// @@@@@ Grid Left @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	#region Grid Left 

		private void DIsplay_PuzzleList_Index(int nn0=int.MaxValue ){
			pGPDM.v7_current_Puzzle_No = nn0;
			int nn = pGPDM.v7_current_Puzzle_No;
			v7_UPuzzle_Base bPzl = pGPDM.v7_current_Puzzle; 
			if( bPzl == null ) return;

			this.Dispatcher.Invoke(() => {
				txt_G60PuzzleNo_EventStop = true;
				txt_G60PuzzleNo.Text = (nn+1).ToString();
				txt_G60PuzzleNo_EventStop = false;
				
				int nnLast = pGPDM.v7_GNPX_Puzzle_Count;
				lbl_G60PuzzlesCount.Content = $"/ {nnLast}";
				txt_G60PuzzleName.Text = bPzl.stPuzzleName;
			} );
		}

		private bool txt_G60PuzzleNo_EventStop = false;
		private void btn_G60ProbPre_Click(object sender,RoutedEventArgs e){ G60_Get_PreNxtPrg(-1); }
        private void btn_G60ProbNxt_Click(object sender,RoutedEventArgs e){ G60_Get_PreNxtPrg(+1); }
		private void G60_Get_PreNxtPrg( int pm, bool initialB=false ){
			Clear_FinalState();

			bool chkDif = (bool)chb_MinDifficulty.IsChecked;
            int nn = pGPDM.v7_current_Puzzle_No;

			bool breakB=false;
		  LNext:
			nn += pm;
			if( initialB ){ nn=0; initialB=false; }
            if( nn<0 || nn>pGPDM.v7_GNPX_Puzzle_Count-1 ){
				nn = (pm<=0)? 0: pGPDM.v7_GNPX_Puzzle_Count-1;
				breakB = true;
			}

            pGPDM.v7_current_Puzzle_No = nn;
			v7_UPuzzle_Base bPZL = pGPDM.v7_current_Puzzle;
			if( bPZL == null ) return;
			int Diff = bPZL.difficulty;
			if( !breakB && chkDif && Diff<G6.G60_PuzzleMinDifficulty )  goto LNext;

			G7.g7FinalState_TE = null;
			G7.g7CurrentState  = null;

			GNPX_App.GNPX_Eng.Set_NewPuzzle( bPZL );
            GNPX_App.GNPX_Eng.AnMan.ResetAnalysisResult(false); //Clear analysis result only

			G60_PB.Set_Puzzle( new UPuzzle(bPZL), setImage:true );

            GNPX_App.GNPX_Eng.AnalyzerCounterReset();
			
			txt_G60PuzzleNo_EventStop = true;

			txt_G60PuzzleNo_EventStop = false;

			lbl_G60PuzzlesCount.Content = $"/ {pGPDM.v7_GNPX_Puzzle_Count}";
			txt_G60PuzzleName.Text = bPZL.stPuzzleName;
			
			btn_G60ProbPre.IsEnabled = nn > 0;
            btn_G60ProbNxt.IsEnabled = nn < pGPDM.v7_GNPX_Puzzle_Count-1;

			// BroadcastToPages()
			Send_InitialState__to_Func_Solvers();

			if( SearchPZL_Win!=null )  this.Dispatcher.Invoke( () => SearchPZL_Win.PuzzleList_SelectionChanged( (object)engPzl, null ) );
        }



		private void txt_G60PuzzleName_TextChanged(object sender, TextChangedEventArgs e ){
			if( txt_G60PuzzleName == null )  return;
            if( txt_G60PuzzleName.IsFocused) engPzl.Name=txt_G60PuzzleName.Text;
		}


		private void txt_G60PuzzleNo_PreviewKeyDown(object sender, KeyEventArgs e ){
			if( e.Key != Key.Return )  return;

			int nn = int.Parse( txt_G60PuzzleNo.Text );
			pGPDM.v7_current_Puzzle_No = nn-1;
			G60_Get_PreNxtPrg(0);
		}

		private void nUD_MinDifficulty_ValueChanged(object sender, GIDOOEventArgs args) {
			G6.G60_PuzzleMinDifficulty = nUD_MinDifficulty.Value;
		}

		private void btn_CopyBitMap_Click(object sender, RoutedEventArgs e ){
			objFunc_Option.btn_CopyBitMap_Click(sender, e );
			objFunc_Option.btn_SaveBitMap_Click(sender, e );
        }


		private void chbx_ShowCandidate_Checked(object sender, RoutedEventArgs e ){
			if( chbx_ShowCandidate ==null ) return;
			G6.sNoAssist = (bool)chbx_ShowCandidate.IsChecked;
		}

		private bool disp_Solution_DLX = false;

		public void Clear_FinalState(){
			//if( !G6.zPowerUser )  return;
			disp_Solution_DLX = false;
			if( GNPX_WindowSub != null )  GNPX_WindowSub.Visibility = Visibility.Collapsed;		//Close();   
		}

		private void btn_FinalState_Click(object sender, RoutedEventArgs e ){
			bool B = G6.zPowerUser;
			if( !B )  return;

			if( engPzl.BOARD.All( uc => uc.No==0 ) )  return;

			B = disp_Solution_DLX = !disp_Solution_DLX;
			if( B ){
				int[] puzzle = engPzl.BOARD.ConvertAll(p => Abs(p.No)).ToArray();
		
				// <<< Solve using DLX solver(ver7.0-). >>>
				DLX_V2.SudokuSolver SDK_Solver = new();
                var solutions = SDK_Solver.Solve( puzzle, maxSolutions:2 /*,ct*/);   //ct:undefine
				if( solutions == null ) return;

				int[]  sol = solutions[0];
				List<UCell> BOARD_final = engPzl.Copy().BOARD;
				BOARD_final.ForEach(U => U.ECrLst=null );
				BOARD_final.ForEach(U => { if(U.No==0) U.No=-sol[U.rc]; } );

				BOARD_final = _Get_Solution( BOARD_final );

				if( GNPX_WindowSub== null ){			
					GNPX_WindowSub = new( GNPX_App );
					GNPX_WindowSub.Visibility = Visibility.Visible;
					GNPX_WindowSub.Left  = this.Left-GNPX_WindowSub.Width-1;
					GNPX_WindowSub.Top   = this.Top+Height-GNPX_WindowSub.Height;
				}

				GNPX_WindowSub.Set_imgPB_GBoard( BOARD_final, whiteBack:true );

				GNPX_WindowSub.Show();
			}
			else{
				GNPX_WindowSub.Visibility = Visibility.Collapsed;		//Close();    
			}

			
		//	GNPX_Event_Handling_man( this, new Gidoo_EventHandler( eName:"Show_AnalysisStatus" ) );
			return;

						List<UCell> _Get_Solution( List< UCell > board ){
							if( board!=null && G7.g7CurrentState!=null ){
								var BD = G7.g7FinalState_TE;
								board.ForEach( uc => board[uc.rc].ECrLst=null );
								foreach( var uc in G7.g7CurrentState.Where(uc=>uc.No<=0) ){
									UCell U = board[uc.rc];
									int   no0 = Abs(U.No);
									if( uc.No!=0 && Abs(uc.No)!=no0 ) U.Set_CellBkgColor( Colors.Bisque );
									if( uc.CancelB.IsHit(no0-1)  )    U.Set_CellBkgColor( Colors.PeachPuff );
								}
							}
							return board;
						}

		}

		private void btn_PuzzleSearch_Click(object sender, RoutedEventArgs e){
			if( sender is UPuzzle )  return;
			if( SearchPZL_Win == null ){ 
				SearchPZL_Win = new GNPX_SearchPuzzle( this ); 
				SearchPZL_Win.Show(); 
				_Set_Position_Win(SearchPZL_Win, new sysWin.Point(0,this.Height+10) );
			}
			else if( SearchPZL_Win.Visibility==Visibility.Collapsed ){
				SearchPZL_Win.Show(); _Set_Position_Win(SearchPZL_Win, new sysWin.Point(0,this.Height+10) );
			}
			else if( SearchPZL_Win.Visibility==Visibility.Hidden )     SearchPZL_Win.Visibility = Visibility.Visible;

					void  _Set_Position_Win( sysWin.Window w,  Point PtShift){
						if( w==null || w.Owner==this || w==this )  return;
						if( w.Name=="devWin" && !G6.LinkedMove )   return;

						Point shift = new Point(this.Left-WinPrePos.X, this.Top-WinPrePos.Y);
						w.Left = this.Left + PtShift.X;
						w.Top  = this.Top  + PtShift.Y;
						//w.Topmost=true;
					}	
		}

	#endregion Grid Left 


	// @@@@@ Grid Right @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	#region Page Processing Function	

		private List<Button>		pageControlList=null;
		private void btn_Page_Clicked(object sender, RoutedEventArgs e ){
			if( pageControlList == null ){
				pageControlList = ( List<Button>)GNPX_Utilitie.GetControlsCollection<Button>(this);
				pageControlList = pageControlList.FindAll( P=> P.Name.Contains("btnP_") );
			}

			Button btn = (Button)sender;
			pageControlList.ForEach( P => P.Foreground=Brushes.White );
			btn.Foreground = Brushes.Gold;

			string btnName = btn.Name.Replace( "btnP_","");
			switch(btnName){ 
				case "File":       frame_GNPX_Func.Navigate( GNPX_App.objFunc_File ); break;
				case "Solve":      frame_GNPX_Func.Navigate( GNPX_App.objFunc_Solve ); break;
				case "Create":     frame_GNPX_Func.Navigate( GNPX_App.objFunc_Create ); break;
				case "Option":     frame_GNPX_Func.Navigate( GNPX_App.objFunc_Option ); break;
				case "Transform":  frame_GNPX_Func.Navigate( GNPX_App.objFunc_Transform ); break;
				case "HomePage":   frame_GNPX_Func.Navigate( GNPX_App.objFunc_HomePage ); break;
				case "Extensions": frame_GNPX_Func.Navigate( GNPX_App.objFunc_ExtensionsPage ); break;
			}
		}
		#endregion File Processing Function



	#region PreviewKeyDown
/*
		private void G60_PB_PreviewKeyDown(object sender, KeyEventArgs e ){
			WriteLine( "+++ G60_PB_PreviewKeyDown +++" );
			GNPXv6_PreviewKeyDown( sender, e );
		}
*/
		private void GNPXv6_PreviewKeyDown(object sender, KeyEventArgs e){
			//WriteLine( $"GNPXv6_PreviewKeyUp  G6.PG6Mode:{G6.PG6Mode}" );

            bool KeySft  = (Keyboard.Modifiers&ModifierKeys.Shift)>0;
            bool KeyCtrl = (Keyboard.Modifiers&ModifierKeys.Control)>0;

			Image imgPB_GBoard = G60_PB.imgPB_GBoard; 
            var (W,H) = (imgPB_GBoard.Width,imgPB_GBoard.Height);
			var Pt = Mouse.GetPosition(imgPB_GBoard);
            if( Pt.X<0 || Pt.Y<0 || Pt.X>=W || Pt.Y>=H )  return;



            if( e.Key==Key.C && KeyCtrl ){                // Ctrl+"c" => board -> Clipboard(81"n")
                string st = CopyToBuffer( KeySft:KeySft, WithSpaceB:true );
                try{
                    Clipboard.Clear();
                    Clipboard.SetData(DataFormats.Text, st);
					Thread.Sleep(100);
                }
                catch(System.Runtime.InteropServices.COMException){ /* NOP */ }
            }



            else if( e.Key==Key.F && KeyCtrl ){				// Ctrl+"f" => board -> Clipboard(9x9"n")
                string st = ToGridString(KeySft);   
                try{
                    Clipboard.Clear();
                    Clipboard.SetData(DataFormats.Text, st);
					Thread.Sleep(100);
                }
                catch(System.Runtime.InteropServices.COMException){ /* NOP */ }
            }



            else if( e.Key==Key.V && KeyCtrl ){				// Ctrl+"v" => Clipboard(any foramt) -> board
				// WriteLine( "==================== e.Key==Key.V && KeyCtrl @@@" );

                string stLine = (string)Clipboard.GetData(DataFormats.Text);
                Clipboard.Clear();
                if( stLine==null || stLine.Length<81 ) return ;

				v7_UPuzzle_Base bPzl = new( stLine.stringToIntArray() );

				pGPDM.v7_GNPX_Puzzle_List_Add( bPzl );
                pGPDM.v7_current_Puzzle_No = int.MaxValue;			//pGPDM.GNPX_Puzzle_List.Count-1

				G60_PB.Set_Puzzle( new UPuzzle(bPzl), setImage:true );	//_SetPuzzleOnBoard();
				G60_Get_PreNxtPrg( int.MaxValue );

				Send_InitialState__to_Func_Solvers();

				Thread.Sleep(100);
            }

			return;


						// ----------------------------------------------------------------------------------------------
						string CopyToBuffer( bool KeySft=false, bool WithSpaceB=true ){
							string st = "";
							if( KeySft ) st = engPzl.BOARD.ConvertAll(q=> Abs(q.No)).Connect("").Replace("0",".");
							else         st = engPzl.BOARD.ConvertAll(q=> Max(q.No,0)).Connect("").Replace("0",".");

							if( WithSpaceB)  st = st.ToStringWithSpace();
							return st;
						}

						string ToGridString( bool SolSet ){
							string st="";
							engPzl.BOARD.ForEach( P =>{
								st+=(SolSet? P.No: Max(P.No,0));
								if( P.c==8 ) st+="\n";
								else if( P.rc!=80 ) st+=",";
							} );
							return st;
						}
		}
		#endregion PreviewKeyDown

	
    }
}	