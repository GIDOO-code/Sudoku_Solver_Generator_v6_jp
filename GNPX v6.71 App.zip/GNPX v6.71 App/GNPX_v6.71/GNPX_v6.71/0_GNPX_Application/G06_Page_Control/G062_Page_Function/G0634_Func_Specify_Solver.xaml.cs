﻿using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using System.Diagnostics.Metrics;

namespace GNPX_space{
	using pRes = Properties.Resources;
	using ioPath = System.IO.Path;
	using pGPDM = GNPX_Puzzle_Database_Manager; 

    public partial class Func_Specify_Solver: Page{
		static public event GNPX_EventHandler Send_GNPX_Control; 

		public GNPX_App_Man 		pGNPX_App;
		public GNPX_win				pGNP00win => pGNPX_App.pGNP00win;

		private G6_Base				G6 => GNPX_App_Man.G6;
		private List<UAlgMethod>    pSolverList_GNPX => pGNPX_App.SolverList_GNPX;		//For internal use. After processing, copy to the external "List".


	//	private string				Method_SelectionMode{ get=>G6.Method_SelectionMode; set=>G6.Method_SelectionMode=value; }
		private int					selIX = -1;
		private CheckBox			selCheckBox = null;
		private string				key_MethodName;

        public Func_Specify_Solver( GNPX_App_Man GNPX_App){
			pGNPX_App = GNPX_App;

            InitializeComponent();
			Send_GNPX_Control += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man ); 

			nud_Difficulty.Value = G6.Method_DifficultyLevel;
        }

	  #region <<< Page Load / Unload >>>
		private void Page_Loaded( object sender, RoutedEventArgs e ){ 
			G6.PG6Mode = GetType().Name;

			G6.OperationalMode = "Initializing";

			if( pSolverList_GNPX != null ){	 // Only once during execution

				G6.Method_DifficultyLevel = Max( G6.Method_DifficultyLevel, 3 );
				nud_Difficulty.Value = G6.Method_DifficultyLevel;

				_PageInitialSet_SolverList( );	

						void _PageInitialSet_SolverList( ){
							UAlgMethod PG = pSolverList_GNPX.Find( P => P.GenLogB );

							var _diffLevel = G6.Method_DifficultyLevel;
							foreach( var P in pSolverList_GNPX ){
								int dif = P.difficultyLevel;
								P.IsChecked = dif>0 && (dif<=_diffLevel);
								P.brshM = P.IsChecked? Brushes.Lime: Brushes.White;
								if( P.Sel_mark && !P.IsChecked ){ P.IsChecked=true; P.brshM=Brushes.Orange; }
							}

							var QGenLogList = pSolverList_GNPX.FindAll( P => P.MethodName.Contains("GeneralLogic") );
							foreach( var P in QGenLogList )  P.IsChecked  = G6.GeneralLogic_on;  // Enable/disable GeneralLogic

							listBox_GMethod00A.ItemsSource = null;
							listBox_GMethod00A.ItemsSource = pSolverList_GNPX;
						}


				var currentDir = Directory.GetCurrentDirectory();
				txtB_SDK_Methods.Text = Path.Combine(currentDir, G6.SDK_Methods_XMLFileName);

				bool B = G6.GeneralLogic_on;
				string cul = Thread.CurrentThread.CurrentCulture.Name;
				string st2;
				st2= (B? "":"not ") + "available";
				lbl_GeneralLogic.Content = "GeneralLogic : "+ st2;
				lbl_GeneralLogic.Foreground = (B)? Brushes.LightBlue: Brushes.Yellow;
			}
			G6.OperationalMode = "NormalOperation";

			listBox_GMethod00A.ItemsSource = null;
			listBox_GMethod00A.ItemsSource = pSolverList_GNPX;
		}


		private void Page_Unloaded(object sender, RoutedEventArgs e ){
			pGNPX_App.fPuzzleFile_IO.WriteXMLFile_AnalysisConditions_MethodList();
		}
	  #endregion ------------------------------------------

	  	private void ChangeCondition_SolverList( ){
			if( G6.OperationalMode == "Initializing" )  return;

			pSolverList_GNPX.ForEach( P=> P.IsChecked=false );
			UAlgMethod PG = pSolverList_GNPX.Find( P => P.GenLogB );

			var _diffLevel = G6.Method_DifficultyLevel;
			foreach( var P in pSolverList_GNPX ){
				int dif = P.difficultyLevel;
				P.IsChecked = dif>0 && (dif<=_diffLevel);
				if( P==PG && !G6.GeneralLogic_on )  PG.IsChecked = false;

				P.brshM = P.IsChecked? Brushes.Lime: Brushes.White;
				if( P.Sel_mark && P.IsChecked ){ P.IsChecked=true; P.brshM=Brushes.Orange; }
			}
			
			UAlgMethod QGenLog = pSolverList_GNPX.Find( P => P.MethodName.Contains("GeneralLogic") );
			if( QGenLog != null )  QGenLog.IsChecked  = G6.GeneralLogic_on;  // Enable/disable GeneralLogic

			listBox_GMethod00A.ItemsSource = null;
			listBox_GMethod00A.ItemsSource = pSolverList_GNPX;
		}





		// ----- <<< Up / Down >> -----
        private void rbtn_GMethod01U_Click( object sender, RoutedEventArgs e ){
			selIX = listBox_GMethod00A.SelectedIndex;
            if( selIX<=3 || selIX==0 )  return;
			
			var Q = (UAlgMethod)listBox_GMethod00A.SelectedItem;
			_ChangeOrder_MethodList(selIX,-1);

			ChangeCondition_SolverList( );
			selIX = pSolverList_GNPX.FindIndex( q=> q.NameM==Q.NameM );
			listBox_GMethod00A.SelectedIndex = selIX;
        }
        private void rbtn_GMethod01D_Click( object sender, RoutedEventArgs e ){
			selIX = listBox_GMethod00A.SelectedIndex;
            if( selIX<=3 || selIX==listBox_GMethod00A.Items.Count-1 )  return;

			var Q = (UAlgMethod)listBox_GMethod00A.SelectedItem;
			_ChangeOrder_MethodList(selIX,+1);

			ChangeCondition_SolverList( );
			selIX = pSolverList_GNPX.FindIndex( q=> q.NameM==Q.NameM );
			listBox_GMethod00A.SelectedIndex = selIX;
        }

        public  void _ChangeOrder_MethodList( int nx, int UD ){
            UAlgMethod MA=pSolverList_GNPX[nx], MB;
            if(UD<0){ MB=pSolverList_GNPX[nx-1]; pSolverList_GNPX[nx-1]=MA; pSolverList_GNPX[nx]=MB; }   
            if(UD>0){ MB=pSolverList_GNPX[nx+1]; pSolverList_GNPX[nx+1]=MA; pSolverList_GNPX[nx]=MB; }
        }




		// ----- <<< DifficultyUp / Recommend >> -----
		private void nud_Difficulty_ValueChanged(object sender, GIDOOEventArgs args) {
			if( G6.OperationalMode == "Initializing" )  return;

			if( nud_Difficulty==null || pSolverList_GNPX==null )  return;
			G6.Method_DifficultyLevel = nud_Difficulty.Value;
			ChangeCondition_SolverList( );
		}


		// ----- <<< Reverting to the start of this page. >> -----
		private void btn_Initial_Click(object sender, RoutedEventArgs e ){

			// <<< Copy form SolverList_SysDef >>>
			pSolverList_GNPX.ForEach( P=> P.Sel_mark=false );
			
			if( (bool)chb_SortByDifficulty.IsChecked ){
				pSolverList_GNPX.Sort( (a,b)=> (a.difficultyLevel-b.difficultyLevel) );
			}
			else{
				pSolverList_GNPX.Sort( (a,b)=> (a.ID-b.ID) );
			}

			nud_Difficulty.Value = G6.Method_DifficultyLevel = 5;
			listBox_GMethod00A.ItemsSource = null;
			listBox_GMethod00A.ItemsSource = pSolverList_GNPX;
		}

		private void CheckBox_Checked(object sender, RoutedEventArgs e ){
			var P = (CheckBox)sender;
			var PContent = (String)P.Content;
			PContent = PContent.Replace("__","_");
			PContent = PContent.Replace("__","_");

			var Q = pSolverList_GNPX.Find( q=> q.MethodName==PContent ); 
			if( Q != null ){
				Q.IsChecked = (bool)P.IsChecked;		//If it's 10 or more, include the negatives.
				Q.Sel_mark  = (bool)P.IsChecked;
			}

			listBox_GMethod00A.ItemsSource = null;
			listBox_GMethod00A.ItemsSource = pSolverList_GNPX;
		}

		private void btn_Sort_Click(object sender, RoutedEventArgs e ){

        }
    }
}
