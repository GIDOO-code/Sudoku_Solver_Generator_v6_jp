﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
	using pGPDM = GNPX_Puzzle_Database_Manager;
	using sysWin = System.Windows;

    public partial class Func_CreateManual: Page{
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 

		public GNPX_App_Man 		pGNPX_App;
        private GNPX_win			pGNP00win{ get=> pGNPX_App.pGNP00win; } 
		public GNPX_Puzzle_Analysis_Support        Pzl_Analysis_Supp => pGNPX_App.Pzl_Analysis_Supp;

		private G6_Base				G6 => GNPX_App_Man.G6;

		private GNPX_Graphics		gnpxGrp => pGNPX_App.gnpxGrp;


        private GNPX_Engin			pGNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine
		public UPuzzle				ePZL{ get=>pGNPX_Eng.ePZL; set=>pGNPX_Eng.ePZL=value; } // Puzzle to analyze

		private bool				InPreparation=true;

        private DispatcherTimer		timerShortMessage;

        public Func_CreateManual( GNPX_App_Man GNPX_App ){
			pGNPX_App = GNPX_App;
            InitializeComponent();

			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  

			InPreparation = false;
		
			lbl_ShortMessage.Visibility = Visibility.Hidden;

			timerShortMessage = new DispatcherTimer(DispatcherPriority.Normal);
			timerShortMessage.Interval = TimeSpan.FromMilliseconds(50);
			timerShortMessage.Tick += new EventHandler(timerShortMessage_Tick);
        }


		private void Page_Loaded(object sender, RoutedEventArgs e ){
			G6.PG6Mode = GetType().Name;
        }

		private void Send_SetPuzzleOnBoard(){
			Gidoo_EventHandler se = new Gidoo_EventHandler( eName:"Show_AnalysisStatus" );  //Report
			Send_Command_to_GNPXwin( this, se );
		}


		private void chbAssist01_Checked(object sender, RoutedEventArgs e ){
			if( InPreparation )  return;
            G6.sNoAssist = (bool)chbx_ShowNoUsedDigits.IsChecked;
			Send_SetPuzzleOnBoard();
		}

		#region === ShortMessage ===
	    private void timerShortMessage_Tick( object sender, EventArgs e ){
            lbl_ShortMessage.Visibility = Visibility.Hidden;
            timerShortMessage.Stop();
        }
		public void shortMessage( string st, sysWin.Point pt, Color cr, int tm ){
			if( tm==9999 ) timerShortMessage.Interval = TimeSpan.FromSeconds(5);
			else           timerShortMessage.Interval = TimeSpan.FromMilliseconds(tm);   

			this.Dispatcher.Invoke( ()=>{
				lbl_ShortMessage.Content = st;
				lbl_ShortMessage.Foreground = new SolidColorBrush(Colors.White);
				lbl_ShortMessage.Background = new SolidColorBrush(cr);
				lbl_ShortMessage.Margin = new Thickness(pt.X,pt.Y,0,0);
				lbl_ShortMessage.Visibility = Visibility.Visible;
			} );
			
			timerShortMessage.Start();
        }
		#endregion === ShortMessage ===





		private void btnNewPuzzle_Click(object sender, RoutedEventArgs e ){
			pGPDM.CreateNewPuzzle();
			ePZL.BOARD.ForEach(P=>P.FreeB=0x1FF);
			pGPDM.v7_current_Puzzle_No = int.MaxValue;
            Send_SetPuzzleOnBoard();
		}

		private void btn_SavePuzzle_Click(object sender, RoutedEventArgs e ){
				//ePZL.BOARD.__CellsPrint( "btn_SavePuzzle_Click  ePZL.BOARD" );
            if( ePZL.BOARD.All(P=>P.No==0) ) return;

			if( (bool)chkbx_Save_only_Sudoku_Puzzle.IsChecked ){
				int[] puzzle = ePZL.BOARD.ConvertAll(p => Abs(p.No)).ToArray();
				// <<< Solve using DLX solver(ver7.0-). >>>
				DLX_V2.SudokuSolver SDK_Solver = new();
				var solutions = SDK_Solver.Solve( puzzle, maxSolutions:2 /*,ct*/);   //ct:undefine
				if( solutions==null || solutions.Count()>1 ){
					shortMessage( "not a Sudoku puzzle.", new sysWin.Point(300,130), Colors.DarkOrange, tm:3000);
					return;
				}
			}

            var chk_v7P = v7_GNPX_Puzzle_List_Add_ifNotContain();
			if( chk_v7P == null ){
				shortMessage( "Already saved. No action taken.", new sysWin.Point(300,130), Colors.DarkOrange, tm:3000);
			}
			else{
				Send_SetPuzzleOnBoard();
				shortMessage( "Saved Puzzle.", new sysWin.Point(300,130), Colors.Blue, tm:3000);
			}

					v7_UPuzzle_Base? v7_GNPX_Puzzle_List_Add_ifNotContain(){
						int[] board = pGNPX_Eng.ePZL.BOARD.ConvertAll(P=>Max(P.No,0)).ToArray();
						v7_UPuzzle_Base v7_Pzl = new(board);
						int hv = v7_Pzl.hasgValue;
						if( pGPDM.v7_GNPX_Puzzle_List.Find(P=>P.hasgValue==hv) != null )  return null;
						pGPDM.v7_GNPX_Puzzle_List_Add( v7_Pzl );
						return v7_Pzl;
					}
		}





		private void btn_CopyPuzzle_Click(object sender, RoutedEventArgs e ){
            UPuzzle tmpPZL = ePZL.Copy( );
            tmpPZL.Name="copy";
            pGPDM.CreateNewPuzzle(tmpPZL);
			pGPDM.v7_current_Puzzle_No = int.MaxValue;
            Send_SetPuzzleOnBoard();
		}
		private void btn_ClearPuzzle_Click(object sender, RoutedEventArgs e ){
            for(int rc=0; rc<81; rc++ ){ ePZL.BOARD[rc] = new UCell(rc:rc,No:0,FreeB:0x1FF); }
            Send_SetPuzzleOnBoard();
		}

		private void btn_DeletePuzzle_Click(object sender, RoutedEventArgs e ){	
            pGPDM.v7_GNPX_Remove();
            Send_SetPuzzleOnBoard();
		}



    }
}
