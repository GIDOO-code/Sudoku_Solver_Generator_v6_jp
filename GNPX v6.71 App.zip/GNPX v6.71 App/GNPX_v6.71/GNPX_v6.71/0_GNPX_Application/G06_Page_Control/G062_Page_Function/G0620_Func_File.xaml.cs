﻿using GNPX_space;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml.Linq;

using GIDOO_space;

namespace GNPX_space{
	using ioPath = System.IO.Path;
	using pGPDM  = GNPX_Puzzle_Database_Manager;
    using pRes   = Properties.Resources;
	using sysWin = System.Windows;



    public partial class Func_File: Page{
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 
		static public GNPX_win		pGNP00win => pGNPX_App.pGNP00win;
		static public GNPX_App_Man 	pGNPX_App;
		static private G6_Base		G6 => GNPX_App_Man.G6;

	    private PuzzleFile_IO		fPuzzleFile_IO => pGNPX_App.fPuzzleFile_IO;

		[DllImport("USER32.dll", CallingConvention = CallingConvention.StdCall)]		// ... Required for SetCursorPos
        static private extern void SetCursorPos(int X,int Y);							//Move the mouse cursor to Control

		private DispatcherTimer    timer_Countdown_Message;


	//	private int CountDownCC;
        public Func_File( GNPX_App_Man GNPX_App){
			pGNPX_App = GNPX_App;

            InitializeComponent();

			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  

			timer_Countdown_Message = new DispatcherTimer(DispatcherPriority.Normal);
			timer_Countdown_Message.Interval = TimeSpan.FromMilliseconds(1000);
			timer_Countdown_Message.Tick += new EventHandler(Countdown_To_Initialization_Tick);
        }

		private void Page_Loaded(object sender, RoutedEventArgs e ){
			G6.PG6Mode = GetType().Name;
			grd_Develop_Exocet.Opacity = 0.0;

			// Move the mouse cursor to Button:btn_OpenPuzzleFile
			if( G6.MousePposition_at_Startup ){
				this.Cursor = Cursors.Arrow;
				var btnQ = btn_OpenPuzzleFile;                    
				var ptM  = new Point( btnQ.Margin.Left, btnQ.Margin.Top );  // Center coordinates
				var pt   = btn_OpenPuzzleFile.PointToScreen(ptM);			// Grid relative coordinates to screen coordinates.
				SetCursorPos((int)pt.X,(int)pt.Y);							// Move the mouse cursor
			}

			txb_AppDefFilePath.Text = G6.Dir_SDK_Methods_XMLFileName;

			if( G6.Dir_SDK_Methods_XMLFileName!=null && G6.Dir_SDK_Methods_XMLFileName!= "")  txtFileName.Text = G6.Dir_SDK_Methods_XMLFileName;

			var PzlCC = pGPDM.v7_GNPX_Puzzle_Count;
			btn_Initialize_PuzzleFile.Visibility = (PzlCC>0)? Visibility.Visible: Visibility.Hidden;
        }




		private void btn_OpenPuzzleFile_Click(object sender, RoutedEventArgs e ){
			btn_OpenPuzzleFile.Width = 120;
			btn_OpenPuzzleFile.Height = 25;
			btn_OpenPuzzleFile.FontSize = 12;
			GradientStop00.Color = Colors.Black;	

		    var openFile = new OpenFileDialog{
				Multiselect = false,
				Title  = pRes.filePuzzleFile,
				Filter = "All files (*.*)|*.*|txt files (*.txt)|*.txt"
			};

            if( (bool)openFile.ShowDialog() ){
                string fName = openFile.FileName;
				List<v7_UPuzzle_Base> puzzleList = fPuzzleFile_IO.GNPX_PuzzleFile_Read( fName );
				txtFileName.Text = fName;

				if( puzzleList!=null && puzzleList.Count>0 ){
					pGPDM.Set_v7_GNPX_Puzzle_List(puzzleList);

					if( puzzleList!=null && puzzleList.Count>0 ){
						// Notify the Main that the puzzle file has been input and request preparation for analysis.
						string fName2 = System.IO.Path.GetFileName(fName);		
						Gidoo_EventHandler se2 = new Gidoo_EventHandler( eName:"PuzzleFile_Loaded", Message:fName2 );  //Report
						Send_Command_to_GNPXwin( this, se2 );

						btn_Initialize_PuzzleFile.Visibility = Visibility.Visible;
						G6.GNPX_PuzzleFileName = fName;
					}
				}
			}
        }


      #region Initialize_PuzzleFile_ 
		// ------------------------------------------------------------------------------------
        private void btn_Initialize_PuzzleFile_Click(object sender, RoutedEventArgs e ){
			if( pGPDM.v7_GNPX_Puzzle_Count==0 )  return; 

			if( GradientStop2.Color==Colors.DarkBlue ){
				GradientStop2.Color = Colors.DarkRed;
				timer_Countdown_Message.Start();
				__CountDownCC = 6;
				return;
			}
			if( GradientStop2.Color==Colors.DarkRed ){
				lbl_ShortMessage.Content = "";
				lbl_ShortMessage.Visibility = Visibility.Hidden;
				timer_Countdown_Message.Stop();
				__CountDownCC = 0;

				pGPDM.v7_GNPX_Puzzle_List.Clear();
				txtFileName.Text = "";
				btn_Initialize_PuzzleFile.Visibility = Visibility.Hidden;
				Gidoo_EventHandler se = new Gidoo_EventHandler( eName:"PuzzleFile_Loaded" );  //Report
				Send_Command_to_GNPXwin( this, se );
			}
			GradientStop2.Color = Colors.DarkBlue;

        }
		
		private int __CountDownCC;
	    private void Countdown_To_Initialization_Tick( object sender, EventArgs e ){	// Countdown to initialization
			if( --__CountDownCC > 0 ){
				lbl_ShortMessage.Visibility = Visibility.Visible;
				if( __CountDownCC > 1 )lbl_ShortMessage.Content = $"Realy? ... {__CountDownCC}";
				else lbl_ShortMessage.Content = $"Cancelled";
				return;
			}

			else{
				lbl_ShortMessage.Content = "";
				lbl_ShortMessage.Visibility = Visibility.Hidden;
				timer_Countdown_Message.Stop();
				GradientStop2.Color = Colors.DarkBlue;
			}
        }
		// ------------------------------------------------------------------------------------
	  #endregion Initialize_PuzzleFile




		private void btn_SavePuzzle_Click(object sender, RoutedEventArgs e ){
            if( pGPDM.v7_GNPX_Puzzle_Count==0 )  return;
		    var saveFile = new SaveFileDialog{ Title=pRes.filePuzzleFile, Filter = "All files (*.*)|*.*|txt files (*.txt)|*.txt" };

            if( (bool)saveFile.ShowDialog() ){
                string fName = saveFile.FileName;
				bool append  = (bool)chb_Additional_Save.IsChecked;
				fPuzzleFile_IO.GNPX_PuzzleFile_Write( fName, append );
			}		
		}

		private void btn_SaveToFavorites_Click(object sender, RoutedEventArgs e ){
            pGNPX_App.fPuzzleFile_IO.btn_FavoriteFileOutput(true);//,SolSet:SolSet,SolSet2:true);
		}



	  #region Develop Exocet
		private void grd_Develop_Exocet_MouseDown(object sender, MouseButtonEventArgs e ){
			if( grd_Develop_Exocet.Opacity>0.5 || G6.zPowerUserCC<10 ){ grd_Develop_Exocet.Opacity=0.0; return; }
			grd_Develop_Exocet.Opacity = 1.0 - grd_Develop_Exocet.Opacity;
		}

		private void btn_Formatting_Click(object sender, RoutedEventArgs e ){
			if( pGPDM.v7_GNPX_Puzzle_List==null || pGPDM.v7_GNPX_Puzzle_Count==0 )  return;
			string addEx = txb_additional.Text;
			bool   blank9  = (bool)chb_File81Plus2.IsChecked;
			bool   AddDate = (bool)chb_Add_Date.IsChecked;
			string fName = G6.GNPX_PuzzleFileName;
			string fName_Extension = ioPath.GetExtension(fName);
			string fn = fName.Replace(fName_Extension,"");

			if( addEx=="" ){
				var eList = System.IO.Path.GetFileName(fName).Split(new Char[]{ '.', '_'},StringSplitOptions.RemoveEmptyEntries).ToList();
				int n = eList.FindAll(p=>p.IsNumeric()).Min(n=>n.ToInt());
				addEx = $"{n:00}_";
			}

			do{
				fn += "A";
				fName = fn+fName_Extension;
				if( !File.Exists(fName) ) break;
			}while(true);

			char[] _sep=new Char[]{ ' ', ',', '\t' };
			using (var fpW=new StreamWriter( fName,append:false, Encoding.UTF8 )){
				int sq = 0;
				foreach( var P in pGPDM.v7_GNPX_Puzzle_List ){
					string line = P.stPuzzle_forFile;
					var eList = P.stPuzzleName.Split(_sep,StringSplitOptions.RemoveEmptyEntries).ToList();
					line += $" {P.difficulty}";

					if( eList.Last().Contains("ID") ) line += $" \"{eList.Last()}\"";
					else line += $" \"ID:{addEx}{++sq} {eList.Last()}\"";

					if( AddDate ) line += $" \"{DateTime.Now:yyyy/MM/dd HH:mm}\"";
					fpW.WriteLine( line );
				}
			}
		}

		private void btn_Create_HTML_Click(object sender, RoutedEventArgs e ){ }
	  #endregion Develop Exocet
	}
}