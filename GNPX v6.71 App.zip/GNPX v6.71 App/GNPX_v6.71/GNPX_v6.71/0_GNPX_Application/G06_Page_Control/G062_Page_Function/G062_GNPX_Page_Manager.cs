﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Controls;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows.Media;


using GIDOO_space;
using System.Globalization;
using System.Text.RegularExpressions;


namespace GNPX_space{
    using pGPDM = GNPX_Puzzle_Database_Manager;

    public partial class GNPX_App_Man{

    	static public G6_Base    G6 = new G6_Base();
		static public G7_Base    G7 = new G7_Base();

        public GNPX_Puzzle_Analysis_Support    Pzl_Analysis_Supp;                      //Puzzle Generator  

		public GNPX_Engin       GNPX_Eng;                      //Analysis Engine

		public PuzzleFile_IO	fPuzzleFile_IO;



 		public List<UAlgMethod> SolverList_SysDef;		// Initial definition of GNPX system
		public List<UAlgMethod> SolverList_GNPX;		// The control has been changed simply (v5.93)

        public DateTime         MultiSolve_StartTime = DateTime.Now;
		
		
		
		
		public GNPX_win         pGNP00win;
		public Page				objFunc_File;	
		public Page				objFunc_Solve;	
		public Page				objFunc_Create;	
		public Page				objFunc_Option;		
		public Page				objFunc_Transform;	
		public Page				objFunc_HomePage;
		public Page				objFunc_ExtensionsPage;
		private List<Page>		GNPX_Pages=null;



    //  public string           SDK_Methods_XMLFileName = "SDK_Methods_XMLV7.xml"; // (Ver.6 was planned, but this was introduced first.)
        public string           _Develop_SuDoKuName = "_Develop_SuDoKu.txt";
        public List<UCell>      _Develop_Puzzle = null;

        public GNPX_Graphics    gnpxGrp;             //board bitmap

		public List<string>     LanguageList;


        public GNPX_App_Man( GNPX_win pGNP00win ){

		    App_Environment.pixelsPerDip = VisualTreeHelper.GetDpi(pGNP00win).PixelsPerDip;

			{
				List<string> DirLst=Directory.EnumerateDirectories(".").ToList();
				LanguageList=new List<string>();
				LanguageList.Add("en");
				foreach( var P in DirLst ){
					var Q = P.Replace(".","").Replace("\\","");
					if( Q == "en" )  continue;
					if( Q.Length == 2 || (Q[2]=='-' && Q.Length==5) )  LanguageList.Add(Q);
				}

				LanguageList = LanguageList.FindAll(P=>(P.Length==2 ||(P[2]=='-' && P.Length==5)));
				LanguageList.Sort();
			}


            //=======================================================
			// Here,
			//   create functions(class object),
			//   link the object.
            //=======================================================
            this.pGNP00win = pGNP00win;

			// *==*==*==*==*==*==*==*==*==*==*==*==*
            GNPX_Eng  = new GNPX_Engin( this );     // Definition of the sole Solver-Engine in GNPX
			pGPDM.pGNPX_Eng = GNPX_Eng;				// 
			// *==*==*==*==*==*==*==*==*==*==*==*==*

            Pzl_Analysis_Supp  = new GNPX_Puzzle_Analysis_Support(this,0);
			gnpxGrp = new GNPX_Graphics(this);		
			UC_PB_GBoard.pGNPX_App = this;			//@@@@@@@@@@@@@@@@@@@


			fPuzzleFile_IO = new( this );

            //-------------------------------------------------------
            SolverList_GNPX   = new ();

			objFunc_File      = new Func_File( this );	//To display at the start.
			objFunc_Solve     = new Func_Solve( this );
			objFunc_Create    = new Func_Create( this );
			objFunc_Option    = new Func_Option( this );	
			objFunc_Transform = new Func_Transform( this );
			objFunc_HomePage  = new Func_HomePage( this );
		}




		public int Get_Difficulty_SolverList_App(){
			if( SolverList_GNPX==null || SolverList_GNPX.Count== 0 ) return 0;
			int diff = SolverList_GNPX.Max( mth =>mth.difficultyLevel );
			return diff;
		}
    }
}
