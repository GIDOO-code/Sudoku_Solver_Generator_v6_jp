﻿using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;
using System.Windows.Threading;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using ioPath = System.IO.Path;
	using pRes = Properties.Resources;
	using sysWin = System.Windows;
	
	
	public struct POINT{ public int x; public int y; }


    public partial class Func_SolveMulti: Page{
		[DllImport("USER32.dll", CallingConvention = CallingConvention.StdCall)]		// ... Required for SetCursorPos
		static public extern void SetCursorPos(int X,int Y);

		[DllImport("USER32.dll", CallingConvention = CallingConvention.StdCall)]		// ... Required for GetCursorPos
		static public extern void GetCursorPos(out POINT lpPoint);
				
					
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 
		static public event GNPX_EventHandler Send_Command_to_SolveMulti;


		static public bool			eventFire_Stop=false;

		public GNPX_App_Man 		pGNPX_App;
		public GNPX_win				pGNP00win => pGNPX_App.pGNP00win;



		public GNPX_Puzzle_Analysis_Support        Pzl_Analysis_Supp => pGNPX_App.Pzl_Analysis_Supp;
		private G6_Base				G6 => GNPX_App_Man.G6;
		private G7_Base				G7 => GNPX_App_Man.G7;
        private GNPX_Engin			pGNPX_Eng => pGNPX_App.GNPX_Eng;   

		public  UPuzzle				ePZL{ get=>pGNPX_Eng.ePZL; set=>pGNPX_Eng.ePZL=value; }  // Puzzle to analyze

        private List<UCell>		    pBOARD{ get=>ePZL.BOARD; /* set=>ePZL.BOARD=value;*/ } 
		private int                 stageNo   => (ePZL is null)? 0: ePZL.stageNo;

		private string			    HTMLName = null;

		private Func_Option			objFunc_Option => (Func_Option)pGNPX_App.objFunc_Option;
		
		private CancellationTokenSource  cts;		
		private MethodDisplayWin	MthdWin;
		private Stopwatch			AnalyzerLap = new();

		private DispatcherTimer     displayTimer;	
		private object				obj = new();
		private bool				displayTimer_Stop;
		private int                 OnWorkCC = 0;
	//	public DateTime				MultiSolve_StartTime = DateTime.Now;    @@@@  TBD

        private DispatcherTimer		timerShortMessage;

		#region <<< Constracter, Load, Unload >>>
        public Func_SolveMulti( GNPX_App_Man GNPX_App){
			pGNPX_App = GNPX_App;	
		//	pGNPX_Eng = pGNPX_App.GNPX_Eng;

			InitializeComponent();

			eventFire_Stop = true;
			lbl_ShortMessage.Visibility = Visibility.Hidden;
			Lbl_onAnalyzingM.Content = "";



			cts = new CancellationTokenSource();　//for Cancellation

			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );
			pGNP00win.Send_Command_to_Func_SolveMulti += new GNPX_EventHandler( GNPX_Event_Handling_man );
		
			displayTimer = new DispatcherTimer(DispatcherPriority.Normal);
			displayTimer.Interval = TimeSpan.FromMilliseconds(50);
			displayTimer.Tick += new EventHandler(Show_RunningMethodName_Tick);

			timerShortMessage = new DispatcherTimer(DispatcherPriority.Normal);
			timerShortMessage.Interval = TimeSpan.FromMilliseconds(50);
			timerShortMessage.Tick += new EventHandler(timerShortMessage_Tick);

	//		thilness_rct_OnWorkMlt = rct_OnWorkMlt.Margin;
	//		MovementRange_rct_OnWorkMlt = (int)(grd_MultiSolve_Info.Width - (thilness_rct_OnWorkMlt.Right - thilness_rct_OnWorkMlt.Left)); 
        }

		private void Page_Loaded(object sender, RoutedEventArgs e ){
			G6.PG6Mode = GetType().Name;
			G6.sNoAssist = true;	// Display candidate digits

		//	elp_OnWorkMlt.Visibility      = Visibility.Hidden;
            MSlvr_MaxLevel.Value          = G6.MSlvr_MaxLevel;
			MSlvr_MaxNoAlgorithm.Value    = G6.MSlvr_MaxNoAlgorithm;
			MSlvr_MaxNoAllAlgorithm.Value = G6.MSlvr_MaxNoAllAlgorithm;
			MSlvr_MaxTime.Value			  = G6.MSlvr_MaxTime;
            MSlvr_MaxLevel.ToolTip		  = $"max:{G6.MSlvr_MaxLevel}";
			
			if( chk_analysisStop_at_level_2 != null )  chk_analysisStop_at_level_2.IsChecked = G6.chk_analysisStop_at_levels_2;

			MthdWin_Control( winDisp:G6.MethodWinShow );

			if( stageNo == 0 ){
				txbxAnalyzerResultM.Text = "";
				txbxAnalyzerResultM.Foreground = Brushes.White;
			}
			eventFire_Stop = false;
			
			Send_SetPuzzleOnBoard();		// Display the puzzle in standard conditions
											
		//	elp_OnWorkMlt.Visibility = Visibility.Hidden;

			btn_PU_HTML.Opacity = (G6.zPowerUserCC>0)? 1.0: 0.02;
			Grp_HTML.Opacity = btn_PU_HTML.Opacity;
			btn_MultiSkip.Opacity = btn_PU_HTML.Opacity;

			txb_folder_59S.Text = G6.folderName_XXX;	//"img59S", "img60";


			if( chk_analysisStop_at_level_2 != null ){
				G6.chk_analysisStop_at_levels_2 = (bool)chk_analysisStop_at_level_2.IsChecked;
			}
						
			prgbar_OnWork.IsIndeterminate = true;
			prgbar_OnWork.Visibility = Visibility.Hidden;
		}


		private void Page_Unloaded(object sender, RoutedEventArgs e ){
			MthdWin.Visibility = Visibility.Collapsed;//	Close();
			G6.folderName_XXX = txb_folder_59S.Text;
			G6.sNoAssist = false;	//false;
		}
		#endregion <<< Constracter, Load, Unload >>>


		public void GNPX_Event_Handling_man( object sender, Gidoo_EventHandler e ){ 
			switch( e.eName ){
				case "ClearAll":
				case "ToInitialState":
					Dispatcher.Invoke( () =>  Puzzle_ResetAnalyzer() );
					break;

				case "ShortMessage": shortMessage( e.gsm.Message, e.gsm.Pt, e.gsm.color, e.gsm.msec ); break;
				case "SystemError":  shortMessage( e.Message, new sysWin.Point(400,180), Colors.Orange, 3000 );	break;
				default:			 shortMessage( "System error. Undefined event.", new sysWin.Point(100,200), Colors.DarkRed, 10000 ); break;
											// ( In other thread control, "Dispatcher.Invoke" is need! )
			}
		}



		#region <<< ShortMessage >>>
	    private void timerShortMessage_Tick( object sender, EventArgs e ){
            lbl_ShortMessage.Visibility = Visibility.Hidden;
            timerShortMessage.Stop();
        }
		public void shortMessage( string st, sysWin.Point pt, Color cr, int tm ){
			if( tm==9999 ) timerShortMessage.Interval = TimeSpan.FromSeconds(5);
			else           timerShortMessage.Interval = TimeSpan.FromMilliseconds(tm);   

			this.Dispatcher.Invoke( ()=>{
				lbl_ShortMessage.Content = st;
				lbl_ShortMessage.Foreground = new SolidColorBrush(Colors.White);
				lbl_ShortMessage.Background = new SolidColorBrush(cr);
				lbl_ShortMessage.Margin = new Thickness(pt.X,pt.Y,0,0);
				lbl_ShortMessage.Visibility = Visibility.Visible;
			} );
			
			timerShortMessage.Start();
        }
		#endregion <<< ShortMessage >>>


		#region Event
 		private void Send_SetPuzzleOnBoard(){
			if( ePZL == null )  return;
			Gidoo_EventHandler se = new Gidoo_EventHandler( eName:"Show_AnalysisStatus" );  //Report
			
			string st = "";
			foreach( var p in ePZL.BOARD.Where(p=>p.FixedNo>0) )  st += $"  {p.rc.TBSrcb()}_FixedNo:{p.FixedNo}";
			foreach( var p in ePZL.BOARD.Where(p=>p.CancelB>0) )  st += $"  {p.rc.TBSrcb()}_CancelB:#{p.CancelB.TBScmp()}";
				//WriteLine($"#### {se} {st}");

			Send_Command_to_GNPXwin( this, se );
		}
		#endregion


		#region Show analysis information
		private void btn_ShowMethodList_Click(object sender, RoutedEventArgs e ){
			if( MthdWin==null )  MthdWin_Control();
			MthdWin.Visibility = (MthdWin.Visibility==Visibility.Hidden)? Visibility.Visible: Visibility.Hidden;
        }

		private void MthdWin_Control( bool winDisp=true ){
            MthdWin = new MethodDisplayWin(pGNP00win);     
			MthdWin.Left  = pGNP00win.Left+pGNP00win.Width;
			MthdWin.Top   = pGNP00win.Top;
			MthdWin.Height = pGNP00win.Height;
			MthdWin.Visibility = (winDisp) ?Visibility.Visible: Visibility.Hidden;
           // if( winDisp ) MthdWin.Show();
		}
		private void btn_TandE_SolutionShow_Click(object sender, RoutedEventArgs e ){
			if( G7.TandE_solList.Count <= 1 )  return;

			List<string> absTandE_solList = new();

			G7.TandE_solList.ForEach( P => absTandE_solList.Add( P.AddSpace9_81(9) ) );
			string stPuzzle = string.Join("",ePZL.BOARD.ConvertAll(p=>Max(p.No,0))).Replace("0","."). AddSpace9_81(9);
			string st = $" There are {absTandE_solList.Count()} solutions.\n\n";
			if(G6.TE_AbsoluteTimeLimitB)  st = $" There are {absTandE_solList.Count()} over solutions. The search was stopped to protect the system.\n\n";
			
			int n = 0;
			st += $"Puzzle : {stPuzzle}\n" + absTandE_solList.Aggregate("",(a,P) => a + $"{++n,6} : {P}\n" );
			pGNPX_Eng.extResult = st;

			Send_SetPuzzleOnBoard();
		}


		private void Show_RunningMethodName_Tick( object sender, EventArgs e ){
			lock(obj){
				var MTHD = G7.AnalyzingMethod;
				if( MTHD != null ){
					string st = /*MTHD.MethodName;*/ $"Lv.{MTHD.difficultyLevel} {MTHD.MethodName}";
					if( G6.Additional_Message!=null && G6.Additional_Message!="" )  st += G6.Additional_Message;
					Lbl_onAnalyzingM.Content = st;
				}

			}

			Lbl_onAnalyzingTSM.Content = AnalyzerLap.Elapsed.TimespanToString();
			prgbar_OnWork.Visibility = Visibility.Visible;

			this.Dispatcher.Invoke( () => txb_StepMCC.Text = stageNo.ToString() );

			if( GNPX_Engin.SolverBusy is false ){
				string st = (G6.LastSuccessfullMethod!="")? G6.LastSuccessfullMethod+" ... Last successfull": "";
				Lbl_onAnalyzingM.Content = st;
			}
			if( displayTimer_Stop ){
				displayTimer.Stop();  
				prgbar_OnWork.Visibility = Visibility.Hidden;
			}
		}
		#endregion Show analysis information


		private int shift_MousePos = 50;

		
		private bool AutoSkip_solveup = false;

		// :::: Continue searching until the specified algorithm :::::
		private void btn_MultiSkip_Click( object sender, RoutedEventArgs e ){
			AutoSkip_solveup = true;
			_Func_MultiSolver();
		}

		// :::: Normal multiple solution search :::::
		private void btn_MultiSolve_Click( object sender, RoutedEventArgs e ){
			AutoSkip_solveup = false;
			_Func_MultiSolver();
		}


	//=========================================================================================================
		private async void _Func_MultiSolver(){
			G7.Sel_mark_Solved = false;

			prgbar_OnWork.Visibility = Visibility.Visible;
			txbxAnalyzerResultM.Foreground = Brushes.White;
			btn_MultiSolve.Visibility = Visibility.Hidden;
			G6.EnginState  = 0;
			
			if( preprocceing() is false )  goto LProcessEnd;

			int MSlvr_MaxLevel			= G6.MSlvr_MaxLevel;
			int MSlvr_MaxNoAlgorithm	= G6.MSlvr_MaxNoAlgorithm;
			int MSlvr_MaxNoAllAlgorithm = G6.MSlvr_MaxNoAllAlgorithm;
			int MSlvr_MaxTime			= G6.MSlvr_MaxTime;

			{ // <<< Solving >>>
				AnalyzerLap.Restart();
				bool solveup = true;

				displayTimer_Stop = false;
				displayTimer.Start();
				GNPX_Engin.SolverBusy = true;
				bool methodSet = true;
				do{
					try{
						string retInfo = pGNPX_Eng.Set_NextStage();
						if( retInfo == "solved" ){ Send_SetPuzzleOnBoard(); goto LSolved; }

						pGNPX_Eng.Adjust_Candidates();  // Confirm element
						if( ePZL.BOARD.All(p => p.No!=0) )  goto LSolved;   // --- All digits are confirmed. ---

						ePZL.SolCode = 0;
						// <<< solver_task start >>>
						await Task.Run(( ) => Pzl_Analysis_Supp.task_Analyzer_SingleStage( cts.Token, methodSet:methodSet )  );

						if( G6.command_Analysis_Stop )  break;
					}
					catch(Exception ex) { WriteLine($"{ex.Message}\n{ex.StackTrace}"); }
					methodSet = false;
					solveup = false;

					if( ePZL!=null && ePZL.Child_PZLs!=null && ePZL.Child_PZLs.Count>0 ){
						int difLevel = ePZL.Child_PZLs.Max( P => P.difficultyLevel );
						Lbl_onAnalyzingM.Foreground = (G6.zPowerUser && difLevel>6)? Brushes.Gold: Brushes.LightBlue;

						if( AutoSkip_solveup && !G7.Sel_mark_Solved )  solveup = true;
					}
				}while(solveup);

			  LSolved:
				GNPX_Engin.SolverBusy = false;
				AnalyzerLap.Stop();
				
				Lbl_onAnalyzingTSM.Content = AnalyzerLap.Elapsed.TimespanToString();

				if( G6.stResult == "Unsolved" ){
					//shortMessage( "Unsolved", new sysWin.Point(150,50), Colors.Crimson, tm:1500);
					txbxAnalyzerResultM.Foreground = Brushes.LightPink;
				}
				else{
					txbxAnalyzerResultM.Foreground = Brushes.White;
					//Send_SetPuzzleOnBoard();
				}
			}

		#region <<< PostProcessing >>>
			txbxAnalyzerResultM.Text = ePZL.Sol_Result;
			txb_StepMCC.Text = ePZL.stageNo.ToString();

			G6.MSlvr_MaxLevel = MSlvr_MaxLevel;
			G6.MSlvr_MaxNoAlgorithm = MSlvr_MaxNoAlgorithm;
			G6.MSlvr_MaxNoAllAlgorithm = MSlvr_MaxNoAllAlgorithm;
			G6.MSlvr_MaxTime = MSlvr_MaxTime;
			G6.stopped_StatusMessage = "";

			Set_USolLst2( selIndx:0 );
		#endregion PostProcessing



		  LProcessEnd:
			displayTimer_Stop = true;
			displayTimer.Start();
			Send_SetPuzzleOnBoard();
			btn_MultiUndo.IsEnabled = true;
			btn_MultiSolve.Visibility = Visibility.Visible;

			AutoSkip_solveup = false;
			return;

				// -----------------------------------------------------------------------------
					bool preprocceing(){
						if( stageNo == 0 ){
							G6.Additional_Message = "verify Puzzle with TE";
							if( !IsValidPuzzle_pageUI() )  return false;	//goto LProcessEnd;
							ePZL.BOARD.ForEach( p=>p.Reset_All() );
						}

						ePZL.BOARD.ForEach( P => P.ECrLst = null );		// ... Clear color information from previous analysis results.

						if( G6.OnWork!="" || GNPX_Engin.SolverBusy)  return false;	//goto LProcessEnd;

						if( pGNPX_Eng.IsSolved() )  return false;	//goto LProcessEnd;;

						//-----------------------------------------------------------------------------
						Lbl_onAnalyzingM.Content = "";
						Lbl_onAnalyzingM.Foreground = Brushes.LightGreen;
						Lbl_onAnalyzingM.Visibility = Visibility.Visible;
						txb_StepMCC.Text = stageNo.ToString();

						OnWorkCC = 0;
						G7.MltAnsSearch = true;
						G7.Set_Solution_Info = true;

						// Measure the search time for each stage of multiple solution search.
						// Incorporating an "upper time check" function into algorithms that require a lot of time

						G6.stopped_StatusMessage = "";
						G6.command_Analysis_Stop = false;
						cts = new CancellationTokenSource();
			
						return true;
					}

					bool IsValidPuzzle_pageUI(){
						var (singlePuzzleB,_) = pGNPX_Eng.IsValidPuzzle();
						if( singlePuzzleB is false ){ 
							string stError = $"Invalid Puzzle\n There are {G7.TandE_solList.Count} pattern to this Puzzle.";
							shortMessage( stError, new sysWin.Point(40,50), Colors.Crimson, tm:3000);
							btn_TandE_SolutionShow_Click(this, new RoutedEventArgs() );
						}
						return singlePuzzleB;
					}	

		}
	//====================================================================================================


		private void btn_MultiSolve_PreviewMouseUp(object sender, MouseButtonEventArgs e ){
			TransitionToInitialState();
		}

		private void btn_MultiStop_Click(object sender, RoutedEventArgs e ){
			// <<< Suspend >>>
			btn_MultiSolve.Visibility = Visibility.Visible;

			btn_MultiSolve.Content = pRes.btn_Solve;
			Lbl_onAnalyzingM.Foreground = Brushes.Red;
			Lbl_onAnalyzingM.Content = "Canceled";
			GNPX_Engin.SolverBusy = false;
			cts.Cancel();		
			displayTimer_Stop = true;
		}

		private void TransitionToInitialState(){
		}


		private void btn_MultiUndo_Click(object sender, RoutedEventArgs e ){
			txbxAnalyzerResultM.Foreground = Brushes.White;
			Lbl_onAnalyzingM.Content = "";

			if( stageNo == 0 )  return;

		    ePZL = (ePZL.stageNo==1)? pGNPX_Eng.rootPZL: ePZL.pre_PZL;
				pGNPX_Eng.Add_Trial_No100();

				txb_StepMCC.Text = ePZL.stageNo.ToString();	
				txbxAnalyzerResultM.Text = ePZL.Sol_Result;
				Set_USolLst2( selIndx:ePZL.selectedIX );

				G6.taskCompInfo = "Complated";
				btn_MultiSolve.Content   = pRes.btn_MultiSolve;
				GNPX_Engin.SolverBusy = false;     
			Send_SetPuzzleOnBoard();


		}
		
		
		private void Set_USolLst2( int selIndx ){
			int mpCC = 0;
			List<UPuzzleS> USolLst2 = ePZL.Child_PZLs.ConvertAll(G => new UPuzzleS(G, ++mpCC));
			if( USolLst2!=null && USolLst2.Count>0) {
				LstBx_MltSolutions.ItemsSource = USolLst2;
				LstBx_MltSolutions.ScrollIntoView(USolLst2.First());
				LstBx_MltSolutions.SelectedIndex = selIndx;
				
				GNPX_Engin.SolverBusy = false;

				List<int> USolLst2Error = USolLst2.FindAll( q => q.Sol_Result.Contains("error") ).ConvertAll(q=>q.__ID);
				if( USolLst2Error.Count == 0 )  txbAlgorithmError.Visibility = Visibility.Collapsed;
				else{
					txbAlgorithmError.Text = $"GNPX Algorithm error\n {string.Join(" ,", USolLst2Error)}";
					txbAlgorithmError.Visibility = Visibility.Visible;
				}
			}
			else{
				LstBx_MltSolutions.ItemsSource = null;
			}
		}	

		private void LstBx_MltSolutions_SelectionChanged(object sender, SelectionChangedEventArgs e ){
            if( GNPX_Engin.SolverBusy )  return;
            
            try{
                var Q = (UPuzzleS)LstBx_MltSolutions.SelectedItem;
                if( Q is null )  return;
                txbxAnalyzerResultM.Text= $"[{Q.__ID}] {Q.Sol_ResultLong}"; 

                int selX = LstBx_MltSolutions.SelectedIndex;
                if( selX>=0 )  pGNPX_Eng.Set_selectedChild( selX );

				Send_SetPuzzleOnBoard();	// <<< Display selected analysis results on the board >>>

				// ..... solver algorith error .....
				SolidColorBrush br = new(Color.FromArgb(0xFF, 0x0A, 0x0a,0x24) );
				if( ePZL.Sol_ResultLong.Contains(" ... error ...") )  br = Brushes.Tomato;// new(Color.FromArgb(0xFF, 0x3A, 0x0a,0x24) );

				txbxAnalyzerResultM.Background = br;

				btn_PU_HTML.Opacity = (G6.zPowerUserCC>=10)? 1.0: 0.02;
				btn_PU_HTML.Opacity = btn_PU_HTML.Opacity;
				Grp_HTML.Opacity = btn_PU_HTML.Opacity;
            }
            catch(Exception e2){ WriteLine($"{e2.Message}\n{e2.StackTrace}"); }
            finally{ }

		}


		private async void btn_AnalyzerResetAll_Click(object sender, RoutedEventArgs e ){

			while(ePZL.stageNo>0){
				ePZL = ePZL.pre_PZL;
				txb_StepMCC.Text = ePZL.stageNo.ToString();	
				await Task.Delay(50);
				Send_SetPuzzleOnBoard();
			}
             
            pGNPX_Eng.MethodLst_Run__Reset_UsedCC();
			ePZL.BOARD.ForEach( p=> p.No=Max(p.No,0));

            Puzzle_ResetAnalyzer(true);
            btn_MultiUndo.IsEnabled = false;

            pGNPX_Eng.ReturnToInitial();

			txbxAnalyzerResultM.Foreground = Brushes.White;
			SolidColorBrush br = new(Color.FromArgb(0xFF, 0x0A, 0x0a,0x24) );
			txbxAnalyzerResultM.Background = br;
			Lbl_onAnalyzingM.Content = "";
					
			G6.EnginState  = 0;
			return;
		}

			// ------------------------------------------
		private void Puzzle_ResetAnalyzer( bool AllF=true ){
			if( G6.OnWork != "" ) return;
                       
			pGNPX_Eng.Add_Trial_No100();
			pGNPX_Eng.Clear_0();

			txbxAnalyzerResultM.Text   = "";
			txbxAnalyzerResultM.Foreground = Brushes.White;
			SolidColorBrush br = new(Color.FromArgb(0xFF, 0x0A, 0x0a,0x24) );
			txbxAnalyzerResultM.Background = br;

			LstBx_MltSolutions.ItemsSource   = null;

			btn_MultiSolve.IsEnabled   = true;
			txb_StepMCC.Text = "0";

			Lbl_onAnalyzingM.Content = "";
			txbAlgorithmError.Text="";

			pGNPX_Eng.AnalyzerCounterReset();
			pGNPX_Eng.ePZL.pMethod = null;

			GeneralLogicGen_base.GLtrialCC=0;

			Send_SetPuzzleOnBoard();
		}

	  #region Conditions for multiple solution search
		private void Save_XMLFile_AnalysisConditions(){
			if( pGNPX_App != null )  pGNPX_App.fPuzzleFile_IO.WriteXMLFile_AnalysisConditions_MethodList();
		}

		private void MSlvr_MaxLevel_ValueChanged(object sender, GIDOOEventArgs args) {
            if( eventFire_Stop )  return;
			G6.MSlvr_MaxLevel = MSlvr_MaxLevel.Value;
			Save_XMLFile_AnalysisConditions();
		}

		private void MSlvr_MaxNoAlgorithm_ValueChanged(object sender, GIDOOEventArgs args) {
			if( eventFire_Stop )  return;
            G6.MSlvr_MaxNoAlgorithm = MSlvr_MaxNoAlgorithm.Value;
			Save_XMLFile_AnalysisConditions();
		}

		private void MSlvr_MaxNoAllAlgorithm_ValueChanged(object sender, GIDOOEventArgs args) {
            if( eventFire_Stop )  return;
            G6.MSlvr_MaxNoAllAlgorithm = MSlvr_MaxNoAllAlgorithm.Value;
			Save_XMLFile_AnalysisConditions();
		}

		private void MSlvr_MaxTime_ValueChanged(object sender, GIDOOEventArgs args) {
            if( eventFire_Stop )  return;
            G6.MSlvr_MaxTime = MSlvr_MaxTime.Value;
			Save_XMLFile_AnalysisConditions();
		}

		private void chk_analysisStop_at_level_2_Checked(object sender, RoutedEventArgs e ){
			G6.chk_analysisStop_at_levels_2 = (bool)chk_analysisStop_at_level_2.IsChecked;
			Save_XMLFile_AnalysisConditions();
		}

		#endregion Conditions for multiple solution search

	  #region Create Sample HTML for PU

		private void btn_PU_HTML_Click(object sender, RoutedEventArgs e ){
			btn_PU_HTML.Opacity = (btn_PU_HTML.Opacity<0.3)? 1.0: 0.02;
			Grp_HTML.Opacity = btn_PU_HTML.Opacity;
        }

		private void btn_putHTML_Click(object sender, RoutedEventArgs e ){
			G6.folderName_XXX = txb_folder_59S.Text;
			var Q = (UPuzzleS)LstBx_MltSolutions.SelectedItem;
			if( Q is null )  return;

		  // Pzl_Analysis_Supp.Save_HTML_of_Puzzle( pGNPX_Eng, G6.folderName_XXX, ePZL );
			pGNPX_App.fPuzzleFile_IO.Save_HTML_of_Puzzle( pGNPX_Eng, G6.folderName_XXX, ePZL );
		}

      #endregion Create Sample HTML 

		private void chbx_ShowCandidate_Checked(object sender, RoutedEventArgs e ){
			if( chbx_ShowCandidate == null ) return;

			G6.sNoAssist = (bool)chbx_ShowCandidate.IsChecked;
            G6.digitColoring = G6.sNoAssist && (bool)chbx_ShowCandidate.IsChecked; //
            Send_SetPuzzleOnBoard();
		}   
    }
}
	