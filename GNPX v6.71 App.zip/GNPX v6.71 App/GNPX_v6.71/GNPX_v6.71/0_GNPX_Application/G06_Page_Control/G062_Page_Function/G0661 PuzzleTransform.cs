﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Controls;

using GIDOO_space;

using STD_SDK;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using pGPDM = GNPX_Puzzle_Database_Manager;
    public partial class Func_Transform{
		static private readonly int[,] permIndex = { {0,1,2}, {0,2,1}, {1,0,2}, {1,2,0}, {2,0,1}, {2,1,0} };
		static private readonly int[]  roteIndex = [5,3,4,1,2,0];


		private Trans_para Set_Transform_Parameter( Button btn, Trans_para TPx ){

			WriteLine( $"btn.Name:{btn.Name}");

			int inIdx=0;

			Trans_para TP0 = (Trans_para)TPx.Copy();
			switch(btn.Name){
				case "btn_TP_Transpose2":
				case "btn_TP_Transpose": 
					TPx.transpos = 1 - TPx.transpos; 
					TPx.RowBndIdx = TP0.ColBndIdx;
					TPx.ColBndIdx = TP0.RowBndIdx;
					for( int k=0; k<3; k++ ){ 
						TPx.RowIdx[k] = TP0.ColIdx[k];
						TPx.ColIdx[k] = TP0.RowIdx[k];
					}
					break;



				
				case "btn_TP_RowBndIdx": 
					int rx = TPx.RowBndIdx = (++TPx.RowBndIdx) % 6;
					//int[]tmpR = (int[])TPx.RowIdx.Clone();
					for( int k=0; k<3; k++ )  TPx.RowIdx[k] = TP0.RowIdx[ permIndex[rx,k] ];
					break;
				
				case "btn_TP_RowIdx_0": TPx.RowIdx[0] = (++TP0.RowIdx[0]) %6; break;
				case "btn_TP_RowIdx_1": TPx.RowIdx[1] = (++TP0.RowIdx[1]) %6; break;
				case "btn_TP_RowIdx_2": TPx.RowIdx[2] = (++TP0.RowIdx[2]) %6; break;






				case "btn_TP_ColBndIdx": 
					int cx = TPx.ColBndIdx = (++TPx.ColBndIdx) % 6;
					//int[] tmpC = (int[])TP0.ColIdx.Clone();
					for( int k=0; k<3; k++ )  TPx.ColIdx[k] = TP0.ColIdx[ permIndex[cx,k] ];
					break;


				case "btn_TP_ColIdx_0": TPx.ColIdx[0] = (++TP0.ColIdx[0]) %6; break;
				case "btn_TP_ColIdx_1": TPx.ColIdx[1] = (++TP0.ColIdx[1]) %6; break;
				case "btn_TP_ColIdx_2": TPx.ColIdx[2] = (++TP0.ColIdx[2]) %6; break;





				case "btn_Sym_Rotate":
					TPx.transpos = 1 - TPx.transpos;
					TPx.ColBndIdx = roteIndex[TP0.ColBndIdx];
					TPx.ColIdx[0] = roteIndex[TP0.ColIdx[2]];
					TPx.ColIdx[1] = roteIndex[TP0.ColIdx[1]];
					TPx.ColIdx[2] = roteIndex[TP0.ColIdx[0]];
					break;

				case "btn_Sym_FlipVertically":
					TPx.RowBndIdx = roteIndex[TP0.RowBndIdx];
					TPx.RowIdx[0] = roteIndex[TP0.RowIdx[2]];
					TPx.RowIdx[1] = roteIndex[TP0.RowIdx[1]];
					TPx.RowIdx[2] = roteIndex[TP0.RowIdx[0]];
					break;

				case "btn_Sym_FlipHorizontally":
					TPx.ColBndIdx = roteIndex[TP0.ColBndIdx];
					TPx.ColIdx[0] = roteIndex[TP0.ColIdx[2]];
					TPx.ColIdx[1] = roteIndex[TP0.ColIdx[1]];
					TPx.ColIdx[2] = roteIndex[TP0.ColIdx[0]];
					break;


				case "btn_Sym_FlipRow123987":
					TPx.RowIdx[0] = (++TPx.RowIdx[0]) %6;
					TPx.RowIdx[2] = roteIndex[TPx.RowIdx[0]];
					break;

				case "btn_Sym_FlipRow456": TPx.RowIdx[1] = roteIndex[TPx.RowIdx[1]]; break;

				case "btn_Sym_FlipCol123987":
					TPx.ColIdx[0] = (++TPx.ColIdx[0]) %6;
					TPx.ColIdx[2] = roteIndex[TPx.ColIdx[0]];
					break;
						
				case "btn_Sym_FlipCol456": TPx.ColIdx[1] = roteIndex[TPx.ColIdx[1]]; break;

			}
#if DEBUG
			lbl_TP_Info.Content = TPx.ToString();
#endif
			Execute_Conversion( TPx );

			return TPx;
        }


		private void Execute_Conversion( Trans_para TPx ){

			//( not efficient, but is simple to implement.)
			TPx.board = board0;
			if( TPx.transpos == 1 )  STD.Transpose_Board(TPx);

			if( TPx.RowBndIdx != 0 )  STD.Swap_BandPIdx(TPx,"row");
			if( TPx.RowIdx[0] != 0 )  STD.Swap_BInnerPIdx(TPx,"row",0);
			if( TPx.RowIdx[1] != 0 )  STD.Swap_BInnerPIdx(TPx,"row",1);
			if( TPx.RowIdx[2] != 0 )  STD.Swap_BInnerPIdx(TPx,"row",2);
			
			if( TPx.ColBndIdx != 0)  STD.Swap_BandPIdx(TPx,"col");
			if( TPx.ColIdx[0] != 0 )  STD.Swap_BInnerPIdx( TPx,"col",0);
			if( TPx.ColIdx[1] != 0 )  STD.Swap_BInnerPIdx( TPx,"col",1);
			if( TPx.ColIdx[2] != 0 )  STD.Swap_BInnerPIdx( TPx,"col",2);

			for( int rc=0; rc<81; rc++ )  ePZL.BOARD[rc].No = TPx.board[rc];

			Send_SetPuzzleOnBoard( DevelopB:true );

		}


		private void Display_on_GNPXScreen( Trans_para TPx ){
			lbl_Transpose.Content = TPx.transpos.ToString();
			lbl_RowBndIdx.Content = TPx.RowBndIdx.ToString();      
			lbl_RowIdx_0.Content = TPx.RowIdx[0].ToString();
			lbl_RowIdx_1.Content = TPx.RowIdx[1].ToString();
			lbl_RowIdx_2.Content = TPx.RowIdx[2].ToString();

			lbl_ColBndIdx.Content = TPx.ColBndIdx.ToString();
			lbl_ColIdx_0.Content = TPx.ColIdx[0].ToString();
			lbl_ColIdx_1.Content = TPx.ColIdx[1].ToString();
			lbl_ColIdx_2.Content = TPx.ColIdx[2].ToString(); 
		}
    }
}