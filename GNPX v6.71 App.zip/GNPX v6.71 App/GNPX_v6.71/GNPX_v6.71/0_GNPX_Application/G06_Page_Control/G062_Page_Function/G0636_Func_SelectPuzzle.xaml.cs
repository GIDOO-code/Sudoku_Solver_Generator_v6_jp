﻿using GIDOO_space;
using GIDOO_space;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml.Linq;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;

namespace GNPX_space{
	using sysWin = System.Windows;
	using ioPath = System.IO.Path;
	using pGPDM  = GNPX_Puzzle_Database_Manager;
	using pRes   = Properties.Resources;


// ** Power User only.
// Func_SelectPuzzle : Extract Puzzles using the specified GNPX-Algorithmn(@) from the Puzzle DB file.
// Usage :
//  (1) Double-click on a specific location on the screen to launch this Function.
//  (2) Specify the Puzzle DB file.
//  (3) Specify the GNPX-analysis-algorithm in two steps.
//    1) Select the basic algorithm by specifying the difficulty level (displayed in green).
//    2) Select the optional algorithm(@) (displayed in orange).
//  (4) Execute the selection.
//  (5) Output the multiple-choice Puzzles (you can also output while the selection is in progress).


    public partial class Func_SelectPuzzle: Page{  // only for Power User
		static public bool  EventSuppression=false;
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 

		//private string  stBOARD(List<UCell> BD) => string.Join("",BD.ConvertAll(p=> Abs(p.No))).Replace("0","."). AddSpace9_81();

		public GNPX_App_Man 		pGNPX_App;
		public GNPX_win				pGNP00win => pGNPX_App.pGNP00win;

		public GNPX_Puzzle_Analysis_Support        Pzl_Analysis_Supp => pGNPX_App.Pzl_Analysis_Supp;
		private G6_Base				G6 => GNPX_App_Man.G6;
		private G7_Base				G7 => GNPX_App_Man.G7;
        private GNPX_Engin			pGNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine

		public UPuzzle				ePZL{ get=>pGNPX_Eng.ePZL; set=>pGNPX_Eng.ePZL=value; } // Puzzle to analyze
		private int                 stageNo   => (ePZL is null)? 0: ePZL.stageNo;
		private GNPX_Graphics		gnpxGrp => pGNPX_App.gnpxGrp;

	    private PuzzleFile_IO		fPuzzleFile_IO => pGNPX_App.fPuzzleFile_IO;
		//private List<v7_UPuzzle_Base>		v7_GNPX_Puzzle_List => pGPDM.v7_GNPX_Puzzle_List;

	    private List<UAlgMethod>    pSolverList_GNPX => pGNPX_App.SolverList_GNPX;

		private DispatcherTimer     displayTimer;
        private DispatcherTimer		timerShortMessage;
		private DispatcherTimer		timerAttensionMark;
		private object				obj = new();


		
		private string  sortMode = "ID";
		private string  dirStr   => G6.DirName_GNPX_ExecutionSpace + "AutoGen_Puzzles";
		private string  fName_MethodList = "MethodList.txt"; 

        public  CancellationTokenSource cts;
		private Stopwatch			AnalyzerLap = new();
		private string				Solving_Message;

		private Color				_Color_SolveSuspend;



		// :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
		//  This function is for PU use only and is not normally used by general users.
		//  Therefore, consistency across the GNPX system as a whole is omitted.
		// :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


		public Func_SelectPuzzle( GNPX_App_Man pGNPX_App ){
			this.pGNPX_App = pGNPX_App;

            InitializeComponent();
			lbl_ShortMessage.Visibility = Visibility.Hidden;

			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  

			displayTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
            displayTimer.Interval = TimeSpan.FromMilliseconds(100);
            displayTimer.Tick += new EventHandler(displayTimer_Tick);

			timerShortMessage = new DispatcherTimer(DispatcherPriority.Normal);
			timerShortMessage.Interval = TimeSpan.FromMilliseconds(50);
			timerShortMessage.Tick += new EventHandler(timerShortMessage_Tick);

			timerAttensionMark = new DispatcherTimer(DispatcherPriority.Normal);
			timerAttensionMark.Interval = TimeSpan.FromMilliseconds(50);
			timerAttensionMark.Tick += new EventHandler(showAttensionMark_Tick);
        }

        private void displayTimer_Tick( object sender, EventArgs e){
			var lap = AnalyzerLap.Elapsed;
			var (nLap,tLap) = __remainMemo;
			lbl_analyzerLap.Content = $"Lap: {lap.TimespanToString(stUnit:true)} + {lap.RemainingTimeToString(nLap,tLap)}";
			
			txblk_AnalyzerResult.Text = Solving_Message;
			int lapMSec = ((int)AnalyzerLap.ElapsedMilliseconds) /50;	
			prgbar_OnWork.Visibility = Visibility.Visible;	
			lock(obj){
				var MTHD = G7.AnalyzingMethod;
				if( MTHD != null )  Lbl_onAnalyzing.Content = $"step: {stageNo,2}\n {MTHD.difficultyLevel,2} {MTHD.MethodName}";
			}
        }

	#region <<< ShortMessage >>>
	    private void timerShortMessage_Tick( object sender, EventArgs e ){
            lbl_ShortMessage.Visibility = Visibility.Hidden;
            timerShortMessage.Stop();
        }
		public void shortMessage( string st, sysWin.Point pt, Color cr, int tm ){
			if( tm==9999 ) timerShortMessage.Interval = TimeSpan.FromSeconds(5);
			else           timerShortMessage.Interval = TimeSpan.FromMilliseconds(tm);   

			this.Dispatcher.Invoke( ()=>{
				lbl_ShortMessage.Content = st;
				lbl_ShortMessage.Foreground = new SolidColorBrush(Colors.White);
				lbl_ShortMessage.Background = new SolidColorBrush(cr);
				lbl_ShortMessage.Margin = new Thickness(pt.X,pt.Y,0,0);
				lbl_ShortMessage.Visibility = Visibility.Visible;
			} );
			
			timerShortMessage.Start();
        }

	    private void showAttensionMark_Tick( object sender, EventArgs e ){
            elp_Attension.Visibility = Visibility.Hidden;
            timerAttensionMark.Stop();
        }
		public void showAttensionMark( int tm ){
			if( tm==9999 ) timerAttensionMark.Interval = TimeSpan.FromSeconds(5);
			else           timerAttensionMark.Interval = TimeSpan.FromMilliseconds(tm);   

			this.Dispatcher.Invoke( ()=> elp_Attension.Visibility = Visibility.Visible );	
			timerAttensionMark.Start();
        }

	#endregion <<< ShortMessage >>>


		// <<< Load / Uncload >>>		
		private void Page_Loaded(object sender, RoutedEventArgs e ){
			if( numUD_DifficultyLevel == null ) return;
			G6.PG6Mode = GetType().Name;
			numUD_DifficultyLevel.Value = G6.zPowerUser? 8: G6.Method_DifficultyLevel;  // for Power User debagging.

		//	pSolverList_GNPX.ForEach( p=> p.mark_Sel=false);	//@@@ pSolverList_GNPX
		//	btn_ResetMark_Click( sender, e );
			ChangeCondition_SolverList();

			txt_FileName.Text = G6.GNPX_PuzzleFileName;
			btn_SolvePuzzle.IsEnabled =false;
			txblk_AnalyzerMessage.Text = "";

			prgbar_OnWork.Visibility = Visibility.Hidden;	
			
			_Color_SolveSuspend = btnColor_SolveSuspend.Color;
			prg_Solved.Value = 0;

			this.Dispatcher.Invoke( ()=> btn_ResetMark_Click( sender, e ) );

			elp_Attension.Visibility = Visibility.Hidden;
			lbl_BlankTime.Content = "0.0 min"; // ... debug
			prg_BlankTime.Value   = 0.0;	 // ... debug

		}

		private void Page_Unloaded(object sender, RoutedEventArgs e ){
		}

		private string Puzzle_To_String_Line( UPuzzle aPZL ){	//String representation of the Puzzle
			var eBN = aPZL.BaseName.Split(" "); 	// First name and ID included.
			string line = aPZL.stPZL_withSP + $" {aPZL.difficultyLevel} \"{eBN[0]} {aPZL.Name}\"";
			return line;
		}

		// <<< Puzzle File Read >>>
		private void btn_OpenPuzzleFile_Click(object sender, RoutedEventArgs e ){
            var OpenFDlog = new OpenFileDialog(){
				Multiselect = false,
				Title  = pRes.filePuzzleFile,
				Filter = "All files (*.*)|*.*|txt files (*.txt)|*.txt"
			};
			
			if( (bool)OpenFDlog.ShowDialog() ){
                string fName = OpenFDlog.FileName;
				var PZL_List = fPuzzleFile_IO.GNPX_PuzzleFile_Read( fName );
				pGPDM.Set_v7_GNPX_Puzzle_List(PZL_List); 

				if( pGPDM.v7_GNPX_Puzzle_List!=null && pGPDM.v7_GNPX_Puzzle_Count>0 ){
					string fName2 = System.IO.Path.GetFileName(fName);			
					Send_Command_to_GNPXwin( this, new Gidoo_EventHandler( eName:"PuzzleFile_Loaded", Message:fName2 ) );
					txt_FileName.Text = fName;
					G6.GNPX_PuzzleFileName = fName;

					int mcc = pSolverList_GNPX.Count(p => p.Sel_mark);
					btn_SolvePuzzle.IsEnabled = (mcc>0 && pGPDM.v7_GNPX_Puzzle_Count>0);
				}
			}

			if( (bool)chbx_Resuming.IsChecked ){ }
		}

		void __Method_CheckMark( bool sel ){
			WriteLine( $"*pSolverList_GNPX : {pSolverList_GNPX.Count} methods" );
			foreach( var (mthd,sq) in pSolverList_GNPX.WithIndex() ){
				if( sel && (mthd.Sel_mark is false) )  continue;
				WriteLine( $"sq:{sq,2} {mthd.NameM.PadRight(30)}  Sel_mark:{(mthd.Sel_mark? "on":"")}" );
			}
		}


		// <<< Solve and Marking : Marking Puzzles using a specified algorithm>>>
		private string fNameSave="", dirFileNameSave="", dirStrSave;
		private int    mSucceed;
		private (int,int) __remainMemo;

		private string Create_Destination_folder( string fullPathName ){
			List<string> folderList = fullPathName.Split(new char[]{'\\','/'}).ToList();
			int nc = folderList.Count;
			string  d0=folderList[nc-2], f0=folderList[nc-1];
			folderList.RemoveAt(folderList.Count-1);

			int m = 1;
			string  d1 = $"_S1";
			string lastFolder = folderList.Last();
			if( lastFolder.Substring(0,2) == "_S" ){
				m = int.Parse(lastFolder.Substring(2))+1;
				d1 = $"_S{m}";
			}
			folderList.Add( d1);
			string d1P = string.Join("\\",folderList);
			if( !Directory.Exists(d1P) )  Directory.CreateDirectory(d1P);

			string f1 = f0.Replace(".txt",d1+".txt");
			folderList.Add(f1);
			string f1P = string.Join("\\",folderList);

			return f1P;
		}

		private async void btn_SolvePuzzle_Click(object sender, RoutedEventArgs e ){
			cts = new CancellationTokenSource();
			prgbar_OnWork.Visibility = Visibility.Hidden;

			txblk_AnalyzerResult.Foreground = Brushes.White;

			if( (string)btn_SolvePuzzle.Content == "Suspend" ){
				_Color_SolveSuspend = btnColor_SolveSuspend.Color;
				cts.Cancel();
				btn_SolvePuzzle.Content = "Solve and Marking";

				return;
			}
			_Color_SolveSuspend = Colors.Orange;
				//	__Method_CheckMark( sel:false );
			txblk_AnalyzerMessage.Text = "";

			if( pGPDM.v7_GNPX_Puzzle_List==null || pGPDM.v7_GNPX_Puzzle_Count<=0 ){
				Lbl_onAnalyzing.Content = "Puzzle file not entered";
				Lbl_onAnalyzing.Foreground = Brushes.Pink;
				displayTimer.Stop();
				AnalyzerLap.Stop();
				shortMessage( "Puzzle file not entered", new sysWin.Point(400,180), Colors.DarkBlue, 2000 );
				return;
			}

			if( pSolverList_GNPX.All(p => !p.Sel_mark) ){
				txblk_AnalyzerResult.Text = "Any Algorithm is not marked.";
				txblk_AnalyzerResult.Foreground = Brushes.Red;

				shortMessage( "Any Algorithm is not marked", new sysWin.Point(400,180), Colors.Orange, 2000 );
				return;
			}

			bool MSelPzlB = G6.PG6Mode=="Func_SelectPuzzle";

		    //region Save standard conditions. Set conditions for development
			int tmpMSlvrMaxAlgorithm = G6.MSlvr_MaxNoAlgorithm;
			int tmpMSlvrMaxTime		 = G6.MSlvr_MaxTime;

			btn_SolvePuzzle.Content  = "Suspend";

			btn_ClearMark.IsEnabled  = false;

			G7.MltAnsSearch  = true;
			G7.Set_Solution_Info = true;

			displayTimer.Start();
			AnalyzerLap.Reset();
			AnalyzerLap.Start();

			string dirFileName = Create_Destination_folder( txt_FileName.Text );

			dirFileNameSave = dirFileName.Replace(".txt","_Selected.txt");
			string dirFileName_Error = dirFileName.Replace(".txt","_Warning_Error.txt");

			string dirFileName_Success_Point = dirFileName.Replace(".txt","_SucessPoint.txt");	//@@@@@ v5.95
			string dirFileName_abnormal_condition = dirFileName.Replace(".txt","_abnormal_condition.txt");	//@@@@@ v5.96
		// ::::::::::::::::::::::::::::::::::::::::::::
			int nPre=0;
			int nTested=0, mError=0;
			
		//	var (lastID,mSucceed) = (bool)chbx_Resuming.IsChecked? _Get_Restart_PuzzleID_FromFile(dirFileName,dirFileName_Success_Point): (0,0);
			var (lastID,mSucceed) = (bool)chbx_Resuming.IsChecked? _Get_Restart_PuzzleID_FromFile(dirFileName,dirFileName_Success_Point): (0,0);
		// ::::::::::::::::::::::::::::::::::::::::::::

			Stopwatch	BlankTimeLap = new();
			BlankTimeLap.Start(); //... debug
			lbl_BlankTime.Content = "0.0 min";
			prg_BlankTime.Value   = 0.0;
			prgbar_OnWork.Visibility = Visibility.Visible;

			foreach( var (aPZL,sqPZL) in pGPDM.v7_GNPX_Puzzle_List.WithIndex() ){
				if( cts.IsCancellationRequested ){ break; }

				// BaseName format is fixed.(ex. "... ID:01_1 ABCDE")
				//if( lastID>0 && Get_BaseID(aPZL.BaseName)<=lastID ){ nPre=nTested++; continue; }
				if( lastID>0 ){
					int IDa = Get_BaseID(aPZL.stPuzzleName);
					if( IDa <= lastID ){ nPre=nTested++; continue; }
				}
				
				UPuzzle ePZL = new UPuzzle(aPZL);
				pGNPX_Eng.ePZL = ePZL;
				foreach( var p in ePZL.BOARD )  if( p.No<0 ) p.No=0;
				pGPDM.v7_current_Puzzle_No = sqPZL;
				Send_Command_to_GNPXwin( this, new Gidoo_EventHandler( eName:"Show_AnalysisStatus" ) );

				try{
					// <1> Show target puzzle
					string st0 = string.Join("",ePZL.BOARD.ConvertAll(p=>Max(p.No,0))).Replace("0",".");
								//WriteLine( $"btn_SolvePuzzle_Click st0:{st0}" );

					// <2> Solve Puzzle. Verify that its Sudoku Puzzle.
					List<string> stList = pGNPX_Eng.IsSudokuPuzzle_DLX_Check( debugPrint:false );

					if( stList.Count != 1 ){  WriteLine( $" System Error. ... btn_SolvePuzzle_Click" ); continue; }

					// <3> Set Puzzle(aPZL) to Solver-Engin.
					pGNPX_Eng.Set_NewPuzzle( aPZL );

					// <4> Initialize Engin.
				//	pGNPX_Eng.AnMan.Update_CellsState( ePZL.BOARD );
					pGNPX_Eng.AnalyzerCounterReset();

		// <5> Initialize search flag.
		G7.g7MarkA0 = false;
		G7.g7Error  = false;
		G7.g7MarkA_MLst0 = new();
//		G7.g7_ePZL = null;


					G6.MSlvr_MaxNoAlgorithm = 1;	// '1' is sufficient. Multiple algorithm solutions can be found during verification.

					G6.MSlvr_MaxNoAllAlgorithm = 1000;
					G6.MSlvr_MaxTime = 100000;		// '1000 msec' is not enough. Time allowed per algorithm (ms)
					G6.stopped_StatusMessage = "";

					pGNPX_Eng.ReturnToInitial();

				    // <6> Engine start
					await Task.Run(() => pGNPX_Eng.GNPX_SolvCompletely(cts.Token) );

					//	if( aPZL.Sol_Result!=null && aPZL.Sol_Result=="Break on step over" )  continue;		// Step limit restrictions. The limit is the specified value

					aPZL.g7MarkA = G7.g7MarkA0;
					aPZL.g7MarkA_Msg = string.Join(" ",G7.g7MarkA_MLst0 );

					UPuzzle ePzl = new(aPZL);
					if( MSelPzlB && aPZL.g7MarkA && !aPZL.g7Error){
						mSucceed++;
						Dispatcher.Invoke( () => txblk_AnalyzerMessage.Text = $"{ePZL.Name}\n{DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")}" );
						if( (bool)chbx_FileOutputOnSuccess.IsChecked ){
							bool addDateTimeB = (bool)chbx_Add_DateTime.IsChecked;
							_Save_SelectedPuzzle_ToFile(dirFileName,ePzl,addTimeStanpB:addDateTimeB);
						}

						BlankTimeLap.Restart();		//... debug
						showAttensionMark( 1000 );   //... debug
					}
					if( G7.g7Error ){ 
						_Save_SelectedPuzzle_ToFile(dirFileName_Error,ePZL); // Alert when an error occurs.
						mError++; aPZL.g7Error=true;
					}		
				

					// :::: Success_Point ... for Debug ::::::::::::::::::::::::::::::::::::::::::::::::::::
					//_Save_SelectedPuzzle_ToFile(dirFileName_Success_Point,aPZL,appendB:false, addTimeStanpB:true); 
					// :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

					this.Dispatcher.Invoke( ()=> {
							Solving_Message = $" Succeed : {mSucceed}\n  Failed : {mError}\n  Parsed : {++nTested} / {pGPDM.v7_GNPX_Puzzle_Count}";
							var prg_Solved_Value = (double)nTested / (double)pGPDM.v7_GNPX_Puzzle_Count * 100.0;
							prg_Solved.Value = prg_Solved_Value;
							lbl_Solved.Content = $"{prg_Solved_Value:F1} %";

							double bt = BlankTimeLap.Elapsed.TotalSeconds / 60.0;  //minits	 //... debug
							lbl_BlankTime.Content = $"Blank Time : {bt:F1} min."; //... debug
							prg_BlankTime.Value = Min( bt, 100.0 ); //... debug
							lbl_BlankTime.Foreground = (bt>30.0)? Brushes.Red: (bt>10.0)? Brushes.Orange: Brushes.LightGreen; //... debug
					} );
					__remainMemo = (nTested-nPre,pGPDM.v7_GNPX_Puzzle_Count-nPre);
					btn_ClearMark.IsEnabled = true;

				}
				catch( Exception ex ){
					_Save_SelectedPuzzle_ToFile(dirFileName_abnormal_condition,ePZL,appendB:false, addTimeStanpB:true); 

					using( var fpW=new StreamWriter( dirFileName_abnormal_condition, append:true, Encoding.UTF8) ){ 
						fpW.WriteLine( $"{ex.Message}\n{ex.StackTrace}");
					}
				}
			}

			await Task.Delay(1000);
			btn_SolvePuzzle.Content="Solve and Marking";

			AnalyzerLap.Stop();
			displayTimer.Stop();
			prgbar_OnWork.Visibility = Visibility.Hidden;

			// Recover standard conditions.
            G6.MSlvr_MaxNoAlgorithm  = tmpMSlvrMaxAlgorithm;
            G6.MSlvr_MaxTime         = tmpMSlvrMaxTime;

			btn_SavePuzzle.IsEnabled =  pGPDM.v7_GNPX_Puzzle_List.Any( P=> P.g7MarkA );  //　This operation is allowed only for PU
		
					int Get_BaseID( string name ){
						int n = name.IndexOf("_")+1;
						int n2 = name.IndexOf(" ")-n; 
					//	int _ID = int.Parse(name.Substring(3,2))*10000000 + int.Parse(name.Substring(n,n2));
						int _ID = int.Parse(name.Substring(n,n2));
						return _ID;						
					}

					void __Method_CheckMark( bool sel ){
						WriteLine( $"*pSolverList_GNPX : {pSolverList_GNPX.Count} methods" );
						foreach( var (mthd,sq) in pSolverList_GNPX.WithIndex() ){
							if( sel && (mthd.Sel_mark is false) )  continue;
							WriteLine( $"sq:{sq,2} {mthd.NameM.PadRight(30)}  mark_Sel:{(mthd.Sel_mark? "on":"")}" );
						}
					}	

					(int,int) _Get_Restart_PuzzleID_FromFile( string fNameSave, string AnalyzedPuzzle_dirFileName ){

						var (_,mSucceed)  = __Get_File_ID(fNameSave);
						var (lastID,_)    = __Get_File_ID(AnalyzedPuzzle_dirFileName);

						return (lastID,mSucceed);

								(int,int) __Get_File_ID(string fName){
									int  mSucceed=0;
									if( !File.Exists(fNameSave) )  return (0,0);
									string line="", lineTmp;
									using( var fpR=new StreamReader(fNameSave, Encoding.UTF8) ){
										while( (lineTmp=fpR.ReadLine()) != null ){
											if( lineTmp.Length <= 2 )  continue;
											line = lineTmp;
											mSucceed++;
										}
									}
									var stLine = line.Split(' ').ToList().FindAll(p=>p.Contains("ID")).First();
									int n = stLine.IndexOf("_")+1;
									int lastID = int.Parse(stLine.Substring(n));
									return (lastID,mSucceed);
								}
					}
					
					void _Save_SelectedPuzzle_ToFile( string dirFileName, UPuzzle aPZL, bool appendB=true, bool addTimeStanpB=false ){
						using( var fpW=new StreamWriter( dirFileName, append:appendB, Encoding.UTF8) ){   
							var eBN = aPZL.BaseName.Split(" "); 	// First name and ID included.

							string  aPZLName = aPZL.Name.Contains("ID")? aPZL.Name: $"{eBN[0]} {aPZL.Name}";
							string line = aPZL.stPZL_withSP + $" {aPZL.difficultyLevel} \"{aPZLName}\"";
							fpW.WriteLine(line);
						}

					}
		}

		private void btn_ClearMark_Click(object sender, RoutedEventArgs e ){
			pGPDM.v7_GNPX_Puzzle_List.ForEach( P=> {P.g7MarkA=false; P.g7Error=false;} );
			this.Dispatcher.Invoke( ()=> Solving_Message = "" );
            txblk_AnalyzerResult.Text = "";

        }



	#region <<< Algorithm Selection >>> 

		private void CheckBox_Checked(object sender, RoutedEventArgs e){

			// --- control ---
			var  CheckBox_sender = sender as CheckBox;
			var  Name_sender = CheckBox_sender.Content as string;
			//Name_sender = Name_sender.Substring(3);	
			Name_sender = Name_sender.Replace("__","_");
			Name_sender = Name_sender.Replace("__","_");

			// --- pSolverList_GNPX ---
			var Q = pSolverList_GNPX.Find(p=>p.MethodName==Name_sender);
			if( Q != null ){
				bool B = (bool)CheckBox_sender.IsChecked;
				Q.IsChecked = Q.Sel_mark = B;
			}
			else{ 
				Send_Command_to_GNPXwin( this, new Gidoo_EventHandler( eName:"Method is inactive" ) );
				Lbl_onAnalyzing.Content = "Method is inactive";
				Lbl_onAnalyzing.Foreground = Brushes.Pink;
				//displayTimer.Stop();
				return;
			}

			// --- Message --- 
			if( pSolverList_GNPX.Any(p => p.Sel_mark) ){
				txblk_AnalyzerResult.Text = "";
				txblk_AnalyzerResult.Foreground = Brushes.OrangeRed;	//Brushes.White;	//0127
			}

			int mcc = pSolverList_GNPX.Count(p => p.Sel_mark);
			if( mcc > 0 ){
				lbl_Selected_Method.Content    = $"Selected Algorithms: {mcc}";
				lbl_Selected_Method.Foreground = Brushes.White;
			}
			else{
				lbl_Selected_Method.Content    = "Specify the Algorithm" ;
				lbl_Selected_Method.Foreground = Brushes.OrangeRed;
			}

			// --- Button Control ---
			btn_SolvePuzzle.IsEnabled = (mcc>0 && pGPDM.v7_GNPX_Puzzle_Count>0);

			_restoration();
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = pSolverList_GNPX;

			return;

			// -------------------------------------------------
					void _restoration(){
						object obj = new object();

						switch(sortMode){
							case "ID":		btn_SortByID_Click( obj, null ); break;
							case "Name":	btn_SortByName_Click( obj, null ); break;
							case "Diff":	btn_SortByDifficulty_Click( obj, null ); break;
							case "Marked":	btn_SortByMarked_Click( obj, null); break;
						}
					}
		}



	
	  #region <<< Check conditions >>>

		private void btn_SortByID_Click(object sender, RoutedEventArgs e ){	
			pSolverList_GNPX.Sort( (a,b)=> (a.ID - b.ID) );
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = pSolverList_GNPX;
			sortMode="ID";
			//Set_Color( sender, e );
			ChangeCondition_SolverList( );
		}
		private void btn_SortByName_Click(object sender, RoutedEventArgs e ){
			pSolverList_GNPX.Sort( (a,b)=> (a.MethodName.CompareTo(b.MethodName)) );
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = pSolverList_GNPX;
			sortMode="Name";
			//Set_Color( sender, e );
			ChangeCondition_SolverList( );
		}
		private void btn_SortByDifficulty_Click(object sender, RoutedEventArgs e ){
			pSolverList_GNPX.Sort( (a,b)=> (Abs(a.difficultyLevel) - Abs(b.difficultyLevel)) );
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = pSolverList_GNPX;
			sortMode="Diff";
			//Set_Color( sender, e );
			ChangeCondition_SolverList( );
		}
		private void btn_SortByMarked_Click(object sender, RoutedEventArgs e ){
			pSolverList_GNPX.Sort( (a,b)=> (a.sortKey - b.sortKey) );
			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = pSolverList_GNPX;
			sortMode="Marked";
			//Set_Color( sender, e );
			ChangeCondition_SolverList( );
		}

		private void btn_ResetMark_Click(object sender, RoutedEventArgs e ){
			if( numUD_DifficultyLevel==null || pSolverList_GNPX==null )  return;

			G6.Method_DifficultyLevel = numUD_DifficultyLevel.Value;
			pSolverList_GNPX.ForEach( p => p.Sel_mark=false );

			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = pSolverList_GNPX;
			sortMode="Reset";
			//Set_Color( sender, e );
			ChangeCondition_SolverList( );
		}
		private void numUD_DifficultyLevel_ValueChanged(object sender, GIDOOEventArgs args){
			//if( numUD_DifficultyLevel == null )  return;
			//btn_ResetMark_Click( sender, new RoutedEventArgs() ); 

			if( numUD_DifficultyLevel==null || numUD_DifficultyLevel==null )  return;
			G6.Method_DifficultyLevel = numUD_DifficultyLevel.Value;
			ChangeCondition_SolverList( );
		}

		private void ChangeCondition_SolverList( ){
			if( G6.OperationalMode == "Initializing" )  return;

			pSolverList_GNPX.ForEach( P=> P.IsChecked=false );
			UAlgMethod PG = pSolverList_GNPX.Find( P => P.GenLogB );

			var _diffLevel = G6.Method_DifficultyLevel;
			foreach( var P in pSolverList_GNPX ){
				int dif = P.difficultyLevel;

				P.IsChecked = dif>0 && (dif<=_diffLevel);
				//if( _diffLevel>=10 ) P.IsChecked = (dif<=_diffLevel);		//If it's 10 or more, include the negatives.
				if( P==PG && !G6.GeneralLogic_on )  PG.IsChecked = false;

				P.brshM = P.IsChecked? Brushes.Lime: Brushes.White;
				if( P.Sel_mark && P.IsChecked ){ P.IsChecked=true; P.brshM=Brushes.Orange; }
			}
			
			UAlgMethod QGenLog = pSolverList_GNPX.Find( P => P.MethodName.Contains("GeneralLogic") );
			if( QGenLog != null )  QGenLog.IsChecked  = G6.GeneralLogic_on;  // Enable/disable GeneralLogic

			lsB_GMethod00B.ItemsSource = null;
			lsB_GMethod00B.ItemsSource = pSolverList_GNPX;
		}

	  #endregion << Check conditions >>>

	#endregion <<< Algorithm Selection >>> 

		/*
				public void Save_SelectedPuzzle_ToHTMLFile( UPuzzle aPZL ){
					using( var fpW=new StreamWriter( dirStrSave+"/"+fNameSave, append:true, Encoding.UTF8) ){   
						var P = aPZL;
						string LRecord = P.stPZL_withSP + $" {P.difficultyLevel} \"{P.Name}\" \"{P.TimeStamp}\"";
						fpW.WriteLine(LRecord);
					}
				}
		*/

		private void btn_SavePuzzle_Click(object sender, RoutedEventArgs e ){
			var PZLs = pGPDM.v7_GNPX_Puzzle_List.FindAll( P=> P.g7MarkA & !P.g7Error );  //　This operation is allowed only for PU
			
			// Selected Puzzles
			int nc = GNPX_PuzzleFile_Write( dirFileNameSave, PZLs, append:true, blank9:false );
			txblk_AnalyzerMessage.Text = $"Selected File : {dirFileNameSave} ... {mSucceed} Puzzles";

			// Puzzles with errors
			var errorPZLs = pGPDM.v7_GNPX_Puzzle_List.FindAll( P=> P.g7Error );
			if( errorPZLs.Count > 0 ) {
				string fNameError = dirFileNameSave.Replace("_Selected.txt","_Error.txt");
				GNPX_PuzzleFile_Write( fNameError, errorPZLs, append:true, blank9:false );
				txblk_AnalyzerMessage.Text += $"Error File : {fNameError} ... {errorPZLs} Puzzles";
			}
		}

		private int GNPX_PuzzleFile_Write( string fName, List<v7_UPuzzle_Base> PZLs, bool append=true, bool blank9=false ){
            if( PZLs.Count==0 )  return 0;

			int nc = 0;
            using( StreamWriter fpW=new StreamWriter(fName,append,Encoding.UTF8) ){
				PZLs.ForEach( aPZL => { fpW.WriteLine( aPZL.stPuzzle_forFile ); nc++; } );
            }
			return nc;
		}
	}	
}
