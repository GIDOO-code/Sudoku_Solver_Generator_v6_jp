﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using System.Xml.Linq;


//using DLX_V2;

using GIDOO_space;

using Microsoft.VisualBasic;


//using GNPX_DLX2;

//using GNPX_space2;

using Microsoft.Win32;

using STD_SDK;

using Windows.Devices.Lights;

using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;
//using static GNPX_space2.GPuzzleTrans_2;

namespace GNPX_space{
	using ioPath = System.IO.Path;
	using pGPDM = GNPX_Puzzle_Database_Manager;
	using pRes = Properties.Resources;
	using standardization_Man = STD_SDK.standardization_Man;
	using sysWin = System.Windows;

    public partial class Func_Transform: Page{



		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 
	//	public event GNPX_EventHandler Send_Command_to_Page;

		static public GNPX_App_Man 	pGNPX_App;
		static private G6_Base		G6 => GNPX_App_Man.G6;
		static public GNPX_win		pGNP00win;




        private GNPX_Engin			pGNPX_Eng => pGNPX_App.GNPX_Eng;		//Analysis Engine
		private GNPX_AnalyzerMan    pAnMan    => pGNPX_Eng.AnMan;			// pGNPX_App.pGNPX_Eng.AnMan;

		public  UPuzzle				ePZL{ get=>pGNPX_Eng.ePZL; set=>pGNPX_Eng.ePZL=value; }

		private int[]				board0 => ePZL.v7B_Puzzle.Get_board();

	    private PuzzleFile_IO		fPuzzleFile_IO => pGNPX_App.fPuzzleFile_IO;
	//	private List<v7_UPuzzle_Base> pGNPX_PUZZLE_List => pGPDM.v7_GNPX_Puzzle_List;



		private standardization_Man STD;
		private STD_SDK.Standard_Form Std_Frm;


		private Trans_para		   TPx => ePZL.TP;

		private int[]			   Puzzle_Initial() => ePZL.BOARD.ConvertAll(p=> Max(p.No,0)).ToArray();


		private DispatcherTimer     displayTimer;
		private Stopwatch			Working_SW = new();





		// The Random initial value of the random number is fixed.
		// ->  The same random number is always used.
		// ->  Reproducibility is maintained even when debugging.



		// :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        public Func_Transform( GNPX_App_Man GNPX_App){
			pGNPX_App = GNPX_App;
			pGNP00win = pGNPX_App.pGNP00win;
//			pPTrans   = new( pGNPX_App );

            InitializeComponent();
			txb_NumChange.Visibility = Visibility.Hidden;

			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );      
			pGNP00win.Send_Command_to_Func_Transform += new GNPX_EventHandler( Event_Reciever );

			displayTimer = new DispatcherTimer(DispatcherPriority.Normal);
			displayTimer.Interval = TimeSpan.FromMilliseconds(10);
			displayTimer.Tick += new EventHandler(Progress_of_Standardization);

			STD = new standardization_Man();
        }

		private void Page_Loaded(object sender, RoutedEventArgs e ){ // Executes when transitioning to this page.
			G6.PG6Mode = GetType().Name; 
			G6.DigitsChangeMode = false;
			prgbar_OnWork.IsEnabled = false;
			prgbar_OnWork.Visibility = Visibility.Hidden;

			Std_Frm = ePZL.v7B_Puzzle. Std_Frm;
			if( Std_Frm == null ){
				int[] board = Puzzle_Initial();
				Std_Frm = new(board);
			}
		}

		private void Page_Unloaded(object sender, RoutedEventArgs e ){ // Executes when leave this page.
			G6.DigitsChangeMode = false;

			
			pGNPX_Eng.extResult = "";
			Send_SetPuzzleOnBoard_A(STD);
        }




 		private void Send_SetPuzzleOnBoard(){	// ( General purpose. )
			Send_Command_to_GNPXwin( this, new Gidoo_EventHandler( eName:"Show_AnalysisStatus" ) );
		}

 		private void Send_SetPuzzleOnBoard( bool DevelopB=false ){
			var se = new Gidoo_EventHandler( eName:"Show_AnalysisStatus" );  //Report
			Send_Command_to_GNPXwin( this, se );
			return;
		}


        private void btn_Save_Changes_Click( object sender, RoutedEventArgs e ){
			//ePZL.BOARD.__DBUG_Print2( sqF:true, st:"btn_Save_Changes_Click" );

			int[] board = ePZL.BOARD.ConvertAll( U => Max(U.No,0) ).ToArray();
			v7_UPuzzle_Base v7_pzl = new( string.Join("",board), ePZL.difficultyLevel, ePZL.Name );
			ePZL.v7B_Puzzle = v7_pzl;

			pGPDM.v7_GNPX_Puzzle_List_Add(ePZL.v7B_Puzzle);		// v7 Add @@@

			lbl_TP_Info.Content = "Saved to the internal Puzzle-List.";
			lbl_TP_Info.Foreground = Brushes.LightBlue;
			
			Send_SetPuzzleOnBoard( DevelopB:true );

			int nPzlIdx = pGPDM.v7_GNPX_Puzzle_Count;
			Gidoo_EventHandler se2 = new Gidoo_EventHandler( eName:"SetPuzzle_no", ePara0:nPzlIdx );  //Report
			Send_Command_to_GNPXwin( this, se2 );

			chbx_ShowSolution_Checked( sender, e );
        }

        private void btn_Trans_ResetToInitial_Click(object sender, RoutedEventArgs e ){

			//ePZL.Reset_ToInitial();
			ePZL = new UPuzzle( ePZL.v7B_Puzzle) ;

			chbx_ShowSolution.IsChecked = false;
			
			TPx.Clear(); //only transrate parameter clear()
			Std_Frm.TP = new();
			TPx.board = ePZL.BOARD.ConvertAll(p=>Max(p.No,0)).ToArray();
            Send_SetPuzzleOnBoard( );	//DevelopB:true );
			Display_on_GNPXScreen(TPx);
        }


		// :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#region Handling board digit-changes
		private int	noPChg = -1;
		private void btn_DigitChange_Click( object sender, RoutedEventArgs e ){		
			// Enter digits-change mode	 
			G6.DigitsChangeMode = true;

            btn_DigitChange.IsEnabled=false;
            btn_DigitChangeRandom.Visibility=Visibility.Hidden;
				// TransSolverA("NumChange",true); //display solution ... Functionality suspended

            txb_NumChange.Text = "1";
            txb_NumChange.Visibility = Visibility.Visible;
            btn_DigitChangeDone.Visibility = Visibility.Visible;
            noPChg = 1;            

            Send_SetPuzzleOnBoard( DevelopB:true );		// Set board click reception status
        }

		public void Event_Reciever( object sender, Gidoo_EventHandler e ){  //Board click receiver
			if( G6.DigitsChangeMode is false )  return;		//It's excessive, but.
			int rc = e.ePara0;		//WriteLine( $" --- Func_Transform / Reciever rc:{e.ePara0}" );
			_Change_PB_GBoardNum( rcX:e.ePara0 ) ;
			return;
					// ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- 
					void _Change_PB_GBoardNum( int rcX ){
						if(rcX<0) return;
						int noP=Abs(ePZL.BOARD[rcX].No);
						if( noP==0 )  return;
						if( noP>noPChg){
							foreach( var uc in ePZL.BOARD.Where(r=>r.No!=0) ){                 
								int nm=uc.No, nmAbs=Abs(nm), nmSgn=Sign(nm);
								if( nmAbs<noPChg ) continue;
								else if( nmAbs==noP ) uc.No = nmSgn * noPChg;
								else if( nmAbs<noP )  uc.No = nmSgn * (nmAbs+1);
							}
						}
						else if( noP<noPChg ){          
							foreach( var uc in ePZL.BOARD.Where(r=>r.No!=0) ){                 
								int nm=uc.No, nmAbs=Abs(nm), nmSgn=Sign(nm);
								if( nmAbs<noP ) continue;
								else if( nmAbs==noP )    uc.No = nmSgn * noPChg;
								else if( nmAbs<=noPChg ) uc.No = nmSgn * (nmAbs-1);
							}           
						}

						Send_SetPuzzleOnBoard();	

						noPChg++;
						txb_NumChange.Text = noPChg.ToString();
						if(noPChg>9) btn_DigitChangeDone_Click(this,new RoutedEventArgs());
						return;
					}
		}
        private void btn_DigitChangeDone_Click( object sender, RoutedEventArgs e ){
            btn_DigitChange.IsEnabled=true;
            btn_DigitChangeRandom.Visibility=Visibility.Visible;
            txb_NumChange.Visibility = Visibility.Hidden;
            btn_DigitChangeDone.Visibility = Visibility.Hidden;
            noPChg = -1;

			G6.DigitsChangeMode = false;

            Send_SetPuzzleOnBoard();
        }
		
		private void btn_DigitChangeRandom_Click(object sender,RoutedEventArgs e){		
            int[] ranNum = Enumerable.Range(0,9).ToArray();
			Random.Shared.Shuffle(ranNum);

            foreach( var q in ePZL.BOARD.Where(p=>p.No!=0) ){
				int nm=q.No, nm2=ranNum[Abs(nm)-1]+1;
                q.No = (nm>0)? nm2: -nm2;
            }

            Send_SetPuzzleOnBoard();
        }	
		
		private void chbx_ShowSolution_Checked( object sender, RoutedEventArgs e ){
			bool DspSol = (bool)chbx_ShowSolution.IsChecked;
			if( DspSol ) _Get_Solution( ePZL.BOARD );
			else		 ePZL.BOARD.ForEach( P=> P.No=Max(P.No,0) );
			
			Send_Command_to_GNPXwin( this, new Gidoo_EventHandler( eName:"Show_AnalysisStatus" ) );
			return;
			
				void _Get_Solution( List<UCell> Q ){

					int[] board = ePZL.BOARD.ConvertAll(P=>P.No).ToArray(); 
		
					// Solve using DLX solver(ver7.0-).
					DLX_V2.SudokuSolver SDK_Solver = new();
					var solutions = SDK_Solver.Solve( board, maxSolutions:1 /*,ct*/); 
										//ct:undefine. ... Process at extremely high speed.
					var boardSol = solutions[0];
					foreach( var P in Q )  if( P.No==0 )  P.No = -boardSol[P.rc];
				}
        }
#endregion Handling board digit-changes


		private void btn_Trans_para_Click( object sender,RoutedEventArgs e) {
			Button? btn = sender as Button;

			Set_Transform_Parameter( btn, TPx );
			Display_on_GNPXScreen(TPx);
        }



      #region Standadization
        // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
        //   Standardization ***
        // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
        private int numAll;
		private void Progress_of_Standardization( object sender, EventArgs e ){
			var (nc,nCount) = standardization_Man.progressCounters;
		    lbl_progress.Content = $"{nc,5} / {nCount}";
			Lbl_onWork.Content = _stElapRem( PuzzleCount, nc, Working_SW.Elapsed );
		}		
		private string _stElapRem( int numAll, int numCur, TimeSpan lapCur ){
			if( numCur <= 0 )  return "";
			var lapT = lapCur * numAll / numCur;
			string st = $"Lap: {lapCur.TimespanToString(stUnit:true)} + {(lapT-lapCur).TimespanToString(stUnit:true)}";
			return st;
		}


        private void btn_Nomalize_Click( object sender, RoutedEventArgs e ){
			if( ePZL.BOARD.All(u=>u.No==0 ) ) return;

            standardization_Man STD = new( );
			int[] board1D =  ePZL.BOARD.ConvertAll(u => Abs(u.No)).ToArray();
			//board1D.PrintBoard( "ePZL.BOARD" );

            Standard_Form  Std_Frm = STD.Standardization( board1D, debugPrint:false );
			if( Std_Frm == null ){ lbl_TP_Info.Content = "Invalid Puzzle";	return; }

			pGNPX_Eng.extResult = STD.Standard_Report();

			Std_Frm.TP.CopyTo(TPx);
			Execute_Conversion(TPx);
			Display_on_GNPXScreen(TPx);

			Send_SetPuzzleOnBoard_A(STD);
		}
 		private void Send_SetPuzzleOnBoard_A( standardization_Man STD, bool DevelopB=true ){
			var se = new Gidoo_EventHandler( eName:"Show_AnalysisStatus" );  //Report
			Send_Command_to_GNPXwin( this, se );
			if(DevelopB)	_Display_PuzzleTransform(STD);
			return;
					// ----------------------------------------------------------
					void _Display_PuzzleTransform( standardization_Man STD ){
						if( STD==null || STD.STD_form==null )  return;
						var TP = STD.STD_form.TP;
						if( TP == null )  return;
					}

		}

		public int PuzzleCount;
		public string stPzl_fName;

		private List<v7_UPuzzle_Base> puzzle_A_List;
        private void btn_OpenPuzzleFile_Click(object sender,RoutedEventArgs e) {
		    var openFile = new OpenFileDialog{
				Multiselect = false,
				Title  = "Puzzle File Open",
				Filter = "All files (*.*)|*.*|txt files (*.txt)|*.txt"
			};

            if( (bool?)openFile.ShowDialog() is true ){
                stPzl_fName = openFile.FileName;
                txt_FileName.Text = stPzl_fName;

				puzzle_A_List = fPuzzleFile_IO.GNPX_PuzzleFile_Read( stPzl_fName );
				PuzzleCount = puzzle_A_List.Count;
				lbl_progress.Content = $"0 / {PuzzleCount}";
			}
        }

		private  CancellationTokenSource cts = new();

		private void btn_Break_Click(object sender,RoutedEventArgs e) {
			cts.Cancel();
			prgbar_OnWork.IsEnabled = false;
            prgbar_OnWork.Visibility = Visibility.Hidden;

			Thread.Sleep(200);
			displayTimer.Stop();
			Working_SW.Stop();
        }

        private async void btn_standardization_DLX_Click(object sender,RoutedEventArgs e) {
            if( puzzle_A_List==null || puzzle_A_List.Count==0 ){
                txt_FileName.Text = "no Puzzles";
                txt_FileName.Foreground = Brushes.Red;
                return;
            }  
            txt_FileName.Foreground = Brushes.White;

            prgbar_OnWork.Visibility = Visibility.Visible;
            prgbar_OnWork.IsEnabled = true;

            displayTimer.Start();
			Working_SW.Start();		  
		    
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
            await Task.Run(( ) => STD.STD_Application_1(stPzl_fName, puzzle_A_List, cts.Token) );
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

			Working_SW.Stop();
			displayTimer.Stop();

            prgbar_OnWork.Visibility = Visibility.Hidden;
            prgbar_OnWork.IsEnabled = false;
					
			var (nc,nCount) = standardization_Man.progressCounters;
			lbl_progress.Content = $"{nc,5} / {nCount}";
			Lbl_onWork.Content = _stElapRem( PuzzleCount, PuzzleCount, Working_SW.Elapsed );
        }
      #endregion Standadization
    }
}