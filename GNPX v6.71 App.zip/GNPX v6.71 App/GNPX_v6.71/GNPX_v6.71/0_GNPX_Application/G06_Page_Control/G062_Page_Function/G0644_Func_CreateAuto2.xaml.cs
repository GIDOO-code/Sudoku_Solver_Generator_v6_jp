﻿using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

using static System.Math;
//using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space {
    using System.Globalization;
    using System.Linq.Expressions;
    using System.Text;

    using GIDOO_space;

    using pGPDM = GNPX_Puzzle_Database_Manager;
    using pRes = Properties.Resources;
    using sysWin = System.Windows;

    public partial class Func_CreateAuto2: Page {
        static public event GNPX_EventHandler Send_Command_to_GNPXwin;

        static public GNPX_App_Man pGNPX_App;
        private GNPX_win pGNP00win{ get=>pGNPX_App.pGNP00win;
        }

        public GNPX_Puzzle_Analysis_Support Pzl_Analysis_Supp => pGNPX_App.Pzl_Analysis_Supp;
        private GNPX_Engin pGNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine
        private G6_Base G6 => GNPX_App_Man.G6;
        private G7_Base G7 => GNPX_App_Man.G7;


        private GNPX_Graphics gnpxGrp => pGNPX_App.gnpxGrp;

        public UPuzzle ePZL{ get => pGNPX_Eng.ePZL; set => pGNPX_Eng.ePZL = value; } // Puzzle to analyze

        private List<RadioButton> PatSel_RBList = null;

        private RenderTargetBitmap bmpPD = new RenderTargetBitmap(176, 176, 96, 96, PixelFormats.Default);//176=18*9+2*4+1*6        
//        private CancellationTokenSource  ctsAPQ = null;

        private MethodDisplayWin MthdWin;
        private Stopwatch        AnalyzerLap;
        private DispatcherTimer  statusDisplayTimer;
        private DispatcherTimer  timerShortMessage;


        public Func_CreateAuto2( GNPX_App_Man GNPX_App ){
            pGNPX_App = GNPX_App;
            InitializeComponent();

            lbl_ShortMessage.Visibility = Visibility.Hidden;

            Send_Command_to_GNPXwin += new GNPX_EventHandler(pGNP00win.GNPX_Event_Handling_man);

          #region Timer
            AnalyzerLap = new Stopwatch();
            statusDisplayTimer = new DispatcherTimer(DispatcherPriority.Normal, this.Dispatcher);
            statusDisplayTimer.Interval = TimeSpan.FromMilliseconds(250);
            statusDisplayTimer.Tick += new EventHandler(statusDisplayTimer_Tick);

            timerShortMessage = new DispatcherTimer(DispatcherPriority.Normal);
            timerShortMessage.Interval = TimeSpan.FromMilliseconds(50);
            timerShortMessage.Tick += new EventHandler(timerShortMessage_Tick);
          #endregion
        }

        private void Page_Loaded(object sender, RoutedEventArgs e ){
            G6.PG6Mode = GetType().Name;

          #region PatSel
            if(PatSel_RBList == null) {
                PatSel_RBList = (List<RadioButton>)GNPX_Utilitie.GetControlsCollection<RadioButton>(this); // Create list of "Pattern Buttons"
                PatSel_RBList = PatSel_RBList.FindAll(P => P.Name.Contains("rdb_patSel"));
            }

            string patN = $"{G6.PatSel0X:00}";
            RadioButton rdb = PatSel_RBList.Find(P => P.Name.Replace("rdb_patSel", "") == patN);
            if(rdb != null) rdb.IsChecked = true;
          #endregion

            string culture = App_Environment.culture;

            int diff = pGNPX_App.Get_Difficulty_SolverList_App();

            btn_sdk_2520_cancel_1.Visibility = Visibility.Hidden;

            prgbar_OnWork_1.Visibility = Visibility.Hidden;
            prgbar_OnWork_1.IsEnabled = false;

            string stM = "Generating puzzles with 17-20 clues is under development.";
            shortMessage( stM, new sysWin.Point(20,50), Colors.Blue, 4000 );

            if( G6.CreateAuto2_Puzzlis == null )  G6.CreateAuto2_Puzzlis = new int[14];
        }



      #region Timer (shortMessage,statusDisplay)
        // <<< ShortMessage >>>
        private void timerShortMessage_Tick(object sender, EventArgs e ){
            lbl_ShortMessage.Visibility = Visibility.Hidden;
            timerShortMessage.Stop();
        }

        private void shortMessage( string st, sysWin.Point pt, Color cr, int tm) {
            if(tm == 9999) timerShortMessage.Interval = TimeSpan.FromSeconds(5);
            else           timerShortMessage.Interval = TimeSpan.FromMilliseconds(tm);

            this.Dispatcher.Invoke(( ) => {
                lbl_ShortMessage.Content = st;
                lbl_ShortMessage.Foreground = new SolidColorBrush(Colors.White);
                lbl_ShortMessage.Background = new SolidColorBrush(cr);
                lbl_ShortMessage.Margin = new Thickness(pt.X, pt.Y, 0, 0);
                lbl_ShortMessage.Visibility = Visibility.Visible;
            });

            Thread.Sleep(200);
            timerShortMessage.Start();
        }

        private void statusDisplayTimer_Tick(object sender, EventArgs e ){
            var DicDLX = new Dictionary<string,string>();
            for( int k=17; k<=30; k++ )  DicDLX[$"{k,7}"] = $"{G6.CreateAuto2_Puzzlis[k-17],7}";
           int total = G6.CreateAuto2_Puzzlis.Sum();
            DicDLX[$"  total"] = $"{total,7}";
 
            lv_DLX_Soluttions.ItemsSource = DicDLX.ToList();

            Lbl_onCresting.Content = AnalyzerLap.Elapsed.TimespanToString();
        }
      #endregion Timer (shortMessage,statusDisplay)


      #region Event Processing
        private void Send_SetPuzzleOnBoard( ) {
        Gidoo_EventHandler se = new Gidoo_EventHandler(eName: "Show_AnalysisStatus");  //Report
        Send_Command_to_GNPXwin(this, se);
        }

        // <<< Event Receiver >>>
        public void GNPX_Event_Handling_man(object sender, Gidoo_EventHandler e ){

            switch(e.eName ){

                case "PuzzleCreated":
//                    Dispatcher.Invoke(( ) => txb_NoOfPuzzles.Text = e.ePara1.ToString());
                    shortMessage($" {e.ePara1} found  ", new sysWin.Point(450, 50), Colors.Blue, tm: 500);
                    // Updates and displays of the main board (UC_PB_GBoard) are done by the main window.
                    break;

                case "ShortMessage":
                    shortMessage(e.gsm.Message, e.gsm.Pt, e.gsm.color, e.gsm.msec);
                    break;

                case "SystemError":
                    shortMessage(e.Message, new sysWin.Point(400, 180), Colors.Orange, 3000);
                    break;

                default:
                    shortMessage("System error. Undefined event.", new sysWin.Point(100, 200), Colors.DarkRed, 10000);
                    break;
                    // ( In other thread control, "Dispatcher.Invoke" is need! )
            }

            if(statusDisplayTimer.IsEnabled == false)
            statusDisplayTimer.Start();
        }

        #endregion Event Processing


// ******************************************************************************************************************




        private SDK_Puzzle_Creator_2520 sdk2520;

        private void btn_Create_Puzzle_X_Click(object sender,RoutedEventArgs e) {
            int maxTime = 2;
            try{
                maxTime = int.Parse(txb_maxTime.Text,NumberStyles.Integer);
            }
            catch(Exception){ maxTime = 2; }
            if( maxTime<=0 || maxTime>=7200 )  maxTime = 2;
            txb_maxTime.Text = maxTime.ToString();

            btn_sdk_2520_cancel_1.Visibility = Visibility.Visible;

            prgbar_OnWork_1.Visibility = Visibility.Visible;
            prgbar_OnWork_1.IsEnabled = true;

            AnalyzerLap.Start();
            statusDisplayTimer.Start();

            sdk2520 = new SDK_Puzzle_Creator_2520( this );
            sdk2520.A_SDK_2520_Solver(maxTime);    // "DLX_RunnerTask_Start up"
        }
        
        private void chbx_File_AutoSave_Checked(object sender,RoutedEventArgs e){
            G6.CreateAuto2_Save_auto = (bool)chbx_File_AutoSave.IsChecked;
        }

        private void btn_sdk_2520_cancel_1_Click(object sender,RoutedEventArgs e) {
            int maxTime = 2;
            try{
                maxTime = int.Parse(txb_maxTime.Text,NumberStyles.Integer);
            }
            catch(Exception){ maxTime = 2; }
            if( maxTime<=0 || maxTime>=7200 )  maxTime = 2;
            txb_maxTime.Text = maxTime.ToString();

            btn_sdk_2520_cancel_1.Visibility = Visibility.Hidden;
            sdk2520.SDK_2520_Solve_suspend( );
            statusDisplayTimer.Stop();
            AnalyzerLap.Stop();

            prgbar_OnWork_1.Visibility = Visibility.Hidden;
            prgbar_OnWork_1.IsEnabled = false;
        }
    }
}
