﻿using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using static System.Math;
//using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space {
    using GIDOO_space;
    using pGPDM = GNPX_Puzzle_Database_Manager;
    using pRes = Properties.Resources;
    using sysWin = System.Windows;

    public partial class Func_CreateAuto : Page {
        static public event GNPX_EventHandler Send_Command_to_GNPXwin;

        static public GNPX_App_Man pGNPX_App;
        private GNPX_win pGNP00win{ get=>pGNPX_App.pGNP00win;
        }

        public GNPX_Puzzle_Analysis_Support Pzl_Analysis_Supp => pGNPX_App.Pzl_Analysis_Supp;
        private GNPX_Engin pGNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine
        private G6_Base G6 => GNPX_App_Man.G6;
        private G7_Base G7 => GNPX_App_Man.G7;


        private GNPX_Graphics gnpxGrp => pGNPX_App.gnpxGrp;

        public UPuzzle ePZL {
            get => pGNPX_Eng.ePZL; set => pGNPX_Eng.ePZL = value;
        } // Puzzle to analyze

        //		private bool				InPreparation=true;
        private List<RadioButton> PatSel_RBList = null;

        private RenderTargetBitmap bmpPD = new RenderTargetBitmap(176, 176, 96, 96, PixelFormats.Default);//176=18*9+2*4+1*6   
        
        private CancellationTokenSource  ctsG643=null;  // ctsAPQ = null;

        private MethodDisplayWin MthdWin;
        private Stopwatch        AnalyzerLap;
        private DispatcherTimer  statusDisplayTimer;
        private DispatcherTimer  timerShortMessage;

        private bool FirstB = true;

        //Automatic Puzzle Generation
        // 1) Generate a Latin Square
        // 2) Apply a mask (LS')
        // 3) Select a unique LS' Puzzle (a non-unique LS' is not a Sudoku Puzzle)
        // 4) Solve with GNPX

        //  Multiple threads that generate LatinSquare(LS) and a thread that solves it with GNPX run in parallel.
        //    The thread solving in GNPX is always in a waiting state.
        //    Using queue.

        public Func_CreateAuto( GNPX_App_Man GNPX_App ){
            pGNPX_App = GNPX_App;
            InitializeComponent();

            lbl_ShortMessage.Visibility = Visibility.Hidden;
            UC_SBoard.pGNPX_App = pGNPX_App;

            Send_Command_to_GNPXwin += new GNPX_EventHandler(pGNP00win.GNPX_Event_Handling_man);

            #region Timer
            AnalyzerLap = new Stopwatch();
            statusDisplayTimer = new DispatcherTimer(DispatcherPriority.Normal, this.Dispatcher);
            statusDisplayTimer.Interval = TimeSpan.FromMilliseconds(50);
            statusDisplayTimer.Tick += new EventHandler(statusDisplayTimer_Tick);

            timerShortMessage = new DispatcherTimer(DispatcherPriority.Normal);
            timerShortMessage.Interval = TimeSpan.FromMilliseconds(50);
            timerShortMessage.Tick += new EventHandler(timerShortMessage_Tick);
            #endregion

            G6.TLoopCC = 0; //::::::::::::::::::::::::::::: Currently checking operation

            //@@			btn_PatternClear_Click( this, null );	// Initial pattern settings
            txb_ElapsedTimeTS3.Text = "0";
        }

        private void Page_Loaded(object sender, RoutedEventArgs e ){

            G6.PG6Mode = GetType().Name;

            //　Pattern Clear(Run once at first)
            if(FirstB){
                FirstB = false;
                UC_SBoard.btn_PatternClear_Click(this, new RoutedEventArgs());
            }

            #region PatSel
            if(PatSel_RBList == null) {
                PatSel_RBList = (List<RadioButton>) GNPX_Utilitie.GetControlsCollection<RadioButton>(this); // Create list of "Pattern Buttons"
                PatSel_RBList = PatSel_RBList.FindAll(P => P.Name.Contains("rdb_patSel"));
            }

            string patN = $"{G6.PatSel0X:00}";
            RadioButton rdb = PatSel_RBList.Find(P => P.Name.Replace("rdb_patSel", "") == patN);
            if(rdb != null) rdb.IsChecked = true;
            #endregion

            nud_Puzzle_LevelLow.Value = G6.Puzzle_LevelLow;
            nud_Puzzle_LevelHigh.Value = G6.Puzzle_LevelHigh;

            string culture = App_Environment.culture;
            //WriteLine( $"Page_IsVisibleChanged => culture is {culture}");

            txb_GenPar00.Text = "0";
            txb_GenPar01.Text = G6.GenPar00[1].ToString();
            txb_GenPar10.Text = "0";
            txb_GenPar11.Text = G6.GenPar00[3].ToString();
            txb_GenPar21.Text = G6.GenPar00[4].ToString();

            chbx_RandomizingDigits.IsChecked = G6.Digits_Randomize;
            chbx_FileOutputOnSuccess.IsChecked = G6.Save_CreatedPuzzle;
            MthdWin_Control(winDisp: G6.MethodWinShow);

            int diff = pGNPX_App.Get_Difficulty_SolverList_App();

            chb_Only_LS.IsChecked = false;
            chb_Only_LS.Visibility = Visibility.Hidden;
            lbl_GenMessage.Content = "";

            if( G6.zPowerUserCC > 30 ){ // [Research] Private. GIDOO code only. Searching for the limits of Sudoku.
                chb_Only_LS.Visibility = Visibility.Visible;
                chb_Only_LS.IsChecked = G6.Only_LS;
            }

            prgbar_OnWork.Visibility = Visibility.Hidden;
            prgbar_OnWork.IsEnabled = false;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e ){
            MthdWin.Close();
            G6.Puzzle_LevelLow = nud_Puzzle_LevelLow.Value;
            G6.Puzzle_LevelHigh = nud_Puzzle_LevelHigh.Value;

            G6.Save_CreatedPuzzle = (bool)chbx_FileOutputOnSuccess.IsChecked;
            G6.Digits_Randomize = (bool)chbx_RandomizingDigits.IsChecked;
            statusDisplayTimer.Stop();
        }

        #region UI Controls
        private void btn_ShowMethodList_Click(object sender, RoutedEventArgs e ){
            if(MthdWin == null) MthdWin_Control();
            MthdWin.Visibility = (MthdWin.Visibility == Visibility.Hidden) ? Visibility.Visible : Visibility.Hidden;
        }

        private void MthdWin_Control(bool winDisp = true ){
            MthdWin = new MethodDisplayWin(pGNP00win);
            MthdWin.Left = pGNP00win.Left + pGNP00win.Width;
            MthdWin.Top = pGNP00win.Top;
            MthdWin.Height = pGNP00win.Height;
            MthdWin.Visibility = (winDisp) ? Visibility.Visible : Visibility.Hidden;
        // if( winDisp ) MthdWin.Show();
        }


        #endregion UI Controls

      #region service 
        private void btn_EmergencySave_Click(object sender, RoutedEventArgs e ){
            var eLS = ePZL.BOARD.ConvertAll(q => Max(q.No, 0) + ((q.c == 8) ? " " : ""));
            string line = string.Join("", eLS).Replace("0", ".");
            line += DateTime.Now.ToString("yyyyMMdd_hhMM");

            string dirError = "Algorithm_Error";
            if(!Directory.Exists(dirError))
                Directory.CreateDirectory(dirError);

            string fNameEmergency = dirError + "/" + "Emergency.txt";
            Utility_Display.GNPX_StreamWriter(fNameEmergency, line, append: true);

            shortMessage("_emargency save done ", new sysWin.Point(40, 5), Colors.DarkOrange, 2000);
        }
      #endregion service


      #region Timer (shortMessage,statusDisplay)
        // <<< ShortMessage >>>
        private void timerShortMessage_Tick(object sender, EventArgs e ){
            lbl_ShortMessage.Visibility = Visibility.Hidden;
            timerShortMessage.Stop();
        }

        private void shortMessage(string st, sysWin.Point pt, Color cr, int tm) {
            if(tm == 9999) timerShortMessage.Interval = TimeSpan.FromSeconds(5);
            else           timerShortMessage.Interval = TimeSpan.FromMilliseconds(tm);

            this.Dispatcher.Invoke(( ) => {
                lbl_ShortMessage.Content = st;
                lbl_ShortMessage.Foreground = new SolidColorBrush(Colors.White);
                lbl_ShortMessage.Background = new SolidColorBrush(cr);
                lbl_ShortMessage.Margin = new Thickness(pt.X, pt.Y, 0, 0);
                lbl_ShortMessage.Visibility = Visibility.Visible;
            });

            Thread.Sleep(tm);
            timerShortMessage.Start();
        }

        private void statusDisplayTimer_Tick(object sender, EventArgs e ){
            txb_ElapsedTimeTS3.Text = AnalyzerLap.Elapsed.TimespanToString();
            lbl_GenMessage.Content = G6.GenMessage;

            txb_GenPar00.Text = G6.GenPar00[0].ToString();
            txb_GenPar10.Text = G6.GenPar00[2].ToString();
            LS_Queue_Solving.Content = G6.LS_Queue;

            string stLS = $"{G6.Info_CreateMessage0}\n {G6.Info_CreateMessage1}\n {G6.Info_CreateMessage2}\n {G6.Info_CreateMessage3}";
            int lapMSec = ((int)AnalyzerLap.ElapsedMilliseconds) / 50;

            //if( G7.g7_GNPX_Solving is false )  LS_Queue_Solving.Content = ""; 

            if(Lbl_QueSize != null && Pzl_Analysis_Supp.QuePuzzle != null)  Lbl_QueSize.Content = $"Queue Count:\n        {Pzl_Analysis_Supp.QuePuzzle.Count}";
        }
      #endregion Timer (shortMessage,statusDisplay)


      #region Event Processing
        private void Send_SetPuzzleOnBoard( ) {
            Gidoo_EventHandler se = new Gidoo_EventHandler(eName: "Show_AnalysisStatus");  //Report
            Send_Command_to_GNPXwin(this, se);
        }

        // <<< Event Receiver >>>
        public void GNPX_Event_Handling_man(object sender, Gidoo_EventHandler e ){

            switch(e.eName ){
                case "PuzzleCreated":
                    Dispatcher.Invoke(( ) => txb_NoOfPuzzles.Text = e.ePara1.ToString());
                    shortMessage($" {e.ePara1} / {e.ePara0} found  ", new sysWin.Point(320, 15), Colors.Blue, tm: 500);
                    // Updates and displays of the main board (UC_PB_GBoard) are done by the main window.
                    break;

                case "ChangedPattern":
                    shortMessage($"Changed Pattern.", new sysWin.Point(30, 170), Colors.DarkBlue, 500);
                    this.Dispatcher.Invoke(( ) => UC_SBoard.SetBitmap_PB_pattern = true);
                    break;

                case "Force_ChangePattern":
                    if(ctsG643 == null || ctsG643.IsCancellationRequested)  break;

                    shortMessage($"Changed Pattern.", new sysWin.Point(30, 170), Colors.DarkBlue, 500);
                    this.Dispatcher.Invoke(( ) => UC_SBoard.btn_PatternAutoGen_Click(this, new RoutedEventArgs()));
                    Thread.Sleep(1);
                    this.Dispatcher.Invoke(( ) => UC_SBoard.SetBitmap_PB_pattern = true);
                    G6.LS_PatternChangeCommand = true;
                    break;

                case "ChangedFrame12347":
                    this.Dispatcher.Invoke(( ) => UC_SBoard.Reflesh_PB_BasePatDig_Prop = true);
                    break;


                case "ShortMessage":
                    shortMessage(e.gsm.Message, e.gsm.Pt, e.gsm.color, e.gsm.msec);
                    break;

                case "SystemError":
                    shortMessage(e.Message, new sysWin.Point(400, 180), Colors.Orange, 3000);
                    break;

                default:
                    shortMessage("System error. Undefined event.", new sysWin.Point(100, 200), Colors.DarkRed, 10000);
                    break;
                    // ( In other thread control, "Dispatcher.Invoke" is need! )
            }

            if(statusDisplayTimer.IsEnabled == false)
            statusDisplayTimer.Start();
        }
      #endregion Event Processing


        private async void btn_CreatePuzzleAuto_G643_Click(object sender, RoutedEventArgs e ){
            if(ctsG643 == null)  ctsG643 = new CancellationTokenSource();

            // <<< suspend >>>
            if( _IsSuspend() is false ){
                prgbar_OnWork.Visibility = Visibility.Hidden;
                prgbar_OnWork.IsEnabled = false;
                return;
            }
            
            prgbar_OnWork.Visibility = Visibility.Visible;
            prgbar_OnWork.IsEnabled = true;

            // At the start, check that 1) a pattern has been set, and 2) the number of pattern cells is 17 or more.
            if( _Checking_initial_conditions() is false )  return;

            _Setting_Search_Conditions();

            // Generate puzzles in a separate thread
            // ===== [1] GNPX solver startup
            if( !G6.Only_LS ){ // (In LS generation mode, GNPXsolver does not start.)
                Pzl_Analysis_Supp.QuePuzzle = new Queue<LatinSquare_9x9>();   // ###Queue	
                Task tSolver = Task.Run(( ) => Pzl_Analysis_Supp.GNPX_Solver_using_Queue(ctsG643));       // GNPX solver
            }

            // ===== [2] GNPX solver startup
            await Task.Run(( ) => Pzl_Analysis_Supp.task_GNPX_PuzzleCreatorAuto_QueB_new(this, ctsG643) );   // Sequential processing of create and solve

            _task_End();

            if( G6.SolutionCounter > G6.NoOfPuzzlesToCreate ){
                shortMessage("Generate puzzles exceeding the specified number.", new sysWin.Point(200,70), Colors.Blue, 1500);
            }

            return;
            // ------------------------------------------------------------------------------------------------------------------------

              #region  inner functions
                    bool _IsSuspend( ) {
                        if( (string)btn_CreatePuzzleAuto_G643.Content != pRes.btn_CreatePuzzleAuto ){    //Suspend
                            if( ctsG643 != null )  ctsG643.Cancel();                                    // Cancel using the "cts" set at the start of creation.
                            btn_CreatePuzzleAuto_G643.Content = pRes.btn_CreatePuzzleAuto;
                            _LPostProcessing();     //<<< process end >>>
                            return false;
                        }
                        return true;
                    }

                    bool _Checking_initial_conditions( ) {
                        int nn = Pzl_Analysis_Supp.PatGen.Count();
                        if( nn == 0 ){   // If no pattern is set, it will be set automatically.
                            UC_SBoard.btn_PatternAutoGen_Click(this, new RoutedEventArgs());
                            nn = Pzl_Analysis_Supp.PatGen.Count();
                        }

                        if( nn < 17 ){   // If the hint digits for the Puzzle is less than 17, it is not a valid Sudoku Puzzle.
                            if( G6.zPowerUserCC < 20 ){ // "Power mode+" disables this condition.
                                shortMessage("Not enough patterns.(n<17)", new sysWin.Point(5, 230), Colors.Orange, 3000);
                                if(ctsG643 != null) ctsG643.Cancel();
                                _LPostProcessing();     //<<< process end >>>
                                return false;
                            }
                        }

                        if( pGNPX_App.SolverList_GNPX.Count <= 1) {
                            shortMessage("No solving method is set.", new sysWin.Point(50, 20), Colors.Orange, 5000);
                            btn_ShowMethodList_Click(this, new RoutedEventArgs());
                            _LPostProcessing();     //<<< process end >>>

                        }

                        if( G6.GenPar00[1]<=0 || G6.GenPar00[3]<=0 ){
                            shortMessage("The generation conditions are inappropriate.", new sysWin.Point(50, 20), Colors.Orange, 5000);
                            _LPostProcessing();     //<<< process end >>>
                            return false;
                        }

                        return true;
                    }

                    void _Setting_Search_Conditions( ){
                        G6.taskCompInfo = null;
                        G6.LoopCC = 0;
                        G6.PatternCC = 0;

                        G6.SolutionCounter = 0;
                        G6.NoOfPuzzlesToCreate = int.Parse(No_PuzzlesToCreate.Text);
                        G6.Search_AllSolutions = false;
                        G6.Digits_Randomize = (bool)chbx_RandomizingDigits.IsChecked;
                        G6.Puzzle_LevelLow = (int)nud_Puzzle_LevelLow.Value;
                        G6.Puzzle_LevelHigh = (int)nud_Puzzle_LevelHigh.Value;

                        G6.GenPar00[1] = int.Parse(txb_GenPar01.Text);
                        G6.GenPar00[3] = int.Parse(txb_GenPar11.Text);

                        btn_CreatePuzzleAuto_G643.Content = pRes.msgSuspend;
                        txb_NoOfPuzzles.Text = "0";

                                G7.AnalyzingMethod = null;      // (Hide the running algorithm display.)
                                AnalyzerBaseV2.__SimpleAnalyzerB__ = true;

                        statusDisplayTimer.Start();
                        AnalyzerLap.Start();
                    }

                    void _task_End( ){
                        // --- task end ---  @@pattern
                        if(ctsG643 == null || ctsG643.IsCancellationRequested || G6.SolutionCounter >= G6.NoOfPuzzlesToCreate ){
                            if(G6.SolutionCounter < G6.NoOfPuzzlesToCreate ){
                                G6.taskCompInfo = "Canceled";
                                shortMessage("Cancellation accepted", new sysWin.Point(300,70), Colors.DarkOrange, 1500);
                            }

                            AnalyzerBaseV2.__SimpleAnalyzerB__ = false;
                            _LPostProcessing();
                            return;
                        }
                        else  G6.taskCompInfo = "Complated";
                        //----------------------------------------------------------------------------------------------

                        if(G6.SolutionCounter >= 1) {
                            string stCreated = $"Create {G6.SolutionCounter} Puzzles";
                            shortMessage(stCreated, new sysWin.Point(90, 5), Colors.Crimson, 5000);
                        }
                        else if(G6.LS_P_P2 >= G6.LS_Pattern_Cntrl_P2) {
                            shortMessage("Pattern change", new sysWin.Point(90, 5), Colors.Crimson, 1000);
                        }

                        // <<< Post Processing >>>
                        _LPostProcessing();
                    }

                    void _LPostProcessing( ) {
                        pGPDM.v7_current_Puzzle_No = int.MaxValue;  // Set to last Puzzle in list.			
                        Send_SetPuzzleOnBoard();

                        statusDisplayTimer.Stop();
                        AnalyzerLap.Stop();

                        btn_CreatePuzzleAuto_G643.Content = pRes.btn_CreatePuzzleAuto;
                        if( ctsG643 != null ){
                            ctsG643.Cancel();
                            Thread.Sleep(1);
                        }
                        if( !G6.Only_LS ) Pzl_Analysis_Supp.QuePuzzle.Clear();
                        Lbl_QueSize.Content = " ";

                        statusDisplayTimer.Stop();
                        AnalyzerLap.Stop();
            
                        prgbar_OnWork.Visibility = Visibility.Hidden;
                        prgbar_OnWork.IsEnabled = false;        

                        ctsG643 = null;
                        lbl_ShortMessage.IsEnabled = false;
                    }
                #endregion  inner functions
        }


        // ::::::::::::::::::::::::::::::::::: CreateAuto_new :::::::::::::::::::::::::::::::::::

        private void nud_Puzzle_LevelLow_ValueChanged(object sender, GIDOOEventArgs args) {
            if(nud_Puzzle_LevelLow == null) return;
            int Lval = (int)nud_Puzzle_LevelLow.Value, Uval = (int)nud_Puzzle_LevelHigh.Value;
            if( Lval > Uval )  nud_Puzzle_LevelHigh.Value = Lval;
        }
        private void nud_Puzzle_LevelHigh_ValueChanged(object sender, GIDOOEventArgs args) {
            if(nud_Puzzle_LevelHigh == null) return;
            int Lval = (int)nud_Puzzle_LevelLow.Value, Uval = (int)nud_Puzzle_LevelHigh.Value;
            if( Uval < Lval )  nud_Puzzle_LevelLow.Value = Uval;
        }

        private void chb_Only_LS_Checked(object sender, RoutedEventArgs e ){
            if(chb_Only_LS == null)  return;
            G6.Only_LS = (bool)chb_Only_LS.IsChecked;

            nud_Puzzle_LevelLow.IsEnabled = G6.Only_LS;
            nud_Puzzle_LevelHigh.IsEnabled = G6.Only_LS;
            lbl_PuzzleLevel.IsEnabled = G6.Only_LS;
        }

        private void txb_GenPar01_TextChanged(object sender, TextChangedEventArgs e ){
            try {
                G6.GenPar00[1] = int.Parse(txb_GenPar01.Text);
            }
            catch(Exception){ }
        }

        private void txb_GenPar11_TextChanged(object sender, TextChangedEventArgs e ){
            try {
                G6.GenPar00[3] = int.Parse(txb_GenPar11.Text);
            }
            catch(Exception){ }
        }
        private void txb_GenPar21_TextChanged(object sender, TextChangedEventArgs e ){
            try {
                G6.GenPar00[4] = int.Parse(txb_GenPar21.Text);
            }
            catch(Exception){ }
        }

        private void chbx_FileOutputOnSuccess_Checked( object sender, RoutedEventArgs e ){
            if( chbx_FileOutputOnSuccess == null )  return;
            G6.Save_CreatedPuzzle = (bool)chbx_FileOutputOnSuccess.IsChecked;
        }
        private void chbx_RandomizingDigits_Checked( object sender, RoutedEventArgs e ){
            G6.Digits_Randomize = (bool)chbx_RandomizingDigits.IsChecked;
        }

        private void No_PuzzlesToCreate_TextChanged( object sender, TextChangedEventArgs e ){
            try {
                G6.NoOfPuzzlesToCreate = int.Parse(No_PuzzlesToCreate.Text);
            }
            catch(Exception ex) { No_PuzzlesToCreate.Text = "5"; }
        }
    }
}
