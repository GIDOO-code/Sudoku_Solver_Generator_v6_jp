﻿using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

using GNPX_DLX2;

using static System.Math;
//using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space {
    using System.Globalization;
    using System.Runtime.CompilerServices;
    using System.Text;

    using GIDOO_space;

    using Microsoft.Win32;

    using STD_SDK;

    using pGPDM = GNPX_Puzzle_Database_Manager;
    using pRes = Properties.Resources;
    using sysWin = System.Windows;

    public partial class Func_CreateAuto3 : Page {
        static public event GNPX_EventHandler Send_Command_to_GNPXwin;

        static public GNPX_App_Man  pGNPX_App;
        private GNPX_win            pGNP00win{ get=>pGNPX_App.pGNP00win; }
//	    private PuzzleFile_IO		fPuzzleFile_IO => pGNPX_App.PuzzleFile_IO;
//      private List<v7_UPuzzle_Base> pGNPX_PUZZLE_List => pGPDM.v7_GNPX_Puzzle_List;
//      public GNPX_Puzzle_Analysis_Support        Pzl_Analysis_Supp => pGNPX_App.Pzl_Analysis_Supp;
//        private GNPX_Engin          pGNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine
        private G6_Base G6 => GNPX_App_Man.G6;
//      private G7_Base G7 => GNPX_App_Man.G7;

		public  Puzzle_17cell_Explore  Pzl17Exp = new();
	
        private CancellationTokenSource  cts = new();
        private Stopwatch        AnalyzerLap;

        private DispatcherTimer  statusDisplayTimer;
        private DispatcherTimer  timerShortMessage;

        public Func_CreateAuto3( GNPX_App_Man GNPX_App ){
            pGNPX_App = GNPX_App;
            InitializeComponent();

            lbl_ShortMessage.Visibility = Visibility.Hidden;
            Send_Command_to_GNPXwin += new GNPX_EventHandler(pGNP00win.GNPX_Event_Handling_man);

          #region Timer
            AnalyzerLap = new Stopwatch();
            statusDisplayTimer = new DispatcherTimer(DispatcherPriority.Normal, this.Dispatcher);
            statusDisplayTimer.Interval = TimeSpan.FromMilliseconds(250);
            statusDisplayTimer.Tick += new EventHandler(statusDisplayTimer_Tick);

            timerShortMessage = new DispatcherTimer(DispatcherPriority.Normal);
            timerShortMessage.Interval = TimeSpan.FromMilliseconds(50);
            timerShortMessage.Tick += new EventHandler(timerShortMessage_Tick);
          #endregion

        }       

        private void Page_Loaded(object sender, RoutedEventArgs e ){
            G6.PG6Mode = GetType().Name;
            string culture = App_Environment.culture;
            prgbar_OnWork_1.Visibility = Visibility.Hidden;
            prgbar_OnWork_1.IsEnabled = false;

            if( G6.CreateAuto2_Puzzlis == null )  G6.CreateAuto2_Puzzlis = new int[14];
        }


      #region Timer (shortMessage,statusDisplay)
        // <<< ShortMessage >>>
        private void timerShortMessage_Tick(object sender, EventArgs e ){
            lbl_ShortMessage.Visibility = Visibility.Hidden;
            timerShortMessage.Stop();
        }

        private void shortMessage(string st, sysWin.Point pt, Color cr, int tm) {
            if(tm == 9999) timerShortMessage.Interval = TimeSpan.FromSeconds(5);
            else           timerShortMessage.Interval = TimeSpan.FromMilliseconds(tm);

            this.Dispatcher.Invoke(( ) => {
                lbl_ShortMessage.Content = st;
                lbl_ShortMessage.Foreground = new SolidColorBrush(Colors.White);
                lbl_ShortMessage.Background = new SolidColorBrush(cr);
                lbl_ShortMessage.Margin = new Thickness(pt.X, pt.Y, 0, 0);
                lbl_ShortMessage.Visibility = Visibility.Visible;
            });

            Thread.Sleep(tm);
            timerShortMessage.Start();
        }



        private void statusDisplayTimer_Tick(object sender, EventArgs e ){
            if( G6.CreateAuto2_Puzzlis == null )  return;
            var DicDLX = new Dictionary<string,string>();
            for( int k=17; k<=30; k++ )  DicDLX[$"{k,7}"] = $"{G6.CreateAuto2_Puzzlis[k-17],7}";
           int total = G6.CreateAuto2_Puzzlis.Sum();
            DicDLX[$"  total"] = $"{total,7}";
 
            lv_DLX_Soluttions.ItemsSource = DicDLX.ToList();

            var (ncNew,ncCandidate,ncTrials,nCount) = Puzzle_17cell_Explore.progressCounters;

		    Lbl_onCresting.Content = $"{ncNew} / {ncCandidate} / {ncTrials} / {nCount}";
			Lbl_onWork.Content = _stElapRem( nCount, ncTrials, AnalyzerLap.Elapsed );
        }

       	private string _stElapRem( int numAll, int numCur, TimeSpan lapCur ){
			if( numCur <= 0 )  return "";
			var lapT = lapCur * numAll / numCur;
			string st = $"Lap: {lapCur.TimespanToString(stUnit:true)} + {(lapT-lapCur).TimespanToString(stUnit:true)}";
			return st;
		}
      #endregion Timer (shortMessage,statusDisplay)


      #region Event Processing
        private void Send_SetPuzzleOnBoard( ) {
        Gidoo_EventHandler se = new Gidoo_EventHandler(eName: "Show_AnalysisStatus");  //Report
        Send_Command_to_GNPXwin(this, se);
        }

        // <<< Event Receiver >>>
        public void GNPX_Event_Handling_man(object sender, Gidoo_EventHandler e ){

            switch(e.eName ){

                case "PuzzleCreated":
                    shortMessage($" {e.ePara1} / {e.ePara0} found  ", new sysWin.Point(320, 15), Colors.Blue, tm: 500);
                    break;

                case "ShortMessage":
                    shortMessage(e.gsm.Message, e.gsm.Pt, e.gsm.color, e.gsm.msec);
                    break;

                case "SystemError":
                    shortMessage(e.Message, new sysWin.Point(400, 180), Colors.Orange, 3000);
                    break;

                default:
                    shortMessage("System error. Undefined event.", new sysWin.Point(100, 200), Colors.DarkRed, 10000);
                    break;
            }

            if(statusDisplayTimer.IsEnabled == false)
            statusDisplayTimer.Start();
        }

        #endregion Event Processing

        private async void btn_Create_Puzzle_X_Click(object sender,RoutedEventArgs e) {
			statusDisplayTimer.Start();

            AnalyzerLap.Reset();
            AnalyzerLap.Start();
            
			prgbar_OnWork_1.IsEnabled = true;
			prgbar_OnWork_1.Visibility = Visibility.Visible;

            bool autoSaveB = (bool)chbx_File_AutoSave.IsChecked;
            
            int N = 0;
            if( (bool)rdb_solver_1.IsChecked ) N = 1;
            if( (bool)rdb_solver_2.IsChecked ) N = 2;
            if( (bool)rdb_solver_3.IsChecked ) N = 3;

            await Task.Run(() => Pzl17Exp.Test_Nx_Replace_Cells( N:N, autoSaveB, cts.Token ) );

			statusDisplayTimer.Stop();
			prgbar_OnWork_1.IsEnabled = false;
			prgbar_OnWork_1.Visibility = Visibility.Hidden;

            var (ncNew,ncCandidate,ncTrials,nCount) = Puzzle_17cell_Explore.progressCounters;

		    Lbl_onCresting.Content = $"{ncNew} / {ncCandidate} / {ncTrials} / {nCount}";
			Lbl_onWork.Content = _stElapRem( nCount, ncTrials, AnalyzerLap.Elapsed );

            txb_Message_1.Text = $"-{N}+{N}\nDerived Puzzle:{ncCandidate}\n  Known Puzzle:{ncCandidate-ncNew}\n    New Puzzle:{ncNew}";
        }
        
        private void chbx_File_AutoSave_Checked(object sender,RoutedEventArgs e){
            if( chbx_File_AutoSave == null )  return;
            G6.CreateAuto2_Save_auto = (bool)chbx_File_AutoSave.IsChecked;
        }

        private void btn_sdk_2520_cancel_1_Click(object sender,RoutedEventArgs e) {
            statusDisplayTimer.Stop();
            AnalyzerLap.Stop();

            cts.Cancel();

            prgbar_OnWork_1.Visibility = Visibility.Hidden;
            prgbar_OnWork_1.IsEnabled = false;
        }
    }
}
