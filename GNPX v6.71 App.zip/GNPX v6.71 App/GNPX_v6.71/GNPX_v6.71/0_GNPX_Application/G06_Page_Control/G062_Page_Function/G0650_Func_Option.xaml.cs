﻿using GIDOO_space;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using static System.Diagnostics.Debug;
using static System.Math;
using System.Threading;
//using System.Windows.Threading;

namespace GNPX_space{
	using pRes = Properties.Resources;
	using ioPath = System.IO.Path;

    public partial class Func_Option: Page{
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 

		public GNPX_App_Man 		pGNPX_App;

		private GNPX_Setting_Editor GNPX_Setting_Win;
		public GNPX_win				pGNP00win => pGNPX_App.pGNP00win;

		public GNPX_Puzzle_Analysis_Support        Pzl_Analysis_Supp => pGNPX_App.Pzl_Analysis_Supp;

		private G6_Base				G6 => GNPX_App_Man.G6;
        private GNPX_Engin			GNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine																				 
		private GNPX_AnalyzerMan	pAnMan => GNPX_Eng.AnMan;
		private GNPX_Graphics		gnpxGrp => pGNPX_App.gnpxGrp;
		private RenderTargetBitmap  bmpGZeroA;

		public UPuzzle				ePZL{ get=>GNPX_Eng.ePZL; set=>GNPX_Eng.ePZL=value; } // Puzzle to analyze

        public Func_Option( GNPX_App_Man GNPX_App){
			pGNPX_App = GNPX_App;

            InitializeComponent();
			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  

			lbl_ProcessorCount.Content = $"ProcessorCount : {Environment.ProcessorCount:N0}";
			bmpGZeroA = new ( 338, 338, 96,96, PixelFormats.Default );
        }

		private void Page_Loaded(object sender, RoutedEventArgs e ){
			G6.PG6Mode = GetType().Name;
			txb_RandomSeed_000.Text = G6.RandomSeedVal_000.ToString();
			int val = G6.RandomSeedVal_000;
			G6.RandomSeedVal_000 = val;
            Pzl_Analysis_Supp.Set_RandomSeed(val);

			chbx_MousePosition_at_Startup.IsChecked = G6.MousePposition_at_Startup;

			txb_Proc_Utilization_per.TextChanged -= new TextChangedEventHandler( txb_randomSeed_000_TextChanged );
			txb_Proc_Utilization_per.Text = G6.Processor_Utilization.ToString();
			txb_Proc_Utilization_per.TextChanged += new TextChangedEventHandler( txb_randomSeed_000_TextChanged );

			btn_CopySolution.Opacity = G6.zPowerUser? 1.0: 0.01;

			chbx_ShowCandidate.IsChecked = G6.sNoAssist;

			PowerUser_OnOff();

			Save_XMLFile_AnalysisConditions();
		}

		private void Page_Unloaded(object sender, RoutedEventArgs e ){
			Save_XMLFile_AnalysisConditions();
		}


		private void Save_XMLFile_AnalysisConditions(){
			if( pGNPX_App != null )  pGNPX_App.fPuzzleFile_IO.WriteXMLFile_AnalysisConditions_MethodList();
		}



		private void btn_PowerUser_Click(object sender, RoutedEventArgs e ){
			Thread.Sleep(200);

			lbl_PowerUser.Visibility = Visibility.Visible;

			if( btn_PowerUser.Opacity<0.5 ){
				grd_zPowerUser.Opacity = 1.0;
				G6.zPowerUserCC = 1;
			}
			else{ G6.zPowerUserCC += 6; }

			PowerUser_OnOff();

			Save_XMLFile_AnalysisConditions();
        }

		private void PowerUser_OnOff(){
			if( --G6.zPowerUserCC > 0 ){
				grd_zPowerUser.Opacity   = 1.0;
				lbl_GNPX_Setting.Opacity = 1.0;
				btn_GNPX_Setting.Opacity = 1.0;

				Gidoo_EventHandler se = new Gidoo_EventHandler( eName:"G6_Changed" );  //Report
				Send_Command_to_GNPXwin( this, se );
			}
			else{
				grd_zPowerUser.Opacity   = 0.05;
				lbl_GNPX_Setting.Opacity = 0.05;
				btn_GNPX_Setting.Opacity = 0.05;
			}
			txb_PowerCC.Text = $"{G6.zPowerUserCC}";
		}


		private void btn_LangageSelect_Click(object sender, RoutedEventArgs e ){
			string lng = (string)((Button)sender).Content;
			string culture = (lng=="Japanese")? "ja-JP": "en-US";
			ResourceService.Current.ChangeCulture(culture);
			App_Environment.culture = culture;
        
			WriteLine( $"Option The current culture is {culture}");

			{
				//    __bruMoveSub();			
				Gidoo_EventHandler se = new Gidoo_EventHandler( eName:"Vibrate!" );  //Report
				Send_Command_to_GNPXwin( this, se );
			}

		//	txtCopyrightDisclaimer.Text = CopyrightJP;		
        //    _MethodSelectionMan();
			Save_XMLFile_AnalysisConditions();
        }

		private void txb_randomSeed_000_TextChanged(object sender, TextChangedEventArgs e ){
			if( txb_RandomSeed_000 == null )  return;

			string st = txb_RandomSeed_000.Text;
			int val = 0;
			try{ val  = int.Parse(st); }
			catch( Exception ex ){ 
				val = 0;
				txb_RandomSeed_000.TextChanged -= new TextChangedEventHandler( txb_randomSeed_000_TextChanged );
				txb_RandomSeed_000.Text = "0";
				txb_RandomSeed_000.TextChanged += new TextChangedEventHandler( txb_randomSeed_000_TextChanged );
			}
			G6.RandomSeedVal_000 =  int.Parse( txb_RandomSeed_000.Text );
            Pzl_Analysis_Supp.Set_RandomSeed(val);

			Save_XMLFile_AnalysisConditions();
		}
		
		private void btn_CopySolution_Click(object sender, RoutedEventArgs e ){
			try{
				List<UCell> board = Get_Solution();
				int nc = board.Count(p=>p.No>0);
				if( nc < 17 )  return;
				
				string st = board.ConvertAll(q=> Abs(q.No)).Connect("").Replace("0",".");
				Clipboard.Clear();
				Clipboard.SetData(DataFormats.Text, st);
				texb_bitmapPath.Text = $"Puzzle Solution\n{st}";
			}
			catch( Exception e2 ){ WriteLine( $"{e2.Message}\n{e2.StackTrace}" ); }
		}

		public void btn_CopyBitMap_Click(object sender, RoutedEventArgs e ){
            try{
				bool sNoAssist  = G6.sNoAssist;
				bool sWhiteBack = G6.sWhiteBack;
				G6.sNoAssist  = (bool) chbx_ShowCandidate.IsChecked;
				G6.sWhiteBack = (bool)chbx_WhiteBack.IsChecked;

				List<UCell> BOARD = (bool)chbx_SetAnswer.IsChecked? Get_Solution(): ePZL.BOARD;
				var bmf = gnpxGrp.GBoardPaint( bmpGZeroA, BOARD,  sNoAssist:G6.sNoAssist, whiteBack:G6.sWhiteBack );

                Clipboard.SetData(DataFormats.Bitmap,bmf);

				G6.sNoAssist = sNoAssist;
				G6.sWhiteBack = sWhiteBack;
            }
            catch(System.Runtime.InteropServices.COMException){  }
		}


		public void btn_SaveBitMap_Click(object sender, RoutedEventArgs e ){
            BitmapEncoder enc = new PngBitmapEncoder(); // JpegBitmapEncoder(); BmpBitmapEncoder();

			bool sNoAssist  = G6.sNoAssist;
			bool sWhiteBack = G6.sWhiteBack;

			G6.sNoAssist  = (bool) chbx_ShowCandidate.IsChecked;
			G6.sWhiteBack = (bool)chbx_WhiteBack.IsChecked;

			List<UCell> BOARD = (bool)chbx_SetAnswer.IsChecked? Get_Solution(): ePZL.BOARD;
			var bmp = gnpxGrp.GBoardPaint( bmpGZeroA, BOARD,  sNoAssist:G6.sNoAssist, whiteBack:G6.sWhiteBack );
            var bmf = BitmapFrame.Create(bmp);
            enc.Frames.Add(bmf);
            try {
                Clipboard.SetData(DataFormats.Bitmap,bmf);
            }
            catch(System.Runtime.InteropServices.COMException){  }

            if( !Directory.Exists( pRes.fldSuDoKuImages) ){ Directory.CreateDirectory(pRes.fldSuDoKuImages); }
            string fName = DateTime.Now.ToString("yyyyMMdd_HHmmss")+".png";
            using( Stream stream = File.Create(pRes.fldSuDoKuImages+"/"+fName) ){
                enc.Save(stream);
            }    
            texb_bitmapPath.Text = "Path : "+ioPath.GetFullPath( pRes.fldSuDoKuImages+"/"+fName);
				
			G6.sNoAssist = sNoAssist;
			G6.sWhiteBack = sWhiteBack;
		}


        private List<UCell> Get_Solution(){
			Research_trial RTrial = new( );
			List<int> intBoard = ePZL.BOARD.ConvertAll( P=> P.No ); 
			List<string> stList = RTrial.TrialAndErrorApp( intBoard, filePutB:true, upperLimit:2 );

			List<UCell>  board = (stList.Count==1)? RTrial.RT_Get_Board(): null;
			return board;
        }



		private void lbl_GNPX_Setting_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e ){
			lbl_GNPX_Setting.Opacity = 1.0;
			btn_GNPX_Setting.Opacity = 1.0;
        }
		private void btn_GNPX_Setting_Click(object sender, RoutedEventArgs e ){
			GNPX_Setting_Win = new GNPX_Setting_Editor( pGNP00win );
			GNPX_Setting_Win.Show();
		}

		private void chbx_ShowCandidate_Checked(object sender, RoutedEventArgs e ){
			G6.sNoAssist = (bool)chbx_ShowCandidate.IsChecked;
			Save_XMLFile_AnalysisConditions();
		}
/*
		private void txb_Proc_Utilization_per_TextChanged(object sender, TextChangedEventArgs e ){
			if( txb_Proc_Utilization_per == null )  return;

			string st = txb_Proc_Utilization_per.Text;
			double val = 0;
			try{ val  = double.Parse(st); }
			catch( Exception ex ){ 
				txb_Proc_Utilization_per.TextChanged -= new TextChangedEventHandler( txb_randomSeed_000_TextChanged );
				txb_Proc_Utilization_per.Text = "0.7";
				txb_Proc_Utilization_per.TextChanged += new TextChangedEventHandler( txb_randomSeed_000_TextChanged );
			}
			val  = double.Parse(st);
			val = Min( Max( val, 0.9 ), 0.2 );
			G6.Processor_Utilization =  val;
        }
*/
		private void txb_Proc_Utilization_per_KeyUp(object sender, System.Windows.Input.KeyEventArgs e ){
			if( txb_Proc_Utilization_per == null )  return;
			if( e.Key != System.Windows.Input.Key.Enter )  return;

			string st = txb_Proc_Utilization_per.Text;
			double val = double.Parse(st); 
/*
			try{ val  = double.Parse(st); }
			catch( Exception ex ){ 
				txb_Proc_Utilization_per.TextChanged -= new TextChangedEventHandler( txb_randomSeed_000_TextChanged );
				txb_Proc_Utilization_per.Text = "0.7";
				txb_Proc_Utilization_per.TextChanged += new TextChangedEventHandler( txb_randomSeed_000_TextChanged );
			}
*/
			val = Min( Max( val, 0.2 ), 0.9 );
			G6.Processor_Utilization =  val;
			Save_XMLFile_AnalysisConditions();
		}

        private void chbx_MousePosition_at_Startup_Checked(object sender,RoutedEventArgs e) {
			G6.MousePposition_at_Startup = (bool)chbx_MousePosition_at_Startup.IsChecked;
			Save_XMLFile_AnalysisConditions();
        }
    }
}
