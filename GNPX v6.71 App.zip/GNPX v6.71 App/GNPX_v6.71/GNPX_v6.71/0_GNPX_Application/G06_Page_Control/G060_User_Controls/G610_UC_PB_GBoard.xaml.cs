﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using GIDOO_space;

using GNPX_space;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using static System.Net.Mime.MediaTypeNames;

	using pApEnv = App_Environment;	
	using pGPDM  = GNPX_Puzzle_Database_Manager;
	using sysWin = System.Windows;


    public partial class UC_PB_GBoard: UserControl{
		
		static public GNPX_App_Man   pGNPX_App;

        private  GNPX_Engin		 	 pGNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine
		private G6_Base			     G6 => GNPX_App_Man.G6;
		private  GNPX_Graphics       gnpxGrp => pGNPX_App.gnpxGrp;

		private  UPuzzle			 ePZL => pGNPX_Eng.ePZL;
		private  RenderTargetBitmap  bmpGZeroA;

	    // ----- Extend -----
        private ExtendResultWin	 	 ExtResultWin;


        // Entering numbers into the board is handled by UC_PB_GBoard (UserControl).
		public   int rc;

        public UC_PB_GBoard(){
            InitializeComponent();	          
			bmpGZeroA = new ( (int)imgPB_GBoard.Width, (int)imgPB_GBoard.Height, 96,96, PixelFormats.Default );
        }


		public void Set_Puzzle( v7_UPuzzle_Base bPZL, bool setImage=true ){
            UPuzzle ePzl = new( bPZL );
            pGNPX_Eng.ePZL = ePzl;
            if( setImage )  Set_imgPB_GBoard( ePZL );
		}

		public void Set_Puzzle( UPuzzle aPZL, bool setImage=true ){
            pGNPX_Eng.ePZL = aPZL;
            if( setImage )  Set_imgPB_GBoard( aPZL );

            // PrintBoard( aPZL.BOARD, "Func_CreateManual" );
		}

        private static void PrintBoard( List<UCell> BOARD, string st="" ){
            string line = $"{st}\n";
            for( int r=0; r<9; r++ ){
                for( int c=0; c<9; c++ ){
                    line += $"{(BOARD[r*9+c].No)} ";
                }
                WriteLine( line.Replace("0",".") );
                line = "";
            }
        }

		public void Set_imgPB_GBoard( UPuzzle aPZL ){
			
            pGNPX_Eng.ePZL = aPZL;

			imgPB_GBoard.Source = gnpxGrp.GBoardPaint( bmpGZeroA, aPZL.BOARD, sNoAssist:G6.sNoAssist, whiteBack:G6.sWhiteBack );
			var (_,nP,nZ,nM)  = Aggregate_CellsPZM(aPZL.BOARD);

			txb_Puzzle.Text   = nP.ToString();
			txb_Unsolved.Text = nZ.ToString();
			txb_Solved.Text   = nM.ToString();
			nud_difficultyLevel.Text = aPZL.difficultyLevel.ToString();

			grd_overLap.Visibility = (GNPX_Graphics.overlaped)? Visibility.Visible : Visibility.Collapsed;
        }

        private (bool,int,int,int) Aggregate_CellsPZM( List<UCell> aBOARD ){
            int P=0, Z=0, M=0;
            if( aBOARD==null )  return (false,P,Z,M);
            aBOARD.ForEach( q =>{
                if(q.No>0)      P++;
                else if(q.No<0) M++;
                else            Z++;
            } );

            return  (Z==0,P,Z,M);
        }



        private int     rowMemo; 
        private int     colMemo;
        private int     noPMemo;

		private void imgPB_GBoard_MouseLeftButtonDown( object sender, MouseButtonEventArgs e ){				// --- Down (first)
            var (noP,r,c) = _Get_PB_GBoardRCNumSmall( );
			if( noP <= 0 )  return;			

			rc = r*9+c;
            noPMemo=noP; rowMemo=r; colMemo=c;

		  //if( G6.P01_mode == "Create#CreateManual")  _img_PadManager( r, c, noP); 
			if( G6.PG6Mode == "Func_CreateManual" )	_img_PadManager( r, c, noP); 
			if( G6.PG6Mode == "Func_Transform"    ) G6.Cell_rc = rc;
        }
		

		// {Att] While specifying the digits, the iPad will be displayed at the top of the board,
		//       so the "Move" and "Up" events are set to the iPad.
        private void img_Pad_MouseMove( object sender, MouseEventArgs e ){								// --- Move (change)
//		    if( G6.P01_mode != "Create#CreateManual") return;
			if( G6.PG6Mode != "Func_CreateManual" )  return;

			try{
				var (noP,r,c) = _Get_PB_GBoardRCNumSmall( );
				if( noP < 0 ) return;

				if( noP!=noPMemo || r!=rowMemo || c!=colMemo ){ 
					noPMemo=noP; rowMemo=r; colMemo=c;
					_img_PadManager(r,c,noP);	//Redraw img_Pad when selection changes
						//WriteLine( $"+++ img_Pad_MouseMove (noP,r,c):({noP},{r},{c})" );
				}
			}
			catch(Exception e2){ WriteLine( $"{e2.Message}\n{e2.StackTrace}" );}
        }  

		private void img_Pad_MouseLeftButtonUp( object sender, MouseButtonEventArgs e ){				// --- Up (Confirm)	
//			if( G6.P01_mode != "Create#CreateManual") return;
			if( G6.PG6Mode != "Func_CreateManual" )  return;

			var (noP,r,c) = _Get_PB_GBoardRCNumSmall( );
			if( noP < 0 ) return;
            if( noP!=noPMemo ){ noPMemo=noP; _img_PadManager(r,c,noP); }
                    //WriteLine( $"img_Pad_MouseLeftButtonUp (noP,r,c):({noP},{r},{c})" );

            if(noP<=0){
                img_Pad.Visibility = Visibility.Hidden;
                rowMemo=-1; colMemo=-1;
                return;
            }
            if( r!=rowMemo || c!=colMemo ) return;

            UCell BDX = ePZL.BOARD[rowMemo*9+colMemo];
            if( Abs(BDX.No) == noP )  BDX.No=0;			//Cancel selected digit.
            else{
                if( ((BDX.FreeB>>(noP-1))&1) == 0 )  return;
                else{ BDX.No = noP; }
            }

            pGNPX_Eng.AnMan.ResetAnalysisResult( clear0:true );

            img_Pad.Visibility = Visibility.Hidden;
            rowMemo=-1; colMemo=-1;

            Set_Puzzle( ePZL );
        }

        private void _img_PadManager( int r, int c, int noP ){              //Draw img_Pad
            noPMemo = noP;
			img_Pad.Source = null;
            img_Pad.Source = gnpxGrp.Create_Cell_Image_Light( ePZL.BOARD[r*9+c], noP );
            int PosX = (int)imgPB_GBoard.Margin.Left +2 +37*c +(int)c/3;
            int PosY = (int)imgPB_GBoard.Margin.Top  +2 +37*r +(int)r/3;        
            img_Pad.Margin = new Thickness(PosX, PosY, 0,0 );        
            img_Pad.Visibility = Visibility.Visible;           
        }    

        private (int,int,int)   _Get_PB_GBoardRCNumSmall( ){
            int cSz = pApEnv.cellSize, LWid = pApEnv.lineWidth;

            int r0=-1, c0=-1;
            sysWin.Point pt = Mouse.GetPosition(imgPB_GBoard);
            int cn = (int)pt.X-2,  rn = (int)pt.Y-2;

            cn = cn - cn/cSz - cn/(cSz*3+LWid)*LWid;
            c0 = cn/cSz;
            cn = (cn%cSz)/12;
            if( cn<0 || cn>=3 || c0<0 || c0>=9 ){ r0=c0=-1;  return (-1,-1,-1); }
            
            rn = rn - rn/cSz - rn/(cSz*3+LWid)*LWid;
            r0 = rn/cSz;
            rn = (rn%cSz)/12;
            if(rn<0 || rn>=3 || r0<0 || r0>=9){ r0=c0=-1;  return (-1,-1,-1); }

			int n0 = rn*3+cn+1; 
            return ( n0, r0, c0);
        }

		//private void imgPB_GBoard_PreviewKeyDown(object sender, KeyEventArgs e ){
		//	WriteLine( "imgPB_GBoard_PreviewKeyDown" );
		//}
	}
}