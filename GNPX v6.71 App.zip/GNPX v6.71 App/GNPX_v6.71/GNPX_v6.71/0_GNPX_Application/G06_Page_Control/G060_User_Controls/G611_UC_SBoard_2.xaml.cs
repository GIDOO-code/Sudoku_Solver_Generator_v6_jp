﻿using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace GNPX_space{
//	
//	using static System.Net.Mime.MediaTypeNames;
	using sysWin = System.Windows;
	//	using pGPDM  = GNPX_Puzzle_Database_Manager;
	using pApEnv = App_Environment;
	public partial class G611_UC_SBoard_2 : UserControl {

		public GNPX_App_Man 		pGNPX_App;
		public GNPX_Puzzle_Analysis_Support        Pzl_Analysis_Supp => pGNPX_App.Pzl_Analysis_Supp;

		public static readonly DependencyProperty TitleProperty =
			DependencyProperty.Register( nameof(Title), typeof(string), typeof(G611_UC_SBoard_2), new PropertyMetadata(string.Empty) );
		 public string Title {
			get => (string)GetValue(TitleProperty);
			set => SetValue(TitleProperty, value);
		}
			
        private GNPX_Engin			pGNPX_Eng => pGNPX_App.GNPX_Eng;                      //Analysis Engine
		public UPuzzle				ePZL{ get=>pGNPX_Eng.ePZL; set=>pGNPX_Eng.ePZL=value; } // Puzzle to analyze
		private G6_Base				G6 => GNPX_App_Man.G6;

		private GNPX_Graphics		gnpxGrp => pGNPX_App.gnpxGrp;
        private RenderTargetBitmap  bmpPD = new RenderTargetBitmap(176,176, 96,96, PixelFormats.Default);//176=18*9+2*4+1*6     

		public G611_UC_SBoard_2( ) {
			InitializeComponent();
		}

		private void UserControl_2_Loaded(object sender, RoutedEventArgs e ){			

		}

		private void rdb_patSel0X_Checked(object sender, RoutedEventArgs e ){
			if( rdb_patSel00 == null )  return;
			RadioButton　rdb = (RadioButton)sender;
			if( (bool)rdb.IsChecked ) G6.PatSel0X = int.Parse( rdb.Name.Replace("rdb_patSel","" ) );//  Substring(10,2) );
		}

	}
}
