﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Windows.Media;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Security.Policy;
using System.Data;
using System.Text;
using System.Windows.Media.Animation;
using System.Windows.Documents;
using static GNPX_space.Research_trial;

namespace GNPX_space{
	// Reference to SudokuCoach.
	// https://www.taupierbw.be/SudokuCoach/SC_Exocet.shtml 


	static public partial class G6_staticFunctions{   

	    static private readonly UInt128 qZero   = UInt128.Zero;
        static private readonly UInt128 qOne    = UInt128.One;
	    static private readonly UInt128 qMaxB81 = (UInt128.One<<81)-qOne;
        static private readonly UInt128 _b9     = 0x1FF;
		static public  readonly UInt128 _na_    = UInt128.MaxValue;
		static private readonly int     _na9_   = (1<<9)-1;

		static private readonly char[]  _sep=new Char[]{ ' ', ',', '\t' };
		static public List<UCell>   pBOARD;

	//	static public int DRCHf( this (int,int) Q )		   => (Q.Item1==0)? (Q.Item2)/9: (Q.Item2)%9+9;	// ... 
		static public int DRCHf( this (int,int) Q )		   => Q.DirRCtoHouse();	// ... Abbreviations
		static public int DirRCtoHouse( this (int,int) Q ) => (Q.Item1==0)? (Q.Item2)/9: (Q.Item2)%9+9;




		static public int ToRCBFrame( this UInt128 Q )    => Q.IEGet_rc().Aggregate( 0, (a,rc) => a| rc.ToRCBFrame() ); 
		
		static public int Get_FreeB_or( this UInt128 B )  => B.IEGet_UCell(pBOARD).Aggregate( 0, (a,uc) => a | uc.FreeB );

		static public string Get_FreeBFixedDigitsString( this UInt128 B ) => "#" + (B.IEGet_UCell(pBOARD).Aggregate(0, (a,uc)=> a| (uc.No!=0? (1<<(Abs(uc.No)-1)): uc.FreeB))).TBScmp();
		static public int Get_FreeB_Efective_or( this UInt128 B )  => B.IEGet_UCell(pBOARD).Aggregate( 0, (a,uc) => a | (uc.FreeB & ~uc.CancelB) );
		static public int Get_FreeB_and( this UInt128 B ) => B.IEGet_UCell(pBOARD).Aggregate( 0, (a,uc) => a & uc.FreeB );


		static public int Get_FixedFreeB( this int rc, bool diffCan=false ){
			UCell U = pBOARD[rc];
			if( U.No != 0 ){ return  1<<(Abs(U.No)-1); }
			else{ 
				int FB = U.FreeB;
				if(diffCan) FB &= ~U.CancelB;
				return FB;
			}
		}
		static public int Get_FixedFreeB( this UInt128 B, bool diffCan=false ){
			return  B.IEGet_rc().Aggregate( 0, (a,rc) => a| rc.Get_FixedFreeB(diffCan) );
		}

		static public (int,int) Get_FreeB_Single_More( this UInt128 B ){
			int oneF=0, twoF=0;
			foreach( var U in B.IEGet_UCell(pBOARD) ){
				int F = U.FreeB;
				twoF |= oneF & F;			// exist in more than one place
				oneF |= F;					// exist somewhere
			}
			return (oneF & ~twoF, twoF);		// only one
		}






		static 	public void __MatrixPrint( this UInt128 Flag, UInt128 BP0, string message ){
			int[] FlagArray = Flag.ToArray();
			int[] BPArray0 = BP0.ToArray();

			WriteLine( message.____splitPad27( ) );
			for(int r0=0; r0<81; r0+=9){
				string st = $"   r{r0/9+1:##0}|{____MatrixToLine(r0,FlagArray,BPArray0)}";
				WriteLine(st);
			}
		}

		static 	public void __MatrixPrint( this UInt128 Flag, UInt128 BP0, UInt128 BP1, string message ){
			int[] FlagArray = Flag.ToArray();
			int[] BPArray0 = BP0.ToArray();
			int[] BPArray1 = BP1.ToArray();
			
			WriteLine( message.____splitPad27( ) );
			for(int r0=0; r0<81; r0+=9){
				string stR = $"   r{r0/9+1:##0}|";
				string st = $"{stR}{____MatrixToLine(r0,FlagArray,BPArray0)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray1)}";
				WriteLine(st);
			}
		}

		static 	public void __MatrixPrint( this UInt128 Flag, UInt128 BP0, UInt128 BP1, UInt128 BP2, string message ){
			int[] FlagArray = Flag.ToArray();
			int[] BPArray0 = BP0.ToArray();
			int[] BPArray1 = BP1.ToArray();
			int[] BPArray2 = BP2.ToArray();

			WriteLine( message.____splitPad27( ) );
			for(int r0=0; r0<81; r0+=9){
				string stR = $"   r{r0/9+1:##0}|";
				string st = $"{stR}{____MatrixToLine(r0,FlagArray,BPArray0)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray1)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray2)}";
				WriteLine(st);
			}
		}

		static 	public void __MatrixPrint( this UInt128 Flag, UInt128 BP0, UInt128 BP1, UInt128 BP2, UInt128 BP3, string message ){
			int[] FlagArray = Flag.ToArray();
			int[] BPArray0 = BP0.ToArray();
			int[] BPArray1 = BP1.ToArray();
			int[] BPArray2 = BP2.ToArray();
			int[] BPArray3 = BP3.ToArray();

			WriteLine( message.____splitPad27( ) );
			for(int r0=0; r0<81; r0+=9){
				string stR = $"   r{r0/9+1:##0}|";
				string st = $"{stR}{____MatrixToLine(r0,FlagArray,BPArray0)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray1)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray2)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray3)}";
				WriteLine(st);
			}
		}

		static 	public void __MatrixPrint( this UInt128 Flag, UInt128 BP0, UInt128 BP1, UInt128 BP2, UInt128 BP3, UInt128 BP4, string message ){
			int[] FlagArray = Flag.ToArray();
			int[] BPArray0 = BP0.ToArray();
			int[] BPArray1 = BP1.ToArray();
			int[] BPArray2 = BP2.ToArray();
			int[] BPArray3 = BP3.ToArray();
			int[] BPArray4 = BP4.ToArray();

			WriteLine( message.____splitPad27( ) );
			for(int r0=0; r0<81; r0+=9){
				string stR = $"   r{r0/9+1:##0}|";
				string st = $"{stR}{____MatrixToLine(r0,FlagArray,BPArray0)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray1)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray2)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray3)}";
					  st += $"{stR}{____MatrixToLine(r0,FlagArray,BPArray4)}";
				WriteLine(st);
			}
		}

		static private string ____splitPad27( this string st, int spN=7 ){ // Split the title of the debug matrix display.
			List<string> eList = st.Split(_sep,StringSplitOptions.RemoveEmptyEntries).ToList().ConvertAll(p=>p.PadRight(27) );
			string stTmp = "\n" + (new string(' ',spN)) + string.Join("      ",eList);
			return  stTmp;
		}


		static string  ____MatrixToLine( int r0, int[] FlagArray, int[] BPArray ){
			string st="";
			for(int c=0; c<9; c++){
				int p = BPArray[r0+c];
				st += (FlagArray[r0+c]!=0)? " *": "  ";
				st += (p==0)? ".": (c+1).ToString("#");
			}
			return st;
		}

/*
		static 	public void _Dynamic_CellsPrint_withFrame( this List<UCell> Cells, string[] Marks, string message="", int width=9 ){
			WriteLine(message);
			//	string stLine3 = new string('-', (width+3)*3-1 );
			//string stLine = $"*{stLine3}*{stLine3}*{stLine3}*";

			string[][] stDD = new string[9][];
			int[]	   colSize = new int[9]; 
			for( int r=0; r<9; r++ )  stDD[r] = ___D_CellToLinet_wF(r*9,Cells, Marks,  width:width);
			
			string  stLine = "*";
			for( int c=0; c<9; c++ ){
				int sz=0;
				for( int r=0; r<9; r++ )  sz = Max( sz, stDD[r][c].Length );
				colSize[c] = sz;
				stLine += new string('-',sz+4);
				stLine += (c%3==2)? "*": "-";
			}


			for(int r=0; r<9; r++){
				if( (r%3)==0 ) WriteLine(stLine);
				string st = "| ";
				for( int c=0; c<9; c++ ){
					int n = colSize[c]+1;
					st += " " + stDD[r][c].PadRight(n);
					st += (c%3==2)? " | ": "   ";
				}
				WriteLine(st);
			}
			WriteLine(stLine);
			return;

				string[]  ___D_CellToLinet_wF( int r0, List<UCell> Cells, string[] Marks, int width=9 ){
					string[] stD = new string[9];
					string st="";
					for(int c=0; c<9; c++){
						string stCell = "";
						UCell P = Cells[r0+c];
						if( P.No!=0 ){
							int no = P.No;
							stCell += (no<0)? $"-<{Abs(no)}>-": $"{Abs(no)}";  
						}
						else{ stCell += P.FreeB.TBSnD(); }
						if( Marks!=null && Marks.Length==81 ){
							string stMark = Marks[r0+c];
							if( stMark!=null && stMark!="" )  stCell += " "+stMark;
						}
						stD[c] = stCell;
					}
					st += " |";
					return stD;
				}
		}
*/


	}

}