using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Threading;
using System.Runtime.ConstrainedExecution;

using Simon_Squared;
using System.Security.Policy;

namespace GNPX_space {

    public partial class AnalyzerBaseV2{
        static public readonly UInt128 qZero   = UInt128.Zero;				
        static public readonly UInt128 qOne    = UInt128.One;
	    static public readonly UInt128 qMaxB81 = (UInt128.One<<81)-qOne;
        static public readonly UInt128 _b9     = 0x1FF;
		static public readonly UInt128 _na_    = UInt128.MaxValue;

        static public readonly int frame_R = 0x1FF;
		static public readonly int frame_C = 0x1FF<<9;
		static public readonly int frame_B = 0x1FF<<18;



        static public bool   __SimpleAnalyzerB__;
        static public int    __DebugBreak;
		static public G6_Base G6 => GNPX_App_Man.G6;
		static public G7_Base G7 => GNPX_App_Man.G7;

        private const int    S=1, W=2;

        static public UInt128[] qFreeCell81b9;

        static private GNPX_Engin pGNPX_Eng;
        public GNPX_AnalyzerMan   pAnMan;

		public int	eNdebug=0;

      // public CancellationToken cts => pGNPX_Eng.cts;
	  
		public string			AdditionalMessage{ set => G7.AdditionalMessage=value; } // @@@



        static public UInt128[] Connected_81 => GNPX_Utilitie.Connected_81;    //Connected Cells
        static public UInt128[] HouseCells81 => GNPX_Utilitie.HouseCells81;   //Row(0-8) Collumn(9-17) Block(18-26)
		static public int[]		Connected33  => GNPX_Utilitie.Connected33;
        static public int[]     Band_BlockB  => GNPX_Utilitie.Band_BlockB;



		private UInt128			_BOARD_Fixed81;				// These are reset before each step.  ... AnalyzerBaseV2_PrepareStage() 
		private UInt128			_BOARD_Free81;
		private UInt128[]?      _BOARD_Free81B9;	
		private UInt128[]?      _BOARD_FreeOrFixed81B9;


		public UInt128			BOARD_Fixed81  => qMaxB81 & ~BOARD_Free81;				   
        public UInt128			BOARD_Free81   => (_BOARD_Free81!=qZero)? _BOARD_Free81:( _BOARD_Free81=pBOARD.Create_Free_BitExp81() );
		public UInt128[]        BOARD_Free81B9 => _BOARD_Free81B9??  (_BOARD_Free81B9=pBOARD.Create_b081B9() );
		public UInt128[]        BOARD_FreeOrFixed81B9 => _BOARD_FreeOrFixed81B9?? (_BOARD_FreeOrFixed81B9=pBOARD.Create_b081B9( withFixedB:true ));
		public UInt128[]        BOARD_Fixed81B9 => pBOARD.Create_FixedBitExp81_9();

		public UInt128			BOARD_FixedB9_noB(int noB) => noB.IEGet_BtoNo().Aggregate(qZero, (a,no) => a |= BOARD_Fixed81B9[no] );
		public UInt128			BOARD_FreeB9_noB(int noB) => noB.IEGet_BtoNo().Aggregate(qZero, (a,no) => a |= BOARD_Free81B9[no] );


        public  GNPX_App_Man    pGNPX_App => pGNPX_Eng.pGNPX_App;
        
        public  UPuzzle         ePZL   => pGNPX_Eng.ePZL;  

        public List<UCell>      pBOARD => ePZL.BOARD;

        private int             stageNoPMemo_ApBV2 = -1;
        public  int             stageNo => ePZL.stageNo;
        public  int             stageNoP => pGNPX_Eng.stageNoP;//pGNPX_Eng.__stageNo100 + stageNo;

		protected string		TandE_st_Puzzle => pGNPX_Eng.TandE_st_Puzzle;
		protected int[]			TandE_sol_int81 => pGNPX_Eng.sol_int81;
		protected string		TandE_st_sol_int81 => pGNPX_Eng.TandE_st_sol_int81;

        public bool             Set_Solution_Info => G7.Set_Solution_Info;

        public int              SolCode{  get=>ePZL.SolCode; set=>ePZL.SolCode=value; }
        public string           Result{   get=>ePZL.Sol_Result; set=>ePZL.Sol_Result=value; }
        public string           ResultLong{ get=>ePZL.Sol_ResultLong; set=>ePZL.Sol_ResultLong=value; }

		public string           ResultHTML{ get=>ePZL.Sol_ResultHTML; set=>ePZL.Sol_ResultHTML=value; }

        public bool             chbx_ConfirmMultipleCells => G6.ConfirmMultipleCells;
               
		public void Clear_Analysis_results(){
			foreach( var UC in pBOARD.Where(p=>p.No==0) ) UC.CancelB=0;
			pBOARD.ForEach( UC => UC.ECrLst=null );
		}

		
//		public bool				PreferSimpleLinks = G6.PreferSimpleLinks > 0;
		public bool				Use_eALS=false;
     // public  bool            DebugSolCheck_Check => pGNPX_Eng.DebugSolCheck_Check();

		public string		    extResult{
									set{
										if( value=="" ) pBOARD.ForEach( P => P.Reset_result() ); //Clear all analysis results
										ePZL.extResult=value; 
									}
									get=> ePZL.extResult; }





    #region Display Control
		static public readonly Color[] PastelColors;

        static public readonly Color AttCr    = Colors.Red;
        static public readonly Color AttCr2   = Colors.SkyBlue;
        static public readonly Color AttCr3   = Colors.LightCoral;
        static public readonly Color AttCr4   = Colors.Gold;
		static public readonly Color AttCr5   = Colors.Blue;
		static public readonly Color AttCr6   = Colors.BlueViolet;

        static public readonly Color SolBkCr; 
        static public readonly Color SolBkCr2; 
        static public readonly Color SolBkCr3; 
        static public readonly Color SolBkCr4; 
        static public readonly Color SolBkCr5; 
        static public readonly Color SolBkCr6; 
    #endregion Display Control   



        static  AnalyzerBaseV2( ){


            __SimpleAnalyzerB__ = false;

			List<Color> _colors = new();
            _colors.Add( Colors.LightGreen );
            _colors.Add( Colors.LightYellow );
            _colors.Add( Colors.LightBlue );

            int cSize = 20;
            var PasCrls_random = Color_Library.Generate_Distinct_PastelColors(cSize, RandomizeB:true);
            foreach( var P in PasCrls_random )  _colors.Add( P );
            PastelColors = _colors.ToArray();

            SolBkCr   = PastelColors[0];
            SolBkCr2  = PastelColors[1];
            SolBkCr3  = PastelColors[2];
            SolBkCr4  = PastelColors[3];
            SolBkCr5  = PastelColors[4];
            SolBkCr6  = PastelColors[5];
        }

        public  AnalyzerBaseV2( ){}

        public  AnalyzerBaseV2( GNPX_AnalyzerMan pAnMan ){ 
            this.pAnMan = pAnMan;
            UCell.pAnMan = pAnMan;
            pGNPX_Eng = pAnMan.pGNPX_Eng;
			UAnLS.qAnalyzer = this;
        }

        public bool  AnalyzerBaseV2_PrepareStage(){		//
            if( stageNoP == stageNoPMemo_ApBV2 )  return false;
			stageNoPMemo_ApBV2 = stageNoP;

			// Disable at each stage
			_BOARD_Fixed81 = qZero;
			_BOARD_Free81  = qZero;
            _BOARD_Free81B9        = null;
			_BOARD_FreeOrFixed81B9 = null;		// for Exocet(V6)
        	
            G6_staticFunctions.pBOARD = pBOARD;
			return true;  
        }

		public UInt128 FreeCell81b9_FreeBAnd( int FreeB ){
			UInt128 b = UInt128.MaxValue;
			foreach( int no in FreeB.IEGet_BtoNo().Where(n =>(FreeB&(1<<n))>0) )  b &= BOARD_Free81B9[no];
			if( b==UInt128.MaxValue ) b=0;
			return b;
		}
        public (int,int) ToTuple1( int X ) => (X>>1,X&1);



	}
}