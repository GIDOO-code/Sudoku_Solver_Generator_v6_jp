using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space {

    public partial class AnalyzerBaseV2{


      // ::::: Single :::::
        public UInt128 _LastDigitT => Enumerable.Range(0,27).Aggregate(qZero, (a,h) => a |(BOARD_Free81&HouseCells81[h]).B81_IsSingle() );
  	    public UInt128 _NakedSingleT => BOARD_Free81.IEGet_rc().Where(rc=>pBOARD[rc].FreeBC==1).Aggregate(qZero, (a,rc)=> a|qOne<<rc );
        public UInt128 _HiddenSingleT( int no ) => Enumerable.Range(0,27).Aggregate(qZero, (a,h)=> a | (BOARD_Free81B9[no] & HouseCells81[h]).B81_IsSingle() );





/*
        public List<(int,int,int)> Func_GNPX_solver(){
            AnalyzerBaseV2_PrepareStage();

            List<(int,int,int)>  Sol_rc_TF = new();

            // single
            foreach( var uc in LastDigitT.IEGet_UCell(pBOARD) )    Sol_rc_TF.Add( (uc.rc, uc.FreeB.BitToNum()+1, -1) );
            foreach( var uc in NakedSingleT.IEGet_UCell(pBOARD) )  Sol_rc_TF.Add( (uc.rc, uc.FreeB.BitToNum()+1, -1) );
            for(int no=0; no<9; no++ ){
                foreach( var uc in __HiddenSingleT(no).IEGet_UCell(pBOARD) )  Sol_rc_TF.Add( (uc.rc, no+1, -1) );
            }

            return  Sol_rc_TF;
        }
*/
	}
}   