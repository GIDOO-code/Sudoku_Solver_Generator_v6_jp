using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Media;
using System.Threading;

using System.Security.Cryptography;
using System.Windows.Interop;
using System.IO;
using System.Text;
using static System.Diagnostics.Debug;
using static System.Math;
using System.Diagnostics;

using GIDOO_space;


namespace GNPX_space{
    using pRes=Properties.Resources;

    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

    // Analyzer Manager
    public partial  class GNPX_AnalyzerMan{
		static private G6_Base  G6 => GNPX_App_Man.G6;
		static private G7_Base  G7 => GNPX_App_Man.G7;
//		static public  UInt128 b081_all  = (UInt128.One<<81)-1;
//      static private Color CrBlack_=Colors.Black;


        private UInt128[]    pConnected_81 => GNPX_Utilitie.Connected_81;  //pConnectedCells81
//		private UInt128[]    pHouseCells81 => GNPX_Utilitie.HouseCells81; 





		private bool		 __SimpleAnalyzerB__ => AnalyzerBaseV2.__SimpleAnalyzerB__;

		public GNPX_App_Man  pGNPX_App => pGNPX_Eng.pGNPX_App;    
		


        public GNPX_Engin    pGNPX_Eng;
        //public v6_GNPX_Engin    v6_pGNPX_Eng;



        public  int          stageNoP	=> pGNPX_Eng.stageNoP;

		public UPuzzle		 ePZL		=> pGNPX_Eng.ePZL; 
		public int           stageNo	=> ePZL.stageNo;     
        public List<UCell>   pBOARD		=> ePZL.BOARD;
        public int           SolCode{	set =>ePZL.SolCode=value; }
        public string        Result{	set=>ePZL.Sol_Result=value; }
        public string        ResultLong{ set=>ePZL.Sol_ResultLong=value; }


		private int			stageNoPMemo=-1;

//        public TimeSpan     SdkExecTime;
//        private int[,]     Sol99sta{ get=> G6.Sol99sta; } //int[,]

            


        public  GNPX_AnalyzerMan( ){ }




/*
        public  GNPX_AnalyzerMan( v6_GNPX_Engin v6_pGNPX_Eng ){
            this.v6_pGNPX_Eng = v6_pGNPX_Eng;
            Define_Methods();
        }
*/





        public  GNPX_AnalyzerMan( GNPX_Engin GNPX_Eng ){
            this.pGNPX_Eng = GNPX_Eng;
            Define_Methods();
        }

        private void Define_Methods(){

          //================================================================================================
          //  UAlgMethod( int pid, string MethodName, int difficultyLevel, dSolver Method, bool GenLogB=false )
          //================================================================================================
		    List<UAlgMethod> _SolverLst_000 = new();

            var Single = new SimpleSingleGen(this);
            _SolverLst_000.Add( new UAlgMethod( 1, "LastDigit",			          1, Single.LastDigit ) );
            _SolverLst_000.Add( new UAlgMethod( 2, "NakedSingle",		          1, Single.NakedSingle ) );
            _SolverLst_000.Add( new UAlgMethod( 3, "HiddenSingle",		          1, Single.HiddenSingle ) );
  
			var LockedCand = new LockedCandidateGen(this);
            _SolverLst_000.Add( new UAlgMethod( 5, "LockedCandidate",	          2, LockedCand.LockedCandidate ) );

				//	var GLTechF = new GeneralLogicGen(this);  // ... ver.6.1  Destructively under consideration. Prohibits referencing
				//  _SolverLst_000.Add( new UAlgMethod( 4, " GeneralLogic",			2, GLTechF.GeneralLogic, true) );
				//	_SolverLst_000.Add( new UAlgMethod( 4, " GeneralLogic_120",		2, GLTechF.GeneralLogic_120, true) );
				//	_SolverLst_000.Add( new UAlgMethod( 4, " GeneralLogic_130",		2, GLTechF.GeneralLogic_130, true) );
				//	_SolverLst_000.Add( new UAlgMethod( 4, " GeneralLogic_131",		2, GLTechF.GeneralLogic_131, true) );
            

            var _LockedSet = new _LockedSetGen(this);
            _SolverLst_000.Add( new UAlgMethod( 10, "Naked__LockedSet",            3, _LockedSet.Naked__LockedSet ) );
            _SolverLst_000.Add( new UAlgMethod( 11, "Hidden__LockedSet",           3, _LockedSet.Hidden__LockedSet ) );

            var Fish = new FishGen(this);
            _SolverLst_000.Add( new UAlgMethod( 20, "Fish",                       4, Fish.Fish ) );
            _SolverLst_000.Add( new UAlgMethod( 21, "Finned_Fish",                5, Fish.Finned_Fish ) ); 
            _SolverLst_000.Add( new UAlgMethod( 22, "FishExt",                    6, Fish.FishExt ) );
            _SolverLst_000.Add( new UAlgMethod( 23, "Finned_FishExt",             7, Fish.Finned_FishExt ) ); 

            _SolverLst_000.Add( new UAlgMethod( 24, "Fish_FM",                    7, Fish.Fish_FM ) );          //Increase the difficulty level of FM-Fish.
            _SolverLst_000.Add( new UAlgMethod( 25, "Finned_Fish_FM",             8, Fish.Finned_Fish_FM ) ); 
            _SolverLst_000.Add( new UAlgMethod( 26, "FishExt_FM",                 8, Fish.FishExt_FM ) );
            _SolverLst_000.Add( new UAlgMethod( 27, "Finned_FishExt_FM",          9, Fish.Finned_FishExt_FM ) ); 
        
            _SolverLst_000.Add( new UAlgMethod( 28, "EndoFin_Fish",              10, Fish.EndoFin_Fish ) );
            _SolverLst_000.Add( new UAlgMethod( 28, "Finned_EndoFin_Fish",       11, Fish.Finned_EndoFin_Fish ) );
            _SolverLst_000.Add( new UAlgMethod( 29, "Cannibalistic_Fish",        10, Fish.CannibalisticFish ) );
             // Finned CannibalisticFish is fundamentally impossible.


            var nxgCellLink = new CellLinkGen(this);
            _SolverLst_000.Add( new UAlgMethod( 30, "Skyscraper",                 4, nxgCellLink.Skyscraper ) );
            _SolverLst_000.Add( new UAlgMethod( 31, "EmptyRectangle",             4, nxgCellLink.EmptyRectangle ) );	//New algorithm using bit representation    
            _SolverLst_000.Add( new UAlgMethod( 33, "Color_Trap",                 4, nxgCellLink.Color_Trap ) );
            _SolverLst_000.Add( new UAlgMethod( 34, "Color_Wrap",                 4, nxgCellLink.Color_Wrap ) );
            _SolverLst_000.Add( new UAlgMethod( 35, "MultiColor_Type1",           5, nxgCellLink.MultiColor_Type1 ) );
            _SolverLst_000.Add( new UAlgMethod( 36, "MultiColor_Type2",           5, nxgCellLink.MultiColor_Type2 ) );		
                                                                                 
            _SolverLst_000.Add( new UAlgMethod( 40, "XY_Wing",                    4, nxgCellLink.XY_Wing ) );  
            _SolverLst_000.Add( new UAlgMethod( 41, "W_Wing",                     4, nxgCellLink.W_Wing ) );	
            _SolverLst_000.Add( new UAlgMethod( 42, "RemotePai",                  4, nxgCellLink.RemotePair ) );  
            _SolverLst_000.Add( new UAlgMethod( 43, "X_Chain",                    5, nxgCellLink.X_Chain ) );
            _SolverLst_000.Add( new UAlgMethod( 44, "XY_Chain",                   5, nxgCellLink.XY_Chain ) ); 


            var AnLSTechP = new AnLSTechGen(this);
            _SolverLst_000.Add( new UAlgMethod( 50,  "SueDeCoq",                  6, AnLSTechP.SueDeCoq ) );		  // original code
			_SolverLst_000.Add( new UAlgMethod( 51,  "SueDeCoqEx1",               5, AnLSTechP.SueDeCoqEx1 ) );		  //   > ver.5
			_SolverLst_000.Add( new UAlgMethod( 52,  "SueDeCoqEx2",               6, AnLSTechP.SueDeCoqEx2 ) );
			_SolverLst_000.Add( new UAlgMethod( 53,  "Franken_SueDeCoqEx3",       7, AnLSTechP.Franken_SueDeCoqEx3 ) );
			_SolverLst_000.Add( new UAlgMethod( 54,  "Finned_SueDeCoqEx1",        5, AnLSTechP.Finned_SueDeCoqEx1 ) );
		 	_SolverLst_000.Add( new UAlgMethod( 55,  "Finned_SueDeCoqEx2",        6, AnLSTechP.Finned_SueDeCoqEx2 ) );
		 	_SolverLst_000.Add( new UAlgMethod( 56,  "Finned_Franken_SueDeCoqEx3",7, AnLSTechP.Finned_Franken_SueDeCoqEx3 ) );
																       

            var ALSTech = new ALSTechGen(this);	  // ALS solution for XYZ_Wing 	
            _SolverLst_000.Add( new UAlgMethod( 101, "XYZ_Wing_ALS",              5, ALSTech.XYZ_Wing_ALS ) );	// recommended
            _SolverLst_000.Add( new UAlgMethod( 102, "ALS_XZ",                    6, ALSTech.ALS_XZ ) );
            _SolverLst_000.Add( new UAlgMethod( 103, "ALS_XY_Wing",               7, ALSTech.ALS_XY_Wing ) );

		    _SolverLst_000.Add( new UAlgMethod( 105, "eALS_ChainA-Unique",       10, ALSTech.eALS_Chain_uniqueStemB ) );
		    _SolverLst_000.Add( new UAlgMethod( 105, "eALS_ChainA_UniqOverl",    10, ALSTech.eALS_Chain_uniqueStemB_Overlap ) );
		 // _SolverLst_000.Add( new UAlgMethod( 105, "eALS_ChainA_O",            10, ALSTech.eALS_Chain_Overlap ) );     
			_SolverLst_000.Add( new UAlgMethod( 105, "eALS_ChainA_Unlimited",    10, ALSTech.eALS_Chain_Unlimited ) );
                                                                                 
            _SolverLst_000.Add( new UAlgMethod( 106, "ALS_DeathBlossom",          8, ALSTech.ALS_DeathBlossom ) );     
            _SolverLst_000.Add( new UAlgMethod( 107, "ALS_DeathBlossomEx",       10, ALSTech.ALS_DeathBlossomEx ) );   
      
        
			var AHSTech = new AHSTechGen(this);                                  
			_SolverLst_000.Add( new UAlgMethod( 108, "AHS_XZ",				      6, AHSTech.AHS_XZ ) );				// AHS_XZ double ver. 6.0 -
                            
        
            var eNW_Tech = new ExtendedNetwork_App(this);                           
            _SolverLst_000.Add( new UAlgMethod( 110,  "eNW_NiceLoop",            11, eNW_Tech.eNW_NiceLoop)); 
																			       
            _SolverLst_000.Add( new UAlgMethod( 108,  "eNW_DeathBlossom",        11, eNW_Tech.eNW_DeathBlossom));
            _SolverLst_000.Add( new UAlgMethod( 120,  "eNW_FC_Cells",            11, eNW_Tech.eNW_FC_Cells));
            _SolverLst_000.Add( new UAlgMethod( 121,  "eNW_FC_House",            11, eNW_Tech.eNW_FC_House));
          //_SolverLst_000.Add( new UAlgMethod( 122,  "eNW_FC_Contradiction",    10, eNW_Tech.eNW_FC_Contradiction));
                                                                                
            _SolverLst_000.Add( new UAlgMethod( 130,  "eNW_ALS_Wing_2D",         11, eNW_Tech.eNW_ALS_Wing_2D ) );
            _SolverLst_000.Add( new UAlgMethod( 131,  "eNW_ALS_Wing_3D",         11, eNW_Tech.eNW_ALS_Wing_3D ) );        
            _SolverLst_000.Add( new UAlgMethod( 132,  "eNW_ALS_Wing_4D",         11, eNW_Tech.eNW_ALS_Wing_4D ) );
        																	    																			 
            _SolverLst_000.Add( new UAlgMethod( 206,  "eKrakenFish",             11, eNW_Tech.V7_Kraken_Fish));             // ▼deff 11->7
            _SolverLst_000.Add( new UAlgMethod( 206,  "Finned_eKrakenFish",      11, eNW_Tech.V7_Finned_Kraken_Fish)); 


			var SubsetTechP = new SubsetTechGen(this);  // under development (GNPXv5.1)
			_SolverLst_000.Add( new UAlgMethod( 140, "SubsetExclusion",           6, SubsetTechP.SubsetExclusion ) );
			_SolverLst_000.Add( new UAlgMethod( 141, "SubsetExclusionALS",        7, SubsetTechP.SubsetExclusion_ALS ) );

			var Firework_TechP = new Firework_TechGen(this);  // under development (GNPXv5.1)
			_SolverLst_000.Add( new UAlgMethod( 150, "Firework_Triple",           7, Firework_TechP.Firework_Triple ) );
			_SolverLst_000.Add( new UAlgMethod( 151, "Firework_Quadruple",        7, Firework_TechP.Firework_Quadruple ) );
			_SolverLst_000.Add( new UAlgMethod( 152, "Firework_WWing",            7, Firework_TechP.Firework_WWing ) );
			_SolverLst_000.Add( new UAlgMethod( 153, "Firework_LWing",            7, Firework_TechP.Firework_LWing ) );
			_SolverLst_000.Add( new UAlgMethod( 154, "Firework_ALP",              7, Firework_TechP.Firework_ALP ) );
			_SolverLst_000.Add( new UAlgMethod( 155, "Firework_DualALP",          7, Firework_TechP.Firework_DualALP ) );


			var Exocet_TechGen = new Exocet_TechGen(this);
			_SolverLst_000.Add( new UAlgMethod( 161, "Exocet_JE2",		          9, Exocet_TechGen.Exocet_JE2) );

			// If JE2++ is possible, Not have a solution at this moment(v6.3).
		//	_SolverLst_000.Add( new UAlgMethod( 161, "Exocet_JE2P",		          9, Exocet_TechGen.Exocet_JE2P) );	// JE2+, JE2++ // still unclear.	
		
			_SolverLst_000.Add( new UAlgMethod( 162, "Exocet_JE1",		          9, Exocet_TechGen.Exocet_JE1) );	
                                                                                  
			_SolverLst_000.Add( new UAlgMethod( 163, "Exocet",			         10, Exocet_TechGen.Exocet ) );		// Basic form of Senior Exocet
			_SolverLst_000.Add( new UAlgMethod( 164, "Exocet_Single",            10, Exocet_TechGen.Exocet_Single) );
			_SolverLst_000.Add( new UAlgMethod( 165, "Exocet_SingleBase",        10, Exocet_TechGen.Exocet_SingleBase) );
																			     
			_SolverLst_000.Add( new UAlgMethod( 166, "Exocet_FM",    	         10, Exocet_TechGen.Exocet_FM) );				// ver.6.00
			_SolverLst_000.Add( new UAlgMethod( 166, "Exocet_FM_Single",         10, Exocet_TechGen.Exocet_FM_Single) );		// ver.6.00
			_SolverLst_000.Add( new UAlgMethod( 166, "Exocet_FM_SingleBase",     10, Exocet_TechGen.Exocet_FM_SingleBase) );	// ver.6.00
																			     
		  //_SolverLst_000.Add( new UAlgMethod( 164, "Exocet_Complex",	         10, Exocet_TechGen.Exocet_Complex) );			// ver. 6.90 still unclear.
		  //_SolverLst_000.Add( new UAlgMethod( 164, "Exocet_Jelly",	         10, Exocet_TechGen.Exocet_Jelly) );			// ver. 6.90 still unclear.

			// MSLS ... under development
			var MSLS_TechGen = new MSLS_TechGen(this);
			_SolverLst_000.Add( new UAlgMethod( 170, "MultiSector_LockedSets",    9, MSLS_TechGen.Multi_Sector_Locked_Sets) );			
			_SolverLst_000.Add( new UAlgMethod( 171, "MSLS_SK_Loop",		      9, MSLS_TechGen.MSLS_SK_Loop) );	

			// PatternOverlayMethod_Man
			var POM_TechGen = new PatternOverlayMethod_Man(this);
			_SolverLst_000.Add( new UAlgMethod( 180, "POM_Rule1",                 9, POM_TechGen.POM_Rule1_all_no_Patten) );
            _SolverLst_000.Add( new UAlgMethod( 181, "POM_Rule2",                 9, POM_TechGen.POM_Rule2_Interactions) );  
            _SolverLst_000.Add( new UAlgMethod( 181, "POM_Rule2_LV2",             9, POM_TechGen.POM_Rule2_Lv2_Interactions) );          
            _SolverLst_000.Add( new UAlgMethod( 181, "POM_Rule3",                 9, POM_TechGen.POM_Rule3_NiceLoop_Contradiction) ); 

            //================================================================================================
            // Set the minimum difficulty level for Exocet development and PU.
    //        G7.g7_Develop_Exocet_difficulty = Max( _SolverLst_000.Min(p=>p.difficultyLevel), 9);
			//================================================================================================

		    _SolverLst_000.Sort( (a,b)=> (a.ID-b.ID) );

			pGNPX_App.SolverList_SysDef = _SolverLst_000;				
			//_SolverLst_000.ForEach( p=> WriteLine( p ) );
        }

    }
}