using System.Windows.Media;
using static System.Math;

namespace GNPX_space{
	public delegate bool dSolver();

    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
    public class UAlgMethod{

        static private  int     ID0=0;
		private G6_Base			G6        => GNPX_App_Man.G6;
        public int				ID{ get; set; }
		public int				pID;
		public string			MethodName{ get; set; }

		public bool				IsChecked{ get; set; }		// Algorithm validpublic string Signature{ get; set; }			



		public readonly dSolver Method;
        public readonly string	MethodKey;

        // For algorithms with negative levels, there are simpler conjugate algorithms.
        // If you just solve Sudoku, you don't need it. For example, the 5D-_LockedSet is conjugate with the 4D-_LockedSet.
        public readonly int		difficultyLevel=-1;     // Level of difficulty
        public readonly int     recommendLevel =-1;
        public int				UsedCC=0;				// Counter applied to solve one puzzle.

		public bool			    method_valid = true;	// Valid method    ... for development

        public bool			    GenLogB;				// method "GeneralLogic"
		public bool				developB;
		public bool				ID_caseGL;				// Low-level method to execute when GL is enabled.


	  // ===== <<<develop >>> =====
		public string		   NameM{ get => $"{Abs(difficultyLevel):00} {MethodName}"; }
		public string		   NameMA{ get; set; }


		public bool			   ErrorB;			// Flag if errorB
		public bool			   SuccessfulB;		// Flag if successful.
			// The algorithm is applied multiple times to find multiple solutions.
			// It is possible that the final trial will fail.
			// For this reason, this flag is set if the algorithm is successful at least once.
		
		
		public bool		       Sel_mark{ get; set; }	//������ focused methods ... for development,

		public Brush		   brshM{ get{
										Brush br = Abs(difficultyLevel)<=G6.Method_DifficultyLevel? Brushes.Lime: Brushes.White;
										if( Sel_mark )    br = Brushes.Orange;
										if( !IsChecked )  br = Brushes.White;
			return  br;
									}
									set{ }
		}
		public int			    sortKey => Sel_mark? ID: (Abs(difficultyLevel)<=G6.Method_DifficultyLevel? ID+100000: ID+200000); 
	  // ----- <<<develop >>> -----





        public UAlgMethod( ){ }

		public UAlgMethod( UAlgMethod P ){
			this.ID				 = P.ID;
            this.recommendLevel  = P.recommendLevel;   
								 
			this.Method			 = P.Method;
            this.MethodName		 = P.MethodName;
            this.difficultyLevel = P.difficultyLevel;     //Level of difficulty
			this.MethodKey		 = P.MethodKey;

            this.GenLogB		 = P.GenLogB;

		}
        public UAlgMethod( int pID, string MethodName, int difficultyLevel, dSolver Method, bool developB=false ){
			this.ID_caseGL	     = (pID<=4);
			this.pID			 = pID;
            this.ID              = pID*1000+(ID0++); //System default order.

			this.Method			 = Method;
            this.MethodName		 = MethodName;
            this.difficultyLevel = difficultyLevel;     //Level of difficulty
			this.MethodKey		 = ID.ToString().PadLeft(7) +difficultyLevel.ToString().PadLeft(2) +MethodName;

            this.GenLogB		 = MethodName.Contains("GeneralLogic");
			this.developB		 = developB;

			string _MethodNameA	 = MethodName;
			int n = _MethodNameA.IndexOf('_');
			NameMA = (n>0)? $"{_MethodNameA.Substring(0,n)}__{_MethodNameA.Substring(n)}": MethodName;
        }

		public void ResetSearch_Ccriteria(){
			SuccessfulB=false; ErrorB=false;
		}


        public override string ToString(){
			//string stMName = $" ID:{ID} {MethodName} (Lv.{difficultyLevel} cc:{UsedCC}) IsChecked:{IsChecked}";
			string stMName = $"{MethodName} (Lv.{difficultyLevel})";
            string st = stMName.PadRight(35);
            if( GenLogB ) st += " *** GeneralLogic:"+GenLogB.ToString();
            return st;
        }
    }

}