using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Media;
using System.Threading;
using static System.Diagnostics.Debug;
using static System.Math;
using System.Security.Cryptography;
using System.Windows.Interop;
using System.IO;
using System.Text;
using GIDOO_space;
using System.Diagnostics;

namespace GNPX_space{
    using pRes=Properties.Resources;

    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

    // Analyzer Manager
    public partial class GNPX_AnalyzerMan{

        private (int,string)  stageNo_MethodName=(-1,""); 
        private int methodCC = 0;
		public int  solutionC;

		public void stageNo_MethodName_Reset() => stageNo_MethodName=(-1,"");


		public bool IsContinueAnalysis( ){

			if( ePZL.BOARD.All(U=>U.FixedNo==0 && U.CancelB==0) ){
				WriteLine( $"\n\nGNPX Algorithm Logic Error :\n{Environment.StackTrace}\n" );
				throw new Exception( $"GNPX Algorithm Logic Error :\n{Environment.StackTrace}" ); // GNPX Algorithm Logic Error
			}


		    {//Analyzer Bug : Code style does not meet specifications
				if( ePZL is null )  return false;
				if( ePZL.Sol_ResultLong is null || ePZL.Sol_Result is null )  return false;   // ... interrupt
				if( ePZL.Sol_Result.Length < 5 ){ WriteLine( "... GNPX algorithm logic error\n{Environment.StackTrace}" ); return true; }
			}

			bool errorB = pGNPX_Eng.IsSolutionValid();	// @1022
			if( !errorB )  G7.AnalyzingMethod.ErrorB = true;
			if( !errorB && __SimpleAnalyzerB__ )  return false;

			G7.AnalyzingMethod.SuccessfulB = true;
			bool IsValid = SnapSaveGP(errorB);
			return IsValid;
		}








		public UPuzzle FirstpPZL(){
			//var pChild_PZLs = ePZL.Child_PZLs;
			if( ePZL.Child_PZLs==null || ePZL.Child_PZLs.Count==0 )  return null;
			return ePZL.Child_PZLs[0];
		}
/*
		public void Clear_Analysis_results(){
			foreach( var UC in pBOARD.Where(p=>p.No==0) ) UC.CancelB=0;
			pBOARD.ForEach( UC => UC.ECrLst=null );
		}
*/
        public bool SnapSaveGP( bool errorB, bool OmiteDuplicateSolutionB=true ){
            try{ 
                //var pChild_PZLs = ePZL.Child_PZLs;
                 ePZL.selectedIX = 0;
				 ePZL.pMethod = G7.AnalyzingMethod;	// pGNPX_Eng.


				// =====================================================================================================
				// Processing by solution type
				// <<< Single >>>
					if( G7.MltAnsSearch is false ){ //... Single Search
						ePZL.Child_PZLs.Add(ePZL); //In one-solution search, save the same Puzzle-object without copying
						G6.command_Analysis_Stop = true;
						//Clear_Analysis_results();
						return false;	//true;
					}


				// <<< Multiple >>>
					string __SolResultKey = $"{stageNoP}_{ePZL.Sol_ResultLong.Replace("\n"," ")}";
					var EAMethod = G7.AnalyzingMethod;				
					// Excluding the same solution
					if( OmiteDuplicateSolutionB && ePZL.Child_PZLs.Any(Q=>(Q.__SolResultKey==__SolResultKey)) ){					
						ePZL.ToPreStage( );
						// WriteLine( $"*** Redundant Solution Found in SnapSaveGP...  not unique solution : {__SolResultKey}" );
					} 
				
					
					// Save the copy of the solution
					else{		
						UPuzzle aPZLcopy = ePZL.Copy( ); //Copy at the same stage
						aPZLcopy.difficultyLevel = EAMethod.difficultyLevel;
						aPZLcopy.selectedIX = ePZL.Child_PZLs.Count;
						ePZL.Child_PZLs.Add(aPZLcopy);    // Save a copy.
						solutionC++;
						ePZL.ToPreStage( );           // Return the original to the state before analysis.
					}
				// =====================================================================================================



				{ // <<< Termination by number of solutions >>>
					if( ePZL.Child_PZLs.Count>=G6.MSlvr_MaxNoAllAlgorithm ){	// Reached the limit of multiple solutions searches.
						G6.stopped_StatusMessage = pRes.msgUpperLimitBreak; // Reached the limit of multiple solution searches.
						G6.command_Analysis_Stop = true;
						//Clear_Analysis_results();
						return false;   // ... Finish analysis
					}  

					// <<< Method-specific counter initialization >>>
					var Stage_Method = ( stageNo, EAMethod.MethodName ); // tuple:(stage,name)
					if( stageNo_MethodName!=Stage_Method || stageNoP!=stageNoPMemo ){
						stageNo_MethodName = Stage_Method;
						stageNoPMemo = stageNoP;
						methodCC = 0;       // Initialization of number of solutions per algorithm
					}
					int selExt = (G6.PG6Mode=="Func_SelectPuzzle" && EAMethod.Sel_mark)? 50: 1;
					bool ContinueAnalysisB = (++methodCC < (G6.MSlvr_MaxNoAlgorithm*selExt) );
					//Clear_Analysis_results();
					return ContinueAnalysisB;  
				}
            }
            catch(Exception e){ WriteLine( $"{e.Message}\n{e.StackTrace}"); }
			//Clear_Analysis_results();
            return false;   // ... interrupt
        }


        public bool Check_TimeLimit(){
			if( G6.PG6Mode.Contains("Func_Develop") )  return false;	// No time limit during development

            if( G7.MltAnsSearch is false )  return false;
            TimeSpan ts =  DateTime.Now - pGNPX_App.MultiSolve_StartTime;	// bag fix v5.96
            bool timeLimit = ts.TotalSeconds >= G6.MSlvr_MaxTime;
            if(timeLimit)  G6.stopped_StatusMessage = pRes.msgUpperLimitTimeBreak;
            return timeLimit;
        }


        //==========================================================
        public (bool,int,int,int) Aggregate_CellsPZM( List<UCell> aBOARD ){
            int P=0, Z=0, M=0;
            if( aBOARD==null )  return (false,P,Z,M);
            aBOARD.ForEach( q =>{
                if(q.No>0)      P++;
                else if(q.No<0) M++;
                else            Z++;
            } );

            return  (Z==0,P,Z,M);
        }



        public int Execute_Fix_Exclude( List<UCell> aBOARD ){//Confirmation process
                    // return code = 0 : Complete. Go to the next stage.
                    //               1 : Solved. 
                    // Throw an exception if the conditions are invalid.

            // ..... Solved .....
            if( aBOARD.All(p=> p.No!=0) )  return 1;         

            // ..... FixedNo .....
            if( aBOARD.Any(p=>p.FixedNo>0) ){                         
                foreach( var P in aBOARD.Where(p=>p.FixedNo>0) ){
                    int No = P.FixedNo;
                    if( No>=1 && No<=9 ){ P.No=-No; P.FixedNo=0; P.FreeB=0; }
					else{ throw new Exception( "GNPX_Algorithm Error" ); }
				}
            }

            // ..... CancelB .....
            if( aBOARD.Any(p=>p.CancelB>0) ){                           
                foreach( var P in aBOARD.Where(p=>p.CancelB>0) ){  P.FreeB &= ~P.CancelB; P.CancelB=0; }
            }

            Update_CellsState(aBOARD);
            return 0;    // 0: Complete. Go to next stage.
        }



        public void Update_CellsState( List<UCell> aBOARD, bool Initial_stateB=false ){	// Update of "ripple effects".
			if( aBOARD == null )  return;
            if(Initial_stateB) foreach( UCell uc in aBOARD.Where(p=>p.No==0) )  uc.FreeB=0x1FF;
            foreach( UCell uc in aBOARD.Where(p=>p.No!=0) ){
                int noBR = ~(1<<Abs(uc.No)-1);
                foreach( UCell Q in pConnected_81[uc.rc].IEGet_UCell(aBOARD) )  Q.FreeB &= noBR;
            }
        }


        public void ResetAnalysisResult( bool clear0 ){
            if(clear0){   // true:Initial State
               foreach(var P in pBOARD.Where(Q=>Q.No<=0)){ P.Reset_StepInfo(); P.FreeB=0x1FF; P.No=0; }
            }
            else{
                foreach(var P in pBOARD.Where(Q=>Q.No==0)){ P.Reset_StepInfo(); P.FreeB=0x1FF; }
            }
            Update_CellsState( aBOARD:pBOARD );
			ePZL.extResult = "";
        }
    }
}