﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;

using Microsoft.Win32;

using static System.Math;

using static System.Diagnostics.Debug;
using static System.Net.Mime.MediaTypeNames;


namespace DLX_V0_Basic{
    #region Basic node
        // A circular doubly linked list with pointers to adjacent nodes in all four directions (up, down, left, and right).
        internal class Node{
            public Node Left;
            public Node Right;
            public Node Up;
            public Node Down;
            public ColumnNode Column;

            public object Tag;

            public Node(){
                Left = Right = Up = Down = this;
            }
        }

        internal class ColumnNode: Node{
            public int    Size;
            public string Name;

            public ColumnNode(string name){
                Name = name;
                Size = 0;
                Column = this;
            }
            //public override string ToString( ){
            //    string st = $"{((ColumnNode)this.Left).ColumnIndex,3} <-- {this.ColumnIndex,3} --> {((ColumnNode)this.Right).ColumnIndex,3}";
            //    return st;
            //}
        }
    #endregion

    #region DLX
        // Core of an Exact Cover problem solver using Dancing Links. ... Knuth's Algorithm X
        internal class DLX{
            private readonly ColumnNode _header;
            private readonly List<Node> _solution = new List<Node>();
            private List<Node> _result;

            public DLX(int numColumns, string[] columnNames=null){
                _header = new ColumnNode("header" );
                var columns = new ColumnNode[numColumns];

                for( int k=0; k<numColumns; k++ ){
                    string name = columnNames != null ? columnNames[k] : k.ToString();
                    var col = new ColumnNode(name);
                    columns[k] = col;

                    // Concatenate to the left side (k.e., the end) of the header.
                    col.Right = _header;
                    col.Left = _header.Left;
                    _header.Left.Right = col;
                    _header.Left = col;
        
                }

                Columns = columns;
/*
j:0  _header: -1 <--  -1 -->  -1

j:0  _header:  0 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->  -1

j:1  _header:  1 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->   1
   colHeaders[1]:   0 <--   1 -->  -1

j:2  _header:  2 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->   1
   colHeaders[1]:   0 <--   1 -->   2
   colHeaders[2]:   1 <--   2 -->  -1

j:3  _header:  3 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->   1
   colHeaders[1]:   0 <--   1 -->   2
   colHeaders[2]:   1 <--   2 -->   3
   colHeaders[3]:   2 <--   3 -->  -1

j:4  _header:  4 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->   1
   colHeaders[1]:   0 <--   1 -->   2
   colHeaders[2]:   1 <--   2 -->   3
   colHeaders[3]:   2 <--   3 -->   4
   colHeaders[4]:   3 <--   4 -->  -1
 ...
*/
            }

            public ColumnNode[] Columns { get; }

            // Add a candidate for a single row. Pass the column indices that the row satisfies to `rowColumns`.
            public Node[] AddRow(int[] rowColumns, object rowTag){
                Node first = null;
                var nodes = new Node[rowColumns.Length];

                for( int k=0; k<rowColumns.Length; k++ ){
                    var col = Columns[rowColumns[k]];
                    var node = new Node { Column = col };
                    node.Tag = rowTag; // Node に Tag を持たせるため拡張（下記参照）

                    // Add to the bottom of the column
                    node.Up = col.Up;
                    node.Down = col;
                    col.Up.Down = node;
                    col.Up = node;
                    col.Size++;

                    // Connected side-by-side within the line
                    if( first == null ){ first = node; }
                    else{
                        node.Left = first.Left;
                        node.Right = first;
                        first.Left.Right = node;
                        first.Left = node;
                    }
                    nodes[k] = node;
                }

                return nodes;
            }

            private void Cover(ColumnNode col){
                col.Right.Left = col.Left;
                col.Left.Right = col.Right;

                for( var row=col.Down; row!=col; row=row.Down){
                    for( var node=row.Right; node!=row; node=node.Right){
                        node.Down.Up = node.Up;
                        node.Up.Down = node.Down;
                        node.Column.Size--;
                    }
                }
            }

            private void Uncover(ColumnNode col){
                for( var row=col.Up; row!=col; row=row.Up){
                    for( var node=row.Left; node!=row; node=node.Left){
                        node.Column.Size++;
                        node.Down.Up = node;
                        node.Up.Down = node;
                    }
                }

                col.Right.Left = col;
                col.Left.Right = col;
            }

            // Returns the first solution found (as this is the basic form, it does not search for all solutions).
            public List<Node> Solve(){
                _result = null;
                Search();
                return _result;
            }

            private bool Search(){
                // All columns have disappeared = an exact cover has been completed.
                if( _header.Right == _header ){
                    _result = new List<Node>(_solution);
                    return true;
                }

                // Select the column with the fewest candidates (to reduce the number of branches).
                ColumnNode chosen = null;
                int minSize = int.MaxValue;
                for( var col=(ColumnNode)_header.Right; col!=_header; col=(ColumnNode)col.Right){
                    if( col.Size < minSize){
                        minSize = col.Size;
                        chosen = col;
                    }
                }

                // There is a column that cannot be satisfied by any row = failure at this point (backtrack).
                if( chosen==null || minSize==0){ return false;}

                Cover(chosen);

                    for( var row=chosen.Down; row!=chosen; row=row.Down){
                        _solution.Add(row);

                        for( var node=row.Right; node!=row; node=node.Right){  Cover(node.Column); }

                        if( Search() ){ return true; }  // *** Recursive call

                        // It failed, so reverting it.
                        for( var node=row.Left; node!=row; node=node.Left){ Uncover(node.Column); }

                        _solution.RemoveAt(_solution.Count-1);
                    }

                Uncover(chosen);
                return false;
            }
        }
    #endregion


    #region solver 9x9 Sudoku
        // A wrapper class for solving 9x9 Sudoku using DLX.
        public static class SudokuDLXSolver{
            public const int Size = 9;       // board side length
            public const int Box = 3;        // box side length
            public const int NumValues = 9;  // 1-9

            // Total columns = 4 constraint kinds x 81
            //   0..80   : cell constraint  - cell (r,c) holds exactly one digit
            //   81..161 : row constraint   - row r holds digit v exactly once
            //   162..242: column constraint- column c holds digit v exactly once
            //   243..323: box constraint   - box b holds digit v exactly once
            private const int NumColumns = 4*Size*Size;

            // Total candidates = 81 cells x 9 digits = 729
            private const int NumCandidates = Size*Size*NumValues;

            private struct Candidate{
                public int Row;   // 0-8
                public int Col;   // 0-8
                public int Value; // 1-9
            }

            // Solves a Sudoku puzzle. 
            //  "board" : An int array of length 81. 0 represents an empty cell; 1-9 represent fixed digits.
            //  Returns : If solved, it returns the solution as an array of length 81. If no solution exists, it returns null.
            public static int[] Solve( int[] board ){
                if( board == null || board.Length != Size * Size){
                    throw new ArgumentException("The board has an irregular shape.");
                }

                // ========================================================
                var dlx = new DLX(NumColumns);

                    // Add a row corresponding to each candidate (r,c,v). 
                    // For cells where the digit is already fixed, register only that digit as a candidate
                    // (this allows the hint conditions to be naturally expressed simply by reducing the digit of DLX rows).
                    var candidateNodes = new Node[Size, Size, NumValues+1];

                    for( int r=0; r<Size; r++ ){
                        for( int c = 0; c < Size; c++){
                            int given = board[r * Size + c];

                            for( int v=1; v<=NumValues; v++ ){
                                if( given != 0 && given != v) continue; // Not generate candidates that contradict the hints from the start.

                                int cellCol = r*Size + c;
                                int rowCol = 81  + r*NumValues + (v-1);
                                int colCol = 162 + c*NumValues + (v-1);
                                int boxIndex = (r / Box) * Box + (c / Box);
                                int boxCol = 243 + boxIndex*NumValues + (v-1);

                                var candidate = new Candidate { Row=r, Col=c, Value=v };
                                var nodes = dlx.AddRow(new[] { cellCol, rowCol, colCol, boxCol }, candidate);

                                candidateNodes[r,c,v] = nodes[0]; // Retain only the head node (unused, but kept for future expansion).
                            }
                        }
                    }

                // ========================================================

                var solutionRows = dlx.Solve();
                if( solutionRows==null ) return null; // no solution

                var result = new int[Size * Size];
                foreach( var node in solutionRows ){    
                    var cand = (Candidate)node.Tag;
                    result[cand.Row * Size + cand.Col] = cand.Value;
                }

                return result;
            }
        }
    #endregion

    #region Sample execution code
                /*
                    // Sample execution code for verifying operation.
                    internal static class Program{
                        private static void Main(){
                            int[] puzzle = {
                                5,3,0, 0,7,0, 0,0,0,
                                6,0,0, 1,9,5, 0,0,0,
                                0,9,8, 0,0,0, 0,6,0,

                                8,0,0, 0,6,0, 0,0,3,
                                4,0,0, 8,0,3, 0,0,1,
                                7,0,0, 0,2,0, 0,0,6,

                                0,6,0, 0,0,0, 2,8,0,
                                0,0,0, 4,1,9, 0,0,5,
                                0,0,0, 0,8,0, 0,7,9
                            };


                            var solution = SudokuDLXSolver.Solve( puzzle );

                            if( solution == null){ WriteLine("no solution"); return; }
                            for( int r=0; r<9; r++ ){
                                string  line = "";
                                for( int c=0; c<9; c++){
                                    line += $"{solution[r*9+c]} ";
                                }
                                WriteLine( line.Replace("0",".") );
                            }
                        }
                    }
                */
    #endregion
}







