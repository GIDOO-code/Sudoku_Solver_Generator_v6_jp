﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using Microsoft.Win32;
using static System.Math;

using System.IO;
using System.Threading;
using System.Threading.Tasks;

using static System.Diagnostics.Debug;
using static System.Net.Mime.MediaTypeNames;

using GIDOO_space;


namespace DLX_V2{

    #region General-Purpose Exact Cover Solver Using Dancing Links.

    // =====================================================================
    // 1. Generic Dancing Links engine (has no knowledge of Sudoku at all)
    // =====================================================================

            // Basic Dancing Links node. Part of a circular doubly linked list with
                internal class Node{
                    public Node L, R, U, D;
                    public ColumnNode Column;

                    public object Tag;

                    public Node(){
                        L = R = U = D = this;
                    }
                }

                internal class ColumnNode : Node{
                    public int Size;
                    public string Name;

                    public ColumnNode(string name){
                        Name = name;
                        Size = 0;
                        Column = this;
                    }
                }

    internal class DLX{
        private readonly ColumnNode _header;
        private readonly List<Node> _solution = new List<Node>();
        private List<List<Node>> _results;
        private int _maxSolutions;
        private CancellationToken _ct;

        public DLX(int numColumns, string[] columnNames = null){
            _header = new ColumnNode("header");
            var columns = new ColumnNode[numColumns];

            for( int k=0; k<numColumns; k++ ){
                string name = (columnNames!=null)? columnNames[k]: k.ToString();
                var col = new ColumnNode(name);
                columns[k] = col;

                col.R=_header; col.L=_header.L;
                _header.L.R=col; _header.L=col;
            }

            Columns = columns;
        }

        public ColumnNode[] Columns { get; }

        public Node[] AddRow(int[] rowColumns, object rowTag){
            Node first = null;
            var nodes = new Node[rowColumns.Length];

            for( int k=0; k<rowColumns.Length; k++ ){
                var col = Columns[rowColumns[k]];
                var node = new Node{ Column=col, Tag=rowTag };

                // Insert at the bottom of the column.
                node.U=col.U; node.D=col;
                col.U.D=node; col.U=node;
                col.Size++;

                // Link into the row (L/R).
                if( first==null)  first = node;
                else{
                    node.L=first.L; node.R=first;
                    first.L.R=node; first.L=node;
                }
                nodes[k] = node;
            }

            return nodes;
        }

        public void CoverColumn(ColumnNode col) => Cover(col);
        public void UncoverColumn(ColumnNode col) => Uncover(col);

        private void Cover( ColumnNode col ){
            col.R.L=col.L; col.L.R=col.R;

            for( var row=col.D; row!=col; row=row.D){
                for( var node=row.R; node!=row; node=node.R){
                    node.D.U=node.U; node.U.D=node.D;
                    node.Column.Size--;
                }
            }
        }

        private void Uncover(ColumnNode col){
            for( var row=col.U; row!=col; row=row.U){
                for( var node=row.L; node!=row; node=node.L){
                    node.Column.Size++;
                    node.D.U=node; node.U.D=node;
                }
            }
            col.R.L=col; col.L.R=col;
        }

        // Runs Algorithm X, collecting U to maxSolutions solutions.
        public List<List<Node>> Solve( int maxSolutions=1, CancellationToken ct=default(CancellationToken)){
            if( maxSolutions<1 ){ throw new ArgumentOutOfRangeException(nameof(maxSolutions), "maxSolutions must be at least 1."); }

            _results = new List<List<Node>>();
            _maxSolutions = maxSolutions;
            _ct = ct;
            _solution.Clear();

            Search();

            return _results;
        }

        // Recursive search. Returning true signals "stop the entire search
        private bool Search(){
            // External cancellation: abort everything immediately and unwind.
            if( _ct.IsCancellationRequested){ return true; }

            // All columns are gone: an exact cover was completed - one solution found.
            if( _header.R == _header){
                _results.Add(new List<Node>(_solution));
                return _results.Count >= _maxSolutions;
            }

            // Pick the column with the fewest remaining candidates (standard heuristic to reduce branching).
            ColumnNode chosen = null;
            int minSize = int.MaxValue;
            for( var col=(ColumnNode)_header.R; col!=_header; col=(ColumnNode)col.R){
                if( col.Size<minSize){ minSize=col.Size; chosen=col; }
            }

            // A column that no row can satisfy: fail here (backtrack).
            if( chosen==null || minSize==0){ return false; }

            Cover(chosen);

            for( var row=chosen.D; row!=chosen; row=row.D){
                _solution.Add(row);

                for( var node=row.R; node!=row; node=node.R ){ Cover(node.Column); }

                bool stop = Search();

                for( var node=row.L; node!=row; node=node.L ){ Uncover(node.Column); }

                _solution.RemoveAt(_solution.Count - 1);

                if( stop ){ Uncover(chosen); return true; }  // Enough solutions collected (or cancelled): unwind without exploring further.
            }

            Uncover(chosen);
            return false;
        }
    }
      
    #endregion General-Purpose Exact Cover Solver Using Dancing Links.



    #region Sudoku Constraint Definition

    // =====================================================================
    // 2. Sudoku constraint definition (how this problem maps onto DLX's
    //    exact cover model). Contains no notion of "solving" (search) at all
    //    - purely the rule definition.
    // =====================================================================

    public struct SudokuCandidate{
        public int Row;   // 0-8
        public int Col;   // 0-8
        public int Value; // 1-9

        public override string ToString() => $"(r={Row}, c={Col}, v={Value})";
    }

    public struct SudokuCandidateRow{
        public SudokuCandidate Candidate;
        public int[] Columns;

        public SudokuCandidateRow(SudokuCandidate candidate, int[] columns){
            Candidate = candidate;
            Columns = columns;
        }
    }

    // Defines standard 9x9 Sudoku as an Exact Cover problem.
    // Holds the definition of "4 constraint kinds x 81" = 324 columns and
    public static class SudokuConstraints{
        public const int Size = 9;       // board side length
        public const int Box = 3;        // box side length
        public const int NumValues = 9;  // 1-9

        // Total columns = 4 constraint kinds x 81
        //   0..80   : cell constraint  - cell (r,c) holds exactly one digit
        //   81..161 : row constraint   - row r holds digit v exactly once
        //   162..242: column constraint- column c holds digit v exactly once
        //   243..323: box constraint   - box b holds digit v exactly once
        public const int NumColumns = 4*Size*Size;

        // Total candidates = 81 cells x 9 digits = 729
        public const int NumCandidates = Size*Size*NumValues;

        // Enumerates every candidate allowed by the rules of Sudoku
        //  (729 of them) along with the 4 column indices each one satisfies.
        // This is "the DLX definition".
        public static IEnumerable<SudokuCandidateRow> AllCandidates(){
            for( int r=0; r<Size; r++ ){
                for( int c=0; c<Size; c++){
                    int boxIndex = (r/Box)*Box + (c/Box);

                    for( int v=1; v<=NumValues; v++ ){
                        int cellCol =   0 + r*Size + c;
                        int rowCol  =  81 + r*NumValues + (v-1);
                        int colCol  = 162 + c*NumValues + (v-1);
                        int boxCol  = 243 + boxIndex*NumValues + (v-1);

                        var candidate = new SudokuCandidate{ Row=r, Col=c, Value=v };
                        yield return new SudokuCandidateRow(candidate, new[] { cellCol, rowCol, colCol, boxCol });
                    }
                }
            }
        }
    }
    #endregion Sudoku Constraint Definition




    #region SudokuSolver
    // =====================================================================
    // 3. Solver for individual problems (the DLX skeleton is built once and reused)
    //
    //    The 729x324 DLX skeleton is the same regardless of which Sudoku puzzle is being solved. 
    //    Construct it once when instantiating SudokuSolver and reuse it.
    //    Temporarily construct only the rows corresponding to the hints.
    //    Always restore the original state by following the sequence: "Cover" → "Search" → "Uncover."
    // =====================================================================

    public sealed class SudokuSolver{
        private static int _instanceCounter;

        // The order in which this SudokuSolver instance was created (starting at 1).
        // Not needed for correctness; this is a diagnostic property used to
        // verify/observe that exactly one instance per thread is created and reused.
        public int InstanceId { get; }

        private readonly int _size = SudokuConstraints.Size;
        private readonly DLX _dlx;

        // candidateNodes[r,c,v] = the 4 nodes of the row representing "place
        // digit v in cell (r,c)". Filled once at construction time; looked
        // U every time a given is applied.
        private readonly Node[,,][] _candidateNodes;

        public SudokuSolver(){
            InstanceId = Interlocked.Increment(ref _instanceCounter);

            _dlx = new DLX(SudokuConstraints.NumColumns);
            _candidateNodes = new Node[_size, _size, SudokuConstraints.NumValues + 1][];

            // Register all 729 rows into the DLX exactly once here, following
            // the rule definition (SudokuConstraints). This structure is never
            // rebuilt afterward (Solve() temporarily Covers parts of it, but
            // always Uncovers them again).
            foreach( var row in SudokuConstraints.AllCandidates()){
                var candidate = row.Candidate;
                var nodes = _dlx.AddRow(row.Columns, candidate);
                _candidateNodes[candidate.Row, candidate.Col, candidate.Value] = nodes;
            }
        }


        public List<int[]> Solve(int[] board, int maxSolutions=1, CancellationToken ct=default(CancellationToken) ){
            if( board==null || board.Length!=_size*_size ){ throw new ArgumentException("board must be a length-81 int array."); }

            if( ct.IsCancellationRequested){ return new List<int[]>(); }

            // Records, in the order they were applied, every row that was
            // force-Covered in this Solve() call to represent a given. After
            // the search finishes, these must always be Uncovered in exactly
            // the reverse order, to fully restore the DLX for the next call.
            var appliedRows = new List<Node[]>();
            var coveredColumns = new HashSet<ColumnNode>();
            bool contradictory = false;

            for( int rc=0; rc<board.Length; rc++ ){
                if( ct.IsCancellationRequested){ contradictory=true; break; } // treat as "nothing to solve"; cleanup below still runs

                int v = board[rc];
                if( v==0 ) continue;
                if( v<1 || v>SudokuConstraints.NumValues ){
                    throw new ArgumentException($"board[{rc}] has value {v}, which is out of the 0-9 range.");
                }

                int r = rc/_size;
                int c = rc%_size;
                var nodes = _candidateNodes[r, c, v];

                // Check whether this conflicts with an already-applied given
                // (i.e. would try to Cover an already-Covered column). This
                // happens when the board itself is contradictory, e.g. the
                // same digit given twice in one row.
                bool conflict = false;
                foreach( var n in nodes ){
                    if( coveredColumns.Contains(n.Column)){ conflict=true; break; }
                }

                if( conflict ){ contradictory=true; break; }

                // This is where the core DLX operation (Cover) is reused for
                // applying a given - the exact same Cover call used when the
                // search selects a candidate row.
                foreach( var n in nodes){
                    _dlx.CoverColumn(n.Column);
                    coveredColumns.Add(n.Column);
                }

                appliedRows.Add(nodes);
            }

            var rawSolutions = contradictory? new List<List<Node>>(): _dlx.Solve(maxSolutions, ct );

            // --- Cleanup: always Uncover in the exact reverse order applied, restoring the DLX. ---
            // Skipping this, or getting the order wrong, corrupts the linked
            // list so the next Solve() call on this instance would be wrong.
            // This is the single most important point of the reuse design.
            for( int k=appliedRows.Count-1; k>=0; k-- ){
                var nodes = appliedRows[k];
                for( int j=nodes.Length-1; j>=0; j-- ){
                    _dlx.UncoverColumn(nodes[j].Column);
                }
            }

            var results = new List<int[]>(rawSolutions.Count);
            foreach( var solutionRows in rawSolutions){
                var result = new int[_size * _size];

                // Cells fixed by the givens.
                foreach( var nodes in appliedRows){
                    var cand = (SudokuCandidate)nodes[0].Tag;
                    result[ cand.Row*_size+cand.Col ] = cand.Value;
                }

                // Cells decided by the search.
                foreach( var node in solutionRows){
                    var cand = (SudokuCandidate)node.Tag;
                    result[ cand.Row*_size+cand.Col ] = cand.Value;
                }

                results.Add(result);
            }

            return results;
        }
    }
    #endregion SudokuSolver



   #region Multithreading support
        // =====================================================================
        // 4. Multithreading support: automatically create and reuse one SudokuSolver per thread.
        //
        //    SudokuSolver temporarily Covers/Uncovers the DLX linked list internally, 
        //    so if multiple threads shared the same instance at the same time,
        //    the state would race and corrupt. 
        //    Each thread therefore needs its own separate SudokuSolver instance.
        //
        //    Using ThreadLocal<T>:
        //      - the first time a thread accesses Current, new SudokuSolver() is
        //        called automatically for it (the 729-row DLX is built exactly
        //        once per thread)
        //      - every later call from that same thread reuses that same instance
        //
        //    The caller only ever needs to call SudokuSolverPool.Current -
        //     there is no need to think about "define it once per thread" at all. 
        //     This combines safely with Parallel.For / Parallel.ForEach.
        // =====================================================================

    public static class SudokuSolverPool{
        private static readonly ThreadLocal<SudokuSolver> ThreadLocalSolver = new( () => new SudokuSolver() );

        public static SudokuSolver Current => ThreadLocalSolver.Value;
    }

    #endregion Multithreading support


    #region Multithreaded sample
    // =====================================================================
    // 5. Batch processing across multiple threads, with locked result output
    //
    //    So that the caller only has to write "Parallel.For / Parallel.ForEach":
    //      - SudokuSolverPool. Current provides the per-thread solver (automatically)
    //      - a lock serializes writes to the shared output file
    //    This class packages exactly that pattern into one ready-made method.
    //    Callers can of course also write their own Parallel.
    //    ForEach using the same pattern directly (see Program.Main(->@@@@@)).
    // =====================================================================

    public static class SudokuBatchProcessor{
        private static readonly object FileLock = new object();

        // Solves multiple Sudoku puzzles in parallel and appends the results to a single text file.
        public static void SolveAllAndSave(
            IEnumerable<int[]> puzzles,
            string outputPath,
            int maxSolutions=1,
            CancellationToken ct = default(CancellationToken)){

            // Start the file empty (results are appended one at a time).
            File.WriteAllText(outputPath, string.Empty);

            if( ct.IsCancellationRequested )  return;

            int index = 0;
            var indexLock = new object();

            try{
                var options = new ParallelOptions { CancellationToken=ct };
                Parallel.ForEach( puzzles, options, (puzzle, state) =>{
                    if( ct.IsCancellationRequested){ state.Stop(); return; }

                    int myIndex;                            //@@@ Thread-specific ID
                    lock(indexLock){ myIndex=index++; }     //@@@

                    // Just fetch the per-thread solver; reuse is automatic.
                    var solver = SudokuSolverPool.Current;                      //@@@
                    var solutions = solver.Solve( puzzle, maxSolutions, ct );   //@@@

                    string line = FormatResultLine(myIndex, solver.InstanceId, solutions );

                    // Concurrent writes to the same file would corrupt it, so
                    // the whole write is serialized with a lock.
                    lock(FileLock){ File.AppendAllText(outputPath, line); }
                });
            }
            catch (OperationCanceledException){
                // Cancellation requested: abort everything and return without rethrowing.
                return;
            }
        }

        private static string FormatResultLine(int index, int solverInstanceId, List<int[]> solutions){
            string text = $"[puzzle {index}] (solverId={solverInstanceId}, thread={Thread.CurrentThread.ManagedThreadId}) ";

            if( solutions.Count == 0){ text += "no solution\n"; return text; }

            text += $"{solutions.Count} solution(s): ";
            for( int s=0; s<solutions.Count; s++){
                if( s>0 ){ text += " | "; }
                foreach( var v in solutions[s]){ text += v; }
            }
            text += "\n";

            return text;
        }
    }
    #endregion Multithreaded sample


    #region Validation sample
  /*  
        // =====================================================================
        // 6. Sample program for verification
        // =====================================================================

        internal static class Program{
            private static void Main(){
                int[] classic = {
                    5,3,0, 0,7,0, 0,0,0,
                    6,0,0, 1,9,5, 0,0,0,
                    0,9,8, 0,0,0, 0,6,0,

                    8,0,0, 0,6,0, 0,0,3,
                    4,0,0, 8,0,3, 0,0,1,
                    7,0,0, 0,2,0, 0,0,6,

                    0,6,0, 0,0,0, 2,8,0,
                    0,0,0, 4,1,9, 0,0,5,
                    0,0,0, 0,8,0, 0,7,9
                };

                // Line U many puzzles at hand (here, just duplicated for the demo).
                var puzzles = new List<int[]>();
                for( int k=0; k<50; k++ ){
                    puzzles.Add((int[])classic.Clone());
                }

                string outputPath = "sudoku_results.txt";
                using (var cts = new CancellationTokenSource()){
                    // The caller only has to write this much.
                    //   - SudokuSolverPool.Current handles per-thread first-time creation automatically
                    //   - file writes are serialized with a lock
                    // Both are already implemented inside SudokuBatchProcessor.
                    SudokuBatchProcessor.SolveAllAndSave(puzzles, outputPath, maxSolutions: 1, cancellationToken: cts.Token);
                }

                Console.WriteLine($"Solved {puzzles.Count} puzzles in parallel and saved to '{outputPath}'.");


        // @@@@@
        // Minimal example of writing your own Parallel.ForEach directly.
        var solverIdsUsed = new System.Collections.Concurrent.ConcurrentBag<int>();
        var manualLock = new object();

        Parallel.ForEach(puzzles, puzzle => {
            var solver = SudokuSolverPool.Current; // per-thread, created and reused automatically
            var solutions = solver.Solve(puzzle);

            solverIdsUsed.Add(solver.InstanceId);

            lock(manualLock){
                File.AppendAllText(outputPath, $"(manual) solverId={solver.InstanceId}, solutionCount={solutions.Count}\n");
            }
        });




                var distinctSolverIds = new HashSet<int>(solverIdsUsed);
                Console.WriteLine($"Distinct SudokuSolver instances used: {distinctSolverIds.Count} (approximately the thread count)");
            }

            private static void PrintBoard(int[] board){
                for( int r=0; r<9; r++ ){
                    string line = "";
                    for( int c=0; c<9; c++ ){
                        line += $"{(board[r*9+c])} ";
                    }
                    WriteLine( line.Replace("0",".") );
                }
            }
    */
    #endregion Validation sample
}