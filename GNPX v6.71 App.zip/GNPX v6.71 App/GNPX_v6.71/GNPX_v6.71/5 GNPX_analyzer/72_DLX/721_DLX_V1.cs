﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Xml.Linq;

using GIDOO_space;

using Microsoft.Win32;

using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;


namespace DLX_V1{

    #region General-Purpose Exact Cover Solver Using Dancing Links.
        // =====================================================================
        // 1. Dancing Links : General-purpose engine.
        // =====================================================================

            internal class Node{
                    public Node L, R, U, D;
                    public ColumnNode Column;

                    public object Tag; // Arbitrary data storing which candidate this row corresponds to.

                    public Node(){
                        L = R = U = D = this;
                    }
            }

            internal class ColumnNode: Node{
                public int Size;
                public string Name;

                public ColumnNode(string name){
                    Name = name;
                    Size = 0;
                    Column = this;
                }
            }

        // A General-Purpose Exact Cover Solver Using Dancing Links. Implemented Knuth's Algorithm X.
        // It can be reused for any Exact Cover problem.

        //@@@ The DLX network maintains candidate states (candidates for consistent states, along with unsatisfied rules).

        internal class DLX{
            private readonly ColumnNode _header;
            private readonly List<Node> _solution = new List<Node>();
            private List<List<Node>> _results;
            private int _maxSolutions;

            public DLX(int numColumns, string[] columnNames = null){
                _header = new ColumnNode("header");
                var columns = new ColumnNode[numColumns];

                for( int i=0; i<numColumns; i++){
                    string name = columnNames != null ? columnNames[i] : i.ToString();
                    var col = new ColumnNode(name);
                    columns[i] = col;

                    col.R = _header;
                    col.L = _header.L;
                    _header.L.R = col;
                    _header.L = col;
                }

                Columns = columns;
            }

            public ColumnNode[] Columns { get; }

            // Adds a candidate for a single row. Pass the column indices satisfied by the row to `rowColumns`. 
            // rowTag : allows you to freely store information about what the row represents (semantic information for the caller).
            public Node[] AddRow(int[] rowColumns, object rowTag){
                Node first = null;
                var nodes = new Node[rowColumns.Length];

                for( int i=0; i<rowColumns.Length; i++ ){
                    var col = Columns[rowColumns[i]];
                    var node = new Node { Column = col, Tag = rowTag };

                    // Add to the bottom of the column
                    node.U = col.U;
                    node.D = col;
                    col.U.D = node;
                    col.U = node;
                    col.Size++;

                    // Connected side-by-side within the line
                    if( first == null){ first = node; }
                    else{
                        node.L = first.L;
                        node.R = first;
                        first.L.R = node;
                        first.L = node;
                    }

                    nodes[i] = node;
                }

                return nodes;
            }

            // Cover the column (remove the column itself and all rows intersecting it from the other columns).
            // It is called from within `Search()`. It is also exposed so that
            // the solver can call it directly from the outside to finalize a row (i.e., apply a hint).
            // The basic operation of DLX consists solely of the pair of "Cover" and "Uncover" actions.
            // By reusing this same operation for both the choices made during the search and
            // the forced choices based on hints, implementation consistency is maintained.

            public void CoverColumn(ColumnNode col) => Cover(col);

            // The reverse operation of Cover. It must be called in the exact reverse order of the Cover operation.
            public void UncoverColumn(ColumnNode col) => Uncover(col);

            
            // @@@ Cover(col): Declare that "this rule has been satisfied by the chosen candidate."
            private void Cover( ColumnNode col ){
                col.R.L=col.L; col.L.R=col.R;

                for( var row=col.D; row!=col; row=row.D ){
                    for( var node=row.R; node!=row; node=node.R ){
                        node.D.U=node.U; node.U.D=node.D; node.Column.Size--;
                    }
                }
            }

            // @@@ Return the column to the header ring, and restore any candidates that had been removed due to that column's influence to their original positions.
            private void Uncover( ColumnNode col ){
                for( var row=col.U; row!=col; row=row.U ){
                    for( var node=row.L; node!=row; node=node.L ){
                        node.Column.Size++; node.D.U=node; node.U.D=node;
                    }
                }

                col.R.L=col; col.L.R=col;
            }





            // The core of Algorithm X. It searches for up to `maxSolutions` solutions.
            public List<List<Node>> Solve(int maxSolutions = 1){

                if( maxSolutions<1 ){ throw new ArgumentOutOfRangeException(nameof(maxSolutions), "maxSolutions must be greater than 1."); }

                _results = new List<List<Node>>();
                _maxSolutions = maxSolutions;
                _solution.Clear();

                Search();  // ### First Search ###

                return _results;
            }


            // Recursive search. Returning `true` signals that enough solutions have been gathered,
            // prompting the entire process to terminate.

            // @@@  Returning via recursion:
            //    1) Recursive unwinding: Elements are uncovered in the reverse order of how they were covered (a natural, last-in-first-out sequence).
            //    2) Explicit reversal in the code: The 'Cover' operation proceeds via 'row.D' / 'node.R' (down/right), 
            //       while the 'Uncover' operation proceeds via 'row.U' / 'node.L' (up/left).
            
            private bool Search(){  // ### Search ###
                // All columns have disappeared = an exact cover has been completed = a solution has been found.
                if( _header.R == _header){
                    _results.Add(new List<Node>(_solution));
                    return _results.Count >= _maxSolutions;
                }

                // Select the column with the fewest candidates 
                //  (a standard strategy to reduce the number of branches).
                ColumnNode chosen = null;
                int minSize = int.MaxValue;
                for( var col=(ColumnNode)_header.R; col!=_header; col=(ColumnNode)col.R ){
                    if( col.Size < minSize ){ minSize=col.Size; chosen=col; }
                }

                // There is a column that cannot be satisfied by any row = failure at this point (backtrack).
                if( chosen==null || minSize==0 )  return false;

                Cover(chosen);

                for( var row=chosen.D; row!=chosen; row=row.D ){
                    _solution.Add(row);

                    for( var node=row.R; node!=row; node=node.R ){ Cover(node.Column); }

                    bool stop = Search();   // ### Recursive Search ###

                    for( var node=row.L; node!=row; node=node.L){ Uncover(node.Column); }

                    _solution.RemoveAt( _solution.Count-1 );

                    if( stop ){
                        Uncover(chosen);

                        // The required number has been reached, so will rewind the entire process without searching further.
                        return true; 
                    }
                }

                Uncover(chosen);
                return false;
            }
        }
    #endregion General-Purpose Exact Cover Solver Using Dancing Links.


    #region Sudoku Constraint Definition
    // =====================================================================
    // 2. Sudoku Constraint Definition. 
    // =====================================================================

            public struct SudokuCandidate{
                public int Row;   // 0-8
                public int Col;   // 0-8
                public int Value; // 1-9

                public override string ToString() => $"(r={Row}, c={Col}, v={Value})";
            }

            public struct SudokuCandidateRow{
                public SudokuCandidate Candidate;
                public int[] Columns;

                public SudokuCandidateRow(SudokuCandidate candidate, int[] columns){
                    Candidate = candidate;
                    Columns = columns;
                }
            }

    // A class that defines a standard 9x9 Sudoku as an Exact Cover problem.
    public static class SudokuConstraints{
        public const int Size      = 9;  // board side length
        public const int Box       = 3;  // box side length
        public const int NumValues = 9;  // 1-9

        // Total columns = 4 constraint kinds x 81
        //   0..80   : cell constraint  - cell (r,c) holds exactly one digit
        //   81..161 : row constraint   - row r holds digit v exactly once
        //   162..242: column constraint- column c holds digit v exactly once
        //   243..323: box constraint   - box b holds digit v exactly once
        public const int NumColumns = 4*Size*Size;

        // Total candidates = 81 cells x 9 digits = 729
        public const int NumCandidates = Size*Size*NumValues;

        // Enumerate all possible candidates (729) defined by the rules of Sudoku,
        // along with the four column indices that each satisfies.
        public static IEnumerable<SudokuCandidateRow> AllCandidates(){
            for( int r=0; r<Size; r++ ){
                for( int c=0; c<Size; c++ ){
                    int boxIndex = (r/Box) * Box + (c/Box);

                    for( int v = 1; v <= NumValues; v++){
                        int cellCol =   0 + r*Size + c;
                        int rowCol  =  81 + r*NumValues + (v-1);
                        int colCol  = 162 + c*NumValues + (v-1);
                        int boxCol  = 243 + boxIndex*NumValues + (v-1);

                        var candidate = new SudokuCandidate { Row = r, Col = c, Value = v };
                        yield return new SudokuCandidateRow(candidate, new[] { cellCol, rowCol, colCol, boxCol });
                    }
                }
            }
        }
    }
    #endregion Sudoku Constraint Definition





    #region SudokuSolver
    // =====================================================================
    // 3. Solver for individual problems (the DLX skeleton is built once and reused)
    //
    //    The 729x324 DLX skeleton is the same regardless of which Sudoku puzzle is being solved. 
    //    Construct it once when instantiating SudokuSolver and reuse it.
    //    Temporarily construct only the rows corresponding to the hints.
    //    Always restore the original state by following the sequence: "Cover" → "Search" → "Uncover."
    // =====================================================================

    public sealed class SudokuSolver{
        private readonly int _size = SudokuConstraints.Size;
        private readonly DLX _dlx;

        private readonly Node[,,][] _candidateNodes;

        public SudokuSolver(){
            _dlx = new DLX(SudokuConstraints.NumColumns);
            _candidateNodes = new Node[_size, _size, SudokuConstraints.NumValues+1][];

            // Construct all 729 rows in the DLX structure according to the Sudoku rules (SudokuConstraints). 
            // This structure itself remains unchanged thereafter (although it is temporarily covered within Solve(),
            // it is always uncovered to restore the original state).
            foreach( var row in SudokuConstraints.AllCandidates() ){
                var candidate = row.Candidate;
                var nodes = _dlx.AddRow(row.Columns, candidate);
                _candidateNodes[candidate.Row, candidate.Col, candidate.Value] = nodes;
            }
        }


        // Solves a Sudoku puzzle. Because the DLX skeleton is reused, 
        // calling this method repeatedly never regenerates the 729 rows.
        public List<int[]> Solve(int[] board, int maxSolutions=1 ){
            if( board==null || board.Length!=_size*_size ){
                 throw new ArgumentException("The board has an irregular shape.");
            }


            // Within this Solve call, record the rows forced as covers (as hints) in the order they were applied. 
            // After the search completes, be sure to uncover them in the reverse order 
            // to fully restore the DLX to its original state for the next Solve call.
            var appliedRows = new List<Node[]>();   // @@@ A record of the hints
            var coveredColumns = new HashSet<ColumnNode>();
            bool contradictory = false;

            for( int rc=0; rc<board.Length; rc++){
                int v = board[rc];
                if( v==0 )  continue;
                if( v<1 || v>SudokuConstraints.NumValues){
                    throw new ArgumentException($"The value {v} for board[{rc}] is outside the range of 0 to 9.");
                }

                int r = rc/_size;
                int c = rc%_size;
                var nodes = _candidateNodes[r,c,v];

                // Check for any contradictions with other hints (e.g., attempting to cover the same column twice).
                // (When the board state itself is contradictory)
                bool conflict = false;
                foreach( var n in nodes ){
                    if( coveredColumns.Contains(n.Column)){  conflict=true; break; }    // @@@ The hints contradict each other.
                }

                if( conflict){ contradictory=true; break; }

                // Reuse the basic DLX operations (Cover) for applying hints as well.
                foreach( var n in nodes ){
                    _dlx.CoverColumn(n.Column);
                    coveredColumns.Add(n.Column);
                }
                appliedRows.Add(nodes);
            }


            var rawSolutions = contradictory? new List<List<Node>>(): _dlx.Solve(maxSolutions);

            // Cleanup: Be sure to "uncover" in the reverse order of application to restore the DLX to its original state.
            for( int j=appliedRows.Count-1; j>=0; j-- ){
                var nodes = appliedRows[j];
                for( int k=nodes.Length-1; k>=0; k-- ){
                    _dlx.UncoverColumn(nodes[k].Column);
                }
            }

            var results = new List<int[]>(rawSolutions.Count);
            foreach( var solutionRows in rawSolutions){
                var result = new int[_size*_size];

                // Cells fixed by the givens.
                foreach( var nodes in appliedRows){
                    var cand = (SudokuCandidate)nodes[0].Tag;
                    result[cand.Row*_size + cand.Col] = cand.Value;
                }

                // Cells decided by the search.
                foreach( var node in solutionRows){
                    var cand = (SudokuCandidate)node.Tag;
                    result[cand.Row*_size + cand.Col] = cand.Value;
                }

                results.Add(result);                                    // @@@ Store a copy of each solution in '_results'
            }

            return results;
        }
    }
    #endregion SudokuSolver

#if false
    #region Sample program for verification
    // =====================================================================
    // 4. Sample program for verification
    // =====================================================================

    internal static class Program{
            private static void Main(){
                int[] puzzle1 = {
                    5,3,0, 0,7,0, 0,0,0,
                    6,0,0, 1,9,5, 0,0,0,
                    0,9,8, 0,0,0, 0,6,0,

                    8,0,0, 0,6,0, 0,0,3,
                    4,0,0, 8,0,3, 0,0,1,
                    7,0,0, 0,2,0, 0,0,6,

                    0,6,0, 0,0,0, 2,8,0,
                    0,0,0, 4,1,9, 0,0,5,
                    0,0,0, 0,8,0, 0,7,9
                };

                int[] puzzle2 = {
                    0,0,0, 0,7,0, 0,0,0,
                    6,0,0, 1,9,5, 0,0,0,
                    0,9,8, 0,0,0, 0,6,0,

                    8,0,0, 0,6,0, 0,0,3,
                    4,0,0, 8,0,3, 0,0,1,
                    7,0,0, 0,2,0, 0,0,6,

                    0,6,0, 0,0,0, 2,8,0,
                    0,0,0, 4,1,9, 0,0,5,
                    0,0,0, 0,8,0, 0,7,9
                };

                // The basic structure of DLX is constructed only once.
                var solver = new SudokuSolver();

                var solutions1 = solver.Solve(puzzle1, maxSolutions:2);
                WriteLine($"Problem 1: Number of solutions (search limited to a maximum of 2) = {solutions1.Count}" );
                foreach( var sol in solutions1){
                    PrintBoard(sol);
                    WriteLine("");
                }

                // Reuse the same solver instance to solve a different problem.
                var solutions2 = solver.Solve(puzzle2, maxSolutions:3);
                WriteLine($"Problem 2 (Empty board): Number of solutions (search limited to max.3) = {solutions2.Count}" );
            }

            private static void PrintBoard(int[] board){
                for( int r=0; r<9; r++ ){
                    string line = "";
                    for( int c=0; c<9; c++ ){
                        line += $"{(board[r*9+c])} ";
                    }
                    WriteLine( line.Replace("0",".") );
                }
            }
        }
    # endregion Sample program for verification
#endif
}







