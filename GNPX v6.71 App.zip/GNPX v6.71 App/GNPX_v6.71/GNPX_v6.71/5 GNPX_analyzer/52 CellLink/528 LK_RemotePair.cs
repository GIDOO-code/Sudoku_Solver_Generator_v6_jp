using System;
using System.Collections.Generic;
//using System.Drawing;
using System.Linq;
//using System.Security.Cryptography.Xml;
using System.Windows.Media;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space{

public partial class CellLinkGen: AnalyzerBaseV2{

        //RemotePair is an algorithm that connects bivalue cells with a StrongLlink.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page47.html

        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
        //.3..9.68...9.64..2..7..8.5.84.6.9....26...41....2.1.96.9.4..1..6..81.5...14.5..6.
        //2..8..1...8.4..6.3...2968...1..3.2.43.......69.5.8..3...1324...6.2..8.1...8..1..2

        public bool RemotePair( ){     //RemotePairs
			NXGCellLinkGen_Prepare();
            UChainXY.pBOARD = pBOARD;

            List<UCell>  BVCellLst = pBOARD.FindAll(p=>(p.FreeBC==2)); //BV:bivalue
            if( BVCellLst.Count<3 ) return false;  

            foreach( var (CRL,FreeB) in _RPColoring( BVCellLst )){
                foreach( var P in pBOARD.Where(p=>(p.FreeB&FreeB)>0) ){
                    if( (CRL[0] & Connected_81[P.rc]).IsZero() )  continue;
                    if( (CRL[1] & Connected_81[P.rc]).IsZero() )  continue;                  
                    P.CancelB = P.FreeB&FreeB;
                }

                UInt128 Exclude = pBOARD.FindAll(u=>u.CancelB>0).Aggregate(qZero, (a,u) => a|qOne<<u.rc);
                if( Exclude > qZero ){ //=== found ===
                    SolCode = 2;
                    string stE = $" Exclude : {Exclude.TBScmp()}"; 
                    string SolMsg = "Remote Pair #{FreeB.TBScmp()}";
                    ResultLong = $"Remote Pair #{FreeB.TBScmp()}\n{stE}";
                    Result = ResultLong.Replace("\n"," ");
                   
                    Color Cr  = PastelColors[0];
                    Color Cr1 = Color.FromArgb(255,Cr.R,Cr.G,Cr.B);   
                    Color Cr2 = Color.FromArgb(150,Cr.R,Cr.G,Cr.B);
                    CRL[0].IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, Cr1 );
                    CRL[1].IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, Cr2 );

					if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                }
            }
            return false;
        }

        private IEnumerable<(UInt128[],int)> _RPColoring( List<UCell>  BVCellLst ){
            if( BVCellLst.Count<4 )  yield break;
          
            // --- coloring with bivalue cells ---
            UInt128 BivalueB = BVCellLst.Aggregate( UInt128.Zero, (p,q)=> p| UInt128.One<<q.rc );
                       // WriteLine( $" BivalueB:{BivalueB.ToRCString()}" );      
            UInt128 usedB = UInt128.Zero;
            var QueTupl = new Queue<(int,int)>();

            UInt128[] CRL=new UInt128[2]; 
            CRL[0]=UInt128.Zero; CRL[1]=UInt128.Zero; 
            int  rc0;
            while( (rc0=BivalueB.FindFirst_rc())>=0 ){              //Start searching from rc0
                BivalueB &= ~(qOne<<rc0);
                        // WriteLine( $" 000 BivalueB{BivalueB.ToRCString()}" );

                CRL[0]=UInt128.Zero; CRL[1]=UInt128.Zero;           //Clear chain
                
                QueTupl.Clear();                                    //Queue(QueTupl) initialization
                QueTupl.Enqueue( (rc0,0) );
                
                int FreeB = pBOARD[rc0].FreeB;         
                usedB = UInt128.Zero;
                while( QueTupl.Count>0 ){
                    var (rc1,color1) = QueTupl.Dequeue();           //Get Current Cell
                    usedB |= qOne<<rc1;
                    CRL[color1] |= qOne<<rc1;
                    int color2 = 1-color1;                          //color inversion

                    UInt128 Chain = BivalueB & Connected_81[rc1];
                    foreach( var rc2 in Chain.IEGet_rc().Where(rc=> !usedB.IsHit(rc)) ){
                        if( pBOARD[rc2].FreeB!=FreeB ) continue;
                        QueTupl.Enqueue( (rc2,color2) );
                        CRL[color2] |= qOne<<rc2;
                    }
                }
                
                if( CRL[1].BitCount()>0 ) yield return (CRL,FreeB);
                BivalueB = BivalueB & ~(CRL[0]|CRL[1]);
                         // WriteLine( $"{(CRL[0]|CRL[1]).TBScmp()}" );
                         // WriteLine( $" 111 BivalueB{BivalueB.TBScmp()}" );
            }
            yield break;
        }
    }
}