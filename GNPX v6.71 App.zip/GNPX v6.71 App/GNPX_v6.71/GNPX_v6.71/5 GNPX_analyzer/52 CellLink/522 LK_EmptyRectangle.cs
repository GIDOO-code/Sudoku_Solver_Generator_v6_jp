using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space{
    

    public partial class CellLinkGen: AnalyzerBaseV2{

        //EmptyRectangle is an algorithm using cell-to-cell link and ConnectedCells.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page41.html
		// 4762391582391584671..4672397.....3253.2.7.6815613827946.789.51.9.....87.81.72.946

        // 825.3.... 3..8.7... .1.6..8.. 4..32..1. .3..1..7. .9..74..3 ..3..1.2. ...7.5..1 ....6.954  // Puzzle
        // 825139.4. 3..857192 .1.642835 4..32.519 53291.47. .9.5742.3 .534.1.2. 2..7.53.1 ...263954  // Current  


        public bool  EmptyRectangle( ){		// New algorithm using bit representation.
			NXGCellLinkGen_Prepare();

            foreach( int no in Enumerable.Range(0,9) ){  //Focused digit
                var StrongLinks_no = CeLKManA.CellLinks.FindAll(p=> p.no==no && p.sw==1);
                if( StrongLinks_no==null || StrongLinks_no.Count()<2 ) continue;   

				int noB = 1<<no;
                UInt128 BD_Free_no = BOARD_Free81B9[no];

                int no_Fixed_Block = BOARD_Fixed81B9[no].IEGet_rc().Aggregate(0,(a,rc)=>a|1<<rc.B());
                foreach( int rcStem in Enumerable.Range(0,81).Where(rc=> !no_Fixed_Block.IsHit(rc)) ){
					int blk0=rcStem.B(), row0=rcStem/9, col0=rcStem%9;

                    UInt128 houseRow = HouseCells81[row0+0];
					UInt128 houseCol = HouseCells81[col0+9];
					UInt128 houseBlk = HouseCells81[blk0+18];
            
                    // Excluding the rows and columns of rcStem, there are no candidate digits in the block.
					UInt128 houseRowCol = houseRow | houseCol;
                    UInt128 BOARD_no_Block = BD_Free_no & houseBlk;
                    if( (BOARD_no_Block & ~houseRowCol) > qZero )  continue;
					if( (BOARD_no_Block & houseRowCol) == qZero )  continue;


					foreach( var rc1 in (BD_Free_no&houseCol&~houseBlk).IEGet_rc() ){
                        int vKey_row = 1<<(rcStem/9) | 1<<(rc1/9);                      // verification row key
                        foreach( var LK1 in StrongLinks_no.Where(p=>(p.hB&0x1FF)>0) ){
                            if( (LK1.rc1.B()==blk0 || LK1.rc2.B()==blk0) ) continue;    // LK is in a different block from the stem.

                            int LK1_row = 1<<(LK1.rc1/9) | 1<<(LK1.rc2/9); 
                            if( LK1_row == vKey_row ){                                  //Key matches
        					    EmptyRectangle_SolResult( no, blk0, LK1, pBOARD[rc1] ); //solution found
							    if( !pAnMan.IsContinueAnalysis() )  return true;        // @is Valid
                            }
                        }
                    }   

					foreach( var rc2 in (BD_Free_no&houseRow&~houseBlk).IEGet_rc() ){
                        int vKey_col = 1<<(rcStem%9) | 1<<(rc2%9);                      // verification column key
                        foreach( var LK1 in StrongLinks_no.Where(p=>(p.hB&(0x1FF<<9))>0) ){
                            if((LK1.rc1.B()==blk0 || LK1.rc2.B()==blk0) ) continue;     // LK is in a different block from the stem.

                            int LK2_col = 1<<(LK1.rc1%9) | 1<<(LK1.rc2%9); 
                            if( LK2_col == vKey_col ){                                  //Key matches
							    EmptyRectangle_SolResult( no, blk0, LK1, pBOARD[rc2] ); //solution found
							    if( !pAnMan.IsContinueAnalysis() )  return true;        // @is Valid
                            }
                        }
                    }   
                }
            }
            return false;
        }

        
        private void EmptyRectangle_SolResult( int no, int bx, UCellLink PLK, UCell PElm ){
            int noB=(1<<no);
            SolCode = 2;

            PElm.CancelB = noB;                                                 //Cancellation Digit Setting
            if(!Set_Solution_Info) return;
              
            PLK.UCe1.Set_CellColor_BkgColor_noBit( noB, AttCr, SolBkCr2 );      //Mark Strong Links
            PLK.UCe2.Set_CellColor_BkgColor_noBit( noB, AttCr, SolBkCr2 );      //Mark Strong Links
               
            string st=""; 
            foreach( var Q in pBOARD.IEGetCellInHouse(bx+18,noB) ){
                Q.Set_CellColor_BkgColor_noBit(noB,AttCr,SolBkCr);   //Empty Rectangle
                st += " "+Q.rc.ToRCString();
            }
            st = $"ER: B{(bx+1)}({st.ToString_SameHouseComp()})";
            string msg=$"\n         digit: #{(no+1)}\n            {st}";
            msg +=     $"\n        S-Link: {PLK.rc1.ToRCString()}-{PLK.rc2.ToRCString()}";
            msg +=     $"\n   ExcludeCell: {PElm.rc.ToRCString()}";
            ResultLong = "EmptyRectangl"+msg;
        
            Result = $"EmptyRectangl #{(no+1)} in b{(bx+1)} {st}";
        }
    }
}