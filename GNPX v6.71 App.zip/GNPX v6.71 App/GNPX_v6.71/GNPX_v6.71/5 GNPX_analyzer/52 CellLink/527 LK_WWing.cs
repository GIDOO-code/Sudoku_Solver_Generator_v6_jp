﻿using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Interop;
using static System.Diagnostics.Debug;

namespace GNPX_space{
    public partial class CellLinkGen: AnalyzerBaseV2{

        //W-Wing is an algorithm composed of bivalue cell and link.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page43.html

        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
        // ..973..81 .8...9... 7.5.84..3 3....82.7 4.2...... .786..4.5 ...8.6..2 6........ 8.74.15.6

        // .4......5 12..7..86 67..9.32. .....7..2 ..28.37.. 4..2..... .93.8..57 71..5..63 8......9.

        public bool  W_Wing( ){ 
			NXGCellLinkGen_Prepare();
            UChainXY.pBOARD = pBOARD;
                                
            var BivalueList = pBOARD.FindAll(p=>p.FreeBC==2).ConvertAll(p=> new{rc=p.rc, FreeB=p.FreeB} );  // Extract binary cells
            var BivalueGroup_ByFreeB = BivalueList.GroupBy(p=>p.FreeB);                                      // Group by candidate digits set

            foreach( var BV_group in BivalueGroup_ByFreeB.Where(q=>q.Count()>=2) ){      // This test is administered to groups containing two or more elements.      
                int FreeB = BV_group.Key;
                UInt128  rc81 = BV_group.Aggregate(qZero, (a,p) => a| qOne<<p.rc); 

                Combination_81B cmb81 = new( rc81.BitCount(), 2, rc81 );
                while( cmb81.Successor() ){                                             // Focus on two cells.                    
                    UInt128 rc12 = cmb81.valueBT;
                    var (rc1,rc2) = rc12.BitToTupple();
                    UInt128 ConnArea_rc1 = Connected_81[rc1];
                    UInt128 ConnArea_rc2 = Connected_81[rc2];

                    if( (ConnArea_rc1 & cmb81.valueB[1])> qZero || (ConnArea_rc1 & cmb81.valueB[0])> qZero )  continue;               
                    UInt128 ConnArea_rc12_nand = ~ConnArea_rc1 & ~ConnArea_rc2; // = ~(ConnArea_rc1 | ConnArea_rc2);
                    
                    foreach( int no in FreeB.IEGet_BtoNo() ){
                        List<UCellLink> SWLink = CeLKManA.CellLinks
                                    .FindAll( p=> p.sw==1 && p.no==no && (p.link81B&ConnArea_rc12_nand)==qZero
                                                  && (p.link81B&ConnArea_rc1).BitCount()==1 && (p.link81B&ConnArea_rc2).BitCount()==1 );
                        if( SWLink.Count() == 0 )  continue;
                        int no_another = (FreeB & ~(1<<no)).BitToNum();
                        if( BOARD_Free81B9[no_another] == null )  continue;

                        foreach( var LKX in SWLink ){
                            UInt128 ConnArea_LKX =  LKX.link81B.Aggregate_ConnectedOr();    // This condition is not necessary.          
                            UInt128 Exclude = BOARD_Free81B9[no_another].IEGet_rc128(mx:81)  
                                            .Where(rcB=> (rcB&ConnArea_rc1).BitCount()==1 && (rcB&ConnArea_rc2).BitCount()==1 ) //&& (rcB&ConnArea_LKX)==0 )
                                            .Aggregate(qZero,(a,rcB) => a| rcB);                         

                            if( Exclude > qZero ){ // ========== Solution ==========
                                W_Wing_Result( rc12, FreeB, no, no_another, Exclude, LKX );
					            if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid       
                            }
                        }
                    }
                }
            }
            return  (SolCode>0);
                    void  W_Wing_Result( UInt128 rc12, int FreeB, int no, int no_another, UInt128 Exclude, UCellLink LKX ){
                        SolCode=2;

                        rc12.IE_SetNoBBgColor( pBOARD, FreeB,  AttCr, SolBkCr2 );
                        LKX.link81B.IE_SetNoBBgColor( pBOARD, FreeB,  AttCr, SolBkCr );
                        foreach( var P in Exclude.IEGet_UCell(pBOARD) ) P.CancelB = (1<<no_another);

                        string msg0 = $"  Bivalue: {rc12.TBScmp()}";
                        string msg1 = $"     Link: {LKX.rc1.ToRCString()} - {LKX.rc2.ToRCString()} #{no+1} ";

                        ResultLong = $"W_Wing\n{msg0}\n{msg1}\n Exclude :{Exclude.TBScmp()} #{no_another+1}";
                        string st = ResultLong.Replace("\n","").Replace("   "," ").Replace("  "," ").Replace("  "," ").Replace(" - ","-");
                        Result = st.Replace("Bivalue","BV").Replace("Link","LK").Replace("Exclude :","Exc.:");
                    }
           
        }
    }
}