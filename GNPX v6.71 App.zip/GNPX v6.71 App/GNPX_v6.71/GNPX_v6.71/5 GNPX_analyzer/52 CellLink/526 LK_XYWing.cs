using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Interop;
using System.Windows.Media;
using static System.Diagnostics.Debug;

namespace GNPX_space{
    public partial class CellLinkGen: AnalyzerBaseV2{

        //XY_Wing is an algorithm that consists of two WeakLinks with common cells.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page42.html

        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
        // .1..7.69. 4.6.9..1. 5.9.2...8 7....9... .9..3..8. ...8....4 1...6.8.9 .8..4.7.5 .67.8..4.
        // 81..7.69. 4.639851. 5.9.2.4.8 748.19.5. .95.3..8. ..185.9.4 154.6.8.9 .8..4.765 .67.8..4.

        // 6..1....7 ..18.73.. .2.3...9. .5.9.8641 ......... 1482.6.3. .7...2.1. ..64.18.. 8....3..4
        // 683129457 591847326 .2.365198 .5.938641 369.14.8. 1482.6.3. .7.682.13 .364.187. 81...3.64

        // 6..1....7 ..18.73.. .2.3...9. .5.9.8641 ......... 1482.6.3. .7...2.1. ..64.18.. 8....3..4
        // 683129457 591847326 .2.365198 .5.938641 369.14.8. 1482.6.3. .7.682.13 .364.187. 81...3.64



        public bool XY_Wing( ){
			NXGCellLinkGen_Prepare();
            UChainXY.pBOARD = pBOARD;                                           // Generate WeakLinks
                                
            UInt128 BP_bivalue = pBOARD.FindAll(p=>p.FreeBC==2).Aggregate(qZero, (a,p)=> a| qOne<<p.rc );

            if( BP_bivalue.BitCount()<3 ) return false;     

            foreach( UCell UStem in BP_bivalue.IEGet_UCell(pBOARD) ){
                int FreeBXY = UStem.FreeB;
                var (no1,no2) = FreeBXY.BitToTupple();
                UInt128 Connected_Stem_BV = Connected_81[UStem.rc] & BP_bivalue;
                UInt128 Connected_Stem_BV_no1 = Connected_Stem_BV & BOARD_Free81B9[no1];
                UInt128 Connected_Stem_BV_no2 = Connected_Stem_BV & BOARD_Free81B9[no2];

                foreach( UCell ULeaf1 in Connected_Stem_BV_no1.IEGet_UCell(pBOARD) ){
                    if( (FreeBXY & ULeaf1.FreeB).BitCount() > 1 )  continue;
                    int noWing = (ULeaf1.FreeB & ~FreeBXY).BitToNum();
                    UInt128 Connected_ULeaf1 = Connected_81[ULeaf1.rc] & BOARD_Free81B9[noWing];

                    foreach( UCell ULeaf2 in Connected_Stem_BV_no2.IEGet_UCell(pBOARD).Where(P=> (P.FreeB&noWing)==0) ){
                        if( (FreeBXY & ULeaf2.FreeB).BitCount() > 1 )  continue;
                        int noX2 = (ULeaf2.FreeB & ~FreeBXY).BitToNum();
                        if( noWing != noX2 )  continue;
                        UInt128 Connected_ULeaf2 = Connected_81[ULeaf2.rc] & BOARD_Free81B9[noWing];
                        
                        UInt128 Exclude = Connected_ULeaf1 & Connected_ULeaf2;

                        if( Exclude != 0 ){ // ========== Solution ==========
                            SolCode=2;
                            foreach( var P in Exclude.IEGet_UCell(pBOARD) )  P.CancelB |= (1<<noWing);
                            UInt128 XY_Wing = (qOne<<UStem.rc) | (qOne<<ULeaf1.rc) | (qOne<<ULeaf2.rc); 
                            // Color Cr = PastelColors[0];
					        XY_Wing.IE_SetNoBBgColor( pBOARD, UStem.FreeB, AttCr, SolBkCr);
            
                            string msg0= $" Pivot: {UStem.rc.ToRCString()} #{FreeBXY.TBScmp()}";
                            string msg1= $" Pin: {ULeaf1.rc.ToRCString()} #{ULeaf1.FreeB.TBScmp()},";
                            string msg2= $"  {ULeaf2.rc.ToRCString()} #{ULeaf2.FreeB.TBScmp()},";
                            Result="XY_Wing"+msg0;
                            ResultLong=$"XY_Wing\n {msg0}\n   {msg1}{msg2}\n  Exclude:{Exclude.TBScmp()} #{noWing+1}";

        				    if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                        }
                    }
                }
            }

            return false;

        }
    }
}