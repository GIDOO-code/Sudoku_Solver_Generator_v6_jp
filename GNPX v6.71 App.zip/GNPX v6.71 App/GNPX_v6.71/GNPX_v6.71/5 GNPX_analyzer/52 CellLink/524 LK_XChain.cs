  using System;
using System.Collections.Generic;
using System.Windows.Media;
using System.Linq;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Collections.Immutable;

namespace GNPX_space{

    public partial class CellLinkGen: AnalyzerBaseV2{

        //X-Chain is an algorithm using Locked which occurs when concatenating strong and weak links.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page48.html

        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
        // ..2..56.1 45..92... .6.41.9.2 ..5.7.... 8.......7 ....2.3.. 1.3.46.2. ...95..73 5.92..8..  // Puzzle
        // 5134..296 679512483 842693517 485.691.2 3962.1.54 721.54..9 23814.9.5 954.3..21 167925348  // Current

        // ...4..296 .79..2..3 .42..351. 4.......2 .....1.5. .21.54..9 2.8...9.. 9.4.3...1 16.9.5.4.  // Puzzle
        // 5134..296 679512483 842693517 485.691.2 3962.1.54 721.54..9 23814.9.5 954.3..21 167925348  // Current


        // Code that prioritizes clarity over speed!

        public bool X_Chain(){
			NXGCellLinkGen_Prepare();
           
            Color Cr = PastelColors[0];
            Color Cr1=Cr; Cr1.A=255;
            Color Cr2=Cr; Cr2.A=128;
            Color Cre=PastelColors[1]; Cre.A = 128;

            foreach( int no in Enumerable.Range(0,9) ){ 
                int noB = (1<<no);   

                foreach( var (CRL,rcStart) in _GetXChain(no) ){

                    // ===== X-Chain found =====
                    UInt128 ELM = CRL[2];
                    foreach( var P in ELM.IESelect81B_with_noB(pBOARD,noB) )  P.CancelB = noB; 
                    SolCode = 2;   
                    string SolMsg=$"X-Chain #{(no+1)} rcStart:{rcStart.ToRCString()}({rcStart})";
                    Result=SolMsg;
                    if( Set_Solution_Info ){  
                        (CRL[0]&~ELM).IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr1 );     
                        (CRL[1]&~ELM).IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr2 );  
                        ELM.IE_SetNoBBgColor( pBOARD, noB, AttCr, Cre );
                        ResultLong=SolMsg;
                    }

					if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                }
            }
            return false;
        }
             
        private IEnumerable<(UInt128[],int)> _GetXChain( int no ){  //## Repeatedly coloring processing.
            var S_Lnks_no  = CeLKManA.CellLinks.FindAll(p=> p.no==no && p.sw==1);   // Strong links
            var SW_Lnks_no = CeLKManA.CellLinks.FindAll(p=> p.no==no);              // All links
            var Links_no   = new[]{ S_Lnks_no, SW_Lnks_no};

            if( S_Lnks_no==null || S_Lnks_no.Count()<2 )  yield break;


            UInt128     start_B81 = S_Lnks_no.Aggregate(qZero, (a,p)=> a|p.link81B );
            UInt128[]   CRL = new UInt128[3];
            UInt128     UsedG = qZero;
            foreach( var rcStart in start_B81.IEGet_rc() ){
                if( (UsedG & (qOne<<rcStart)) > qZero )  continue;

                CRL[0]=qZero; CRL[1]=qZero;

                Queue<(int,int)> Que = new();
                Que.Enqueue( (rcStart,0) );

                UInt128 usedB = qZero;
                while( Que.Count > 0 ){   // Repeat until queue is empty.
                    var (rcCurrent,color) = Que.Dequeue();
                    UInt128  current81B = qOne<<rcCurrent;
                    usedB |= current81B;
                    CRL[color] |= current81B;

                    var Q = Links_no[color].FindAll( P=> (P.link81B&current81B)>qZero ); // Links_no[color] : Switch S-link/SW-link with color
                    var nextB = Q.Aggregate(qZero, (a,P) =>  a | P.link81B );      
                    foreach( int rc in (nextB&~usedB).IEGet_rc() )  Que.Enqueue( (rc,(1-color)) );   // push to queue
                }

                CRL[2] = (Connected_81[rcStart] & CRL[0]);      // Exclude Cells
                if( CRL[2].BitCount()>0 ){ 
                    yield return (CRL,rcStart);
                    UsedG |= (CRL[0] | CRL[1]); 
                    CRL = new UInt128[3];
                }
            }
            yield break;
        }
    }

}