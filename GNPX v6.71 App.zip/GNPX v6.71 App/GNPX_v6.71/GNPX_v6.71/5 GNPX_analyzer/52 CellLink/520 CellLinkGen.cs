 using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space{

    public partial class CellLinkGen: AnalyzerBaseV2{
        public CellLinkGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }

        private int            stageNoPMemo = -9;	
        public CellLinkMan?   CeLKManA;
        public void NXGCellLinkGen_Prepare( bool debugPrint=false ){
            if (stageNoP != stageNoPMemo){
                stageNoPMemo = stageNoP;
                base.AnalyzerBaseV2_PrepareStage();
                CeLKManA = new CellLinkMan(pAnMan);
                CeLKManA.PrepareCellLink();
			}
            return;
		}
    }

}