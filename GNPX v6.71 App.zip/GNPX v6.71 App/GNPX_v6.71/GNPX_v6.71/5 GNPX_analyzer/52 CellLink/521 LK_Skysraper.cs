 using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space{


        //Skyscraper is an algorithm consisting of two StrongLinks.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page40.html

        // .5.....9. 3...2...5 ..2...68. ....65... .8.7..4.9 ...9.1.5. ..6.5..32 2.5..49.. .7..9.5.6
        // 857316294 36..2...5 .125..683 ....65.2. 581732469 62.9.1.5. ..6.5..32 2356.49.. 178293546

        // 56....... ....23.4. 9.....18. 6....14.. .592.486. ..16....3 .36.....9 .7.36.... .......34

    public partial class CellLinkGen: AnalyzerBaseV2{
        public bool Skyscraper(){
            NXGCellLinkGen_Prepare();

            foreach( int no in Enumerable.Range(0,9) ){ 
                int noB = 1<<no;
                var StrongLinks_no = CeLKManA.CellLinks.FindAll(p=> p.no==no && p.sw==1);
                if( StrongLinks_no==null || StrongLinks_no.Count()<2 ) continue;    
                
                Combination prm = new( StrongLinks_no.Count, 2 );                 // Linked(SSLst) list contains both x-y and y-x
                int nxtX=1;
                while(prm.Successor(nxtX)){
                    UCellLink UCLa = StrongLinks_no[ prm.Index[0] ];
                    UCellLink UCLb = StrongLinks_no[ prm.Index[1] ];

                    UInt128 conn_a = UCLb.connectedArea & UCLa.link81B;
                    UInt128 conn_b = UCLa.connectedArea & UCLb.link81B; 
                    if( conn_a.BitCount()!=1 || conn_b.BitCount()!=1)  continue;

                    int rc_conn_a = conn_a.BitToNum(81);
                    int rc_conn_b = conn_b.BitToNum(81);

                    UInt128 ELM = (UCLa.connectedArea & UCLb.connectedArea) & BOARD_Free81B9[no];
                    ELM &= ~(conn_a | Connected_81[rc_conn_a] | conn_b | Connected_81[rc_conn_b]);
                 
                    foreach(UCell P in ELM.IESelect81B_with_noB(pBOARD,noB)) P.CancelB=P.FreeB&noB;
                    if( pBOARD.All(p=>p.CancelB==0) )  continue;

                    skyscraper_Result( UCLa, UCLb, ELM );
                    if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                }

            }
            return (SolCode>0);
        }         
                    void skyscraper_Result( UCellLink UCLa, UCellLink UCLb, UInt128 ELM ){
                        int no=UCLa.no, noB=1<<no;

                        // ---------- Result ----------
                        SolCode =2;                

                        UInt128 Skyscraper81 = UCLa.link81B | UCLb.link81B;
                        Skyscraper81.IE_SetNoBBgColor(pBOARD, noB, AttCr, SolBkCr);
            
                        string msg = $"SkyscraperV7\n digitt : #{no+1}\n link : {UCLa.link81B.TBScmp()} - {UCLb.link81B.TBScmp()}";
                        msg += $"\n exclude : {ELM.TBScmp()}";
                        ResultLong = msg;
                        Result = $"SkyscraperV7 #{no+1} {UCLa.link81B.TBScmp()}-{UCLb.link81B.TBScmp()} exclude:{ELM.TBScmp()}";
                    }
    }
}