using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using System.Windows.Shapes;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Security.Cryptography;
using System.Runtime.CompilerServices;
using System.Windows.Documents;

namespace GNPX_space{
    public partial class CellLinkGen: AnalyzerBaseV2{

        //Coloring is an algorithm that connects the focused digit with a strong link.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page46.html

        public bool Color_Trap( ){
            //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
            //4....9.5.23..58.67...4.7.........3253.2....8.5.1...7.....89....9......7..1.72..46  by /Solve/MultiSolve step19
            //4762391582391584671..4672397.....3253.2.7.6815613827946.789.51.9.....87.81.72.946  for develop.

			NXGCellLinkGen_Prepare();

            foreach( int no in Enumerable.Range(0,9) ){ 
                int noB=(1<<no);
                foreach( UInt128[] CRL in _Coloring2(no,minSize:3) ){                   // _Coloring: cells_network connected by strong-links
                    UInt128 HitB = UInt128.Zero;
                    UInt128 ELM  = BOARD_Free81B9[no] & ~(CRL[0] | CRL[1]);
                    foreach( var rc in ELM.IEGet_rc() ){                                // rc:Candidate cell  
                        UInt128 connB = Connected_81[rc];                               // Cells not included in Network
                        if( (connB&CRL[0])==qZero || (connB&CRL[1])==qZero) continue;
                        HitB |= qOne<<rc;                                               // solution cells
                    }

                    if( HitB > qZero ){     //===== found =====
                        //WriteLine( $"     no:#{no+1}\n   HitB:{HitB.TBS()}\n CRL[0]:{CRL[0].TBS()}\n CRL[1]:{CRL[1].TBS()}" );
                        _Color_Trap_Result( no, HitB, CRL );
						if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                        HitB=new UInt128();
                    }
                }
            }
            return false;

                    void _Color_Trap_Result( int no, UInt128 HitB, UInt128[] CRL ){
                        int noB = 1<<no;
                        foreach( var P in HitB.IEGet_rc().Select(p=>pBOARD[p]) )   P.CancelB |= noB;    
                        
                        SolCode = 2;
                        string SolMsg="Coloring Trap #"+(no+1);
                        Result = SolMsg;
                        if( Set_Solution_Info ){
                            string st1 = $"\n group 1 : {CRL[0].ToRCStringComp()}";
                            st1 += $"\n group 2 : {CRL[1].ToRCStringComp()}";
                            st1 += $"\n eliminate : {HitB.ToRCStringComp()}#{no+1}";

                            ResultLong = SolMsg + st1;
                        
                            Color Cr =PastelColors[0]; // 0:Yellow 1:LightGreen, 2:Aqua
                            Color Cr1= Cr * 0.6f;                  //Color.FromArgb(120,Cr.R,Cr.G,Cr.B);  
                            CRL[0].IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr );
                            CRL[1].IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr1 );
                        }
                    }
        }

        public bool Color_Wrap( ){
            //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/    
            //..9..154..5..9.....6.5..92.8..3..1.41..4.6..95.4..8..2.42..9.6.....6..1..187..2..  by /Solve/MultiSolve step3

			NXGCellLinkGen_Prepare();

            foreach( int no in Enumerable.Range(0,9) ){ 
                int noB=(1<<no);
                UInt128 BD_Free_no = BOARD_Free81B9[no];

                foreach( UInt128[] CRL in _Coloring2(no,minSize:3) ){                // _Coloring: cells_network connected by strong-links
                    if( CRL[0].BitCount()<=1 || CRL[1].BitCount()<=1)  continue;

                    UInt128 ELM = BD_Free_no &~(CRL[0] | CRL[1]);                    // ELM:Elements not included in the network
                    if( ELM.BitCount()==0 ) continue;

                    for(int k=0; k<2; k++ ){    
                        for(int h=0; h<27; h++ ){
                            if( (CRL[k]&HouseCells81[h]).BitCount() < 2 ) continue;
                            //There are two Cs of the same color. If this is true it will break the network.

                            //===== found =====
                            _Color_Wrap_Result( k, no, CRL );
                            
							if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                        }
                    }
                }
            }
            return false;

                    void _Color_Wrap_Result( int k, int no, UInt128[] CRL ){
                        int noB = 1<<no;
                        foreach( var Q in CRL[k].IEGet_rc().Select(p=>pBOARD[p]) ) Q.CancelB=noB; 
                            
                        SolCode = 2;
                        string SolMsg="Coloring Wrap #"+(no+1);
                        Result=SolMsg;
                        if( Set_Solution_Info ){
                            string st1 = $"\n group 1 : {CRL[1-k].ToRCStringComp()}";
                            st1 += $"\n group 2 : {CRL[k].ToRCStringComp()}";
                            st1 += $"\n eliminate : {CRL[k].ToRCStringComp()}#{no+1}";

                            ResultLong = SolMsg + st1;
                            Color Cr  = PastelColors[0];
                            Color Cr1 = Cr;     
                            Color Cr2 = Cr * 0.6f;
                            CRL[1-k].IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr1 );
                            CRL[k].IE_SetNoBBgColor(   pBOARD, noB, AttCr, Cr2 );
                        }
                    }
        }

        //=================== MultiColoring ==================================
        public bool MultiColor_Type1( ){
            //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
            //..9..154..5..9.....6.5..92.8..3..1.41..4.6..95.4..8..2.42..9.6.....6..1..187..2..  by /Solve/MultiSolve step8

			NXGCellLinkGen_Prepare();
            
            foreach( int no in Enumerable.Range(0,9) ){ 
                int noB=(1<<no);
                UInt128 BD_Free_no = BOARD_Free81B9[no];
                List<UInt128[]> MCRL = _Coloring2(no:no, minSize:3).ToList();

                if( MCRL==null || MCRL.Count()<2 ) continue;

                var  cmb = new Combination( MCRL.Count(), 2 );
                while( cmb.Successor() ){
                    UInt128[] CRLa = MCRL[cmb.Index[0]];      // group_A
                    UInt128[] CRLb = MCRL[cmb.Index[1]];      // group_B

                    for(int na=0; na<2; na++ ){
                        UInt128 HCRLa = new UInt128();
                        foreach(var rc in CRLa[na].IEGet_rc()) HCRLa |= Connected_81[rc]; // HCRLa: cell group connected to group_A[na]

                        for(int nb=0; nb<2; nb++ ){
                            if( (HCRLa&CRLb[nb]).IsZero() ) continue;
                            // HCRLa and group_B[nb] are weakly connected

                            UInt128 ELMtry = BD_Free_no & ~( (CRLa[na] | CRLb[nb] | CRLa[1-na] | CRLb[1-nb]) ); // Cells unrelated to group_A and group_A
                            if(ELMtry.BitCount() ==0) continue;
                            
                            bool found=false;
                            UInt128 ELM=new UInt128();
                            foreach( var rc in ELMtry.IEGet_rc() ){
                                if( !Connected_81[rc].IsHit(CRLa[1-na]) ) continue;
                                if( !Connected_81[rc].IsHit(CRLb[1-nb]) ) continue;
                                pBOARD[rc].CancelB=noB; ELM|=qOne<<rc; found=true;
                            }
                            if(found){
                                _MultiColor_Type1_Result( no, MCRL, ELM, cmb.Index );
								if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                            }
                        }
                    }
                }
            }
            return false;  

                            void _MultiColor_Type1_Result( int no, List<UInt128[]> MCRL, UInt128 ELM, int[] Index ){
                                int noB = 1<<no;
                                string SolMsg="MultiColoring Type1 #"+(no+1);
                                SolCode = 2;

                                Result=SolMsg;
                                if( !Set_Solution_Info )  return;

                                Color CrA = PastelColors[4];
                                foreach( var P in ELM.IEGet_rc().Select(p=>pBOARD[p]) ) P.Set_CellColor_BkgColor_noBit(noB,AttCr,CrA);
                                string st1 = "";
                                for(int k=0; k<2; k++){
                                    UInt128[] CRLX = MCRL[Index[k]];
                                    Color Cr1=PastelColors[k*2];
                                    Color Cr2 = Cr1 * 0.6f;          
                                    CRLX[1-k].IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr1 );
                                    CRLX[k].IE_SetNoBBgColor(   pBOARD, noB, AttCr, Cr2 );

                                    st1 +=  $"\n group {k+1}-A: {CRLX[0].ToRCStringComp( $"#{no+1}" )}";
                                    st1 +=  $"\n group {k+1}-B: {CRLX[1].ToRCStringComp( $"#{no+1}" )}";
                                }
                                st1 +=  $"\n eliminate : {ELM.ToRCStringComp( $"#{no+1}" )}";
                               
                                ResultLong = SolMsg + st1;
                            }
        }

        public bool MultiColor_Type2( ){
            //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
            //...6.8...6...9...529.....483.1...4.64..3.1..2...8.6....1.4.2.7..6.7.9.5.....8....  by /Solve/MultiSolve step11

            // .46..3.8. 72....... .8.7..3.. ..42.7... ..9.58.2. .....6..1 ..14396.. 4.....139 .976.1.4.
            // .46..3.8. 723...... .857..3.. ..42.7... 6.9.58.2. ....46..1 .5143967. 46..7.139 3976.1.4.

			NXGCellLinkGen_Prepare();

            foreach( int no in Enumerable.Range(0,9) ){ 
                int noB=(1<<no);
                List<UInt128[]> MCRL = _Coloring2(no:no, minSize:2).ToList();
                   // foreach( var (CRL,kx) in MCRL.WithIndex() )
                   //       WriteLine( $"\n kx:{kx}  no:#{no+1}\n  0:{CRL[0].TBScells()}\n  1:{CRL[1].TBScells()}" ); 
                if(MCRL==null || MCRL.Count()<2)  continue;


                var prm = new Permutation( MCRL.Count(), 2 );
                while(prm.Successor()){
                    UInt128[] CRLa = MCRL[prm.Index[0]];
                    UInt128[] CRLb = MCRL[prm.Index[1]];
        
                    UInt128[] CRLa_conn = new UInt128[]{ CRLa[0].Aggregate_ConnectedOr(), CRLa[1].Aggregate_ConnectedOr() };
                    foreach( var (Pconn,nx) in CRLa_conn.WithIndex() ){
                        if( (CRLb[0]&Pconn)>qZero && (CRLb[1]&Pconn)>qZero ){
                            _MultiColor_Type2_Result( no, CRLb, CRLa, nx );
                            if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                        }
                    }
        
                    UInt128[] CRLb_conn = new UInt128[]{ CRLb[0].Aggregate_ConnectedOr(), CRLb[1].Aggregate_ConnectedOr() };
                    foreach( var (Pconn,nx) in CRLb_conn.WithIndex() ){
                        if( (CRLa[0]&Pconn)>qZero && (CRLa[1]&Pconn)>qZero ){
                            _MultiColor_Type2_Result( no, CRLa, CRLb, nx );
                            if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                        }

                    }
        
                }
            }
            return false;    

                    void _MultiColor_Type2_Result( int no, UInt128[] CRLa, UInt128[] CRLb, int nx ){
                        int noB = 1<<no;

                        SolCode = 2;
                        foreach( var P in CRLb[nx].IEGet_rc().Select(p=>pBOARD[p]) ) P.CancelB=noB;                       

                        string SolMsg="MultiColoring Type2 #"+(no+1);
                        Result=SolMsg;
                        if( Set_Solution_Info ){

                            Color Cr1 = PastelColors[0];   
                            Color Cr2 = Cr1 * 0.6f;
                            CRLa[0].IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr1 );
                            CRLa[1].IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr2 );

                            Cr1 = PastelColors[1];   
                            Cr2 = Cr1 * 0.7f;
                            CRLb[0].IE_SetNoBBgColor( pBOARD, noB, AttCr, Cr2 );
                            CRLb[1].IE_SetNoBBgColor(   pBOARD, noB, AttCr, Cr1 );

                            string st1 = $"\n group 1-A: {CRLa[0].ToRCStringComp( $"#{no+1}" )}";
                            st1 += $"\n group 1-B: {CRLa[1].ToRCStringComp( $"#{no+1}" )}";
    
                            st1 += $"\n group 2-A: {CRLb[0].ToRCStringComp( $"#{no+1}" )}";
                            st1 += $"\n group 2-B: {CRLb[1].ToRCStringComp( $"#{no+1}" )}";   
        
                            st1 +=  $"\n exclude : {CRLb[nx].ToRCStringComp( $"#{no+1}" )}";
                            
                            ResultLong = SolMsg + st1;
                        }
                    }

        }    


        private IEnumerable<UInt128[]> _Coloring2( int no, int minSize=3 ){ 
            var StrongLinks_no = CeLKManA.CellLinks.FindAll(p=> p.no==no && p.sw==1);
            if( StrongLinks_no==null || StrongLinks_no.Count()<2 )  yield break;

            Queue<(int,int)> Que = new();
            UInt128     start_B81 = StrongLinks_no.Aggregate(qZero, (a,p)=> a|p.link81B );
            UInt128[]   CRL = new UInt128[2];
            UInt128     UsedG = qZero;
            foreach( var rcStart in start_B81.IEGet_rc() ){
                if( (UsedG & (qOne<<rcStart)) > qZero )  continue;
                UInt128 usedB = qZero;

                CRL[0]=qZero; CRL[1]=qZero;
                Que.Enqueue( (rcStart,0) );
                        //WriteLine( $"\n\n ///// rcStart:{rcStart.ToRCString()} /////" );

                while( Que.Count > 0 ){                                                     // Repeat until queue is empty.
                    var (rcCurrent,color) = Que.Dequeue();
                        //WriteLine( $"  +++ rcCurrent:{rcCurrent.ToRCString()} - {color}" );

                    UInt128  current81B = qOne<<rcCurrent;
                    usedB |= current81B;
                    CRL[color] |= current81B;

                    var Q = StrongLinks_no.FindAll( P=> (P.link81B&current81B)>qZero );     // Strong-Link connected to current-Node
                    var nextB = Q.Aggregate(qZero, (a,P) =>  a | P.link81B );      // Unused Nodes
                        //WriteLine( $"   nextB:{nextB.TBS()}\n    ---CRL[0]:{CRL[0].TBS()}\n    ---CRL[1]:{CRL[1].TBS()}" );

                    foreach( int rc in (nextB&~usedB).IEGet_rc() )  Que.Enqueue( (rc,(1-color)) );   // push to queue
                }

                if( CRL[0]>qZero && CRL[1]>qZero && (CRL[0]|CRL[1]).BitCount()>=minSize ){
                    yield return CRL;
                    UsedG |= (CRL[0] | CRL[1]); 
                    CRL = new UInt128[2];
                }
            }
            yield break;
        }
    }
}
