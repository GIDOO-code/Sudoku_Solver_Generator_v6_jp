using System;
using System.Collections.Generic;
using System.Windows.Media;
using System.Linq;

using GIDOO_space;
//using System.Windows.Input.Manipulations;
using static System.Diagnostics.Debug;
using System.Linq.Expressions;

namespace GNPX_space{
    public partial class CellLinkGen: AnalyzerBaseV2{

        //XY-Chain is an algorithm using Locked which occurs in the concatenation of bivalues.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page49.html

        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
        // .5....3.. .71.43... 2..61...9 ..5....7. 7.34..19. 1...9.8.. 3.2.64.5. .......18 5.927.4..
        // .5....3.1 .71.435.. 23.6157.9 895...674 7.34..19. 1...9.8.. 3.2.64957 ..7..9218 5.927.4..  step 18

        // ...71...9 .14.9.... .9....3.7 2...4.5.1 86.1.72.. ....8.7.. ..6471..5 .......68 9.25..17.
        // .2371.849 714893652 .98..4317 2...4.581 86.1.72.4 4.1.8.7.6 386471925 1.....468 942568173  step 21



        private class UChainXY{
            static public List<UCell>  pBOARD;
            public int   rc;
            public int   no;
            public UChainXY pre;
            public List<UChainXY> next;

            public UCell Cell => pBOARD[rc];

            public UChainXY( int rc, int no, UChainXY pre){
                this.rc=rc; this.no=no; this.pre = pre;
            }

            public override string ToString(){
                string  stPre = (pre==null)? "-": $"{(pre.rc).ToRCString()}#{pre.no+1}";
                string  st = $"@< {rc.ToRCString()}#{no+1}> <- @<{stPre}";
                return  st;
            }
        }  


        public bool XY_Chain(){
			NXGCellLinkGen_Prepare();
            UChainXY.pBOARD = pBOARD;

            foreach( var (XYChainList,PatternExclude,noStart) in _GetXYChain_sub() ){

                //===== XY-Chain found =====
                SolCode=2;                    
                String SolMsg = $"XY_Chain {PatternExclude.TBScmp()} #{noStart+1} is false";
                Result = SolMsg;
                int noB = (1<<noStart);
                foreach( var P in PatternExclude.IEGet_UCell(pBOARD) )  P.CancelB |= noB;

                if( Set_Solution_Info ){
                    string msg2 = "";
                    Color Cr = PastelColors[0];
                    foreach( var P in XYChainList ){
                        P.Cell.Set_CellColor_BkgColor_noBit(1<<P.no,AttCr,Cr);
						msg2 += $" - {(P.Cell.rc).ToRCString()}#{P.no+1}";
                    }
                    ResultLong = $"{SolMsg}\n >{msg2.Substring(2)}\n Exclude : {PatternExclude.TBScmp()} #{noStart+1}" ;
                    if( XYChainList.Count() >= 6 )  extResult = ResultLong;
                }

				if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
            }
            return false;

            // = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
        
                    IEnumerable< (List<UChainXY>,UInt128,int) > _GetXYChain_sub( ){  
                        UInt128 BP_bivalue = pBOARD.FindAll(p=>p.FreeBC==2).Aggregate(qZero, (a,p)=> a| qOne<<p.rc );
               
                        UInt128    usedG = qZero;
                        foreach( var rcStart in BP_bivalue.IEGet_rc().Where(rc=>(usedG&(qOne<<rc))==0) ){ // Choose one BV_Cell(=>PStart) 
                            UInt128 rcStartB = qOne<<rcStart;

                            UCell  PRoot = pBOARD[rcStart];
                            foreach( var noStart in PRoot.FreeB.IEGet_BtoNo() ){                    // Choose one digit

                                // ===== prepare ===================================
                                UInt128 PatternStart = Connected_81[rcStart] & BOARD_Free81B9[noStart] & ~rcStartB; // here if there is a solution
                                if( PatternStart == qZero ) continue;

					            Queue<UChainXY> Que = new();
					            Que.Enqueue( new UChainXY(rcStart,noStart,null) );

                                // ===== search ====================================
                                UInt128 used = qZero;
                                bool firstB=true;
                                while(Que.Count>0){                                             // Extend the chain step by step
                                    
                                    // ===== origin ==========
                                    var XYChain_1 = Que.Dequeue();
                                    int rc1=XYChain_1.rc, no1=XYChain_1.no;
        			                used |= qOne<<rc1;
                                    int  no1B = 1<<XYChain_1.no;
                                     
                                    UCell Uorg = pBOARD[rc1];
                                    int no2 = (Uorg.FreeB & ~no1B).BitToNum();


                                    // ===== destination =========
                                    UInt128 Q = Connected_81[rc1] & BOARD_Free81B9[no2] & BP_bivalue & ~used;
                                    foreach( int rc2 in Q.IEGet_rc().Where(rc=>(used&(qOne<<rc))==0) ){
                                        UCell UC2 = pBOARD[rc2];
                                        if( firstB ){ // Is the first chain an S-link?
                                            UInt128 link81B = rcStartB | (qOne<<rc2);
                                            var R = CeLKManA.CellLinks_rc[rc1].FindAll(p=> p.sw==1 && p.no==no2 && p.link81B==link81B);
                                            if( R == null )  goto LBreak;  
                                        }

                                        var XYChain_2 = new UChainXY(rc2,no2,XYChain_1);
        			                    Que.Enqueue( XYChain_2 );
                
                                        int noEnd = (UC2.FreeB & ~(1<<no2)).BitToNum();
                                        UInt128 PatternDes = Connected_81[rc2] & BOARD_Free81B9[noEnd] & ~rcStartB;
                                        UInt128 PatternExclude = PatternStart & PatternDes & ~used;       

                                        if( noEnd==noStart && PatternExclude>qZero ){  
                                            { // Is the last chain an S-link?
                                                UInt128 link81B = rcStartB | (qOne<<rc2);
                                                var R = CeLKManA.CellLinks_rc[rc2].FindAll(p=> p.sw==1 && p.no==noStart && p.link81B==link81B);
                                                if( R == null )  goto LBreak;  
                                            }

                                            // === found XY-Chain ===
                                            List<UChainXY>  XYChainList = new();
                                            var XYC = XYChain_2;
                                            UInt128 usedSol = qZero; 
                                            while(XYC!=null){ usedSol|=(qOne<<XYC.rc); XYChainList.Add(XYC); XYC=XYC.pre; };
                                            XYChainList.Reverse();
                                            yield return (XYChainList,PatternExclude,noStart);  
                                            usedG |= usedSol;
                                            goto LBreak;
                                        } 
                                    }
                                    firstB = false;
                                }

                            LBreak:
                                continue;
                            }
                        }
                        yield break;
                    }

        }

    }
}