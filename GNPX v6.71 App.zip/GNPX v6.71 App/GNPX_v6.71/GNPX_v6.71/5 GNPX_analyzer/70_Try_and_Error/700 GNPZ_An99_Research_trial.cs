using System.Diagnostics;
using System.IO;
using System.Numerics;
using System.Text;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space{

// *=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
// "TrialAndErrorApp" routine is independent of GNPX.
// It is structured to facilitate reuse in other contexts.
// (Some minor adjustments may be required.)
// *=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*

    public partial class Research_trial{
        private object  lockObj = new();

        // ... ... ...
        private string dirName = "Debug";
        private string TE_fileName => $"Multiple_Solutions {DateTime.Now.ToString("yyyyMMdd")}.txt";

        public List<string>     stTE_SolList;
        private List<int[]>     IArrayList;
        public List<List<int>>  I_SolList => IArrayList.ConvertAll( P => P.ToList() );

        public  TimeSpan        laps_Time = new();
        private Stopwatch       SW;

        public Research_trial( ){
            SW = new();
        }




        public List<UCell> RT_Get_Board(  ){
            int rc = 0;
            return I_SolList[0].ConvertAll( no => new UCell(rc++, no));
        }


        public List<string> TrialAndErrorApp( string stPZL, bool filePutB, int upperLimit=int.MaxValue ){
            if(stPZL == null) return null;
            List<int> PZL = __stringToInt( stPZL.Replace(".", "0") ).ToList();

            stTE_SolList = TrialAndErrorApp( PZL, filePutB, upperLimit: upperLimit);

            return stTE_SolList;

		            IEnumerable<int> __stringToInt( string source ){
                        int ToInt( char ch ) => int.Parse( ch.ToString() );
			            foreach( int k in Enumerable.Range(0,source.Length) )  yield return ToInt( source[k] );
		            }
        }


        public List<string> TrialAndErrorApp( List<int> PZLlist, bool filePutB, int upperLimit=int.MaxValue ){
            if(PZLlist == null) return null;
            int[] PZL99 = PZLlist.ToArray();
            IArrayList = TE_Solver( PZL99, upperLimit);
            
            stTE_SolList = IArrayList.ConvertAll( P => string.Join("",P) );

            if( filePutB ) _fileOutput_TE_multisolution();    
            return stTE_SolList;

                    void _fileOutput_TE_multisolution(){
                        lock(lockObj){
                            if( !Directory.Exists(dirName)) Directory.CreateDirectory(dirName);
                            using (var fpW = new StreamWriter($"{dirName}/{TE_fileName}", append: true, Encoding.UTF8)){
                                fpW.WriteLine($"\n{DateTime.Now}  {stTE_SolList.Count} solutions");
                                int mx = 0;
                                stTE_SolList.ForEach(Q => fpW.WriteLine($"{Q} solution:{++mx}"));
                            }
                        }
                    }
        }
    }




#region  1D array version
    // =================================================================================================
    // ** Try and Error Sudoku Solver ... 1D array version
    // =================================================================================================

    public partial class Research_trial{

        public List<int[]> TE_Solver( int[] puzzle, int maxSol){
            int ToBlock(int rc) => rc/27*3+(rc%9)/3;

            SW.Start();
            var foundSolutions = new List<int[]>();

            bool Solved = false;
            int[] board = (int[])puzzle.Clone();
            int[] rowMask = new int[9];
            int[] colMask = new int[9];
            int[] boxMask = new int[9];

            for( int rc=0; rc<81; rc++ ){
                int val = board[rc];
                if( val != 0 ){
                    int mask = 1<<val;
                    rowMask[rc/9] |= mask;
                    colMask[rc%9] |= mask;
                    boxMask[ToBlock(rc)] |= mask;
                }
            }

            Backtrack( rc:0 );
            SW.Stop();
            return foundSolutions;
          // ----------------------------------------------------------------------------------------------------
                    void Backtrack( int rc ){
                        //if( foundSolutions.Count >= maxSol ) return;
                
                        if( rc >=81 ){ 
                            foundSolutions.Add( (int[])board.Clone() ); 
                            if( foundSolutions.Count >= maxSol )  Solved = true;
                            return; 
                        }

                        int nextRC = rc+1;
                        if( board[rc] != 0 ){ Backtrack(nextRC); return; }

                        int r=rc/9, c=rc%9, b=ToBlock(rc);
                        for( int num=1; num<=9; num++ ){
                            int mask = 1<<num;
                            if( (rowMask[r] & mask)==0 && (colMask[c] & mask)==0 && (boxMask[b] & mask)==0 ){
                                board[rc] = num;
                                rowMask[r] |= mask; colMask[c] |= mask; boxMask[b] |= mask;

                                Backtrack(nextRC);
                                if( Solved ) return;  // Terminate immediately upon reaching the target number.

                                board[rc] = 0;
                                rowMask[r] &= ~mask; colMask[c] &= ~mask; boxMask[b] &= ~mask;

                                if( foundSolutions.Count >= maxSol ) return;
                            }
                        }
                    }
        }
#endregion  1D array version



#region  2D array version
        public List<int[,]> TE_Solver_2D(int[,] puzzle, int maxSol){
            var foundSolutions = new List<int[,]>();

            SW.Start();
            bool Solved = false;
            int[,] board = (int[,])puzzle.Clone();
            int[] rowMask = new int[9];
            int[] colMask = new int[9];
            int[] boxMask = new int[9];

            for( int r=0; r<9; r++ ){
                for( int c=0; c<9; c++ ){
                    int val = board[r,c];
                    if( val != 0 ){
                        int mask = 1<<val;
                        rowMask[r] |= mask;
                        colMask[c] |= mask;
                        boxMask[(r/3)*3+(c/3)] |= mask;
                    }
                }
            }


            Backtrack(0, 0);
            SW.Stop(); laps_Time = SW.Elapsed;
            return foundSolutions;

                    void Backtrack(int row, int col){
                        if( foundSolutions.Count >= maxSol ) return;
                
                        if( row == 9 ){ 
                            foundSolutions.Add((int[,])board.Clone()); 
                            if( foundSolutions.Count >= maxSol )  Solved = true;
                            return; 
                        }

                        int nextRow = (col==8)? row+1: row;
                        int nextCol = (col==8)? 0: col+1;
                        if( board[row,col] != 0 ){ Backtrack(nextRow, nextCol); return; }
                        int boxIdx = (row/3)*3 + (col/3);

                        for( int num=1; num<=9; num++ ){
                            int mask = 1 << num;
                            if( (rowMask[row] & mask)==0 && (colMask[col] & mask)==0 && (boxMask[boxIdx] & mask)==0 ){
                                board[row,col] = num;
                                rowMask[row] |= mask; colMask[col] |= mask; boxMask[boxIdx] |= mask;

                                Backtrack(nextRow, nextCol);
                                if( Solved ) return;  // Terminate immediately upon reaching the target number.

                                board[row,col] = 0;
                                rowMask[row] &= ~mask; colMask[col] &= ~mask; boxMask[boxIdx] &= ~mask;

                                if( foundSolutions.Count >= maxSol ) return;
                            }
                        }
                    }
        }
#endregion  2D array version

    }
}