using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using System.Windows.Navigation;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Windows.Interop;

namespace GNPX_space{
    public partial class ALSTechGen: AnalyzerBaseV2{

        //DeathBlossom is an algorithm based on the arrangement of ALS.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page53.html
        
        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/

        //1..89..4.8..21...7...7.59813154.9..8.8.5..41...41.8395..1382.646.89..1...236.18.9  for develop(1)
        //1.2956.485.6...29.4.9.7.56..538...1.248....56.17..582.761589432394...185825431679  for develop(2) 
        //285..91.4743..1...169.24.7.6.4....8.8.2.4.6.7597..84.14...928.33.84....292..8.74.  for develop(3,4)

        // ...8...4. ...21...7 ...7.5981 315..9..8 .8....4.. ..41.83.5 ..1.82.64 6.8...1.. .236.18..
        // 1..89..4. 8..21...7 ...7.5981 3154.9..8 .8.5..41. ..41.8395 ..1382.64 6.89..1.. .236.18.9

        // 285..91.4 7.3..1... 16..24.7. .......8. ..2.4.6.7 597..84.. 4...92..3 ..84....2 9...8.74.
        // 285..91.4 743..1... 169.24.7. 6.4....8. 8.2.4.6.7 597..84.1 4...928.3 3.84....2 92..8.74.

        // ..2956.48 5.6....9. 4...7.5.. .538...1. 2.......6 .1...582. ..1.8...2 .9....1.5 82.4316..
        // 1.2956.48 5.6...29. 4.9.7.56. .538...1. 248....56 .17..582. 761589432 394...185 825431679

        // 417..35.6 2.5..7... 93..56.7. .......6. ..3.9.7.1 691..58.. 3...71..9 ..98....7 7...3.21.
        // 417..35.6 265..7... 938.56.7. .7.31.96. ..369.7.1 6917.58.. 3...716.9 1.986...7 7.6.3921.

        private bool break_ALS_DeathBlossom=false; //True if the number of solutions reaches the specified number.

        public bool ALS_DeathBlossom()   => ALS_DeathBlossomEx( connected:false );

        public bool ALS_DeathBlossomEx() => ALS_DeathBlossomEx( connected:true );


        public bool ALS_DeathBlossomEx( bool connected=false ){
            break_ALS_DeathBlossom=false;
			PrepareStage();
            if( ALSMan.ALSList==null || ALSMan.ALSList.Count<=2 ) return false;

            ALSMan.QSearch_Cell2ALS_Link();

            for(int sz=2; sz<=4; sz++){     //Size 5 and over ALS DeathBlossom was not found?
				foreach( bool solfound in IE_ALS_DeathBlossomSub( sz, connected:connected) ){
					if( !solfound ) continue;
					if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
				}
            }
            return false;
        }



        private IEnumerable<bool> IE_ALS_DeathBlossomSub( int sz, bool connected=false ){
            int szM= (connected? sz-1: sz);

            foreach( var StemCell in pBOARD.Where(p=>p.FreeBC==sz) ){                       //Stem Cell

                if( pAnMan.Check_TimeLimit() ) yield break;

                List<Link_Cell_Subset> LinkCeAlsLst = ALSMan.LinkCeAlsLst[StemCell.rc];
                if( LinkCeAlsLst==null || LinkCeAlsLst.Count<sz) continue;
                      //  int mx=0;
                      //  LinkCeAlsLst.ForEach( X => WriteLine( $"#{mx++} {X}") );

                int nxt=0, PFreeB=StemCell.FreeB;
                var cmb = new Combination( LinkCeAlsLst.Count ,szM );               //Select szM ALSs in Combination
                while( cmb.Successor(skip:nxt) ){
                    nxt = szM;
                    int FreeB = StemCell.FreeB;     // Concatenated digits of stems(remaining digits)
                    int AFreeB = 0x1FF;       // Common digits for ALS
                    for( int k=0; k<szM; k++ ){
                        nxt = k;
                        var LK = LinkCeAlsLst[cmb.Index[k]];                        //Link[cell-ALS]
                        if( (FreeB&(1<<LK.nRCC)) ==0 ) goto LNxtCmb;               
                        FreeB = FreeB.BitReset(LK.nRCC);                            //nRCC:RCC of stemCell-ALS                      
                        AFreeB &= LK.ALS.FreeB; 
                        if( AFreeB == 0 )  goto LNxtCmb;
                    }

                    // =============== connected=true ===============
                    UInt128 E = new UInt128();
                    if( connected ){
                        if( FreeB.BitCount()!=1 || (FreeB&AFreeB)==0 )  continue;
                        int no  = FreeB.BitToNum();
                        int noB = FreeB;

                        UInt128 Ez = UInt128.Zero;
                        for( int k=0; k<szM; k++ ){
                            var ALS = LinkCeAlsLst[cmb.Index[k]].ALS;
                            var UClst = ALS.UCellList;
                            foreach( var P in UClst.Where(p=>(p.FreeB&noB)>0) )  Ez |= qOne<<P.rc;
                        }

                        foreach( var P in Connected_81[StemCell.rc].IEGet_rc().Select(rc=>pBOARD[rc]) ){
                            if( (P.FreeB&noB)==0 ) continue;
                            if( (Ez & ~Connected_81[P.rc]) == qZero ){ P.CancelB=noB; E|=qOne<<P.rc; SolCode=2;  }
                        }
                        if(SolCode<1) continue;
                        
                        var LKCAsol=new List<Link_Cell_Subset>();
                        Array.ForEach( cmb.Index,nx => LKCAsol.Add(LinkCeAlsLst[nx]) );
                        _DeathBlossom_SolResult( LKCAsol, StemCell, no, E, connected );

						yield return true;
                    }



                    // =============== connected=false ===============
                    else if( FreeB==0 && AFreeB>0 ){
                        AFreeB = AFreeB & ~(StemCell.FreeB);
                        foreach( var no in AFreeB.IEGet_BtoNo() ){
                            int noB=(1<<no);
                            UInt128 Ez = new UInt128();
                            for( int k=0; k<sz; k++ ){
                                var ALS = LinkCeAlsLst[cmb.Index[k]].ALS;
                                var UClst = ALS.UCellList;
                                foreach( var P in UClst.Where(p=>(p.FreeB&noB)>0) )  Ez |= qOne<<P.rc;
                            }

                            foreach( var P in pBOARD.Where(p=>(p.FreeB&noB)>0) ){
                                if( (Ez & ~Connected_81[P.rc]) == qZero ){ P.CancelB=noB; E|=qOne<<P.rc; SolCode=2; }
                            }
                            if( SolCode<1 ) continue;
                        
                            var LKCAsol = new List<Link_Cell_Subset>();
                            Array.ForEach( cmb.Index,nx=> LKCAsol.Add(LinkCeAlsLst[nx]) );
                            _DeathBlossom_SolResult( LKCAsol, StemCell, no, E, connected);

							yield return true;
                        }
                    }
                
                LNxtCmb:
                    continue;
                }
            }
            yield break;
        }

        private void _DeathBlossom_SolResult( List<Link_Cell_Subset> LKCAsol, UCell StemCell, int no, UInt128 E, bool connected=false ){
            string st0 = "ALS Death Blossom";
            if(connected) st0 += "Ex";

            Color cr, crStemFg=Colors.Navy, crStemBg = SolBkCr;//Colors.HotPink;
            StemCell.Set_CellColor_BkgColor_noBit(StemCell.FreeB,crStemFg,crStemBg);
            StemCell.Set_CellFrameColor(Colors.Blue);
            string st = $"\n Stem cell: {StemCell.rc.ToRCString()} #{StemCell.FreeB.ToBitStringNZ(9)}";

            bool  overlap = false;
            UInt128 OV = UInt128.Zero;
            int   k=0, noB=(1<<no);

            foreach( var LK in LKCAsol ){
                int noB2 = 1<<LK.nRCC;
                cr = PastelColors[++k];
                LK.ALS.UCellList.ForEach( p=> { 
                    UCell P = pBOARD[p.rc];
                    P.Set_CellColor_BkgColor_noBit(noB,AttCr,cr);
                    P.Set_CellColor_BkgColor_noBit(noB2,AttCr3,cr);
                    if( OV.IsHit(P.rc) ) overlap=true;
                    OV |= qOne<<P.rc;
                } );
                st += $"\n   -#{(LK.nRCC+1)}-ALS{k} : {LK.ALS.ToStringRCN()}";
            }

            st += $"\n eliminated : { E.ToRCStringComp()} #{no+1}";

            if( overlap ) st0+=" [overlap]";
            if( connected )  st0+=" [connected]";
            st0 = st0.Replace("] [","," );
            Result = st0;
            if( Set_Solution_Info ) ResultLong=st0+st;
        }
    }
}