using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Windows.Media;


namespace GNPX_space{
    public partial class ALSTechGen: AnalyzerBaseV2{

        //Algorithm using ALS and RCC((Restricted Common Candidate).
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page50.html

        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/   

        // 2.548...9 .9..3..2. ..7.923.4 ..8.....2 541...687 9.....1.. 4.961.2.. .8..7..9. 7...584.6
        // 23548.7.9 .94.3.82. 8.7.923.4 ..8...9.2 541329687 9..8..1.. 459613278 .8.27459. 7..9584.6

        // .2...783. .47.2...1 3..1....7 ....38.15 ...5.4... 58.79.... 6....2..8 2...8.57. .793...6.
        // 125..783. 947823651 3681....7 496238715 7..5.4.8. 58.79.... 65..72..8 2...8.57. 8793...6.

        // 87....... .9.81.65. ...79...8 .....6731 6..5.1..9 7124..... 3...57... .57.48.1. .......74
        // 87.....9. .9381.657 ...79...8 .4.286731 638571..9 712439865 3.415798. .57.48.1. .8....574

        // .9..4..6. 4..15...2 ..6..91.. ..4....7. 36.....15 .8....3.. ..82..4.. 9...34..1 .4..8..3.
        // .9..4..6. 473156..2 ..6..91.. .14....7. 36.4...15 .8....3.. .382..4.. 9...34..1 .4..8..3.

		// 324861597 657943821 918527364 2.143.... 5.32.6... 4..7..... 1..6..... 8..1746.. 7..39..1.
        // 324861597 657943821 918527364 2.143.... 5.32.6... 4..7..... 1..6..... 8..1746.. 7..39..1.


		private int  size_ALS_Max; // Testing will begin with small(ALS1size + ALS2size).

        public bool ALS_XZ( ){
			PrepareStage();
            if( ALSMan.ALSList==null || ALSMan.ALSList.Count<=2 ) return false;
        
			size_ALS_Max = 0;   
		    for(int sz=4; sz<=18; sz++ ){
				foreach( bool solFound in _IE_ALSXZsub(sz) ){
					if( sz > size_ALS_Max )  break;
					if( !solFound )   continue;
					if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
					Clear_Analysis_results();
				}
            }
            return false;
        // =============== _ALSXZsub ==============================================

                IEnumerable<bool> _IE_ALSXZsub( int sz ){
			        size_ALS_Max = 0;
                    var cmb = new Combination(ALSMan.ALSList.Count,2);
                    int nxt = 0;
                    while( cmb.Successor(nxt) ){                        //Select two ALSs
                        if( pAnMan.Check_TimeLimit() )  yield break;

                        UAnLS UA = ALSMan.ALSList[ cmb.Index[1] ];
                        if( UA.CellSize >= (sz-1) ){ nxt=0; continue; }    
                        UAnLS UB = ALSMan.ALSList[ cmb.Index[0] ];
                        nxt = 1;
				        if( (UA.b081 & UB.b081).IsNotZero() )  continue;

				        int szPTmp = UA.CellSize + UB.CellSize;
				        size_ALS_Max = Max(size_ALS_Max, szPTmp);
				        if( szPTmp != sz ) continue;

                        //=======================================================

                        int RCC = ALSMan.Get_AlsAlsRcc( UA, UB );          //Common numbers, House contact, Without overlap
                        if( RCC==0 ) continue;               

                        if( RCC.BitCount()==1 ){        //===== Singly Linked =====
                            int othersB = (UA.FreeB&UB.FreeB) & ~RCC; //Eliminate candidate digit. digits are included in both UA and UB.
                            if( othersB>0 ){
						        var singlyB = __ALSXZ_IsSinglyLinked(UA,UB,RCC,othersB);	// 1:singly  2:doubly  0:nothing
						        if( singlyB ){
							        SolCode = 2;
							        __ALSXZ_SolResult( RCC, UA, UB );
							        yield return true;
						        }
					        }
                        }
                        else if( RCC.BitCount()==2 ){   //===== Doubly Linked =====
                            if( __ALSXZ_DoublyLinked( UA, UB, RCC) ){
                                SolCode=2;
                                __ALSXZ_SolResult( RCC, UA, UB );
						        yield return true;
                            }
                        }
                    }
                    yield break;


                        void __ALSXZ_SolResult( int RCC, UAnLS UA, UAnLS UB ){
                            string st = "ALS-XZ "+((RCC.BitCount()==1)? "(Singly Linked)": "(Doubly Linked)");
                            Result = st;
            
                            string st2="", st3="";
                            if( Set_Solution_Info ){
				                Color SolBkCr0 = PastelColors[0];
				                Color SolBkCr1 = PastelColors[1];
				                Color SolBkCr2 = PastelColors[2];

                                UA.b081.IE_SetNoBBgColorNSel( pBOARD, UA.FreeB, AttCr5, SolBkCr0);
                                UB.b081.IE_SetNoBBgColorNSel( pBOARD, UB.FreeB, AttCr5, SolBkCr1);
                            
                                string stE = "";
				                foreach( var P in pBOARD.Where(p=>p.CancelB>0) ){
                                    P.Set_CellColor_BkgColor_noBit(P.FreeB,AttCr,SolBkCr6);
                                    stE += $"{P.rc.ToRCString()}#{P.CancelB.TBScmp()} ";
                                }

                                st2 += "\n ALS1: "+UA.b081.TBScmp();
                                st2 += "\n ALS2: "+UB.b081.TBScmp();
                                st2 += "\n  RCC: #"+RCC.ToBitStringN(9);
                                st2 += $"\n Exclude: {stE.Trim()}";

                                st3 += $" ALSs:{UA.ToStringRC()} / {UB.ToStringRC()} RCC:#{RCC.ToBitStringN(9)}";
                                Result = ($"{st}{st3}").Replace(" Linked","");
			
                #if DEBUG
				                st2 += $"\n\n... ID: {UA.ID} / {UB.ID}";
                #endif
				                ResultLong = $"{st}{st2}";
                            }
                        }       
  
		                bool __ALSXZ_IsSinglyLinked( UAnLS UA, UAnLS UB, int RCC, int othersB ){   
                        // *=*=* SinglyLinked subroutine *=*=*
                        //othersB : Common digits for UA and UB other than RCC. Bit representation.

                            // Suppose that two ALSs have RCC(digit x).
                            // And, let z be the digit contained in both ALS different from RCC.
	                        // digit z outside the ALS and associated with all z in both ALS can be eliminated from the candidate.
	                        // If z is true, both ALSs are changed to _LockedSet, and both ALSs include RCC.
                            bool solF=false;
                            foreach( var no in othersB.IEGet_BtoNo() ){ 
                                int noB = 1<<no; 
                                UInt128 ELM128 = BOARD_Free81B9[no] & ~( UA.b081 | UB.b081 );
                                foreach( var P in UA.UCellList.Where(p=> (p.FreeB&noB)>0) )  ELM128 = ELM128 & Connected_81[P.rc];
                                foreach( var P in UB.UCellList.Where(p=> (p.FreeB&noB)>0) )  ELM128 = ELM128 & Connected_81[P.rc];

                                if( ELM128.IsNotZero() ){
                                    foreach( var uc in ELM128.IEGet_UCell(pBOARD) ){ uc.CancelB |= (uc.FreeB & noB); solF=true; }
                                }
                            }

                            return solF;
                        }

                        bool __ALSXZ_DoublyLinked( UAnLS UA, UAnLS UB, int RCC ){              // *=*=* DoublyLinked subroutine *=*=*
                            UInt128 B81inALS = UInt128.Zero; //Covered cells
                            bool solF=false;

                            //----- RCC -----
                            // A digit belonging to the same house as non-ALS RCC can be eliminated.
                            // If this applies to RCC-1, then the two ALS are _LockedSet and
                            // the RCC-2 is eliminated from both ALS.
                            foreach( int no in RCC.IEGet_BtoNo() ){
                                int noB=1<<no;
                                UInt128 B81inALS128 = UInt128.Zero;
                                foreach( var uc in UA.UCellList.Where(p=>(p.FreeB&noB)>0) ) B81inALS128 |= qOne<<uc.rc;
                                foreach( var uc in UB.UCellList.Where(p=>(p.FreeB&noB)>0) ) B81inALS128 |= qOne<<uc.rc;
                                UInt128 B81outside128 = BOARD_Free81B9[no] & ~(UA.b081 | UB.b081);    //Cells outside ALS(UA,UB)

                                foreach( var rc in B81outside128.IEGet_rc() ){
                                    if( (B81inALS128 & ~Connected_81[rc] ) == qZero ){              // no cells linked with all #no in ALS.
                                        pBOARD[rc].CancelB |= (pBOARD[rc].FreeB & noB); solF=true;  // Therefore, rc#no is Excludeed.
                                    }
                                }
                            }

                            //----- ALS element digit other than RCC -----
                            // For a element of ALS digited z(different from RCC),
		                    // z outside the ALS and related to all z in the ALS can be eliminated from the candidate.
		                    // If this is true, that ALS is a _LockedSet and two RCCs belong to this ALS.
		                    // In the other ALS, there are n-1 candidate digits in n cells, and ALS collapses.

                            int nRCC = UB.FreeB & ~RCC;                
                            foreach( int no in nRCC.IEGet_BtoNo() ){    // a digit other than RCC
                                int noB = 1<<no;
                                B81inALS = UInt128.Zero;

                                foreach( var uc in UB.UCellList.Where(p=>(p.FreeB&noB)>0) ) B81inALS |= UInt128.One<<uc.rc; //Cells#no inside UB
                                UInt128 B81inALS128 = UInt128.Zero;
                                foreach( var uc in UB.UCellList.Where(p=>(p.FreeB&noB)>0) ) B81inALS128 |= UInt128.One<<uc.rc; //Cells#no inside UB
                                UInt128 B81outside128 = BOARD_Free81B9[no] & ~(UA.b081 | UB.b081);                     //Cells#no outside UA & UB
           
                                foreach( var rc in B81outside128.IEGet_rc() ){
                                    if( (B81inALS128 & ~Connected_81[rc]) == qZero ){               // If rc#no is true, eliminate all UB#no.
                                        pBOARD[rc].CancelB |= (pBOARD[rc].FreeB & noB); solF=true;  // Therefore, rc#no is Excludeed.
                                    }
                                }
                            }

                            return solF;
                        }
                }
        }
    }
}
 