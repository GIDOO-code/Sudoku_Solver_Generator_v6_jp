using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Windows.Interop;
using System.Windows.Media;
using static System.Diagnostics.Debug;
using GIDOO_space;

namespace GNPX_space{
    public partial class ALSTechGen: AnalyzerBaseV2{

        //Algorithm using ALS and RCC((Restricted Common Candidate).
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page51.html

        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/
        // 8....5..7 .7.1.8.6. ..6.9.8.. 64.9.7.3. ..3...7.. .9.8.2.46 ..9.8.4.. .1.5.4.2. 4..3....1
        // 83...5..7 97.1.8.6. ..67938.4 64.9.7.3. ..34.67.. .9.832.46 ..9.814.. .1.5.4.2. 4..3.9..1

        // 4..1....3 9.7.3.54. .539..7.. ..5...3.. 2963.7154 ..8...6.. ..4..389. .39.4.2.5 6....9..7
        // 4.21759.3 9.7.3.54. .539.47.. ..5...3.. 296387154 3.8...6.. 5.4..389. .39.4.2.5 6.1..9437


		private bool debug_with_ID=false;

        public bool ALS_XY_Wing( ){
		
			PrepareStage();
            if(ALSMan.ALSList==null || ALSMan.ALSList.Count<=2) return false;

            for(int szT=4; szT<15; szT++ ){    //Search in descending order of the total size of 3 ALS
                foreach( var _ in IE_ALS_XY_Wing_Sub(szT) ){
                    if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                }
            }
            return false;
        }

        private IEnumerable<bool> IE_ALS_XY_Wing_Sub( int szT ){

            //(ALS sorted by size)    
            foreach( var Ustem in ALSMan.ALSList.Where(p=>p.CellSize<=szT-2) ){  // ===== Stem ALS =====
                int szS=szT-Ustem.CellSize;

                UAnLS UA, UB, UApre=null;

                // RCC(Restricted Common Candidate)
                // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page26.html
                int nxt =0, RccAC=-1, RccBC=-1;

                var cmb = new Combination(ALSMan.ALSList.Count,2);       
                while(cmb.Successor(skip:nxt)){
                    if( pAnMan.Check_TimeLimit() ) yield break; 
                    
                    // ----- UA connects with Stem ALS with RCC?
                    nxt=0;
                    UA = ALSMan.ALSList[ cmb.Index[0] ];

                    if( UA==Ustem || UA.CellSize>szS-1 ) continue;
					if( (Ustem.b081 & UA.b081).IsNotZero() )  continue;
                    if( UA!=UApre ){
                        RccAC = ALSMan.Get_AlsAlsRcc(UA,Ustem);
                        if( RccAC.BitCount()!=1 ) continue;             // Singly-RCC connected?
                        UApre=UA;
                    }

                    // ----- UB connects with Stem ALS with RCC?
                    nxt=1;     
                    UB = ALSMan.ALSList[ cmb.Index[1] ];

                    if( UB.CellSize>(szS-UA.CellSize))  continue;  // Skip using "Sort by size"
					if( (Ustem.b081 & UB.b081).IsNotZero() )  continue;  // Overlap
               
                    if( UB==Ustem || UB.CellSize!=(szS-UA.CellSize) )  continue;
                    RccBC = ALSMan.Get_AlsAlsRcc(UB,Ustem);              // RCC(Restricted Common Candidate)
                    if( RccBC.BitCount()!=1 ) continue;                  // Singly-RCC connected?
                    if( RccAC==RccBC ) continue;                         // Different RCCs?

                    // ----- Candidate Digits -----
                    int CandidateDigitsB = (UA.FreeB&UB.FreeB) & ~(RccAC|RccBC); // Common and non-RCC
                    if( CandidateDigitsB==0 ) continue;


                    foreach( var no in CandidateDigitsB.IEGet_BtoNo() ){
                        int noB = 1<<no;

                        // ... inside
                        UInt128 UE = UInt128.Zero;
                        foreach( var P in UA.UCellList.Where(p=>(p.FreeB&noB)>0)) UE |= qOne<<P.rc;
                        foreach( var P in UB.UCellList.Where(p=>(p.FreeB&noB)>0)) UE |= qOne<<P.rc;
                    
                        // ... outside
                        UInt128 TBD = BOARD_Free81B9[no] & ~(UA.b081 | UB.b081 | Ustem.b081);
                        if( TBD.IsZero() )  continue;
                        
                        UInt128 elmB = UInt128.Zero;
                        foreach( var rc in TBD.IEGet_rc() ){
                            if( (UE & ~Connected_81[rc]) > qZero ) continue; //cell-rc and all digits inside are connected
                            elmB |= qOne<<rc;
                            pBOARD[rc].CancelB=noB;
                            SolCode=2;
                        }
                    
                        if( elmB.IsNotZero() ){ //===== ALS XY-Wing found =====
                            ALS_XY_Wing_SolResult( UA, UB, Ustem, RccAC, RccBC, no, elmB );
                            yield return (SolCode>0);
                        }
                    }
                }
            }
            yield break;
        }  
        private void ALS_XY_Wing_SolResult( UAnLS UA, UAnLS UB, UAnLS Ustem, int RccAC, int RccBC, int noX, UInt128 elmB ){
            string st = "ALS XY-Wing ";
            string st2 = $"Eliminated: {elmB.ToRCStringComp()} #{noX+1}";          
        
            if( Set_Solution_Info ){            
                UA.UCellList.IE_SetNoBBgColor( pBOARD, RccAC, AttCr, SolBkCr );
                UB.UCellList.IE_SetNoBBgColor( pBOARD, RccBC, AttCr, SolBkCr2 );
                Ustem.UCellList.IE_SetNoBBgColor( pBOARD, RccAC|RccBC, AttCr, SolBkCr3 );
       
                st += "\n ALS Stem: "+Ustem.ToStringRCN();
															if(debug_with_ID)  st += $"  [ID:{Ustem.ID}]";
                st += "\n ALS    A: "+UA.ToStringRCN();
															if(debug_with_ID)  st += $"  [ID:{UA.ID}]";
                st += "\n ALS    B: "+UB.ToStringRCN();
															if(debug_with_ID)  st += $"  [ID:{UB.ID}]";

                st += "\n  RCC Stem-A: #"+RccAC.ToBitStringN(9);
                st += "\n  RCC Stem-B: #"+RccBC.ToBitStringN(9);

                ResultLong = $"{st}\n {st2}";
				extResult  = ResultLong;
            }
            Result = "ALS XY-Wing " + st2;
        }
    }
}