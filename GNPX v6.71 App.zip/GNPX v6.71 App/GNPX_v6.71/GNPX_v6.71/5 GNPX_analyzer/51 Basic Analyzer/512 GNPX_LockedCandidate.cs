using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Markup.Localizer;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;

    public class LockedCandidateGen: AnalyzerBaseV2{

        public LockedCandidateGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }

        // Assumption: Cannot be solved by the "single" algorithm.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page32.html

        // .3.1.5.8...........8.....2...9.1.2...5.3.9.4..6.....7.7..6.1..851..7..69..8...7..


        public bool LockedCandidate( ){     //***** new version *****
            base.AnalyzerBaseV2_PrepareStage();
            int b1, b2, hs0;

            //==== Type-1 =====
            foreach( int no in Enumerable.Range(0,9) ){
                int noB=(1<<no);
                UInt128 BD_Free_no = BOARD_Free81B9[no];
                int[] BRCs = new int[9];

                //aggregate rows and columns with #no for each block
                foreach( var P in BD_Free_no.IEGet_UCell(pBOARD) ){ BRCs[P.b] |= (1<<P.r) | (1<<(P.c+9)); }

                for( int hs=0; hs<18; hs++ ){                               // 0-8:row 9-17:column
                    int b0=hs%9, direction=(hs/9)*9;                        // direction: 0(row) or 9(column)

                    int rch = (BRCs[b0]>>direction)&0x1FF;
                    if( rch.BitCount()!=1 ) continue;                       // only one row(column) has #no
                      
                    hs0 = rch.BitToNum(9)+direction;                        // hs0:house number
                    if( pBOARD.IEGetCellInHouse(hs0,noB).All(Q=> Q.b==b0) )  continue;

                            // in house hs0, blocks other than b0 have #no
                            { //----- found ----- 
                                SolCode = 2; //----- found -----
                                foreach( var P in pBOARD.IEGetCellInHouse(hs0,noB) ){ 
                                    if(P.b!=b0) P.CancelB=noB;
                                    else        P.Set_CellColor_BkgColor_noBit( noB, AttCr, SolBkCr);
                                }
                                string SolMsg = $"Locked Candidate B{b0+1} #{no+1}";
                                Result = SolMsg;
						        if( Set_Solution_Info ) ResultLong = SolMsg;
						        if( !pAnMan.IsContinueAnalysis() )  return true;    // @is Valid
                            }
                }
            }

            //==== Type-2 =====
            for(int no=0; no<9; no++ ){  //#no
                int noB=(1<<no);
                int[] BRCs2 = new int[18];

                // aggregate blocks with #no for each rows or columns.
                foreach( var P in pBOARD.Where(Q=>(Q.FreeB&noB)>0) ){
                    BRCs2[P.r]   |= (1<<P.b);
                    BRCs2[P.c+9] |= (1<<P.b);
                }

                for( int hs=0; hs<18; hs++ ){                               //   0-8:row 9-17:column
                    int HRC = BRCs2[hs];
                    if( HRC.BitCount() != 1 )  continue;                    // 1 block only?

                    int b0 = HRC.BitToNum();                                // b0:target block
                    if( hs<9 ){         //row house
                        if( pBOARD.IEGetCellInHouse(b0+18,noB).All(Q=> Q.r==hs) )  continue;
                        //Conditions with a solution: Block b0 has digits(#no) other than row #hs.
                        b1=(b0+1)%3+(b0/3*3); b2=(b0+2)%3+(b0/3*3);         // b1,b2:block(row direction)
                    }
                    else{               //column house
                        if( pBOARD.IEGetCellInHouse(b0+18,noB).All(Q=> Q.c==(hs-9)) )  continue;
                        //Conditions with a solution: Block b0 has digits(#no) other than Column #(hs-9).
                        b1=(b0+3)%9;          b2=(b0+6)%9;                  // b1,b2:block(column direction)  
                    }

                            { //----- found -----
                                SolCode=2; 
                                foreach( var P in pBOARD.IEGetCellInHouse(18+b0,noB) ){
                                    if(!HouseCells81[hs].IsHit(P.rc))   P.CancelB=noB;
                                    else                              P.Set_CellColor_BkgColor_noBit( noB, AttCr, SolBkCr );
                                }
                                string SolMsg =  $"Locked Candidate B{b0+1} #{no+1}";
                                Result = SolMsg; 
						        if( Set_Solution_Info ) ResultLong = SolMsg;
                                if( !__SimpleAnalyzerB__ ){
							        foreach( var P in pBOARD.IEGetCellInHouse(18+b1,noB)) P.Set_CellColor_BkgColor_noBit( noB, AttCr, SolBkCr );
							        foreach( var P in pBOARD.IEGetCellInHouse(18+b2,noB)) P.Set_CellColor_BkgColor_noBit( noB, AttCr, SolBkCr );

						        }

                                if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                            }
                }
            }
            return false;
        }
    }
}