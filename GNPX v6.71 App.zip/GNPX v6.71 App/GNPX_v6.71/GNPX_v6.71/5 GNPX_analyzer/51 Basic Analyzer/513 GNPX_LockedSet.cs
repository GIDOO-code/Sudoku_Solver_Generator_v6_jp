using GIDOO_space;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Windows;
using System.Windows.Input;


using static GNPX_space.SubsetTechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.WebRequestMethods;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
    public partial class _LockedSetGen: AnalyzerBaseV2{
        private int stageNoPMemo = -9;

        public _LockedSetGen( GNPX_AnalyzerMan AnMan ): base(AnMan){ }


        private void _LockedSet_Prepare( bool debugPrint=false ){
            if (stageNoP != stageNoPMemo){
                stageNoPMemo = stageNoP;
                base.AnalyzerBaseV2_PrepareStage();
			}
            return;
		}

        /* ::::::::: GNPX version 7.  Lockedset :::::::::
            The logic for _LockedSet is expressed using C#'s LINQ and GNPX functions.
            While the GNPX function is a naive implementation in C#, limiting it to only simple functions minimizes the possibility of errors.
            It may appear complex at first glance, but the implementation code is hidden and composed of function-level code.
            This ensures that the logic for _LockedSet is implemented accurately, safely, and concisely.
        */


        /* Puzzle for Test
            2.891..54....4..7.41.5..6.2...7...61....2....69...1...5.2..7.16.4..6....16..594.3
            ...857.....736.2...6...48..142..86..57......26.35..47..216.3........1.......2....

            4......6..1..62..9.624.........8..5.1.8..7.4.......9..9...3.2..58....63..36.5...7
            .8.........4..71.2.6718.39..2..3.9....38.52....5.1..3..18.4.67.4.96..8.........1.
        */
        

        public bool Naked__LockedSet( ){
            _LockedSet_Prepare();

            foreach( int sz in Enumerable.Range(2,6) ){
                foreach( var (h,LS,nLS) in _IE_Naked_LockedSet_sub(sz) ){
                    int FreeB = LS.Get_FreeB_or();
                    foreach( var uc in nLS.IEGet_UCell(pBOARD).Where(u=>(u.FreeB&FreeB)>0) ) uc.CancelB = uc.FreeB&FreeB;
                    if( pBOARD.All(uc=>uc.CancelB==0) ) continue;

                    LS.IE_SetNoBBgColor(pBOARD, FreeB, AttCr, SolBkCr);
                    
                    string resST = $"{LS.TBScmp()}#{FreeB.TBScmp()}";
                    _LockedSet_Result(sz,resST,HiddenFlag:false);

                    if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                }
            }
            return false;

                    IEnumerable<(int,UInt128,UInt128)> _IE_Naked_LockedSet_sub( int sz ){      
			            foreach( int h in Enumerable.Range(0,27) ){
                            UInt128 cells_in_house = BOARD_Free81 & HouseCells81[h];                    // cells_in_house : unresolved cells in the house

                            int nc = cells_in_house.BitCount();
                            if( nc < sz ) continue;
 
                            Combination_81B cmbG = new(nc,sz,cells_in_house);
                            while( cmbG.Successor() ){
				                UInt128 LS = BOARD_Free81 & cmbG.valueBT;
				                int LSFreeB = LS.Get_FreeB_or();
				                if( LSFreeB.BitCount() != sz )  continue;							// @ The number of candidate digits within the sector is sz.
				                UInt128 nLS = (cells_in_house | _nLS_adjustment(h,LS)) & ~LS; 
                                if( LS.Is_pure_LockedSet(pBOARD) == true )  yield return (h,LS,nLS); // @ If it includes a smaller _LockedSet81T, it's not a pure pattern.
                            }
			            }
			            yield break;

                                UInt128 _nLS_adjustment( int h, UInt128 LS){
                                    int  LSFrame = LS.Ceate_rcbFrameOr();
                                    int  blk     = LSFrame&frame_B;
                                    if( h<=17 && blk.BitCount()==1 )  return (BOARD_Free81 & HouseCells81[blk.BitToNum(27)]);
                                    return qZero;
                                }
                    }
        }





        public bool Hidden__LockedSet( ){
            _LockedSet_Prepare();

            foreach( int sz in Enumerable.Range(2,6) ){
                foreach( var (h,LS,nLS,onlyLSFreeB) in _IE_Hidden_LockedSet_sub(sz) ){
                    foreach( var uc in LS.IEGet_UCell(pBOARD) ) uc.CancelB = uc.FreeB&~onlyLSFreeB;
                    if( pBOARD.All(uc=>uc.CancelB==0) ) continue;

                    LS.IE_SetNoBBgColor(pBOARD, onlyLSFreeB, AttCr, SolBkCr);
                    
                    string resST = $"{LS.TBScmp()}#{onlyLSFreeB.TBScmp()}";
                    _LockedSet_Result(sz,resST,HiddenFlag:true);

                    if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
                }
            }
            return false;

                    IEnumerable<(int,UInt128,UInt128,int)> _IE_Hidden_LockedSet_sub( int sz ){ 
			            foreach( int h in Enumerable.Range(0,27) ){
                            UInt128 cells_in_house = BOARD_Free81 & HouseCells81[h];    // cells_in_house : unresolved cells in the house

                            int nc = cells_in_house.BitCount();
                            if( nc < sz ) continue;
 
                            Combination_81B cmbG = new(nc,sz,cells_in_house);
                            while( cmbG.Successor() ){
				                UInt128 LS = BOARD_Free81 & cmbG.valueBT;
				                int LSFreeB = LS.Get_FreeB_or();

                                UInt128 nLS = cells_in_house & ~LS;
                                int nLSFreeB = nLS.Get_FreeB_or();
                                int onlyLSFreeB = LSFreeB & ~nLSFreeB;
				                if( onlyLSFreeB.BitCount() != sz )  continue;			

                                if( nLS.Is_pure_LockedSet(pBOARD) == true )  yield return (h,LS,nLS,onlyLSFreeB); // @ If it includes a smaller _LockedSet81T, it's not a pure pattern.
                            }
			            }
			            yield break;
                    }
        }



        private void _LockedSet_Result( int sz, string resST, bool HiddenFlag ){
            string[]  lockedSet_type = {"Pair[2D]", "Triple[3D]", "Quartet[4D]", "Set[5D]", "Set[6D]", "Set{7D}" };

            SolCode = 2;
            string SolMsg = "Locked" + lockedSet_type[sz-2];
            if( HiddenFlag ) SolMsg += " hidden";
            SolMsg += " "+resST;
            Result = SolMsg;
            ResultLong = SolMsg;
        }
    }
}
