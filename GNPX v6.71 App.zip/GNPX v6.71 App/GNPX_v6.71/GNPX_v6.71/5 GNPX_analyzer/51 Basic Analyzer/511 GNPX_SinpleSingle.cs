using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using static GNPX_space.PatternOverlayMethod_Man;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{

    // First, understand UCell, Connected_81, HouseCells81, and IEGetCellInHouse.
    //  https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page23.html

    // Then the following algorithm("Single") is almost trivial.
    //  https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page31a.html
    //  https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page31b.html
    //  https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page31c.html


    public class SimpleSingleGen: AnalyzerBaseV2{
        private int stageNoPMemo = -9;	
        private void SimpleSingle_Prepare( bool debugPrint=false ){
            if (stageNoP != stageNoPMemo){
                stageNoPMemo = stageNoP;
                base.AnalyzerBaseV2_PrepareStage();
			}
            return;
		}

        public SimpleSingleGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }



        //*==*==*==*==* Last Digit *==*==*==*==*==*==*==*==* 
         public bool LastDigit( ){

            SimpleSingle_Prepare();
 
            UInt128 solBit = _LastDigitT; // Enumerable.Range(0,27).Aggregate(qZero, (a,h) => a | (BOARD_Free81 &HouseCells81[h]).B81_IsSingle() );

            if( solBit != qZero ){
                    // WriteLine( $" ### LastDigit:{solBit.TBS(withSlashB:true)}" );
                SolCode=1;
                if( !chbx_ConfirmMultipleCells )  solBit = qOne<<solBit.FindFirst_rc();
                foreach( var uc in solBit.IEGet_UCell(pBOARD) ) uc.FixedNo = uc.FreeB.BitToNum()+1;

                Result = "Last Digit  Fixed:" + solBit.TBScmp();
				ResultLong = "Last Digit\n  Fixed:" + solBit.TBScmp();
				if( !pAnMan.IsContinueAnalysis() )  return true;
            }
            return false;
        }



        //*==*==*==*==* Naked Single *==*==*==*==*==*==*==*==* 
        public bool NakedSingle( ){
            SimpleSingle_Prepare();

		    UInt128 solBit = _NakedSingleT;  // BOARD_Free81.IEGet_rc().Where(rc=>pBOARD[rc].FreeBC==1). ToUInt128();

            if( solBit != qZero ){
                    // WriteLine( $" ### NakedSingle:{solBit.TBS(withSlashB:true)}" );

                SolCode=1;
                if( !chbx_ConfirmMultipleCells )  solBit = qOne<<solBit.FindFirst_rc();
                foreach( var uc in solBit.IEGet_UCell(pBOARD) ) uc.FixedNo = uc.FreeB.BitToNum()+1;

                Result = "Naked Single  Fixed:" + solBit.TBScmp();
				ResultLong = "Naked Single\n  Fixed:" + solBit.TBScmp();
				if( !pAnMan.IsContinueAnalysis() )  return true;
            }
            return false;
        }



        //*==*==*==*==* Hidden Single *==*==*==*==*==*==*==*==*
        public bool HiddenSingle( ){
            SimpleSingle_Prepare();

            string stResult = "";
            for( int no=0; no<9; no++ ){ //no:digit
                UInt128 solBit = _HiddenSingleT(no); // Enumerable.Range(0,27).Aggregate(qZero, (a,h)=> a | (BOARD_Free81B9[no] & HouseCells81[h]). B81_IsSingle() );

                if( solBit == qZero )  continue;
                          // WriteLine( $" ### HiddenSingle #{no+1}:{solBit.TBS(withSlashB:true)}" );
                SolCode=1;
                foreach( var uc in solBit.IEGet_UCell(pBOARD) ) uc.FixedNo = no+1;
                if( solBit.BitCount() == 1 )  stResult += $" {solBit.ToRCStringComp()}#{no+1}";
                else 　stResult += $" ({solBit.ToRCStringComp()})#{no+1}";
            }

            if( stResult != "" ){
                Result = "Hidden Single  Fixed:" + stResult;
                ResultLong = "Hidden Single\n  Fixed:" + stResult;
                if( !pAnMan.IsContinueAnalysis() )  return true;
            }
            return false;
        }
    }
}
