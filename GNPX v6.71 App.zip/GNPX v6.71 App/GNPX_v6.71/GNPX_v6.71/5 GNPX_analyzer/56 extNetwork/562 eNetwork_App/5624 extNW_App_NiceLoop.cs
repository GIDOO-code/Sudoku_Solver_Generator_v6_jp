using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using static System.Diagnostics.Debug;
using System.Threading;

using GIDOO_space;
//using System.Windows.Input;
//sing System.Xml.Linq;
//using static System.Formats.Asn1.AsnWriter;
using System.Drawing.Text;

namespace GNPX_space{
    using pRes=Properties.Resources;
    using  tuple3 = Tuple<int,int,int>;

    public partial class ExtendedNetwork_App: AnalyzerBaseV2{

        // Along with expanding the types of links, the link expression was changed from "strong/weak_link" to "cell, candidate digits, true/false".
        // Link connection is also determined by matching "cell, candidate digits, true/false".
        // Also, AALSXZ (Almost ALSXZ) was added as a new link. This is the first step in expanding link types.
        // (Introduced a difficult type of link, intentionally.)


        public List<int> Processed_Solutions_List;

        public bool eNW_NiceLoop(){

            bool  debugPrint = false;                           // for Develop 
            eNW_Link.Set_withID_( withID:debugPrint );          // Display the element_ID in the output only when debugging.

            eNW_Prepare( ALS_plus:3, minSize:2 );               // Prepare
            Processed_Solutions_List = new();

			int searchCC = pBOARD.Sum(p=>p.FreeBC), serchKK=0;  // for Progress Report
            int FreeBC_X = 0;
            double FreeBC_T = 100.0 / searchCC;

            foreach( var UCOrg in pBOARD.Where(p=>(p.FreeB>0)) ){     //----- origin rc    

				foreach( var noOrg in UCOrg.FreeB.IEGet_BtoNo() ){    //----- origin no	

                    double ratio = (++FreeBC_X) * FreeBC_T;
                    G6.Additional_Message = $"  {ratio:F1} % ({FreeBC_X}/{searchCC})"; // for Progress Report

                    //----- Control of search conditions 
                    for( int pmCnd0=0; pmCnd0<=1; pmCnd0++ ){
                        int rcOrg = UCOrg.rc;
                        ULogical_Node ULGstart = new( no:noOrg, rc:UCOrg.rc, pmCnd:pmCnd0);    // no,rc,pmCnd
                                    if(debugPrint) WriteLine( $"\n\n@@@@@ _IE_NiceLoop_Control  ULGstart:{ULGstart}  pmCnd0:{pmCnd0} rcBreakX:{rcOrg}" );

					  // ========== ========== ========== ========== ========== ========== ========== ==========
                        (int,int) rcno_Org = (rcOrg,noOrg);
                        var (solType,eL_tail) = eGLink_ManObj.extNW_QSearch_Loop( ULGstart, rcOrg, debugPrint:debugPrint );
                        if( solType<0 || eL_tail is null )  continue;
                      // ---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------  
                        int hashValue_Solution = ULGstart.hv ^ eL_tail.hv;
                        if( Processed_Solutions_List.Contains( hashValue_Solution ) )  continue;

                        switch(solType){
                            case 1: case 2:
                                bool solFlag = NiceLoop_SolResult_Conneted( eL_tail, ULGstart, solType );
                                if( solFlag is true ){
                                    SolCode = 2;
                                    Processed_Solutions_List.Add( hashValue_Solution );      
                                    if( !pAnMan.IsContinueAnalysis() )  return true;    // ----- Solution save

                                }
                                break;
                            case 3:// ... Contradiction!   the path was found that led to both Plus/Minus(true/false).
                                NiceLoop_SolResult_Contradiction( ULGstart, eL_tail ); 
                                SolCode = 2;
                                Processed_Solutions_List.Add( hashValue_Solution ); 
                                if( !pAnMan.IsContinueAnalysis() )  return true;
                                break;

                            default:
					            throw new Exception( $"Operation Error. extNW_QSearch_Loop ... solType:{solType}");
                        }
                    }
                }
            }
            G6.Additional_Message = "";
            return (SolCode>0);

          // ====================== Inner function ========================================================================================

                (string,ULogical_Node) _Is_NiceLoop_Connected( ULogical_Node sNode, ULogical_Node eNode ){ 
                    if(debugPrint) WriteLine( $"   ----- IsNLConnected? {sNode} ... {eNode}" );

                    (string,ULogical_Node) NL_cond = ("",null);

                    if( sNode.rc != eNode.rc ){ NL_cond = ("contradiction",eNode); goto LsubEnd; }                   // rcS!=rcE ... contradiction
                    if( sNode.rc<0 )  goto LsubEnd;   

                    // -------------------------------------------------------------
                    UCell UC = pBOARD[sNode.rc];
                    bool  IsMatchno = sNode.no==eNode.no;
                    bool  IsMatchTF = sNode.pmCnd==eNode.pmCnd;
                    bool  UC_bivalue = UC.FreeBC==2;

                    if( sNode.pmCnd==0  && eNode.pmCnd==1 ){     // F - T  (1)
                        if( !IsMatchno ){ NL_cond = ("continue",eNode); goto LsubEnd; }               
                        else{             NL_cond = ("discontinue",eNode); goto LsubEnd; }
                    }

                    if( sNode.pmCnd==1 && eNode.pmCnd==0 ){     // T - F  (2)
                        if( !IsMatchno && UC_bivalue ){ NL_cond = ("continue",eNode); goto LsubEnd; }  
                        if( IsMatchno ){                NL_cond = ("discontinue",eNode); goto LsubEnd; }  
                        NL_cond = ("--",eNode); goto LsubEnd;
                    }

                    if( sNode.pmCnd==1 && eNode.pmCnd==1 ){
                        if( IsMatchno ){  NL_cond = ("continue",eNode); goto LsubEnd; }    // T - T  (3)
                        else{             NL_cond = ("discontinue",eNode); goto LsubEnd; }
                    }

                    if( sNode.pmCnd==0  && eNode.pmCnd==0 ){
                        if( IsMatchno ){  NL_cond = ("continue",eNode); goto LsubEnd; }    // F - F  (4)
                        else{             NL_cond = ("discontinue",eNode); goto LsubEnd; }
                    }


                  LsubEnd:
                    if(debugPrint) WriteLine( $"-- -- -- -- -- {sNode} ... {eNode}   NL_cond:{NL_cond} -- -- -- -- --" );

                    return NL_cond;
                }

                bool _IsSolution( (string,ULogical_Node) NL_cond, ULogical_Node ULGstart, List<eNW_Link> eNetList ){
                    var  (NLtype,eN)= NL_cond;
                    bool  SolFlag = false;
                    UCell UCstart = pBOARD[ULGstart.rc];

                    UInt128 NL128 = eNetList.Aggregate(UInt128.Zero, (a,b)=>a|b.eObject );
                    ULogical_Node ULGend = eNetList.Last().DesN;

                    if( NLtype=="continue" ){
                        int kcr=0;

                        // Evaluation of Origin and Destination (not internal link connection)
                        //  ULGstart:Origin   ULGend:Destination
                        if( ULGstart.pmCnd==0 && ULGend.pmCnd==1 ){  // (rc,no,pmCnd) 
                            int noBcan = (1<<ULGstart.no) | (1<<ULGend.no);
                            int cancelB = UCstart.FreeB &~noBcan;
                            if( cancelB>0 ){ UCstart.CancelB=cancelB; SolFlag=true; }
                        }

                        eNW_Link eL1 = null;
                        foreach( var eL2 in eNetList ){      
                            if( eL1 != null  ){              // ... Node
                                ULogical_Node U1 = eL1.DesN;
                                ULogical_Node U2 = eL1.OrgN;
                                if( U1.LGN_key3 == U2.LGN_key3 ){  // (rc,no,pmCnd) 
                                    if( U1.pmCnd==1 ){
                                        UCell UC = pBOARD[U1.rc];
                                        int cancelB = UC.FreeB & ~(1<<U1.no);
                                        if( cancelB>0 ){ UC.CancelB=cancelB; SolFlag=true; }
                                    }
                                }
                            }

                            if( eL2 is eNW_Link_InterCells ){  // ... Link
                                int no2 = eL2.noOrg;
                                UInt128 bpCom = eL2.OrgN.Aggregate_ConnectedAnd() & eL2.DesN.Aggregate_ConnectedAnd();
                                bpCom &= BOARD_Free81B9[no2];
                                bpCom = bpCom & ~(NL128 | eL2.eObject);
                                if( bpCom.IsNotZero() ){
                                    foreach( var P in bpCom.IEGet_UCell(pBOARD) ) P.CancelB = 1<<no2;
                                    SolFlag = true;
                                        if(debugPrint) WriteLine( $" eL2:{eL2}  cancel no2:{no2+1}  {bpCom.ToBitString81()}");
                                }
                            }
                            eL1 = eL2;
                        }
                    }

				    else if( NLtype =="discontinue" ){
                        bool  UC_bivalue = UCstart.FreeBC==2;
                        string conectionType = (ULGstart.pmCnd==1? "P":"M") + (ULGend.pmCnd==1? "P":"M");
                        int noBX = 1<<ULGstart.no | 1<<ULGend.no;
                        switch(conectionType){
                            case "MP": UCstart.FixedNo = ULGstart.no+1; SolFlag=true;  break;

                            case "PM": UCstart.CancelB = 1<<ULGstart.no; SolFlag=true; break;
                            
                            case "PP":                           
                                UCstart.CancelB = 1<<ULGstart.no;
                                if( UCstart.CancelB>0 ) SolFlag = true;
                                break;    

                            case "MM":
							    if( UC_bivalue ){
								    UCstart.CancelB = UCstart.FreeB &~noBX;
								    if( UCstart.CancelB>0 ) SolFlag = true;
							    }
                                break;    
                        }
                    }

                    else if( NLtype =="contradiction" ){  //discontinuous
                        if( ULGstart.pmCnd==1 ){
                            UCstart.CancelB = 1<<ULGstart.no;
                            SolFlag = true;
                        }
                    }
                
                    else{ } //--
                    return SolFlag;
                }


                void NiceLoop_SolResult_Contradiction( ULogical_Node ULGstart, eNW_Link eL_rail ){
        						if(debugPrint)  WriteLine( $"start ULGstart:{ULGstart}   rcBreakX:{ULGstart.b081.TBScmp()}" );
                    eNW_Node eN_Des = eL_rail.eN_Des_nPM;
                    var (stLM,stLP) = eGLink_ManObj.ToString_ContradictionLinks(eN_Des);  

                    ULogical_Node contraURG = eN_Des; 
                    int rc=ULGstart.rc, no=ULGstart.no, noB=1<<no;
                    UCell UCstart=pBOARD[ULGstart.rc], Pcontra=pBOARD[contraURG.rc] ;

                    if( ULGstart.pmCnd==1 ) UCstart.CancelB = noB;
                    else                    UCstart.CancelB = UCstart.FreeB & ~noB;

                    // ===================== result report ===========================
                    string st = "NiceLoop" + " contradiction" ;
			        string st2 = $" Org:{_ToString_eN(ULGstart)} to {eN_Des.b081.TBScmp()}#{eN_Des.no+1}";
                    Result = st+st2;
            
                    string stCan = $" {ULGstart.b081.TBScmp()}#{UCstart.CancelB.TBScmp()} is excluded.";
                    ResultLong = $"{st}\n{st2}\n{stCan}\n{stLP}\n{stLM}";
 			        extResult  = ResultLong;

                    // ===================== result coloring ===========================
                    Color  cr, crStart=Colors.LightPink, crStem=Colors.Navy;
                    UCstart.Set_CellColor_BkgColor_noBit(noB,AttCr,AttCr2);
                    UCstart.Set_CellFrameColor(Colors.Blue);

                    Pcontra.Set_CellColor_BkgColor_noBit(noB,AttCr,AttCr3);

                
                    var (hvM,eNetListM) = eGLink_ManObj.Get_eNW_OrgToChain( eN_Des, pmCnd:0 );            
                    var (hvP,eNetListP) = eGLink_ManObj.Get_eNW_OrgToChain( eN_Des, pmCnd:1 );   

                    int kx1 = Cells_Colorlink(eNetListM, kxColor:0);
                    Cells_Colorlink(eNetListP, kxColor:kx1);       

			                // ----- inner function -----
			                string _ToString_eN( ULogical_Node ULG){
				                string ToString_pmCnd() => ( (ULG.pmCnd==1)? "+": (ULG.pmCnd==0)? "-": "*");
                                string st = $"{ULG.b081.TBScmp()}#{no+1}{ToString_pmCnd()}";
				                if( ULG.ID>0 )  st += $" {ULG.ID}";
				                return st;
			                }
                }


             
                bool  NiceLoop_SolResult_Conneted( eNW_Link eL_tail, ULogical_Node? ULGstart, int solType ){
                    // ... Clarifying the conditions ...
                            if(debugPrint) eGLink_ManObj.eNWMan_DisplayNetworkPath( eL_tail, debugBPM:true ); 

                    eNW_Node eN_Des = eL_tail.eN_Des_nPM;
                    int pm = eL_tail.DesN.pmCnd;
                    var (hv,eNetList) = eGLink_ManObj.Get_eNW_OrgToChain( eN_Des, pmCnd:pm );                            

                    if( eNetList==null || eNetList.Count<=0 )  return false;  // <<-- This if statement is not needed.
								if(debugPrint)  WriteLine( eGLink_ManObj.eNW_ToStringB(eNetList, debugPrint:debugPrint) );

                    ULogical_Node _endULG = new( 1<<eN_Des.no, b081:eN_Des.b081, /*lkType:solType-1,*/ pmCnd:pm );  // variable for determining continuity	 
                    var NL_cond = _Is_NiceLoop_Connected(ULGstart, _endULG );
								if(debugPrint) WriteLine( $"ULGstart:{ULGstart}  eN_Des:{eN_Des} ... (iSCon,noX):{NL_cond}" ); 
                    if( NL_cond.Item1=="" || NL_cond.Item1=="--" )  return false; // ...try next

                    bool _solFlag = _IsSolution( NL_cond, ULGstart, eNetList );
                    if( !_solFlag )  return false;
                    // -----------------------------------------------------------------------------

                    // Continuous/DisContinuous Nice_Loop 
                    string stL = eGLink_ManObj.eNW_ToStringB(eNetList,debugPrint:false); //WriteLine( stL );
                    stL = stL.eLinkFormatter(55,4);
                    // .. .. .. .. .. .. .. result report.. .. .. .. .. .. ..
                    int rc = ULGstart.rc, no=ULGstart.no, noB=1<<no;
                    string st = "NiceLoop";
                    st += $" {NL_cond.Item1} Origin:{rc.ToRCString()}#{no+1}";     //In Continuous, the starting point has no meaning, but is used for identification.
			        Result     = st;
                    ResultLong = $"{st}\n\n{stL}";
			        extResult  = ResultLong;
        
                    // .. .. .. .. .. .. .. coloring .. .. .. .. .. .. ..
                    Color  cr, crStart=Colors.LightPink, crStem=Colors.Navy;
                    UCell UCstart = pBOARD[ULGstart.rc];
                    UCstart.Set_CellColor_BkgColor_noBit(noB,AttCr,AttCr2);
                    /*if( !iSCon )*/ UCstart.Set_CellFrameColor(Colors.Blue);

                    Cells_Colorlink( eNetList, kxColor:0);

        /*
                    int kColor=2, kColor2=1, kColorX;
                    int crLstSize = PastelColors.Length;
                    bool simpleNL = eNetList.All(p=>(p is eNW_Link_IntraCell) || (p is eNW_Link_InterCells) ); 

                    foreach( var eL in eNetList.Skip(1) ){
                        if( eL is eNW_Link_IntraCell ) continue;  // Omit coloring of inter-cell links.

                        ULogical_Node eLGN = eL.OrgN;
                        int  noB2=1<<eLGN.no;
                        kColor %= crLstSize;
                        kColorX = simpleNL? kColor2: kColor++;
                        cr = PastelColors[kColorX];
                        foreach( var P in eLGN.b081.IEGet_UCell(pBOARD) ){
                            P.Set_CellColor_BkgColor_noBit(noB2,AttCr,cr);
                        }

                        if( (eL is eNW_Link_ALS) || (eL is eNW_Link_AIC) ){
                            kColorX = simpleNL? kColor2: kColor++;
                            cr = PastelColors[kColorX];
                            foreach( var P in eL.eObject.IEGet_UCell(pBOARD) ){
                                P.Set_CellColor_BkgColor_noBit(P.FreeB,AttCr,cr);
                            }
                        }

                    }
        */
                    return true;
                }
        }

        public int Cells_Colorlink( List<eNW_Link> eNetList, int kxColor ){
            int kColor=kxColor+2, kColor2=kxColor+1, kColorX;
            int crLstSize = PastelColors.Length;
            bool simpleNL = eNetList.All(p=>(p is eNW_Link_IntraCell) || (p is eNW_Link_InterCells) ); 

            foreach( var eL in eNetList.Skip(1) ){
                if( eL is eNW_Link_IntraCell ) continue;  // Omit coloring of inter-cell links.

                ULogical_Node eLGN = eL.OrgN;
                int  noB2=1<<eLGN.no;
                kColor %= crLstSize;
                kColorX = simpleNL? kColor2: kColor++;
                Color cr = PastelColors[kColorX];
                eL.eObject.IE_SetNoBBgColor_All(pBOARD,0X1FF,AttCr,cr);
            }
            return kColor;
        }

    }  
}