using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using System.Windows.Navigation;
using static System.Diagnostics.Debug;

using GIDOO_space;


namespace GNPX_space{
    public partial class ExtendedNetwork_App: AnalyzerBaseV2{
		private int stageNoPMemo = -9;
//        public static DevelopWin devWin; //## development 

        public eNW_Man eGLink_ManObj;

        private ALSLinkMan  ALSMan;
        public  int			NiceLoopMax{ get => G6.NiceLoopMax; }
        public  ExtendedNetwork_App( GNPX_AnalyzerMan pAnMan ): base(pAnMan){
            this.pAnMan=pAnMan;
        }

		public bool eNW_Prepare( int ALS_plus, int minSize=1, bool debugPrint=false ){
			if( stageNoP!=stageNoPMemo ){
				stageNoPMemo = stageNoP;

				base.AnalyzerBaseV2_PrepareStage();						// @ Initialize the constants for the board state.

                eNW_Link.Initialize();								// @ link ID initialization
				
				ALSMan = new ALSLinkMan(pAnMan);						// @ Only definitions here. There is no substance
                eGLink_ManObj = new eNW_Man( pAnMan );
				eGLink_ManObj.QGenerator_Link_Man( checkPrintB:false );	// Links : Cell, AIC, ALS, ALSXZ AnLS, eALS

        //        bool ALSChecked   = G6.ALS"];
        //        bool ALSXZChecked = G6.ALSXZ"];    
		//        ALSMan.Prepare_ALSLink_Man( nPlsB:ALS_plus, minSize:minSize, setCondInfo:true, debugPrint:false );

				//
				Use_eALS          = G6.Use_eALS > 1;                                                      //                                                                
			}  
            return true;
		}
    }
}