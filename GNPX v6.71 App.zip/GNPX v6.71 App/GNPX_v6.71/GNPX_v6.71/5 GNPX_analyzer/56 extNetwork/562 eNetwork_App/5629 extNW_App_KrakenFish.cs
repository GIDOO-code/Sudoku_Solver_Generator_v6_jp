using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Policy;
using System.Windows.Interop;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using defBC = (UInt128,int,UInt128,int);
	using G6_SF = G6_staticFunctions;
    public partial class ExtendedNetwork_App: AnalyzerBaseV2{

		// 4....9.5. 23..58.67 ...4.7... ......325 3.2....8. 5.1...7.. ...89.... 9......7. .1.72..46  Puzzle
		// 476239158 239158467 1..467239 7.....325 3.2.7.681 561382794 6.789.51. 9.....87. 81.72.946  Current

		// .38.6...9 6....93.. 2..43...1 ..61..935 5.3.8.1.. .4....... .8.65..13 ...8..5.6 3.59..827


		//   @@@ [ver.6.5]  Under development and adjustment.


		public List<eNW_Link> eNW_Link_List => eNW_Man.eNW_Link_List;


		public bool V7_Kraken_Fish()        => Kraken_Fish_Function( );
		public bool V7_Finned_Kraken_Fish() => Kraken_Fish_Function( finnedB:true );



		public bool Kraken_Fish_Function( bool finnedB=false, bool debugPrint=false ){

			bool retPrepare = eNW_Prepare(ALS_plus:1);				// @ Create eLink
            if( !retPrepare ) return false;

			var eNW_Link_ListS = eNW_Link_List.FindAll(P=> P.OrgN.b081.BCC()==1 && P.DesN.b081.BCC()==1); // is ???
			
			Fish_absolute Fish000 = new( this, FMavail:true, minSize:2, maxSize:7); 
			int szMin = G6.KrakenFishSizeMin;
			foreach( int sz in Enumerable.Range(szMin,8-szMin) ){

				foreach( var V7FC in Fish000.IE_BaseCover_absolute_Kraken(sz,finnedB) ){  // @ Generate Fish
						//WriteLine(V7FC);

					UInt128  finX = V7FC.Fin;
					if( finnedB != (finX!=qZero) )  continue;

					int      no=V7FC.no;
					UInt128  Fish=V7FC.Fish, BaseSet=V7FC.BaseSet, CoverSet=V7FC.CoverSet;
					int      BaseHouse=V7FC.BaseHouse, CoverHouse=V7FC.CoverHouse;
					UInt128  Fin= V7FC.Fin, EndoFin=V7FC.EndoFin, CannFin=V7FC.CannFin;	
							if(debugPrint){
								var query = eNW_Link_List.GroupBy(x => x.OrgN.LGN_key3);
								foreach( var group in query ){
									WriteLine( "" );
									foreach( var P in group ) WriteLine( P.ToString() );
								}
							}

					// ----- Kraken Fish Test --------------------------------------------------------------------------------------------
					List<(int,int,int,string)>  Kraken_Cancel_List = new(); 
					foreach( var hc in CoverHouse.IEGet_BtoNo(27) ){
						UInt128 Hin=(HouseCells81[hc] & Fish), Hout=(HouseCells81[hc] & ~Fish);
						var ECand = eNW_Link_ListS.FindAll(P => P.noDes==no && P.DesN.pmCnd==0 && (P.OrgN.b081&Hout)>qZero && (P.DesN.b081&Hin)>qZero ); 
							if(debugPrint)  ECand.ForEach( P => WriteLine(P) );
				

						UInt128 test_Hin = (Hin & (BOARD_Free81B9[no]) | finX);
						var query2 = ECand.GroupBy(x => x.OrgN.LGN_key3);
						foreach( var grp in query2 ){
							if(debugPrint){ WriteLine( "" ); foreach( var P in grp ) WriteLine( P.ToString() ); }

							UInt128 Exclude = grp.Aggregate(qZero, (a,p) => a| p.DesN.b081);
							if( (test_Hin&~Exclude) == qZero ){
								if(debugPrint){
									WriteLine( $"\n@@@ Kraken Fish\n{V7FC}" );
									foreach( var P in grp ) WriteLine( $"		Kraken_Fish {P.ToString()}" );
								}

								var Qorg = grp.First().OrgN;
								string extMsg = $"  {Qorg.b081.TBScmp()}#{Qorg.no+1} is false.";
								foreach( var P in grp )  extMsg += $"\n    {P.ToString()}";

								int noB = 1<<Qorg.no;
								foreach( var P in Qorg.b081.IEGet_UCell(pBOARD) )  Kraken_Cancel_List.Add( (hc, P.rc, Qorg.no, extMsg) );
							}
						}                       
					}

					if( Kraken_Cancel_List.Count() > 0 ){
						string extMsgT = "";
						foreach( var (h,rc,orgno,extMsg) in Kraken_Cancel_List ){
							var P = pBOARD[rc];
							 P.CancelB = P.FreeB & (1<<orgno);
							extMsgT += $"\n\n{extMsg}";
						}						
						KrFish_Fish_Result( V7FC, extMsgT );

						SolCode = 2;
						if( !pAnMan.IsContinueAnalysis() )  return true;

						// ----- Final processing -----
						foreach( var UC in pBOARD.Where(p=>p.No!=0) ) UC.CancelB=0;
						pBOARD.ForEach( UC => UC.ECrLst=null );
					}
				}
			}
			return (SolCode>0);
		}


        private bool KrFish_Fish_Result( UFish V7FC, string extMsg ){
            int      no=V7FC.no, sz=V7FC.sz;
            UInt128  Fish=V7FC.Fish, BaseSet=V7FC.BaseSet, CoverSet=V7FC.CoverSet;
            int      BaseHouse=V7FC.BaseHouse, CoverHouse=V7FC.CoverHouse;
            UInt128  Fin= V7FC.Fin, EndoFin=V7FC.EndoFin, CannFin=V7FC.CannFin;
    
            int noB=(1<<no);    
            Fish.IE_SetNoBBgColor( pBOARD, noB, AttCr,SolBkCr);
            V7FC.Fin.IE_SetNoBBgColor( pBOARD, noB, AttCr,SolBkCr6);

            string FishNames = UFish.FishNames[sz-2];
			string st = $" size: {sz}\n   no: #{no+1}\n Fish: {Fish.TBScmp()}";
			st += $"\n BaseSet:{BaseSet.TBScmp()} /  BaseHouse:{BaseHouse.TBS27cmp()};";
			Result = $"Kraken {FishNames} {st.Replace("\n "," ").Replace("  "," ")}";  

			if( EndoFin > qZero )  st += $"  EndoFin:{EndoFin.TBScmp()}";
			st += $"\nCoverSet:{CoverSet.TBScmp()}  /  CoverHouse:{CoverHouse.TBS27cmp()};";
			if( CannFin > qZero )  st += $"  CannFin:{CannFin.TBScmp()}";
			st += $"\n   Fin:{Fin.TBScmp()}";
			ResultLong = $"Kraken {FishNames} {st}";
			extResult = ResultLong + extMsg;
			return true;
        }
    }
}