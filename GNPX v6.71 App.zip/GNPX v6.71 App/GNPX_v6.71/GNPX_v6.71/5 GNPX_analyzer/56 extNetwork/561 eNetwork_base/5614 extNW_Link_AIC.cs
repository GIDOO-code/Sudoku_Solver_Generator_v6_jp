using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Windows.Documents;
using System.Xml.Linq;

using GIDOO_space;

using GNPX_space;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space {

    public partial class eNW_Man: ALSLinkMan{       

        // *--*--*--*--*--*--*--*
        //  eNW_Link_AIC
        // *--*--*--*--*--*--*--*

        public int QGenerator_eNW_AIC_Link( bool debugPrint=true ){
            List<eNW_Link> AIC_List = new(); 

            foreach( int selH in Enumerable.Range(0,27) ){
                UInt128 B81selH = BOARD_Free81 & HouseCells81[selH];									// selected house cells
                if( B81selH.BitCount()<=1)  continue;
                    if( debugPrint )  WriteLine( $"\n selH:{selH}  AIC:{B81selH.ToBitString81N()}" );

				USubset qAIC = new USubset( 0, pBOARD, B81selH );

                foreach( int axis1 in B81selH.Ceate_rcbFrameOr().IEGet_BtoNo(sz:27).Where(h=>h!=selH) ){ // 1st axis
					UInt128 h81 = HouseCells81[axis1];
					if( (h81&B81selH) == qZero ) continue;

					// debugPrint = true;

					int  FreeB_Axis = (BOARD_Free81 & h81).Get_FreeB_or();
					foreach( int noOrg in FreeB_Axis.IEGet_BtoNo() ){										// select noOrg

						{ //SUBset_Modification
							SUBset_Modification_initialSetting_house( qAIC, noOrg, h81, debugPrint:debugPrint );
								bool modified = SUBset_Modification ( qAIC, noOrg, debugPrint:debugPrint );
							if( !modified )  continue;
						}

						var B81ax1 = B81selH & HouseCells81[axis1];
						if( B81ax1.IsZero() )  continue;

						var B81selH_outer = B81selH & ~B81ax1;
						if( B81selH_outer == qZero )  continue;�@// If there are no remaining elements, it will fail.

						// === Origin ===
						List<ULogical_Node> ULG_OrgList = _Generate__ULG_OrgList( qAIC, noOrg, B81selH_outer, debugPrint:debugPrint );	
						if( ULG_OrgList==null || ULG_OrgList.Count==0 )  continue;

						// === Destination ===
						List<ULogical_Node> ULG_DesList = _Generate_ULG_DesList(qAIC, debugPrint:false);

						// === Generate Links ===
						foreach( var ULGorg in ULG_OrgList ){
							foreach( var ULGdes in ULG_DesList.Where(p=>(ULGorg.b081&p.b081)==0) ){
								eNW_Link_AIC R = new( qAIC.ULG_node, ULGorg, ULGdes, axis1 );
								Set_eGLink( R, debugPrint, AIC_List );
									if(debugPrint)  WriteLine( R );
							}
						}
					}
                }
            }
            eNW_Link_List.AddRange(AIC_List);

            return AIC_List.Count; 

					// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
						List<ULogical_Node> _Generate__ULG_OrgList( USubset qAIC, int noOrg, UInt128 cand81, bool debugPrint=false ){
							List<ULogical_Node> ULG_OrgList = new();
							var qALS_rcbAnd9_Org = qAIC.rcbAnd9[noOrg];
							if( qALS_rcbAnd9_Org == 0 )  return null;
									//WriteLine( $"qALS_rcbAnd9_Org:{qALS_rcbAnd9_Org.rcbToBitString27()}" );

							foreach( int hOrg in qALS_rcbAnd9_Org.IEGet_BtoHouse27() ){
								UInt128 rc81h = cand81 & HouseCells81[hOrg];
								foreach( var ULG in Generate_ULG_by_Combination(noOrg, rc81h, pmCnd:1, hNo:hOrg) ){
									ULG_OrgList.Add( ULG );
										if(debugPrint)  WriteLine( $" noOrg:#{noOrg+1}  hOrg:{hOrg:00}  origin {ULG}" );
								}
							}
							ULG_OrgList =  ULG_OrgList.DistinctBy(p=> p.LGN_key3).ToList();
										if(debugPrint){
											WriteLine("** ULG_OrgList **");
											ULG_OrgList.ForEach( (p,mx) => WriteLine( $"{mx} {p}" ) );
										}
							return ULG_OrgList;
						}

					// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
						// Termination is (1)within the AIC , (2) outside the AIC
						List<ULogical_Node> _Generate_ULG_DesList( USubset qAIC, bool debugPrint=false ){
							List<ULogical_Node> ULG_DesList = new();

							// (1p) Targets within ALS-1 positive
							foreach( UCell UC in qAIC.UCellList ){												// fixed							
								int noDes = UC.FreeB_SP.BitToNum();		
								if( noDes >= 0 ){
									ULogical_Node URGdes1 = new( no:noDes, rc:UC.rc, pmCnd:1 );
									ULG_DesList.Add( URGdes1 );
										if(debugPrint) WriteLine( $"  -1- URGdes1:{UC}  URGdes1:{URGdes1}" );
								}
							}
							
							// (1n) Targets within ALS-2 negative
							foreach( UCell UC in qAIC.UCellList.Where(p =>(p.FreeB & ~p.FreeB_SP) >0) ){		//canceled
								int noDesB = UC.FreeB & ~UC.FreeB_SP;
								foreach( int noDes in noDesB.IEGet_BtoNo() ){
									ULogical_Node URGdes2 = new( no:noDes, rc:UC.rc, pmCnd:0 );
									ULG_DesList.Add( URGdes2 );
										if(debugPrint) WriteLine( $"  -2- URGdes1:{UC}  URGdes2:{URGdes2}" );
								}

							}
							
							//(2) Targets outside of ALS
							foreach( int noDes in qAIC.FreeB_SP.IEGet_BtoNo() ){
								var qALS_rcbAnd9wk_Des = qAIC.rcbAnd9_wk(noDes);
								foreach( int hDes in qALS_rcbAnd9wk_Des.IEGet_BtoHouse27() ){
									UInt128 rc81DesOut = (BOARD_Free81B9[noDes] & HouseCells81[hDes]) & ~qAIC.b081B9[noDes];
									if( rc81DesOut == 0 ) continue;
									foreach( var ULGdes in Generate_ULG_by_Combination( noDes, rc81DesOut, pmCnd:0, hNo:hDes ) ){
										ULogical_Node URGdes3 = new( noB9:1<<noDes, b081:rc81DesOut, pmCnd:0 );
										ULG_DesList.Add( URGdes3 );
											if(debugPrint) WriteLine( $"  -3- noDes:#{noDes+1}  hDes:{hDes:00}  URGdes3:{URGdes3}" );
									}
								}
							}
							ULG_DesList = ULG_DesList.DistinctBy(p=> p.LGN_key3).ToList();
							if(debugPrint){
								WriteLine("** ULG_DesList **");
								ULG_DesList.ForEach( (p,mx) => WriteLine( $"{mx} {p}" ) );
							}
							return ULG_DesList;
						}
        }

    }
}
                        