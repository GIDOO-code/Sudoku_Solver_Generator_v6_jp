using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Windows.Shapes;

using GIDOO_space;

using Windows.UI.Composition.Interactions;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space {

    public partial class eNW_Man: ALSLinkMan{
		static private readonly string _space10 = new string(' ',10);	// for debug
		static private readonly string _space20 = new string(' ',20);
		static private readonly string _space30 = new string(' ',30);
		static private readonly string _space50 = new string(' ',50);

// under development !!!

		private int priority000=0;



        public (int,eNW_Link?) extNW_QSearch_Radical( ULogical_Node LGN_start, (int,int) rcno_Break, UInt128 rcProhibit, bool debugPrint=false ){
			if( debugPrint )  eNW_Link.Set_withID_(false);    // ... Add an ID to the link display.     

            // ----- for develop/debug ----- 
            int debugIX = 0;
//debugPrint = true;
			// ----------------------------------------------------


            // ===== Prepare ... Select Target Network =====
			var eNW_Link_List_Act = eNW_Link_List;			// Select this in the "Solver Options".

            if( (eNW_Link_List_Act is null) || eNW_Link_List_Act.Count<=0 )  return (-1,null);													
					if(debugPrint)  WriteLine( $"\n===#-1  -->  ULGstart:{LGN_start}" );			
								

			// === Search control variables
            eNW_NodeList = new();
            eNW_pmCnd    = new int[81];

			UInt128    usedPattern    = qZero;
            UInt128[]  usedNode9      = new UInt128[9];
			usedNode9[ LGN_start.no ] = LGN_start.b081;

            List<int> UsedLink_noDir = new();  
			// -----------------------------------------------


			// === First Links
			bool LoopType = (rcno_Break.Item1>=0);
			priority000 = 0;
            PriorityQueue<eNW_Link,int> Queue_Next_Links = _Prepare_First_Queue_Next_Links( LGN_start, LoopType );
			if( Queue_Next_Links == null )  return (-1,null);
			usedPattern    = LGN_start.b081;

//  var  (rcOrg,noOrg) = rcno_Break;	// @ specify the end node(cell) and digits.
//  if( rcOrg>=0 && rcOrg>=0 ){			// @ When specifying the end node : NiceLoop.
//		usedNode9[noOrg] &= ~(qOne<<rcOrg);
// 		usedPattern &= ~(qOne<<rcOrg);
//	}

			// ===================================================================================================
            while( Queue_Next_Links.Count > 0 ){
				eNW_Link eLnext = _Set_NextLink( );	
				if( eLnext == null )  break;
				if( (eLnext is not eNW_Link_IntraCell) && (eLnext.eN_Des_nPM.b081 & LGN_start.b081) > qZero )  continue;  

						// Returning to the starting point to form a loop is prohibited.
							if(debugPrint){
								eNW_Node eNDnext = eLnext.eN_Des_nPM;
								WriteLine( $"  ====-3 --> {_space50} {eNDnext} --- debugIX:{debugIX++}   {eNDnext.GetType()} " );
								eNWMan_DisplayNetworkPath( eLnext );
							}


                var (settedB,ndStatus) = Set_Upstream_Link_Information_OnNode( eLnext, debugPrint:false );

                if( ndStatus==3 ) return (3,eLnext);   // *** contradiction ****
      
				usedPattern |= eLnext.eObject;

//===== Reached the target point.
// if( (eLnext is not eNW_Link_IntraCell) && eLnext.eN_Des_nPM.rc==rcOrg )  return (1,eLnext);	 // (rcno: rc<<4 | no)   //<<< Reached >>>
				if( eLnext.genNo>=G6.QSearchMaxGen )  continue;			// <<< Limit link length >>>

				_Get_Connected_Links(eLnext, debugPrint);
            }
            return (-1,null);
		// ---------------------------------------------------------------------------------------------------------
	
						void _debug_RoutePrint( eNW_Node eND ){
							var (stLM,stLP,eNList) = Get_ContradictionLinks_Info( eND );
							WriteLine( $"{stLP}\n{stLM}" );
						}


						PriorityQueue<eNW_Link,int> _Prepare_First_Queue_Next_Links( ULogical_Node LGN_startbool, bool LoopType, bool debugPrint=false ){
							int no=LGN_start.no, pmCmd=LGN_start.pmCnd; 
						  
							PriorityQueue<eNW_Link,int> _firstLinks = new();
							bool Is_Intra_Inter( eNW_Link eNL ) => (eNL is eNW_Link_IntraCell ) || ((eNL is eNW_Link_InterCells) ); 
						  
							foreach( int rc in LGN_start.b081.IEGet_rc(81) ){
								ULogical_Node ULGtmp = new( no, rc, pmCmd, Sentinel:true );		// Origin Node
								var eN_Links = eNW_Link_List_Act.FindAll( q => Is_Intra_Inter(q) && q.OrgN.LGN_key3==ULGtmp.LGN_key3 );
								if( LoopType )  eN_Links.RemoveAll(p => (p is eNW_Link_IntraCell) );	
								eN_Links.ForEach( p=> _firstLinks.Enqueue(p, GenPRI(p.lkCode) ) );
							}		
						  
							return _firstLinks;
						}
						// ---------------------------------------------------------------------------------------------------------


						eNW_Link _Set_NextLink(  ){
							bool IsValidLink( eNW_Link L ) => (L.eObject & usedNode9[L.noDes])==UInt128.Zero && (rcProhibit & L.eObject)==UInt128.Zero;
						 
							eNW_Link eLnext = null;
							int hv = 0;
							do{
								if( Queue_Next_Links.Count == 0 )  break;
								eLnext = Queue_Next_Links.Dequeue();						// Select Link with minimum ID
								if( !IsValidLink(eLnext) )  continue;
								hv = eLnext.hv;										// link hash value, direction insensitive
							}while( UsedLink_noDir.Contains(hv) );					// Exclud used Links(including reverse direction)
							UsedLink_noDir.Add(hv);
										if(debugPrint)  WriteLine( $"\nP1 debugIX:{debugIX++}  eLnext: @ {eLnext}" );
							return  eLnext;
						}	 
						// ---------------------------------------------------------------------------------------------------------



						bool _Get_Connected_Links( eNW_Link eLnext, bool debugPrint ){
							// Add the links connecting to the node[eN2].
					
						    var Connected_Links = eNW_Link_List_Act.FindAll( q => __IsConnected(eLnext,q,usedPattern,usedNode9,LGN_start) );
							if( Connected_Links.Count==0 )  return false;
							usedNode9[eLnext.noDes] |= eLnext.eObject;  

							// Consecutive use of intra_links is prohibited.
							bool Is_Added_Links = false;
							foreach( var eL2 in Connected_Links.Where(p=>p.noDes>=0) ){ 
// if( eL2.DesN.rc==rcOrg )  WriteLine( $"@@@ eL2{eL2}" );

								if( (eL2.eObject & usedNode9[eL2.noDes] ) > UInt128.Zero )  continue;
								if( UsedLink_noDir.Contains(eL2.hv) )  continue;				// Excluding used Links(including reverse direction)
								bool contains = Queue_Next_Links.UnorderedItems.Any(p => p.Element.hv==eL2.hv);
								if( contains ) continue;

								eL2.genNo = eLnext.genNo+1;
								Queue_Next_Links.Enqueue(eL2, GenPRI(eL2.lkCode) );    //Add next links to list. Exclude used links (reverse direction is also possible).
								Is_Added_Links = true;
										if(debugPrint)  WriteLine( $"   P2 Queue_Next_Links.Add debugIX:{debugIX++}  @+ {eL2}" );
							}
							return true;

									bool __IsConnected( eNW_Link eLpre, eNW_Link eL2, UInt128 usedPattern, UInt128[] usedNode9, ULogical_Node LGN_start ){
									    //In a radial search, links connected to the starting node are excluded.	
// if( rcOrg==-1 && eL2.eN_Des_nPM.rc==LGN_start.rc )  return false;    //  radial type
										UInt128 LGN_key3_eLtail = eLpre.DesN.LGN_key3;    // rc,no,pmCnd
										if( eLpre.DesN.LGN_key3 != eL2.OrgN.LGN_key3 )  return false;									
// if( eL2.eN_Des_nPM.rc == rcOrg )  WriteLine( eL2 );									
										if( (eLpre is eNW_Link_IntraCell) && (eL2 is eNW_Link_IntraCell) )  return false;
												if( (usedNode9[eL2.noOrg]&eL2.eObject).IsNotZero() )  return false;
												if( (usedPattern&eL2.eObject).IsNotZero() )  return false;
										return true;
									}
						}
						// ---------------------------------------------------------------------------------------------------------
        }
    }
}
                        