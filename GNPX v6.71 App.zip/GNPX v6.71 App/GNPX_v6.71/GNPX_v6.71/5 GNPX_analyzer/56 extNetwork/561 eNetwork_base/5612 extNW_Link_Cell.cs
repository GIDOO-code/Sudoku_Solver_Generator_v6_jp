using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Threading.Channels;
using System.Windows.Documents;
using System.Xml.Linq;
using System.IO;
using System.Text;

namespace GNPX_space {

    public partial class eNW_Man: ALSLinkMan{       

        // *--*--*--*--*--*--*--*
        //  eNW_Link_IntraCell
        // *--*--*--*--*--*--*--*
        private int QGenerator_eNW_IntraCell( bool debugPrint=true ){
			// WriteLine( $"========== {++eNdebug} QGenerator_eNW_IntraCell" );

            List<eNW_Link> IntraCell_List = new(); 
            foreach( var UC in pBOARD.Where(p=> p.No==0 && p.FreeBC>=2) ){
                    if( debugPrint )  WriteLine( $"\nUC:{UC}" );
                
                List<int> noList = UC.FreeB.IEGet_BtoNo().ToList();

                UInt128 b128_rc = UInt128.One<<UC.rc;
                Permutation prm = new(UC.FreeBC,2);
                while(prm.Successor()){
                    int no1 = noList[prm.Index[0]];
                    int no2 = noList[prm.Index[1]];
                    
                    ULogical_Node OrgN = new( noB9:1<<no1, b081:b128_rc, pmCnd:1 );
                    ULogical_Node DesN = new( noB9:1<<no2, b081:b128_rc, pmCnd:0 );

                    eNW_Link_IntraCell R = new( UC, OrgN, DesN );
                    Set_eGLink( R, debugPrint, IntraCell_List );							// Strong link

                    if( UC.FreeBC==2 ){
                        ULogical_Node OrgN2 = new( noB9:1<<no1, b081:b128_rc, pmCnd:0 );
                        ULogical_Node DesN2 = new( noB9:1<<no2, b081:b128_rc, pmCnd:1 );

                        eNW_Link_IntraCell R2 = new( UC, OrgN2, DesN2 );					// Binary Weak link
                        Set_eGLink( R2, debugPrint, IntraCell_List );
                    }
                }
            }
            if(debugPrint)  IntraCell_List.ForEach( P => WriteLine(P) );
            eNW_Link_List.AddRange(IntraCell_List);

            return IntraCell_List.Count;
        }



        // *--*--*--*--*--*--*--*
        //  eNW_Link_InterCells
        // *--*--*--*--*--*--*--*
        private int QGenerator_eNW_InterCells( bool debugPrint=true ){ 
			//	WriteLine( $"========= {++eNdebug} QGenerator_eNW_InterCells" );

            List<eNW_Link> InterCell_List = new(); 
			foreach( int no in Enumerable.Range(0,9) ){
				int noB = 1<<no;
                UInt128 BD_Free_no = BOARD_Free81B9[no];	//Board_BitRep[no];
						//WriteLine( $"#{no+1} BD_Free_no:{BD_Free_no.ToBitString81N()}" );//###

                int BD_no_rcbFrame = BD_Free_no.Ceate_rcbFrameOr();
                foreach( int h in BD_no_rcbFrame.IEGet_BtoHouse27() ){
						//WriteLine( $"--- h:{h}" );

                    UInt128 BD_Free_no_h = BD_Free_no & HouseCells81[h];
                    if( BD_Free_no_h.BitCount() < 2 )  continue;

                    foreach( var U1 in BD_Free_no_h.IEGet_rc128(mx:81) ){
                        ULogical_Node OrgNp = new( noB9:noB, b081:U1, pmCnd:1 );
										//WriteLine( $"QGenerator_eNW_InterCells OrgNp:{OrgNp}" );

                        UInt128 U2 = BD_Free_no_h & ~U1;
                        int szU2 = U2.BitCount();
                        foreach( var U2A in IE_UInt128_Combination(U2,1,szU2) ){ 
                            ULogical_Node DesNp = new( noB9:noB, b081:U2A, pmCnd:0 );
										//WriteLine( $"QGenerator_eNW_InterCells DesNp:{DesNp}" );

                            var Rp = new eNW_Link_InterCells( OrgNp, DesNp, h ); //R:+ -> -
										//WriteLine( $"QGenerator_eNW_InterCells Rp:{Rp}" );

                            Set_eGLink( Rp, debugPrint, InterCell_List  );						// Strong Link
                        }

						{// If all cells in U1 are negative, then U2 will be positive.
							ULogical_Node OrgNm = new( noB9:noB, b081:U1, pmCnd:0 );
							ULogical_Node DesNm = new( noB9:noB, b081:U2, pmCnd:1 );
							var Rm = new eNW_Link_InterCells( OrgNm, DesNm, h );				//  Weak Link  R:- -> +
											//WriteLine( $"QGenerator_eNW_InterCells Rm:{Rm}" );
							Set_eGLink( Rm, debugPrint, InterCell_List  );
						}
                    }
                }
            }
			    // InterCell_List.Sort( (a,b) => ((a.OrgN.rc*10+a.OrgN.no) - (b.OrgN.rc*10+b.OrgN.no) ) );
                // InterCell_List.ForEach( P =>WriteLine( $"{P}") );

            eNW_Link_List.AddRange(InterCell_List);
            return InterCell_List.Count; 
        }
    }
}
                        