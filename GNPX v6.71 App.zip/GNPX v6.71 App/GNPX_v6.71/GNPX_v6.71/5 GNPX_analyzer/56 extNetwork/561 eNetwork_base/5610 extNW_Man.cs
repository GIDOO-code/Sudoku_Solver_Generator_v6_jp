using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Windows.Documents;
using System.Diagnostics;

namespace GNPX_space {

    public partial class eNW_Man: ALSLinkMan{   
	    static private readonly UInt128 qZero  = UInt128.Zero;
        static private readonly UInt128 qOne   = UInt128.One;
        static private readonly UInt128 _filter_b081 = (UInt128.One<<81)-1;  //b081    0 -  80 (81)

//        static public  UInt128[] Board_BitRep;
        static public List<eNW_Link> eNW_Link_List;
        static public List<eNW_Node> eNW_NodeList = new();

		static public eNW_Node Get_NodeRef( ULogical_Node ULG ) => eNW_NodeList.Find(p => p.matchKey2==ULG.matchKey2);


		static public int Get_NodeRef_Index( eNW_Node eN ) => Get_NodeRef_Index(eN as ULogical_Node);  //.ULGNode);
		static public int Get_NodeRef_Index( ULogical_Node ULG ) => eNW_NodeList.FindIndex(p => p.matchKey2==ULG.matchKey2);


        private Queue<eNW_Node> QSearchQue = new();

        private Dictionary<UInt128,int> DefinedNodes = new();

        private int bpTNO(int no, int pmCnd) => 1<< (pmCnd+no*2);
        //==============================
        private bool debugPrint=false;  //true;
        //------------------------------


		// ===== Constructor =====
        public eNW_Man( GNPX_AnalyzerMan pAnMan ): base(pAnMan){
            eNW_Link.pAnMan = pAnMan;
            eNW_Node.pAnMan = pAnMan;
        }

		



		private int /*Generat_Priority*/ GenPRI( int priority ) => priority<<16 | (priority000++);

        private int IsConnected_withRCC( UAnLS UA, UAnLS UA2, int without_X=-1 ){
            int nRCC=0, RCC_BitExp=0;
					//WriteLine( $" UA:{UA}\nUA2:{UA2}" );

			int  FreeBX = (without_X>0)? without_X: (UA.FreeB_SP & UA2.FreeB_SP);
            foreach( var no in FreeBX.IEGet_BtoNo() ){  
				int rcbB = UA.rcbAnd9_wk(no) & UA2.rcbAnd9_wk(no);
				bool RCC1 = (rcbB&0x1FF).BitCount()==1 || ((rcbB>>9)&0x1FF).BitCount()==1 || ((rcbB>>18)&0x1FF).BitCount()==1;

                if( !RCC1 )  continue;
					//WriteLine( $"          rcbB:{rcbB.rcbToBitString27()}" );
                nRCC++;
                RCC_BitExp |= (1<<no); 
            }
            return RCC_BitExp;
        }
		
	// NWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNWNW

		public List<eNW_Link> Get_eNW_OrgToChain( eNW_Node eNX ){
			if( eNX.eChaineNtwk_pre_Minus!=null && eNX.eChaineNtwk_pre_Plus!=null ){
				var (_,eNListM) = Get_eNW_OrgToChain( eNX, pmCnd:0 );      // pmCnd:0   
				var (_,eNListP) = Get_eNW_OrgToChain( eNX, pmCnd:1 );      // pmCnd:1 

				var stLM=eNW_ToStringB(eNListM); stLM=eNW_ToStringB(eNListM);  // ..B..
				var stLP=eNW_ToStringA(eNListP); stLP=eNW_ToStringA(eNListP);  // ..A..
					//WriteLine( $"\n...stLM:{stLM}\n...stLP:{stLP}" );
					//WriteLine( $">>>... Get_eNW_OrgToChain usage error." );
			}
			else{
				var (_,eNetList) = Get_eNW_OrgToChain( eNX, pmCnd:1 );
				return eNetList;
			}
			return null;
		}

		public List<eNW_Link> Get_eNW_OrgToChain( ULogical_Node LG0 ){
            List<eNW_Link> eNetList=null;
            ULogical_Node LGX = LG0;

		  //eNW_Node eNX = eNW_Man.eNW_NodeList.Find(p => p.matchKey2==LG0.matchKey2);
			eNW_Node eNX = eNW_Man.Get_NodeRef(LG0);
            int loopC=0;
            while( LGX!=null && (++loopC)<18 ){
				eNW_Link eL = (LGX.pmCnd==0)? eNX.eChaineNtwk_pre_Minus: eNX.eChaineNtwk_pre_Plus;
//              eNW_Link eL = LGX.eChaineNtwk_pre_Plus ?? LGX.eChaineNtwk_pre_Minus;
                if( eL == null ) break;
                if( eNetList is null ) eNetList = new();
                eNetList.Add(eL);
                LGX = eL.eN_Org_nPM;

//                if( (LGX is null) || (eN0 is null) ){ WriteLine( $"LGX:{LGX}  eN0:{eN0}" ); break; }
                if( LGX.LGN_key3 == LG0.LGN_key3 )  break;
            }
            if( eNetList!=null ) eNetList.Reverse();
            return eNetList;
        }


        public (int,List<eNW_Link>) Get_eNW_OrgToChain( eNW_Node eN0, int pmCnd ){
            List<eNW_Link> eNetList = new();
            eNW_Node  eNX = eN0;

            int  hashValue=0, loopC=0, pm=pmCnd, badX=0;
            while( eNX!=null & (++loopC)<20 ){   
                eNW_Link eLX = (pm==0)? eNX.eChaineNtwk_pre_Minus: eNX.eChaineNtwk_pre_Plus;        
                if( eLX is null )  break;
                hashValue |= (badX=eLX.hv ^ _hushBase[eLX.ID%8191]);//2-1]);
                eNetList.Add(eLX);
                if( badX==-1 )  WriteLine( $"badX:{badX}" );
                if( eLX. Sentinel ) break;

                eNX = eLX.eN_Org_nPM;
                if( eNX. Sentinel ) break;
                pm  = eLX.OrgN.pmCnd;
                if( eNX==null || eNX.matchKey2==eN0.matchKey2)  break;
            }
            if( eNetList!=null ) eNetList.Reverse();
            return (hashValue,eNetList);
        } 


// ---------------------------------------------------------------------------------------------
        public string  eNWMan_DisplayNetworkPath( eNW_Link eLX, bool lineType=true, bool debugBPM=false ){
            eNW_Node eNX = eLX.eN_Des_nPM;
			string st = eNWMan_DisplayNetworkPath( eNX, lineType, debugBPM );
			return  st;
		}

        public string  eNWMan_DisplayNetworkPath( eNW_Node eNX, bool lineType=true, bool debugBPM=false ){
			if( eNX.eChaineNtwk_pre_Minus==null && eNX.eChaineNtwk_pre_Plus==null ){
				ULogical_Node ULG = new ULogical_Node( no:eNX.no, rc:eNX.rc, pmCnd:0);	
			  //eNX = eNW_Man.eNW_NodeList.Find(p => p.matchKey2==ULG.matchKey2);
				eNX = eNW_Man.Get_NodeRef(ULG);
			}

			var (_,eNListM) = Get_eNW_OrgToChain( eNX, pmCnd:0 );      // pmCnd:0   
            var (_,eNListP) = Get_eNW_OrgToChain( eNX, pmCnd:1 );      // pmCnd:1 

			string st="", stLM="", stLP="";
			if(lineType){ stLM=eNW_ToStringB(eNListM); stLP=eNW_ToStringB(eNListP); }  // ..B..
			else{         stLM=eNW_ToStringA(eNListM); stLP=eNW_ToStringA(eNListP); }  // ..A..

			 int spN=5;
			if(debugBPM){ st=$"{new string(' ',spN)}@ ---> --M-- : {stLM}\n{new string(' ',spN)}@ ---> ++P++ : {stLP}"; }
			else{ 		  st = $"{stLM}\n{stLP}";	}

            if(debugBPM) WriteLine( st );
			return st;
		}


		private IEnumerable<UInt128> IE_UInt128_Combination( UInt128 basicH, int szStart, int szMax=6, bool debugPrint=false ){ 
			// Generates combinations of only elements of the same House.

			int szH = basicH.BitCount();
			if( szH == 1 ){ yield return basicH; }
			else{
				int szMaxA = Min( szH, szMax);
				for( int sz=szStart; sz<=szMaxA; sz++ ){
					Combination_81B cmb = new( szH, sz, basicH);
					while( cmb.Successor() )  yield return cmb.valueBT;
				} 
			}
			yield break;
        }  

    }
}

                        