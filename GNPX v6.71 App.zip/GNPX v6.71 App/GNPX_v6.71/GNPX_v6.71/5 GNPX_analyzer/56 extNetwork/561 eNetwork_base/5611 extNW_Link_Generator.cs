using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Threading.Channels;
using System.Windows.Documents;
using System.Xml.Linq;
using System.IO;
using System.Text;

namespace GNPX_space {

    public partial class eNW_Man: ALSLinkMan{       

		public int QGenerator_Link_Man( bool checkPrintB ){
						//WriteLine( $"========== {++eNdebug} QSearch_Links" );

            eNW_Link_List = new();
						//debugPrint = true;

            if( G6.Cell ){
                QGenerator_eNW_IntraCell( debugPrint:debugPrint );
                QGenerator_eNW_InterCells( debugPrint:debugPrint );
            }
            if( G6.AIC ) QGenerator_eNW_AIC_Link( debugPrint:debugPrint );

            if( G6.ALS ){			
				//QGenerator_eNW_ModificationALS_practice( debugPrint:debugPrint );   // Rejected

				if( G6.eALS )  QGenerator_eNW_ModificationALS( debugPrint:debugPrint );

				if( G6.ALSXZ ) QGenerator_eNW_ALSXZ_Link( debugPrint:debugPrint );	
						//if( G6.AnLS"] )  QSearch_AnLS_eLinks( debugPrint:debugPrint );	 //Next development goal


			}
			eNW_Link_List = eNW_Link_List.DistinctBy( p=> p.hv ).ToList();

            if(checkPrintB){
                var query = eNW_Link_List.GroupBy(x => x.OrgN.LGN_key3);
                foreach( var group in query ){
                    foreach( var P in group ) WriteLine( P.ToString() );
                }
            }
            return eNW_Link_List.Count;
                      //eNW_Link.Set_withID_(withID:false);   // ... for debug
        }


        private void Set_eGLink( eNW_Link R, bool debugPrint, List<eNW_Link> QList ){
            if( QList.Find(r=> r.keySt==R.keySt) is null )  QList.Add(R);
					//if( debugPrint )  WriteLine( R );
        }


		private IEnumerable<ULogical_Node> Generate_ULG_by_Combination( int no, UInt128 ULGbase81, int pmCnd, int hNo ){
			int sz = ULGbase81.BitCount();
				
			List<ULogical_Node> LogNDs = new();
			for( int n=1; n<=sz; n++ ){
				Combination_81B cmb = new( sz, n, ULGbase81 );
				while( cmb.Successor() ){
					ULogical_Node LogND = new( noB9:1<<no, b081:cmb.valueBT, pmCnd:pmCnd, hNo:hNo);
					LogNDs.Add(LogND);
				}
			}
			LogNDs = LogNDs.DistinctBy(p=>p.LGN_key3).ToList();  //keys: no, b081, pmCnd (not include ID)

			foreach( ULogical_Node ULG in LogNDs )  yield return ULG;
			yield break;
		}
    }
}
                        