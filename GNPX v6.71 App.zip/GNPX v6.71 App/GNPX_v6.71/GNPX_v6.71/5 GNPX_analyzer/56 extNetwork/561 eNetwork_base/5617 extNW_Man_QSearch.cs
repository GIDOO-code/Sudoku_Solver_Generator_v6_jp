using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Windows.Shapes;
using System.Net;
using System.Runtime.CompilerServices;

namespace GNPX_space {

    public partial class eNW_Man: ALSLinkMan{         
        static public int[]  _hushBase = new int[8192]; 
		static eNW_Man(){
			// The initial value of the random number is fixed.
			// ->  The same random number is always used.
			// ->  Reproducibility is maintained even when debugging.
			Random _rnd_ = new Random(1);
			for( int k=0; k<_hushBase.Length; k++ )  _hushBase[k] = _rnd_.Next();
		}

        private int   debugCCX = 0;
        public int[]  eNW_pmCnd;





        public (bool,int) Set_Upstream_Link_Information_OnNode( eNW_Link eLX, bool debugPrint=false ){
            int _Func_pmCndNo( int pmCnd, int no ) => 1<< (pmCnd+no*2);
            
			eNW_Node eN = eLX.eN_Des_nPM; //eNW_Man.Get_NodeRef(eLX.eN_Des_nPM);
			if( eN==null )  return (false,0);		
            int eN_Index  = eNW_Man.Get_NodeRef_Index(eLX.eN_Des_nPM);

			bool rcIsOne = eN.b081.BitCount()==1;
			int  rc = eN.rc;
			int  no = eN.no;
			int  pm = eLX.DesN.pmCnd;

            bool settedB = false;
			if( pm==0 && eN.eChaineNtwk_pre_Minus==null ){
				eN.eChaineNtwk_pre_Minus = eLX;		// Set Upstream Link Infomation
				if(rcIsOne) eNW_pmCnd[rc] |= _Func_pmCndNo(0,no);
                    if(debugPrint){
					    if( rc>=0 ){
						    int noXX = (eNW_pmCnd[rc]>>(no*2)) & 0x3;
						    string stX = $"=== {noXX} gn:{eLX.genNo} ===  {((noXX==3)? "*****": "")}" ;
								    WriteLine( $"\n{stX}  {eN.eChaineNtwk_pre_Minus}" );
					    }
                        else{ WriteLine( $"=== 0  gn:{eLX.genNo} ===  {eLX}" ) ; }
                        __Path_Check(eN);
                    }
				settedB=true; 
			}

			if( pm==1 && (eN.eChaineNtwk_pre_Plus==null) ){
				eN.eChaineNtwk_pre_Plus = eLX;		// Set Upstream Link Infomation 
				if(rcIsOne) eNW_pmCnd[rc] |= _Func_pmCndNo(1,no);  
                        if(debugPrint){
					        if( rc>=0 ){
						        int noXX = (eNW_pmCnd[rc]>>(no*2)) & 0x3;
						        string stX = $"=== {noXX} gn:{eLX.genNo}  ===  {((noXX==3)? "*****": "")}" ;
								        WriteLine( $"\n{stX}  {eN.eChaineNtwk_pre_Plus}" );
					        }
                            else{ WriteLine( $"=== 1  gn:{eLX.genNo} ===  {eLX}" ) ; }
                            __Path_Check(eN);		
                        }
				settedB=true; 
			}
			var node_Status = 0;
			if( rcIsOne )  node_Status = (eNW_pmCnd[rc]>>(no*2)) & 0x3;

            return  (settedB, node_Status);		

                void __Path_Check( eNW_Node eN ){
                        string pmString(int X) => (X==0)? "-->": "++>";
                        for( int pmX=0; pmX<2; pmX++ ){  
                            var (hv,eNetListX) = Get_eNW_OrgToChain( eN, pmCnd:pmX );
                            WriteLine( $" {pmString(pmX)} {eNW_ToStringB( eNetListX, debugPrint:debugPrint)}" );
                        }

                }

        }




        private eNW_Node Is_Contradiction( eNW_Link eL, bool debugPrint=false ){        
            eNW_Node eNdes = eL.eN_Des_nPM;

            foreach( var rc in eNdes.b081.IEGet_rc(81) ){
                UCell  U = pBOARD[rc]; 
                int pmCnd_rc9B = eNW_pmCnd[U.rc];
                if( pmCnd_rc9B == 0 )  continue;

				// ... contradiction ...
				foreach( int no in U.FreeB.IEGet_BtoNo() ){ 
                    int tfFlag = (pmCnd_rc9B>>(no*2))&3;
                    if(tfFlag==3){
								if( debugPrint ){
									WriteLine( pmCnd_rc9B.ToBitString(18) );
									for( int pm=0; pm<2; pm++ ){
										ULogical_Node ULG = new ULogical_Node( no:no, rc:rc, pmCnd:pm);	
										var eNX = eNW_Man.Get_NodeRef(ULG);
										var (hv,_eNList) = Get_eNW_OrgToChain( eNX, pmCnd:pm );                            
										if( _eNList==null || _eNList.Count<=0 )  continue;

										WriteLine( eNW_ToStringB(_eNList, debugPrint:true) );
										DebugPrint_preLink( eNX );
									}		
								}
						return eNdes;
                    }
                }
            }
            return null;  // >=0 : Contradiction
                  
                    void DebugPrint_preLink( eNW_Node eN2 ){
                        string stX = $"-->>> CheckAndSet_Node/DebugPrint"; 
                        stX += "   M:" + ((eN2.eChaineNtwk_pre_Minus!=null)? eN2.eChaineNtwk_pre_Minus.ToString(): "@@@@@@null");
                        stX += "   P:" + ((eN2.eChaineNtwk_pre_Plus!=null)?  eN2.eChaineNtwk_pre_Plus.ToString():  "@@@@@@null");         
                        WriteLine( stX ); 
                    }
        }
  


		private string eNW_ToStringA( List<eNW_Link> extNW ){
            string st = "";
            if( extNW is null )  return st;
            bool ft=true; // Only at first true.
            extNW.ForEach( L => {
                string st2 = L.ToString2(ft); ft=false;
                st += "\n"+ st2;
            } ); 
            return  st;
        }



        public string eNW_ToStringB( List<eNW_Link> extNWList, bool debugPrint=true ){
            string st = "";
            if( extNWList is null )  return st;
            bool ft=true; // Only at first true.
            extNWList.ForEach( L => {
                string st2 = L.ToString2B(ft); ft=false;
                st += st2;
            } ); 
            if( st=="" )  st = " (null)";
            else{
				var DesN = extNWList.Last().DesN;
				if( DesN == null ){ st += " ... ?????";  WriteLine(st); }
            }
            return  st;
        }


    }
}
                        