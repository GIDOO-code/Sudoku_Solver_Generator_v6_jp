using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space {
       
    [Serializable]

    public partial class eNW_Man: ALSLinkMan{       

		//  SUBset_Modification
		//   The "+" element modifies ALS. Check the changes using FreeB_SP.

		// @ Preparation. Copy FreeB => FreeB_SP ----------------------------
		public void  SUBset_Modification_initialSetting( USubset qSUB, int no, bool debugPrint=false ){
			int noB = 1<<no;
			qSUB.UCellList.ForEach( U => U.FreeB_SP = U.FreeB & ~noB );
						if(debugPrint) WriteLine( $"SUBset_Modification_initialSetting  no:#{no+1}\n{qSUB}" );
		}

		public void  SUBset_Modification_initialSetting_house( USubset qSUB, int no, UInt128 h81, bool debugPrint=false ){
			int noB = 1<<no;
						if(debugPrint) WriteLine( $"\nSUBset_Modification_initialSetting_house no:#{no+1} ... Before{qSUB}" );
			foreach( var U in qSUB.UCellList ) U.FreeB_SP =  h81.IsHit(U.rc)? (U.FreeB & ~noB): U.FreeB;	
						if(debugPrint) WriteLine( $"\nSUBset_Modification_initialSetting_house no:#{no+1} ... After{qSUB}" );
		}




		// @ Reconfigure Manager ----------------------------
		public bool  SUBset_Modification( USubset qSUB, int no, bool debugPrint=false ){ 

			int HashValue_FreeB_SP(USubset Q) => Q.UCellList. Aggregate( 0, (a,u) => a^ ((u.rc<<9) | u.FreeB_SP).GetHashCode() );

					if(debugPrint) WriteLine( $"SUBset_Modification  no:#{no+1}  {qSUB.ToString_Free_SP()}" );

			int  sz=qSUB.CellSize, noB=1<<no;
			int  hv0=HashValue_FreeB_SP( qSUB ), hv1=int.MaxValue;


			int changeCC = 0;
			while(hv0!=hv1){
				if(hv1!=int.MaxValue )  hv0 = hv1;

				// LastDigit is not useful for ALS modification.	
				_NakedSingle( qSUB );
				HiddenSingle( qSUB );
				_LockedSet( qSUB );

				hv1 = HashValue_FreeB_SP( qSUB );
				changeCC++;
			}
					if(debugPrint)  WriteLine( qSUB );

			return (changeCC>1);


					void _NakedSingle( USubset qSUB ){
						UInt128 solBit = qSUB.UCellList.Where( U=> (U.FreeB_SP).BitCount()==1) .Aggregate(qZero, (a,u)=> a| qOne<<u.rc);
						if( solBit != qZero ){
							foreach( var uc in solBit.IEGet_UCell(pBOARD) ){
								int noB = uc.FreeB_SP;
								foreach( var P in (qSUB.b081&~solBit).IEGet_UCell(pBOARD) ){ P.FreeB_SP &= ~noB; }
							}
						}
					}


					void HiddenSingle( USubset qSUB ){
						var (one_noB,_) = qSUB.b081.Get_FreeB_Single_More();
						foreach( int no in one_noB.IEGet_BtoNo() ){
							int noB = 1<<no;
							foreach( UCell U in qSUB.UCellList.Where(u=>(u.FreeB_SP&noB)!=0) )  U.FreeB_SP = noB;
						}
					}


					void _LockedSet( USubset qSUB ){
						int  sz = qSUB.CellSize;
						foreach( var u128_ALS in __Func_Combination( qSUB.b081, sz, 2 ,sz-1 ) ){ // Elements is 2 or more, and pure subset.
							int FreeB_Sel = u128_ALS.IEGet_UCell(pBOARD) .Aggregate( 0, (a,uc) => a | uc.FreeB_SP );
							if( FreeB_Sel.BitCount() != u128_ALS.BitCount() )  continue;
							// The number of cells and the number of candidate digits are the same. _LockedSet occurred within ALS.

							UInt128 Cells_Another = qSUB.b081 & ~u128_ALS;
							foreach( var P in Cells_Another.IEGet_UCell(pBOARD) )  P.FreeB_SP &= ~FreeB_Sel;
						}
								IEnumerable<UInt128> __Func_Combination( UInt128 u128_ALS, int sz, int szStart, int szEnd ){  
									for( int nSZ=szStart; nSZ<=szEnd; nSZ++ ){
										Combination_81B cmb = new( sz, nSZ, u128_ALS );
										while( cmb.Successor() ){ yield return cmb.valueBT; }
									} 
									yield break;
								}
					}
		}
	}
}
                    