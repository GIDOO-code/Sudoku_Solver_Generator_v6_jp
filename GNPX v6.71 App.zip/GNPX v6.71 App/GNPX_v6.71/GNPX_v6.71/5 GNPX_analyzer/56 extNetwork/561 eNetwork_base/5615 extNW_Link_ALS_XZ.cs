using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Threading.Channels;
using System.Windows.Documents;
using System.Xml.Linq;
using System.IO;
using System.Text;

namespace GNPX_space {

    public partial class eNW_Man: ALSLinkMan{       

		//1..89..4.8..21...7...7.59813154.9..8.8.5..41...41.8395..1382.646.89..1...236.18.9  for develop

        // *--*--*--*--*--*--*--*
        //  eNW_Link_ALSXZ
        // *--*--*--*--*--*--*--*

        private int QGenerator_eNW_ALSXZ_Link(  bool debugPrint=false ){

            Prepare_ALSLink_Man( ALS_plus:2, setCondInfo:true, debugPrint:false );         
            if( ALSList is null || ALSList.Count<=1)  return 0;     //AALSList: Almost ALS
					//ALSList.ForEach( (p,mx) => WriteLine( $"{mx}: {p.ToStringA()}" ) );

			List<eNW_Link >  DL_ALSXZ_List = new();
			foreach( var (UA,UA2,RCC) in _IE_Select_UA_UA2(ALSList) ){
				if( UA2 == null )  continue;
				UInt128 UA_UA2 = UA.b081 | UA2.b081;
				ULogical_Node ULGalsxz = new( noB9:(UA.FreeB|UA2.FreeB), b081:(UA.b081|UA2.b081) );	

					//if( UA.b081.TBScmp()=="r1258c6" && UA2.b081.TBScmp()=="r9c1689" )  debugPrint=true;

				// Get Origin Node
				foreach( var ULG_OrgList in IE_Get_Origin_no_h(UA, UA2, RCC) ){
							if(debugPrint) ULG_OrgList.ForEach( P =>
									WriteLine($"\n\n\n@@@@@@@ \n  UA: {UA.ToString_Free_SP()}\n  UA2 {UA2.ToString_Free_SP()}\n----- ULG_OrgList:{P}") ); 
					
					int noOrgB = 1<<ULG_OrgList[0].no;	
					// RCC and noOrg are not candidates for the terminal node's digits.
					foreach( var ULG_DesList in _IE_Get_Destination_no_h( UA, UA2, (RCC | noOrgB) ) ){
							if(debugPrint) ULG_DesList.ForEach( P =>WriteLine($"+++++ ULG_DesList:{P}") );

						// === Generate Links ===
						foreach( var ULGorg in ULG_OrgList ){
							foreach( var ULGdes in ULG_DesList.Where(p=>(ULGorg.b081&p.b081)==0) ){
								eNW_Link_ALSXZ R = new( UA, UA2,RCC, OrgN:ULGorg, DesN:ULGdes, ULGdes.hno );
								Set_eGLink( R, debugPrint, DL_ALSXZ_List );
									//if(debugPrint)  WriteLine( R );
							}
						}
					}
				}

				//DL_ALSXZ_List.ForEach( (P,mx) => WriteLine( $"{mx}:{P}" ) );
			}
			eNW_Link_List.AddRange(DL_ALSXZ_List);
			return eNW_Link_List.Count;

						IEnumerable< (UAnLS,UAnLS,int) >  _IE_Select_UA_UA2( List<UAnLS> ALSList ){
							foreach( var UA in ALSList.Where(p=>p.CellSize>=2 && p.Level==1) ){
								foreach( var UA2 in ALSList.Where( p=> p.ID>UA.ID && p.CellSize>=3 && p.Level==2)){	//The ALSList is sorted by Level.
									if( (UA.b081 & UA2.b081) > qOne )        continue;  // overlaps�@
									if( (UA.connectedB81 & UA2.b081) == qZero )	 continue;  // no contact		

									int RCC = Get_AlsAlsRcc(UA,UA2);
									if( RCC.BitCount() != 2 )  continue;
									
									yield return (UA,UA2,RCC);
								}
							}
							yield break;
						}

						IEnumerable< List<ULogical_Node> >?  IE_Get_Origin_no_h( UAnLS UA, UAnLS UA2, int RCC ){
							// Find an external element that changes UA2(class:A2LS) to ALS.

							UInt128 b81_UA_UA2 = UA.b081 | UA2.b081;
							int FreeB_Org_cand = UA2.FreeB & ~RCC;							// RCC is excluded from the search digits.
							
							List<ULogical_Node>? ULG_OrgList=null;
							foreach( int noOrg in FreeB_Org_cand.IEGet_BtoNo() ){ 
								int frame_UA2 = UA2.b081B9[noOrg].Ceate_rcbFrameAnd();		// ... And Search
								if( frame_UA2 == 0 ) continue;

								foreach( int hOrg in frame_UA2.IEGet_BtoHouse27() ){
									UInt128 b81_House = BOARD_Free81B9[noOrg] & HouseCells81[hOrg];

									// Due to [noOrg,hOrg], A2LS changes to ALS, and [UA.UA2] becomes LockedSet.
									UInt128 b81_Org_In  = b81_House & ~b81_UA_UA2;
									if( b81_Org_In == qZero ) continue;

									ULG_OrgList = Generate_ULG_by_Combination( noOrg, b81_Org_In, pmCnd:1, hNo:hOrg).ToList();
									if( ULG_OrgList == null ) continue;

									yield return ULG_OrgList;
								}
							}
							yield break;
						}

						IEnumerable< List<ULogical_Node> >  _IE_Get_Destination_no_h( UAnLS UA, UAnLS UA2, int RCC_noOrgB ){				
							UInt128 UA_UA2 = UA.b081 | UA2.b081;
							int FreeB_Des_cand = (UA.FreeB | UA2.FreeB) & ~RCC_noOrgB;					// Candidate digits for UA and UA2
							UInt128 b81_UA_UA2 = UA.b081 | UA2.b081;					// UA UA2 internal bit

							List<ULogical_Node> ULG_DesList = null;
							foreach( int noDes in FreeB_Des_cand.IEGet_BtoNo() ){				// Focus on node noDes
								UInt128 b81_no_DesCand = BOARD_Free81B9[noDes] & b81_UA_UA2;	// Elements within "UA |UA2"

								int frame_Ua_UA2 = b81_no_DesCand.Ceate_rcbFrameAnd();			// 
								if( frame_Ua_UA2 == 0 ) continue;

								foreach( int hDes in frame_Ua_UA2.IEGet_BtoHouse27() ){
									UInt128 b81_noDes_hDes = b81_no_DesCand & HouseCells81[hDes];
									if( b81_noDes_hDes == qZero ) continue;

									// -----------------------------------------------------------------------------------------
									// --- inner of ALSXZ ---
									UInt128 B81_h_inner = BOARD_Free81B9[noDes] & UA_UA2;
									if( B81_h_inner > qZero ){
										if( ULG_DesList == null )  ULG_DesList = new();
										ULG_DesList.Add( new ULogical_Node(1<<noDes, B81_h_inner, pmCnd:1, hNo:hDes) );
									}

									// --- Outer of ALSXZ ---
									UInt128 B81_h_outer = BOARD_Free81B9[noDes] & HouseCells81[hDes] & ~UA_UA2;
									if( B81_h_outer > qZero ){
										if( ULG_DesList == null )  ULG_DesList = new();
										ULG_DesList.AddRange( Generate_ULG_by_Combination( noDes, B81_h_outer, pmCnd:0,hNo:hDes).ToList() );
									}
								}
							}
							if( ULG_DesList != null )	yield return ULG_DesList;
							yield break;
						}
		}


	}
}