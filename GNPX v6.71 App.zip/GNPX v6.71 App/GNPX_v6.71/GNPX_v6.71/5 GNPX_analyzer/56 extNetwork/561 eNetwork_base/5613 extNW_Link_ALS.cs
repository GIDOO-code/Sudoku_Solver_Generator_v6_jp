using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space {
        
	//Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/       
    //6.14..5.7.3.7..4..9..35.....6..1.3.415.....688.4.3..1.....94..2..2..3.4.4.6..21.3

    public partial class eNW_Man: ALSLinkMan{       

        // *--*--*--*--*--*--*--*
        //  eNW_Link_ALS
        // *--*--*--*--*--*--*--*

        private int QGenerator_eNW_ModificationALS( bool debugPrint=false ){
            Prepare_ALSLink_Man( ALS_plus:1, setCondInfo:true, debugPrint:false );         
            if( ALSList is null ) return 0;     //AALSList: Almost ALS

            List<eNW_Link> qALS_List = new();

			foreach( var qALS in ALSList.Where(p=> p.Level==1 && p.CellSize>=4) ){

				foreach( var noOrg in qALS.FreeB.IEGet_BtoNo(9) ){
					int noOrgB = 1<<noOrg;
					UInt128 cand81 = BOARD_Free81B9[noOrg] & ~qALS.b081;                        // Candidates excluding the ALS region

					{ //SUBset_Modification
					  SUBset_Modification_initialSetting( qALS, noOrg );
					  bool modified =   SUBset_Modification( qALS, noOrg, debugPrint:debugPrint );
					  if( !modified )  continue;
					}

					// === Origin ===
					List<ULogical_Node> ULG_OrgList = _Generate__ULG_OrgList( qALS, noOrg, cand81, debugPrint:debugPrint );	
					if( ULG_OrgList==null || ULG_OrgList.Count==0 )  continue;
					
					// === Destination ===
					List<ULogical_Node> ULG_DesList = _Generate_ULG_DesList(qALS, debugPrint:false);

					foreach( var ULGorg in ULG_OrgList ){
						foreach( var ULGdes in ULG_DesList.Where(p=>(ULGorg.b081&p.b081)==0) ){
							eNW_Link_refALS R = new( qALS, ULGorg, ULGdes, int.MinValue );	
									//house no. is not defined. If use "house no.", it should result in an error.
							Set_eGLink( R, debugPrint, qALS_List );
								if(debugPrint)  WriteLine( R );
						}
					}
				}
			}

			qALS_List = qALS_List.DistinctBy( p=> p.hv ).ToList();
			if(debugPrint) qALS_List.ForEach( (P,kx) => WriteLine( $"eNW_Link_refALS {kx} {P}" ) );

			eNW_Link_List.AddRange(qALS_List);
			return qALS_List.Count();

			// ==============================================================================================
			#region inner_function
				// Origin
				List<ULogical_Node> _Generate__ULG_OrgList( UAnLS qALS, int noOrg, UInt128 cand81, bool debugPrint=false ){
					List<ULogical_Node> ULG_OrgList = new();
					var qALS_rcbAnd9_Org = qALS.rcbAnd9[noOrg];
					if( qALS_rcbAnd9_Org == 0 )  return null;
							//WriteLine( $"qALS_rcbAnd9_Org:{qALS_rcbAnd9_Org.rcbToBitString27()}" );

					foreach( int hOrg in qALS_rcbAnd9_Org.IEGet_BtoHouse27() ){
						UInt128 rc81h = cand81 & HouseCells81[hOrg];
						foreach( var ULG in Generate_ULG_by_Combination(noOrg, rc81h, pmCnd:1, hNo:hOrg) ){
							ULG_OrgList.Add( ULG );
								if(debugPrint)  WriteLine( $" noOrg:#{noOrg+1}  hOrg:{hOrg:00}  origin {ULG}" );
						}
					}
					ULG_OrgList =  ULG_OrgList.DistinctBy(p=> p.LGN_key3).ToList();
								if(debugPrint){
									WriteLine("** ULG_OrgList **");
									ULG_OrgList.ForEach( (p,mx) => WriteLine( $"{mx} {p}" ) );
								}
					return ULG_OrgList;
				}
				// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

				// Termination is (1)within the ALS , (2) outside the ALS
				List<ULogical_Node> _Generate_ULG_DesList( UAnLS qALS, bool debugPrint=false ){
					List<ULogical_Node> ULG_DesList = new();

					// (1p) Targets within ALS-1 positive
					foreach( UCell UC in qALS.UCellList ){												// fixed							
						int noDes = UC.FreeB_SP.BitToNum();		
						if( noDes >= 0 ){
							ULogical_Node URGdes1 = new( no:noDes, rc:UC.rc, pmCnd:1 );
							ULG_DesList.Add( URGdes1 );
								if(debugPrint) WriteLine( $"  -1- URGdes1:{UC}  URGdes1:{URGdes1}" );
						}
					}
							
					// (1n) Targets within ALS-2 negative
					foreach( UCell UC in qALS.UCellList.Where(p=>(p.FreeB & ~(p.FreeB_SP))>0) ){		//canceled
						int noDesB = UC.FreeB & ~UC.FreeB_SP;
						foreach( int noDes in noDesB.IEGet_BtoNo() ){
							ULogical_Node URGdes2 = new( no:noDes, rc:UC.rc, pmCnd:0 );
							ULG_DesList.Add( URGdes2 );
								if(debugPrint) WriteLine( $"  -2- URGdes1:{UC}  URGdes2:{URGdes2}" );
						}

					}
							
					//(2) Targets outside of ALS
					foreach( int noDes in qALS.FreeB_SP.IEGet_BtoNo() ){
						var qALS_rcbAnd9wk_Des = qALS.rcbAnd9_wk(noDes);
						foreach( int hDes in qALS_rcbAnd9wk_Des.IEGet_BtoHouse27() ){
							UInt128 rc81DesOut = (BOARD_Free81B9[noDes] & HouseCells81[hDes]) & ~qALS.b081B9[noDes];
							if( rc81DesOut == 0 ) continue;
							foreach( var ULGdes in Generate_ULG_by_Combination( noDes, rc81DesOut, pmCnd:0, hNo:hDes ) ){
								ULogical_Node URGdes3 = new( noB9:1<<noDes, b081:rc81DesOut, pmCnd:0 );
								ULG_DesList.Add( URGdes3 );
									if(debugPrint) WriteLine( $"  -3- noDes:#{noDes+1}  hDes:{hDes:00}  URGdes3:{URGdes3}" );
							}
						}
					}
					ULG_DesList = ULG_DesList.DistinctBy(p=> p.LGN_key3).ToList();
					if(debugPrint){
						WriteLine("** ULG_DesList **");
						ULG_DesList.ForEach( (p,mx) => WriteLine( $"{mx} {p}" ) );
					}
					return ULG_DesList;
				}

			#endregion inner_function
		}

    }
}
                        