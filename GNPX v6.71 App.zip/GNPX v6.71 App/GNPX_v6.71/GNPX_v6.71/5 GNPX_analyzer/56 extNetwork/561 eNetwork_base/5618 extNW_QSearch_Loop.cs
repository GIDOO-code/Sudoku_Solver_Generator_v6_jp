using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Shapes;
using System.Xml.Linq;

using GIDOO_space;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space {
    //using Tuple3 = (int,int,int);

    public partial class eNW_Man: ALSLinkMan{   
        private List<eNW_Link> eNW_Link_List_Cell;


        //* == * == * == * == * == * == * == * == * == * == * == * == * == * == * == * == *
        // Radial loop search algorithm:
        //   The search begins with a link.
        //   Leave a return path(link) to close the loop.
        //* == * == * == * == * == * == * == * == * == * == * == * == * == * == * == * == *
        //


        //  The code is a bit of a mess, and I'd like to clean it up !!!

        public (int,eNW_Link?) extNW_QSearch_Loop( ULogical_Node LGN_start, int rcOrg, bool suspendOnB=false, bool debugPrint=false ){ 
            if( debugPrint )  eNW_Link.Set_withID_(true);    // ... Add an ID to the link display.
            int NLdbg = 0;    // ----- for develop/debug -----
					if(debugPrint)  WriteLine( $"\n======== 00  -->  ULGstart:{LGN_start}" );   // debug



			var eNW_Link_List_Act = eNW_Link_List;			// Select this in the "Solver Options".
            if( (eNW_Link_List_Act is null) || eNW_Link_List_Act.Count<=0 )  return (-1,null);



            //================================================================================================
            // Select the links that connect to the Starting node(LGN_start). These links are inter-cell links.
        
            List<eNW_Link> eN_Links_start =new();
            if( LGN_start.b081.BitCount() == 1 ){
                eN_Links_start = eNW_Link_List_Act.FindAll( L => (L is eNW_Link_InterCells) && (L.OrgN.LGN_key3==LGN_start.LGN_key3) );
                LGN_start.Sentinel = true;                          // Set Node_Sentinel (@@)
            }
            else{
                foreach( UInt128 b081 in LGN_start.b081.IEGet_rc128(mx:81) ){
                    ULogical_Node LGN = new(LGN_start);
                    LGN.b081 = b081;
                    var eN_Links_startM = eNW_Link_List_Act.FindAll( L => (L is eNW_Link_InterCells) && (L.OrgN.LGN_key3==LGN.LGN_key3) );
                    eN_Links_startM.ForEach( P=> P.Sentinel=true ); // Set Node_Sentinel (@@)
                    eN_Links_start.AddRange( eN_Links_startM );
                }
            }



            if( eN_Links_start.Count<=0 )  return (-1,null); 
			if( LGN_start.pmCnd==0 && eN_Links_start.Count>=2 )  return (-1,null);
					if(debugPrint)  eN_Links_start.ForEach( (P,mx) => WriteLine( $" First link eN_Links[{mx}]: {P}" ) );

            int solType=0; 
            eNW_Link eL_tail = null;
            foreach( var firstLink in eN_Links_start ){       // The First Link is not eNW_Link_IntraCell.
                   if(debugPrint)  WriteLine( $"   === ===@1 firstLink:{firstLink}" );      // debug

              // ===== Prepare (Parameters that control the search)  =====    
                eNW_NodeList.Clear();
                eNW_pmCnd = new int[81];
	            UInt128    usedPattern = qZero;// LGN_start.b081;// | firstLink.eObject;  ...@@@@@@@@@@@@@@@@@@@@@@@
                var (Queue_Next_Links, UsedLink_List) = _Set_First_Queue_Next_Links( firstLink );
                if( Queue_Next_Links == null )  continue;
                                    if(debugPrint){ 
                                        eNWMan_DisplayNetworkPath( firstLink, debugBPM:true );
    					                WriteLine( $"   firstLink.OrgN.b081:{firstLink.OrgN.b081} {firstLink.OrgN.b081.ToBitString81()}");
        					            WriteLine( $"                  usedPattern:{ usedPattern.TBS()}");
                                    }





              // ===== Search for roop =============================
                   // extNW_QSearch_Loop:
                   //     1) The first link (L0) is an inter-cell link.
                   //     2) The second link (L1) is a link that connects to the end of L0. L1 is not the reverse direction of L0.
                   //     3) Once L0 is determined, the list of L1 candidates is created, and the search begins.
				int  loop = 0;
                while( Queue_Next_Links.Count > 0 ){
						        if(debugPrint){
                                    WriteLine( $"\n\n====== loop:{loop}  Queue_Next_Links.Count:{Queue_Next_Links.Count} ============" );
                                    int kx=0;
                                    var sorted_eLK = Queue_Next_Links.UnorderedItems.OrderBy(x => x.Priority);
                                    foreach( var (eLK,pri) in sorted_eLK) WriteLine( $" Queue_Next_Links[{kx++}] PRI:{pri}: {eLK}" );
                                }

                    eNW_Link eLK_current = Queue_Next_Links.Dequeue();       // Select Link

                    bool settedB = _Post_processing_of_link_management( eLK_current, usedPattern, UsedLink_List );
                    usedPattern |= eLK_current.eObject;   

                    if( settedB is false )  continue;
                      
                    bool IsLoop_= _Evaluation_of_Search_Results( rcOrg, eLK_current );
                    if( IsLoop_ )  return (solType,eL_tail);

                    _Search_for_connected_nodes( eLK_current, Queue_Next_Links,  usedPattern, UsedLink_List );
                }
            }
                            
            eNW_NodeList.Clear();
            eNW_pmCnd = new int[81];
            return (-1,null);

        // ----- inner function ------------------------------------------
                    ( PriorityQueue<eNW_Link,int>, List<int>) _Set_First_Queue_Next_Links( eNW_Link firstLink){
                        // ===== Set the status for the first link. =====
				        firstLink.genNo = 0;
                        Set_Upstream_Link_Information_OnNode( firstLink );		// Initialization is required. @@@@@@@ 
                        List<int> UsedLink_List = new();                        // @ direction insensitive
                        UsedLink_List.Add(firstLink.hv);  //Link hash value, direction insensitive. is not eNW_Link_IntraCell. Exclude the reverse direction of the first link.

                        // Next Link : LGN_start(N) - firstLink(L) - firstLink.DesN(N) - LKX(L)
                        PriorityQueue<eNW_Link,int> Queue_Next_Links = new();
                        int kx = 0;
                        foreach( var eLK in eNW_Link_List_Act.Where( L => L.OrgN.LGN_key3== firstLink.DesN.LGN_key3) ){
                            if( UsedLink_List.Contains(eLK.hv) || (LGN_start.b081 & eLK.DesN.b081)>qZero ) continue;
                            Queue_Next_Links.Enqueue(eLK,GenPRI(eLK.lkCode));
                                if(debugPrint)  WriteLine( $"{kx++}: {eLK}" );
                        }
                        if( Queue_Next_Links.Count<=0 )  return (null,null);
                        return  (Queue_Next_Links, UsedLink_List);
                    }

                    bool _Post_processing_of_link_management( eNW_Link eLK_current, UInt128  usedPattern, List<int> UsedLink_List ){
                        // Post-processing of link management               
                        if( ( usedPattern & eLK_current.eObject) > qZero ) return false;;
                      //  usedPattern |= eLK_current.eObject;   // [Att] Information is not passed outside the function.
                                    if(debugPrint)  WriteLine( $" NLdbg:{NLdbg++}   ==== @2  --> {eLK_current} ---    {eLK_current.GetType()}" );

                        // Excluding used Links(including reverse direction)
                        if( UsedLink_List.Contains(eLK_current.hv) )  return false;;    // Exclude opposite links  ���Ό����֎~���s���S
                        UsedLink_List.Add(eLK_current.hv);

                        // Node states are managed individually. 
                        //  The state of a node is defined by two or more paths, and these paths may be inconsistent.
                        //  Cleared the connection conditions? Is it already registered? => if not, Interrupt.
                        var (settedB,rcnoF) = Set_Upstream_Link_Information_OnNode( eLK_current );	// @@@@@@@@@
                        if( !settedB )  return false;
						            if( debugPrint && rcnoF==3 ){ WriteLine( $"\n\n\n@@@@ contradiction @@@@@\n\n\n" ); }
                        return settedB;
                    }

                    bool _Evaluation_of_Search_Results( int rcOrg, eNW_Link eLK_current ){
                        //  eN -- eLK_current --eN_term ( eNW_Node - eNW_Link - eNW_Node )
                        eNW_Node eN_term = eLK_current.eN_Des_nPM;   // eN_term Link termination node
							    if(debugPrint){
								    WriteLine( $" NLdbg:{NLdbg++}      ==== @3   -->  {eN_term}  ---     {eN_term.GetType()} " );
								    eNWMan_DisplayNetworkPath( eLK_current, debugBPM:true );
							    }

                        // @@@ Contradiction
                        // If there is a conflict (both True/False routes), proceed to the end process. This may also occur during the route.
                        eNW_Node eNcontra  = Is_Contradiction( eLK_current, debugPrint:debugPrint );          
                        if( eNcontra!=null ){		//contradiction.
                            solType = 3;
                            eL_tail = eLK_current; 
                                    if(debugPrint){
								        var (conP,conM) = ToString_ContradictionLinks( eNcontra );
					 			        WriteLine( $"contradiction\n  {conP}\n {conM}" );
					 		        }
                            return true;
                        }

                        int rcSame = Check_same_node_in_upstream(eN_term);
					    if( rcSame != rcOrg  )  return false;

                        // @@@ found loop
                        //  rcOrg: A node specified externally. When this node is reached, the search will be interrupted.
                        if( rcOrg>=0 && eLK_current.DesN.rc==rcOrg ){
							    if(debugPrint){ int nx=0; eNWMan_DisplayNetworkPath( eLK_current, debugBPM:true ); }

                            eL_tail = eLK_current;
                            solType = eLK_current.DesN.pmCnd+1;
                            if( eLK_current.DesN.no!=LGN_start.no ){ // The starting node has been reached.
                                var eL2X = __TerminationProcessing( LGN_start, eLK_current, debugPrint:debugPrint );    //@@@@@@@@@@@
                                if( eL2X != null ){    
                                    var (settedB2,rcnoF2) = Set_Upstream_Link_Information_OnNode( eL2X );			
										    if( debugPrint && rcnoF2==3 ){ WriteLine( $"\n\n\n@@@@ contradiction @@@@@\n\n\n" ); }

                                    solType = eL2X.DesN.pmCnd+1;
                                    eL_tail = eL2X;
                                
                                    if( LGN_start.matchKey2==eL_tail.DesN.matchKey2 && LGN_start.pmCnd!=eL_tail.DesN.pmCnd ){
                                        // An inconsistent state occurred due to the link added in the loop.
                                        solType=3; 
                                            if(debugPrint)  WriteLine( $"\n\ncontradiction LGN_start:{LGN_start}  eL_tail:{eL_tail}" );
                                    }
                                }
                            }
                            return true;
                        } 
                        return false;
                                   
                            int Check_same_node_in_upstream ( eNW_Node tarNode ){
                                // Check if the same node is included upstream.

                                eNW_Node  curNode = tarNode;            // current node
                                UInt128  tarNodeB81 = tarNode.b081;

			                    int loopC = 0;
                                while( curNode!=null && (++loopC)<18 ){
                                    eNW_Link  preLink = curNode.eChaineNtwk_pre_Plus?? curNode.eChaineNtwk_pre_Minus;
                                    if( preLink == null ) return -999;
                                    curNode = preLink.eN_Org_nPM; 
                                    //  if( curNode.rc == rcOrg )  return false;
                                    if( preLink is not eNW_Link_IntraCell ){
                                        if( (curNode.b081 & tarNodeB81) > UInt128.Zero )  return curNode.rc;
                                    }
                                }
                                return -999;
                            } 

                            eNW_Link __TerminationProcessing( ULogical_Node ULGstart, eNW_Link eL, bool debugPrint=false ){
                                ULogical_Node  ULGend = eL.DesN;
                                if( ULGend.pmCnd==0 || pBOARD[ULGend.rc].FreeBC>2 )  return null;
                                    //CheckAndSet_Node( eL, debugPrint:debugPrint );
                                eNW_Link eL2T = eNW_Link_List_Act.Find( q => (q is eNW_Link_IntraCell) && (q.OrgN.LGN_key3==ULGend.LGN_key3) );
                                return eL2T;
                            }
                    }

                    void _Search_for_connected_nodes( eNW_Link eLK_current, PriorityQueue<eNW_Link,int> Queue_Next_Links, UInt128 usedPattern, List<int> UsedLink_List ){
                            // Add the links connecting to the node[eN_term].
	                        var _ConnectedLinks = eNW_Link_List_Act.FindAll( q => __IsConnected(eLK_current,q, usedPattern) );
                            if( _ConnectedLinks.Count==0 )  return;

                            // Consecutive intra_links is prohibited.									
					        bool __added_NextLinks = false;
                            foreach( var eLK2 in _ConnectedLinks ){ 
                                // eNW_Link_IntraCell has a different hash value definition
                                if( UsedLink_List.Contains(eLK2.hv) )  continue;   // Excluding used Links(including reverse direction)
						        if( !__IsExistNextLink(eLK_current) )    continue;      //@@## ___test___
                                if( ( usedPattern & eLK2.eObject) > qZero )  continue;
						        eLK2.genNo = eLK_current.genNo+1;
                                Queue_Next_Links.Enqueue(eLK2,GenPRI(eLK2.lkCode));    //Add next links to list. Exclude used links (reverse direction is also possible).
						        __added_NextLinks = true;
                            }

                            return ;

			                        bool __IsExistNextLink( eNW_Link el ){
				                        int no = el.DesN.no;
				                        int rcb = el.DesN.b081.Ceate_rcbFrameAnd();
				                        if( rcb==0 )  return false;

				                        foreach( int h in rcb.IEGet_BtoHouse27() ){
					                        if( (BOARD_Free81B9[no] & HouseCells81[h]) > UInt128.Zero )  return true;
				                        }
				
				                        return  false;
			                        }
                                    bool __IsConnected( eNW_Link eLpre, eNW_Link eL2, UInt128  usedPattern ){
                                        UInt128 LGN_key3_eLtail = eLpre.DesN.LGN_key3;    // rc,no,pmCnd
                                        bool chk = (LGN_key3_eLtail == eL2.OrgN.LGN_key3);
                                        if( !chk )  return false;
                                        if( (eLpre is eNW_Link_IntraCell) && (eL2 is eNW_Link_IntraCell) )  return false;
                                        if( ( usedPattern&eL2.eObject) > qZero )  return false;
                                        return true;
                                    }
                        }
		}

        public (string,string) ToString_ContradictionLinks( eNW_Node eNX ){//  int rc, int no ){
			string[] stL = new string[2];
            for( int pm=0; pm<=1; pm++ ){
				var ULG = new ULogical_Node( no:eNX.no, rc:eNX.rc, pmCnd:pm);
			  //var eNX0 = eNW_Man.eNW_NodeList.Find( p => p.matchKey2==ULG_matchKey2);
				var eNX0 = eNW_Man.Get_NodeRef(ULG);
                var (_,_eNList) = Get_eNW_OrgToChain( eNX0, pmCnd:pm );
                stL[pm] = eNW_ToStringA(_eNList); 
            }
			return (stL[0],stL[1]);
        }

        public  (string,string,List<eNW_Link>[]) Get_ContradictionLinks_Info( eNW_Node eNX ){
            List<eNW_Link>[]  eNList = new List<eNW_Link>[2];
			string[] stL = new string[2];
            for( int pm=0; pm<=1; pm++ ){
				var ULG = new ULogical_Node( no:eNX.no, rc:eNX.rc, pmCnd:pm);
			  //var eNX0 = eNW_Man.eNW_NodeList.Find( p => p.matchKey2==ULG_matchKey2);
				var eNX0 = eNW_Man.Get_NodeRef(ULG);
                var (_,_eNList) = Get_eNW_OrgToChain( eNX0, pmCnd:pm );
                eNList[pm] = _eNList;
                stL[pm] = eNW_ToStringA(_eNList); 
            }
			return  (stL[0],stL[1],eNList);
        }

    }
}
                        