using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;

#if !f_ULogical_Node

namespace GNPX_space {

    public partial class ULogical_Node: IComparable{   // Logical Unit Element
        static private readonly UInt128 qZero   = UInt128.Zero;
        static private readonly UInt128 qOne    = UInt128.One;


		private UInt128  get_bits( UInt128 num, int start_pos, int width) => (num>>start_pos) & ((qOne<<width)-1);
		private UInt128  set_bits( ref UInt128 num, int start_pos, int width, UInt128 value) => num = num & ~(((qOne<<width)-1)<<start_pos) | ((UInt128)value<<start_pos);


		private UInt128  _LogNode_ = qZero;	//Storage

		public UInt128   b081{   get=>      get_bits(_LogNode_,0,81);   set=> set_bits( ref _LogNode_, 0,81,value); }						//  81 bit
		public int       noB9{   get=> (int)get_bits(_LogNode_,81,9);   set=> set_bits( ref _LogNode_, 81,9,(UInt128)value); } 				//  9 bit
		public int       pmCnd{  get=> (int)get_bits(_LogNode_,90,1);   set=> set_bits( ref _LogNode_, 90,1,(UInt128)value); }				//  1 bit (+:1 -:0)
//		public int       lkType{ get=> (int)get_bits(_LogNode_,91,1);   set=> set_bits( ref _LogNode_, 91,1,(UInt128)value); }				//  1 bit (S:1 W:0)
		public int	     hno{    get=> (int)get_bits(_LogNode_,92,5);   set=> set_bits( ref _LogNode_, 92,5,(UInt128)value); }				//  5 bit (0-26)
		public bool      markTmp{get=> ((int)get_bits(_LogNode_,97,1))==1;   set=> set_bits( ref _LogNode_, 97,1, (value? qOne: qZero) ); }	//  1 bit(set:1 reset:0)
        public bool      selected{ get=> ((int)get_bits(_LogNode_,98,1))==1; set=> set_bits( ref _LogNode_, 98,1, (value? qOne: qZero) ); }	//  1 bit(set:1 reset:0)
					     
		public int       ID{     get=> (int)get_bits( _LogNode_,100,16); set=> set_bits( ref _LogNode_, 100,16,(UInt128)value); }			//  16 bit(0 - 65535)
					     
	
		// : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :
		public bool      Sentinel{ get=> ((int)get_bits(_LogNode_,127,1))==1; set=> set_bits( ref _LogNode_, 127,1, (value? qOne: qZero) ); }// 1 bit(set:1 reset:0)
		// : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :




        public int       rc			=> b081.BitToNum(sz:81);			// rc for 1-cell case, -1 otherwise
		public int       no			=> noB9.BitToNum(sz:9);             // no for 1 digit case.	
        public (int,int) rcno		=> (rc,no);
		public int	     rcbFrame	=> b081.Ceate_rcbFrameOr();			// (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9); }
		public long      rcbnFrame  => ((long)rcbFrame)<<9 | (long)noB9;
					     
        public int       b081Size	=> b081.BitCount();
					     
		public UInt128   matchKey2  => get_bits( _LogNode_,0,90); //	b081, no
		public UInt128   LGN_key3   => b081 | ((UInt128)(no | pmCnd<<9))<<81;	//b081, no, pmCnd
					     
        public string    stTFmark	=> (pmCnd==1)? "+": "-";

		public int       hv			=> eNW_ToString().GetHashCode(); 
					     
		// -----------------------------------------------------------------------------------------------------------

		public ULogical_Node(){ }  // static

		public ULogical_Node( ULogical_Node ULG ){
			this._LogNode_ = ULG._LogNode_;
		}

        public ULogical_Node( int noB9, UInt128 b081, /*int lkType=0,*/ int pmCnd=0, int ID=0, int hNo=-999 ){	// house link
 			this.noB9 = noB9;  	
			this.b081 = b081;

//			this.lkType = lkType;
			this.pmCnd  = pmCnd;
			this.ID = ID;
			
			this.hno  = (hNo!=-999)? hNo: ID;  // and no;
		}
		public ULogical_Node( int no, int rc, int pmCnd, int ID=0, int hNo=-999, bool Sentinel=false ){							// cell link
			this.noB9  = 1<<no;
			this.b081  = UInt128.One<<rc;
//			this.lkType = 2;
			this.pmCnd = pmCnd;
			this.ID    = ID;
			this.hno  = (hNo!=-999)? hNo: ID;  // and no;
        }
		// --------------------------------------------------------------------------


	  #region CompareTo HashCode
		public int CompareTo( object obj ){				// Used in extNW. Not used in GeneralLogic.
            var Xobj = obj as ULogical_Node;
            if( Xobj is null  )  return -1;
            var dif = this.LGN_key3-Xobj.LGN_key3;
            int ret = (dif<0)? -1: (dif>0)? 1: 0;
            return ret;
        }

		public int CompareToA( ULogical_Node B ){		// Used in GeneralLogic.
            var Xobj = B as ULogical_Node;
            if( Xobj is null  )  return -1;
			if( this.noB9 !=B.noB9 )  return (this.noB9-B.noB9);
            if( this.b081 == B.b081 ) return 0;
            return (this.b081<B.b081)? -1: +1;
        }
        #endregion CompareTo HashCode


        #region ToString()
        public override string ToString( ){
			string st = $"ULogical_Node  Sentinel:{Sentinel}  pmCnd:{pmCnd} no:#{noB9.TBS()}  {b081.TBScmp().PadRight(8)} b81t:{b081.TBS()}" ;
			return st;
        }

		private string eNW_ToString() => $"{ID} {Sentinel} {pmCnd} {noB9.TBS()} {b081.TBScmp()} {b081.TBS()}";

		public string GL_ToString(){
			string st =$"{hno.HouseToString()}#{noB9.TBScmp()} ";
			return st.Trim();
		}

		public string ToString_SameHouseComp(){
            string st = $"{ToRCBString().ToString_SameHouseComp()}";
            return st.Trim();
        }

        public string ToRCBString(){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( b081 >> (n*27) );
                for(int k=0; k<27; k++){
                    if((bp&(1<<k))==0)  continue;
                    int rc=n*27+k;
                    st += $" {rc.ToRCString()}";
                }
            }
            return st.Trim();
        }

	  #endregion ToString()
    }
}

#endif