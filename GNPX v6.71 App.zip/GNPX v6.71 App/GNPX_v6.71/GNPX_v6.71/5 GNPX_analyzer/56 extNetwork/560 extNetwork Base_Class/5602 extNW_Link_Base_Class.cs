using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Xml.Linq;

namespace GNPX_space {
    public partial class eNW_Link: IComparable{
        static public GNPX_AnalyzerMan	pAnMan;
        static private int				ID0=0;
//		static public bool				DispID;
        static public bool              debugPrint=false;


        static public void Initialize() => ID0=-1;
        static private protected bool   _withID_=false;

        static public List<eNW_Node>    peNW_NodeList => eNW_Man.eNW_NodeList;

        static public void              Set_withID_( bool withID ) => _withID_ = withID;  // for DEBUG
        static public int               qConnectTo_RC=-1;  

	    //static protected bool debugAT = false;
        // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*




        public int						ID;
        public bool                     Sentinel;

		public int						lkCode=0;
		public int						genNo=0;		// branch order from stem	
    //   public int						Size => eObject.BitCount();
        public string					keySt;

		public int  			        hv=0;


		/* *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
			A link has a source node and a destination node.
			eNW_Node is set as required from ULogical_Node information.
			Information on links connecting to nodes is not automatically set.
			Upstream link information for a node is set using dedicated routines.
			Nodes can maintain upstream link information.
			A node's upstream links include positively defined links and negatively defined links.
			and each is maintained separately.
			It is possible to detect that upstream link information is set in a node.
		   *--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*
		*/
        public UInt128                  b081;
//      public UInt128                  eObjectA => eObject | OrgN.b081 | DesN.b081;
		public ULogical_Node			OrgN;
		public ULogical_Node			DesN;
        public int                      h;

        public eNW_Node			        eN_Org_nPM => Get_eNW_Node_with_ULG(OrgN);  //search with matchKey2  (with rc,no)
        public eNW_Node			        eN_Des_nPM => Get_eNW_Node_with_ULG(DesN);//search with matchKey2  (with rc,no)
        public int						noOrg => OrgN.no;
        public int						noDes => DesN.no;
//        public UInt128					eBody_B81 => eObject & ~DesN.b081;

        public UInt128					eObject;  // The `eObject` is used to avoid overlaps during pathfinding. 
                                                  // <<< Important >>> It is defined according to the characteristics of the link.




        private eNW_Node Get_eNW_Node_with_ULG( ULogical_Node ULG, bool addOn=true ){
			// Find the same node regardless of whether the node is positive or negative.
			// The positive/negative information of the node is held by ULogical_Node.

            eNW_Node eN=null;
			UInt128 _matchKey2 = (ULG!=null)? ULG.matchKey2: UInt128.MaxValue;
            if( peNW_NodeList!=null && peNW_NodeList.Count>0 ) eN = peNW_NodeList.Find(p => p.matchKey2==_matchKey2);      

            if( (eN is null) && addOn )  peNW_NodeList.Add( eN = new eNW_Node(ULG) );

					//WriteLine(""); peNW_NodeList.ForEach( (p,mx) => WriteLine( $" peNW_NodeList  {mx} : {p}" ) ); 
            return eN;
        }

    //===============================================================================================================================



        public eNW_Link(){ ID = ++ID0;}


        public eNW_Link( ULogical_Node _OrgN, ULogical_Node _DesN, int h ): this(){
            this.OrgN = _OrgN;
			this.DesN = _DesN;
            this.h    = h;
        }


        public virtual string CreateKey() => "";
        public virtual int CompareTo( object xObj ){ return 0; }

        public int SearchOrder( eNW_Link A ){		
            int val = 0;
            if( (val = genNo - A.genNo) !=0 )  return val;			
            if( (val = OrgN.b081Size - A.OrgN.b081Size) !=0 )   return val;
            if( (val = DesN.b081Size - A.DesN.b081Size) != 0 )  return val;
            return (ID - A.ID);
        }
        public int SearchOrderSimple( eNW_Link A ){		
            int val = this.lkCode-A.lkCode;
			if( val != 0 )  return val;
            if( (val = genNo - A.genNo) !=0 )  return val;		// branch order from stem	
            if( (val = OrgN.b081Size - A.OrgN.b081Size) != 0 )  return val;
            if( (val = DesN.b081Size - A.DesN.b081Size) != 0 )  return val;
            return (ID - A.ID);
        }

		public override string ToString( ){
			return (_withID_? $"#_ID:{ID} ": "");
		}


#region Remove duplicate elements in link column display. 
		public string ToString2(bool firstTimet){
            string st = this.ToString();
            if(firstTimet) return st;
            else{
                int n = st.IndexOf( "=>");
				if( n<=0 )  return st;  
                string st2 = new string(' ',9) + st.Substring(n);
                return st2;
            }
        }

        public string ToString2B(bool firstTimet){
            string st = this.ToString();
            if(!firstTimet){
                int n = st.IndexOf( "=>");		
				if( n>=0 )  st = st.Substring(n);
			}
			int m = st.Length;
			st = st.Replace("=> [intra cell ->","=>").Replace("=> [inter cell ->","=>");
			if( st.Length != m )  st = st.Replace("]","");

            return st;
        }
#endregion
    }

}
