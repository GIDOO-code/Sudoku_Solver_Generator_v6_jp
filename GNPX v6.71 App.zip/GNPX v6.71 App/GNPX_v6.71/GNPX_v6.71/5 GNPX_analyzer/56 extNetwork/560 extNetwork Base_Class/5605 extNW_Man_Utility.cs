using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Windows.Documents;
using System.Diagnostics;

namespace GNPX_space {

    static public class eNW_Man_Utility{

        static public string eLinkFormatter( this string stSource, int len=60, int sft=-1 ){
            List<string> stList = stSource.Split(new []{ "=>" }, StringSplitOptions.None).ToList();
            var stList2 = stList.ConvertAll( p => p.Trim() );
            return  stList2.eLink_Formatter_sub(len,sft);
        }

        static public string eLink_Formatter_sub( this List<string> stList, int len, int sft=-1 ){
            List<int>  lenX = stList.ConvertAll( p => p.Length );

            string st = stList[0];
            int  sftX=(sft>0)? sft:(st.Length), nn=sftX;
            for( int k=1; k<stList.Count; k++ ){
                if( nn+lenX[k]>len ){
                    st += $"\n{new string(' ',sftX)}";
                    nn = sftX;
                }
                st += $" => {stList[k]}";
                nn += (lenX[k]+4);
            }
            return st;
        }
    }

}
                        