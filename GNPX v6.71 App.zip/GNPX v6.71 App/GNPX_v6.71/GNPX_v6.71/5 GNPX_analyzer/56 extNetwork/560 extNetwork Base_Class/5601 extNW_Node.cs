using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Xml.Linq;
using System.Net;

namespace GNPX_space {

	 /* *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
			A link has a origin node and a destination node.
			Link information to connect to a node is not automatically set.
			Upstream link information for a node is set using a dedicated routine.
			(Node can hold upstream link information.)
			Upstream link of a node include links that are defined positively and negatively,
			and each is maintained separately.
			It is possible to detect that upstream link information has already been set in a node.
	    *--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*   */

    public class eNW_Node: ULogical_Node{
        static public GNPX_AnalyzerMan pAnMan;
        static private protected bool _withID_=false;
        static public void    Set_withID_( bool withID ) => _withID_ = withID;  // for DEBUG 

        public eNW_Link  eChaineNtwk_pre_Plus  = null;	// positively defined link
        public eNW_Link  eChaineNtwk_pre_Minus = null;	// negatively defined link 	


        public eNW_Node( ULogical_Node ULG ): base(ULG){}
    }

}
