using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Xml.Linq;

namespace GNPX_space {

    [Serializable]

	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//            eNW_Link_IntraCell
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	public class eNW_Link_IntraCell: eNW_Link, IComparable{
		public UCell   qUC;

		public eNW_Link_IntraCell( UCell UC, ULogical_Node OrgN, ULogical_Node DesN ): base( OrgN, DesN, h:-9 ){
			this.qUC     = UC;
			this.eObject = UInt128.Zero;
			this.lkCode  = 10 + DesN.b081Size;
			this.keySt   = CreateKey();
			this.hv		 = keySt.GetHashCode();
		}
					public override string CreateKey() => this.ToString().Trim();
					public override int CompareTo( object obj ){
						var xUC = obj as eNW_Link_IntraCell;
						if( xUC is null  )  return -1;
						int cmp = this.qUC.rc - xUC.qUC.rc;
						if( cmp != 0 )  return cmp;
						return (this.noOrg-xUC.noDes);
					}

					public override string ToString(){
						string  stOrg="--", stDes="--";
						if( OrgN!=null ) stOrg = $"{OrgN.ToString_SameHouseComp()}#{noOrg+1}{OrgN.stTFmark}";
						if( DesN!=null ) stDes = $"{DesN.ToString_SameHouseComp()}#{noDes+1}{DesN.stTFmark}";
						string st = $"{base.ToString()} {stOrg} => [intra cell -> {stDes}]";
						if( debugPrint )  st += $" hv:#{hv}";
						return st;
					}
	}





	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//            eNW_Link_InterCells
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	public class eNW_Link_InterCells: eNW_Link, IComparable{

		public eNW_Link_InterCells( ULogical_Node OrgN, ULogical_Node DesN, int h ): base( OrgN, DesN, h){
			this.eObject = DesN.b081;//OrgN.b081 | DesN.b081;      // (InterCells is not displayed)  ???
			this.lkCode  = 20 + DesN.b081Size;
			this.keySt   = CreateKey();
			this.hv		 = keySt.GetHashCode();
		}

					public override string CreateKey() => this.ToString().Trim();
					public override int CompareTo( object obj ){
						var eGL = obj as eNW_Link_InterCells;
						if( eGL is null  )  return -1;
						if( this.noOrg != eGL.noOrg )  return (this.noOrg-eGL.noOrg);
						if( this.OrgN.b081 != eGL.OrgN.b081) return this.OrgN.CompareTo( eGL.OrgN );
						if( this.DesN.b081 != eGL.DesN.b081) return this.DesN.CompareTo( eGL.DesN );
						return  0;
					}

					public override string ToString(){
						string  stOrg="--", stDes="--";
						if( OrgN!=null )  stOrg = $"{OrgN.ToString_SameHouseComp()}#{noOrg+1}{OrgN.stTFmark}";
						if( DesN!=null )  stDes = $"{DesN.ToString_SameHouseComp()}#{noDes+1}{DesN.stTFmark}";
						string st = $"{base.ToString()} {stOrg} => [inter cell -> {stDes}]";
						if( debugPrint )  st += $" hv:#{hv}";
						return st;
					}
	}




  
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//            eNW_Link_ALS
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//ALS(Almost Locked Set) 
	// ALS is a state where there are "n+1 candidate digits" in "n cells" belonging to the same house. 
	// https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page26.html
	public class eNW_Link_ALS: eNW_Link, IComparable{
		public UAnLS     qALS;

		public eNW_Link_ALS( UAnLS qALS, ULogical_Node OrgN, ULogical_Node DesN, int h ): base( OrgN, DesN, h ){
			this.qALS    = qALS;
			this.eObject = qALS.b081 | DesN.b081;
			this.lkCode  = 30 + qALS.CellSize;
			this.keySt   = CreateKey();
			this.hv		 = keySt.GetHashCode();
		}

					public override string CreateKey() => this.ToString().Trim();
					public override int CompareTo( object xObj ){
						var x = xObj as eNW_Link_ALS;
						if( x is null )  return -1;

						int cmp = this.qALS.CompareTo(x.qALS );
						if( cmp != 0 )  return cmp;
						cmp = this.keySt.CompareTo(x.keySt);
						if( cmp != 0 )  return cmp;
						return base.CompareTo(xObj);
					}

					public override string ToString(){
						string  stOrg="--", stDes="--";

						if( OrgN!=null ) stOrg = $"{OrgN.ToString_SameHouseComp()}#{OrgN.no+1}";

						int fb0=qALS.FreeB, fb1 = fb0 & ~(1<<noOrg);
						string stObj = $"ALS:{qALS.b081.ToRCStringComp()} #{fb0.ToBitStringNZ(9)}";           
						stObj += $"->#{fb1.ToBitStringNZ(9)}";
						if( _withID_ )  stObj = $"ID:{ID} " + stObj;

						if( DesN!=null ){
							stDes = $"{DesN.ToString_SameHouseComp()}";
							if( qConnectTo_RC>=0 )  stDes=qConnectTo_RC.ToRCString();   //=== Refine the display of solutions ===

							stDes += $"#{DesN.no+1}{DesN.stTFmark}";
						}

						string st = $"{base.ToString()} {stOrg}+ => [{stObj} ->{stDes}]";
						if( debugPrint )  st += $" hv:#{hv}";
						return st;
					}
	}




	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//            eNW_Link_refALS
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	// refALS(reconfigure Almost Locked Set) 
	// ALS is a state where there are "n+1 candidate digits" in "n cells" belonging to the same house. 
	// https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page26.html

	public class eNW_Link_refALS: eNW_Link, IComparable {
		public UAnLS qrefALS;

		public eNW_Link_refALS( UAnLS qALS, ULogical_Node OrgN, ULogical_Node DesN, int h ): base( OrgN, DesN, h ){
			this.qrefALS = qALS;
			this.eObject = qALS.b081 | DesN.b081;
			this.lkCode  = 40 + qALS.CellSize;
			this.keySt   = CreateKey();
			this.hv		 = keySt.GetHashCode();
		}

					public override string CreateKey( ) => this.ToString().Trim();

					public override int CompareTo(object xObj) {
						var x = xObj as eNW_Link_refALS;
						if(x is null)
							return -1;

						int cmp = this.qrefALS.CompareTo(x.qrefALS);
						if(cmp != 0)
							return cmp;
						cmp = this.keySt.CompareTo(x.keySt);
						if(cmp != 0)
							return cmp;
						return base.CompareTo(xObj);
					}

					public override string ToString( ) {
						string stOrg = "--", stDes = "--";

						if(OrgN != null)
							stOrg = $"{OrgN.ToString_SameHouseComp()}#{OrgN.no + 1}";

						int fb0 = qrefALS.FreeB, fb1 = qrefALS.FreeB_SP;
						string stObj = $"ALS:{qrefALS.b081.ToRCStringComp()} #{fb0.ToBitStringNZ(9)}";
						stObj += $"->#{fb1.ToBitStringNZ(9)}";
						if(_withID_)
							stObj = $"ID:{ID} " + stObj;

						if(DesN != null) {
						stDes = $"{DesN.ToString_SameHouseComp()}";
						if(qConnectTo_RC >= 0)
							stDes = qConnectTo_RC.ToRCString();   //=== Refine the display of solutions ===
						stDes += $"#{DesN.no + 1}{DesN.stTFmark}";
						}

						string st = $"{base.ToString()} {stOrg}+ => [{stObj} ->{stDes}]";
						if( debugPrint )  st += $" hv:#{hv}";
						return st;
					}
	}




	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//            eNW_Link_AIC
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	public class eNW_Link_AIC: eNW_Link, IComparable{   
		public ULogical_Node qAIC;

		public eNW_Link_AIC( ULogical_Node qAIC, ULogical_Node  OrgN, ULogical_Node DesN, int h ): base( OrgN, DesN, h ){
			this.qAIC    = qAIC;
			this.eObject = qAIC.b081 | DesN.b081;
			this.lkCode  = 50 + qAIC.b081Size;
			this.keySt   = CreateKey();
			this.hv		 = keySt.GetHashCode();
		}

					public override string CreateKey() => this.ToString().Trim();
					public override int CompareTo( object obj ){
						var xAIC = obj as eNW_Link_AIC;
						if( xAIC is null  )  return -1;
						int cmp = this.qAIC.CompareTo(xAIC);
						if( cmp != 0 )  return cmp;
						return base.CompareTo(obj);
					}

					public override string ToString(){
						string  stOrg="--", stDes="--", stObj="--";

						if( OrgN!=null ){
							stOrg = $"{OrgN.ToString_SameHouseComp()}#{noOrg+1}{OrgN.stTFmark}";
							stObj = $"AIC:{qAIC.ToString_SameHouseComp()} {qAIC.ToString_SameHouseComp()}#{noOrg+1}{qAIC.stTFmark}";
								if( _withID_ )  stObj = $"ID:{ID} " + stObj;
						}
						if( DesN!=null ){
							stDes = $"{DesN.ToString_SameHouseComp()}";
							if( qConnectTo_RC>=0 )  stDes=qConnectTo_RC.ToRCString();   //=== Refine the display of solutions ===
							stDes += $"#{noDes+1}{DesN.stTFmark}";
						}
						string st = $"{base.ToString()} {stOrg} => [{stObj} ->{stDes}]";
						if( debugPrint )  st += $" hv:#{hv}";
						return st;
					}
				}



	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//            eNW_Link_ALSXZ
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	public class eNW_Link_ALSXZ: eNW_Link, IComparable{
		private UAnLS   qALS1;
		private UAnLS   qA2ALS2;
		private int     RCC;
		public  int     RCCsize;

		public eNW_Link_ALSXZ( UAnLS qALS1, UAnLS qA2ALS2, int RCC, ULogical_Node OrgN, ULogical_Node DesN, int h ): base( OrgN, DesN, h ){

			this.qALS1   = qALS1;
			this.qA2ALS2 = qA2ALS2;
			this.RCC     = RCC;
			this.RCCsize = RCC.BitCount();
			this.eObject = qALS1.b081 | qA2ALS2.b081 | DesN.b081;;
			this.lkCode  = 60 + (qALS1.CellSize + qA2ALS2.CellSize);
			this.keySt   = CreateKey();
			this.hv		 = keySt.GetHashCode();
		}

					public override string CreateKey() => this.ToString().Trim();
					public override int CompareTo( object xObj ){
						var x = xObj as eNW_Link_ALSXZ;
						if( x is null )  return -1;

						int cmp1 = this.qALS1.CompareTo(x.qALS1 );
						if( cmp1 != 0 )  return cmp1;
						int cmp2 = this.qA2ALS2.CompareTo(x.qA2ALS2 );
						if( cmp2 != 0 )  return cmp2;
						int cmp = this.keySt.CompareTo(x.keySt);
						if( cmp != 0 )  return cmp;
						return base.CompareTo(xObj);
					}

					public override string ToString(){
						string  stOrg="--", stDes="--";

						if( OrgN!=null ) stOrg = $"{OrgN.ToString_SameHouseComp()}#{OrgN.no+1}{OrgN.stTFmark}";

						int fb1=qALS1.FreeB, fb2=qA2ALS2.FreeB;
						string stObj1 = $"1)ALS:{qALS1.b081.ToRCStringComp()}#{fb1.ToBitStringNZ(9)}";  
						string stObj2 = $"2)AnLS:{qA2ALS2.b081.ToRCStringComp()}#{fb2.ToBitStringNZ(9)}"; 

						if( _withID_ ){
							stObj1 = $"ID:{qALS1.ID} " + stObj1;
							stObj1 = $"ID:{qA2ALS2.ID} " + stObj1;
						}
						string stObj = $"{stObj1} @ {stObj2} (RCC:#{RCC.ToBitStringNZ(9)})";

						if( DesN!=null ) stDes = $"{DesN.ToString_SameHouseComp()}";
						stDes += $"#{DesN.no+1}{DesN.stTFmark}";

						string st = $"{base.ToString()} [{stOrg} => ALSXZ[{stObj}] =>{stDes}]";   
						if( debugPrint )  st += $" hv:#{hv}";
						return st;
					}
	}

}
