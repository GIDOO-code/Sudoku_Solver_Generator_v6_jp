using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Intrinsics.X86;
using System.Security.Policy;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{

	using defBC = (UInt128,int,UInt128,int,UInt128,UInt128);
	using G6_SF = G6_staticFunctions;
    public partial class Fish_absolute{
		static public UInt128 qZero=UInt128.Zero;

		private string[]	_FishNameList = { "Xwing","SwordFish","JellyFish","Squirmbag","Whale", "Leviathan" };
		private int[]		BOARD_FrameB9;
		private UInt128		BD_Free_no;

		protected UInt128[] pHouseCells81		=> GNPX_Utilitie.HouseCells81;
        protected UInt128[] pConnected_81	=> GNPX_Utilitie.Connected_81;

		AnalyzerBaseV2		analyzerV2;
		private UInt128[]	BOARD_Free81B9 => analyzerV2.BOARD_Free81B9;
		private int			minSize;
		private int			maxSize;



        public Fish_absolute( AnalyzerBaseV2 analyzerV2, bool FMavail, int minSize, int maxSize ){
			this.analyzerV2 = analyzerV2;
			this.minSize	= minSize;
			this.maxSize	= maxSize;

			BOARD_FrameB9	= new int[9];
			int Framemask = (1<<(FMavail? 27: 18))-1;
			foreach( int no in Enumerable.Range(0,9) )	BOARD_FrameB9[no] = BOARD_Free81B9[no].Ceate_rcbFrameOr() & Framemask;
		}



		public IEnumerable<UFish> IE_BaseCover_absolute( bool finnedB, bool EndoFinB, bool CannFinB ){
			for( int sz=minSize; sz<=maxSize; sz++ ){
				foreach( var V7FB in IE_BaseSet(sz,EndoFinB) ){							// === Create BaseSet		
					foreach( var V7FC in IE_CoverSet(V7FB,CannFinB) ){					// === Create CoverSet	
						if( finnedB != (V7FC.Fin!=qZero) )  continue;
						yield return V7FC;
					}
				}
			}
			yield break;
		}

		public IEnumerable<UFish> IE_BaseCover_absolute_Kraken( int sz, bool finnedB, bool EndoFinB=false, bool CannFinB=false ){
			foreach( var V7FB in IE_BaseSet(sz,EndoFinB) ){							// === Create BaseSet		
				foreach( var V7FC in IE_CoverSet(V7FB,CannFinB) ){					// === Create CoverSet	
					if( finnedB != (V7FC.Fin!=qZero) )  continue;
					yield return V7FC;
				}
			}
			yield break;
		}


		private IEnumerable<UFish> IE_BaseSet( int sz, bool EndoFinB=false ){
			foreach( int no in Enumerable.Range(0,9) ){
				BD_Free_no = BOARD_Free81B9[no];
				if( BD_Free_no == qZero )  continue;
				int	 Frame_no = BOARD_FrameB9[no]; 
				int  rcbFrameSize = Frame_no.BitCount();


				if( EndoFinB is false ){ // normal fish
					Combination_IntB cmbFrame = new(rcbFrameSize, sz, Frame_no);		
					int nxt = -1;
					while( cmbFrame.Successor(nxt) ){
			
						UInt128 BaseSet = qZero;	
						nxt = 0;
						for( int k=0; k<sz; k++ ){
							int h = cmbFrame.IndexL[k];
							UInt128 bSet = pHouseCells81[h] & BD_Free_no;
							if( (BaseSet & bSet) > qZero )  goto Next_Combination;
							BaseSet |= bSet;
							nxt++;
						}
						int BaseHouse = cmbFrame.valueT;
						UFish V7UF = new( sz,no, BaseSet,BaseHouse, qZero,0, EndoFin:qZero, CannFin:qZero );
						yield return V7UF;

					Next_Combination:
						continue;
					}
				}
				else{ // --- with EndoFin ---
					Combination_IntB cmbFrame = new(rcbFrameSize, sz, Frame_no);						
					while( cmbFrame.Successor() ){
						int BaseHouse = cmbFrame.valueT;
					
						List<UInt128> BaseList = BaseHouse.IEGet_BtoHouse27().ToList().ConvertAll(h=>pHouseCells81[h]&BD_Free_no);
						UInt128 BaseSet = BaseList.Aggregate(qZero,(a,p)=>a|p);

						var (one,two,more) = BaseList.Get_UInt128_Single_Two_More();	
						if( two>qZero && more==qZero ){ 
							UFish V7UF = new( sz,no, BaseSet,BaseHouse, qZero,0, two,qZero);	// two:EndoFin
							yield return V7UF;
						}
					}
				}
			}
			yield break;
		}


		private IEnumerable<UFish> IE_CoverSet( UFish V7UF, bool CannFinB ){
			int  no=V7UF.no, sz=V7UF.sz, BaseHouse=V7UF.BaseHouse;
			int	 FMhouse = 0x1FF<<18;	

			UInt128  BaseSet = V7UF.BaseSet;
			int      par_no_Frame = BOARD_FrameB9[no] & ~BaseHouse;

			int rcbSize = par_no_Frame.BitCount();
			if( rcbSize < sz )  yield break;

			Combination_IntB cmbFrame = new(rcbSize, sz, par_no_Frame);						
			while( cmbFrame.Successor() ){
				int CoverHouse = cmbFrame.valueT;
				List<UInt128> CoverList = CoverHouse.IEGet_BtoHouse27().ToList().ConvertAll(h=>pHouseCells81[h]&BD_Free_no);
				CoverList = CoverList.ConvertAll(p=>p&BD_Free_no);
				UInt128 CoverSet = CoverList.Aggregate(qZero,(a,p)=>a|p);
				var (one,two,more) = CoverList.Get_UInt128_Single_Two_More();  // Check the overlapping state

				V7UF.CoverSet=CoverSet; V7UF.CoverHouse=CoverHouse;
				V7UF.CannFin = two;
				if( CannFinB is false && (two | more)==qZero)  yield return V7UF;
				if( CannFinB && two>qZero && more==qZero )     yield return V7UF;
			}
			yield break;
		}
    }
}