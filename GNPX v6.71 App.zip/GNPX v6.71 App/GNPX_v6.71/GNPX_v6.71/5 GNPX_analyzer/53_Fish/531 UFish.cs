using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Intrinsics.X86;
using System.Security.Policy;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{

	public class UFish{
		static public string[] FishNames = { "Xwing","SwordFish","JellyFish","Squirmbag","Whale", "Leviathan" };
		public int		sz;
		public int	    no;
		public UInt128  Fish => BaseSet & CoverSet;
		public UInt128  BaseSet;
		public int      BaseHouse;
		public UInt128  CoverSet;
		public int	    CoverHouse;
		public UInt128  EndoFin;
		public UInt128  CannFin;

		public UInt128  Fin => BaseSet & ~CoverSet;
		public UInt128  Exclude;


		public UFish( int sz, int no, UInt128 BaseSet, int BaseHouse, UInt128 CoverSet, int CoverHouse, UInt128 EndoFin, UInt128 CannFin ){
			this.no=no; this.sz=sz;
			this.BaseSet=BaseSet;   this.BaseHouse=BaseHouse;
			this.CoverSet=CoverSet; this.CoverHouse=CoverHouse;
			this.EndoFin=EndoFin;   this.CannFin=CannFin;
		}

		public override string ToString(){
			string st = $"sz:{sz}  no:#{no+1}  Fish:{Fish.TBScmp()}";
			st += $"\n BaseSet:{BaseSet.TBScmp()}  /  BaseHouse:{BaseHouse.TBS27cmp()}  /  EndoFin:{EndoFin.TBScmp()}";
			st += $"\nCoverSet:{CoverSet.TBScmp()}  /  CoverHouse:{CoverHouse.TBS27cmp()}  /  CannFin:{CannFin.TBScmp()}";
			st += $"Fin:{Fin.TBScmp()}\n  Exclude:{Exclude.TBScmp()}";
			return  st;
		}
	}
}