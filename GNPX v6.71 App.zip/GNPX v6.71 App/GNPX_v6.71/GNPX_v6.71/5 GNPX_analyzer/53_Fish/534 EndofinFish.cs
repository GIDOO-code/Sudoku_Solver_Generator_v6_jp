using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Policy;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using defBC = (UInt128,int,UInt128,int);
	using G6_SF = G6_staticFunctions;
    public partial class FishGen: AnalyzerBaseV2{

		// ....2.6.. 7.41.9... .3.847.1. .7.9.1.54 1.3...7.9 .9.2.8.36 .4.683.7. 3.75.4... ....1.4.. // EndoFin_Fish Puzzle
		// ...325647 7541693.. .3.847915 .7.931.54 1.34567.9 495278136 .4.68357. 3.7594.6. 568712493 // Current

		// .46..3.8. 72....... .8.7..3.. ..42.7... ..9.58.2. .....6..1 ..14396.. 4.....139 .976.1.4.
		// .46..3.8. 723.....6 .8576.3.. .14297.63 639158.2. .7.346..1 .5143967. 46..7.139 3976.1.4.


        public bool EndoFin_Fish( )		   => Endo_Fish_Function( );
        public bool Finned_EndoFin_Fish( ) => Endo_Fish_Function( finnedB:true );


		public bool Endo_Fish_Function( bool finnedB=false ){
			Fish_Prepare();

			Fish_absolute Fish000 = new(this,FMavail:true, minSize:2,maxSize:7); 
			foreach( var V7FC in Fish000.IE_BaseCover_absolute( finnedB:finnedB, EndoFinB:true, CannFinB:false) ){  // @ Generate Fish
				int     no = V7FC.no;
				UInt128 BaseSet = V7FC.BaseSet, CoverSet=V7FC.CoverSet;	
		
				if( finnedB != (V7FC.Fin>qZero) )  continue;

				UInt128 _LockedSet = BaseSet & CoverSet;
				UInt128 Exclude = BOARD_Free81B9[no] & (CoverSet & ~BaseSet);
				UInt128 fin_EndoFin = (BaseSet & ~CoverSet) | V7FC.EndoFin;

				if( fin_EndoFin != qZero ){	// If with fins, exclude elements covering the fins.
					Exclude = Exclude.IEGet_rc().Where(rc=>(fin_EndoFin&~Connected_81[rc])==0) .Aggregate(qZero,(a,rc)=>a| qOne<<rc);
				}
				if( Exclude == qZero )  continue;
				V7FC.Exclude = Exclude; 	

				// --------------------------------------------------------------------------------
				bool solFound = Fish_Result(V7FC);	// ::: Results report
				if( solFound ){
					SolCode = 2;
					if( !pAnMan.IsContinueAnalysis() )  return true;

					// :::::: Final processing ::::::
					foreach( var UC in pBOARD.Where(p=>p.No!=0) ) UC.CancelB=0;
					pBOARD.ForEach( UC => UC.ECrLst=null );
				}
			}
			return (SolCode>0);
		}
	}
}