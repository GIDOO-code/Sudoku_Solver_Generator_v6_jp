using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Policy;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using defBC = (UInt128,int,UInt128,int);
	using G6_SF = G6_staticFunctions;
    public partial class FishGen: AnalyzerBaseV2{

		// ....9.6.. 4.61.8... .8.462.5. .6.2.1.37 3.5...2.8 .4.3.6.95 .3.914.7. 6.18.5... ....2.8..  // Puzzle    test example
		// ...59.68. 4.61.8.2. .8.462.5. .6.251437 315749268 .4.386195 .3.91457. 6.18.5.4. ...62.81.  // Current



        public bool CannibalisticFish( )		   => Cannibalistic_Fish_Function( );
		
		// *** Cannibalistic fish are possible from size 2. However, size 2(3) is too simple.
		//     The minimum search size is specified in the Page"solver options".
		//
		// *** Finned CannibalisticFish is fundamentally impossible.



		public bool Cannibalistic_Fish_Function( ){
			Fish_Prepare();

			Fish_absolute Fish000 = new( this,FMavail:true, minSize:G6.CannibalisticMin,maxSize:7 );
			foreach( var V7FC in Fish000.IE_BaseCover_absolute( finnedB:false, EndoFinB:false, CannFinB:true) ){  // @ Generate Fish
				if( V7FC.CannFin == qZero )  continue;
				if( V7FC.Fin > qZero  )  continue;

				V7FC.Exclude = V7FC.CannFin;;
				// --------------------------------------------------------------------------------

				bool solFound = Fish_Result(V7FC);
				if( solFound ){
					SolCode = 2;
					if( !pAnMan.IsContinueAnalysis() )  return true;

					// :::::: Final processing ::::::
					foreach( var UC in pBOARD.Where(p=>p.No!=0) ) UC.CancelB=0;
					pBOARD.ForEach( UC => UC.ECrLst=null );
				}
			}
			return (SolCode>0);
		}
	}
}