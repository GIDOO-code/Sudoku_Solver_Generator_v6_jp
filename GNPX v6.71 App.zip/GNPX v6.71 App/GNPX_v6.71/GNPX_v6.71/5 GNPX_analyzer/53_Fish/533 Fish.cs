using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Policy;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using defBC = (UInt128,int,UInt128,int);
	using G6_SF = G6_staticFunctions;
    public partial class FishGen: AnalyzerBaseV2{

		// 4....9.5. 23..58.67 ...4.7... ......325 3.2....8. 5.1...7.. ...89.... 9......7. .1.72..46  Puzzle
		// 476239158 239158467 1..467239 7.....325 3.2.7.681 561382794 6.789.51. 9.....87. 81.72.946  Current

		// Franken/mutants Fish are not logically special type. Therefore, they are not shown.


		public bool Fish()        => Fish_Function( FMavail:false, minSize:2, maxSize:4);
		public bool Finned_Fish() => Fish_Function( FMavail:false, minSize:2, maxSize:4, finnedB:true );

		public bool FishExt()        => Fish_Function( FMavail:false, minSize:5, maxSize:7 );
		public bool Finned_FishExt() => Fish_Function(FMavail:false, minSize:5, maxSize:7, finnedB:true );

		public bool Fish_FM()        => Fish_Function( FMavail:true, minSize:2, maxSize:4);
		public bool Finned_Fish_FM() => Fish_Function( FMavail:true,minSize:2, maxSize:4, finnedB:true );

		public bool FishExt_FM()        => Fish_Function( FMavail:true,minSize:5, maxSize:7 );
		public bool Finned_FishExt_FM() => Fish_Function( FMavail:true,minSize:5, maxSize:7, finnedB:true );



		public bool Fish_Function( bool FMavail, int minSize, int maxSize, bool finnedB=false ){
			Fish_Prepare();

			Fish_absolute Fish000 = new(this,FMavail,minSize,maxSize); 
			foreach( var V7FC in Fish000.IE_BaseCover_absolute( finnedB:finnedB, EndoFinB:false, CannFinB:false) ){  // @ Generate Fish
				int no=V7FC.no;
				UInt128 BaseSet=V7FC.BaseSet, CoverSet=V7FC.CoverSet;
					
				UInt128 finX = V7FC.Fin;
				if( finnedB != (finX!=qZero) )  continue;

				UInt128 Exclude = BOARD_Free81B9[no] & (CoverSet & ~BaseSet);
				if( finnedB ){				// If with fins, exclude elements covering the fins.
					Exclude = Exclude.IEGet_rc().Where(rc=>(finX&~Connected_81[rc])==0) .Aggregate(qZero,(a,rc)=>a| qOne<<rc);
				}
				if( Exclude == qZero )  continue;
				V7FC.Exclude = Exclude;
				
				// --------------------------------------------------------------------------------
				bool solFound = Fish_Result(V7FC);	// ::: Results report

				if( solFound ){
					SolCode = 2;
					if( !pAnMan.IsContinueAnalysis() )  return true;

					// :::::: Final processing ::::::
					foreach( var UC in pBOARD.Where(p=>p.No!=0) ) UC.CancelB=0;
					pBOARD.ForEach( UC => UC.ECrLst=null );
				}
			}
			return (SolCode>0);
		}
    }
}