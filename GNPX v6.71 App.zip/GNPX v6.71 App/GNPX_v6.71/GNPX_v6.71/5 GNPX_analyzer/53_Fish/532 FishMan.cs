using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Intrinsics.X86;
using System.Security.Policy;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{

	using defBC = (UInt128,int,UInt128,int,UInt128,UInt128);
	using G6_SF = G6_staticFunctions;
    public partial class FishGen: AnalyzerBaseV2{
		private int		 stageNoPMemo = -9;
		private string[] _FishNameList = { "Xwing","SwordFish","JellyFish","Squirmbag","Whale", "Leviathan" };
		private int[]    BOARD_FrameB9;
		private UInt128  BOARD_no;


		// 4....9.5. 23..58.67 ...4.7... ......325 3.2....8. 5.1...7.. ...89.... 9......7. .1.72..46  Puzzle
		// 476239158 239158467 1..467239 7.....325 3.2.7.681 561382794 6.789.51. 9.....87. 81.72.946  Current



        public FishGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }

		private List<(int,UInt128)> eLinkSummaryList;

		private void Fish_Prepare( bool eLinkB=false ){
			if( stageNoP!=stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
		
				BOARD_FrameB9 = new int[9];
				foreach( int no in Enumerable.Range(0,9) )	BOARD_FrameB9[no] = BOARD_Free81B9[no].Ceate_rcbFrameOr();
			}
		}


		// ===== Result =====
		private bool Fish_Result( UFish V7UF ){
			int     no=V7UF.no, sz=V7UF.sz, BaseHouse=V7UF.BaseHouse, CoverHouse=V7UF.CoverHouse;
			UInt128 BaseSet=V7UF.BaseSet, CoverSet=V7UF.CoverSet, EndoFin=V7UF.EndoFin, CannFin=V7UF.CannFin;
			UInt128 Exclude=V7UF.Exclude, Fin=V7UF.Fin;

			int noB = 1<<no;	
			foreach( var U in Exclude.IEGet_UCell(pBOARD) )  U.CancelB |= U.FreeB&noB;
			int cnt = pBOARD.Count(U=>(U.CancelB)>0);
			if( cnt == 0 )  return false;

			SolCode = 2;

			Exclude.IE_SetNoBBgColor( pBOARD, noB, AttCr, SolBkCr6 );
			UInt128 _LockedSet = BaseSet & CoverSet;
			_LockedSet.IE_SetNoBBgColor( pBOARD, noB, AttCr, SolBkCr );
			if( Fin>qZero )  Fin.IE_SetNoBBgColor( pBOARD, noB, AttCr, SolBkCr2 );
			if( EndoFin>qZero )  EndoFin.IE_SetNoBBgColor( pBOARD, noB, AttCr, SolBkCr2 );
			if( CannFin>qZero )  CannFin.IE_SetNoBBgColor( pBOARD, noB, AttCr, SolBkCr3 );

			string  FishName = _FishNameList[sz-2];				// ### "G7_"
			if( EndoFin != qZero )  FishName = "EndoFin_" + FishName;
			if( CannFin != qZero )  FishName = "Cannibalistic_" + FishName;
			if( Fin>qZero )  FishName = "Finned_" + FishName;

			Result = $"{FishName} BaseSet:{BaseHouse.TBS27cmpN()} #{no+1}  CoverSet:{CoverHouse.TBS27cmpN()} #{no+1}";

			string st0 = $"      size : {sz}\n    BaseSet : {BaseHouse.TBS27cmpN()} #{no+1}\n   CoverSet : {CoverHouse.TBS27cmpN()} #{no+1}";
			if( Fin>qZero )  st0 += $"\n        Fin : {Fin.TBScmp()}";
			if( EndoFin>qZero )  st0 += $"\n   Endo_Fin : {EndoFin.TBScmp()}";
			if( CannFin>qZero )  st0 += $"\nCannibalistic_Fin : {CannFin.TBScmp()}";
			string stE = $"    Exclude : {Exclude.TBScmp()}";
			ResultLong = $"{FishName}\n {st0}\n{stE}" ;
			if( CannFin>qZero )  ResultLong += "\n\n * Minimum size for Cannibalistic Fish can be set\n　 in the method options.";

			return (SolCode>0);	
		}
    }
}