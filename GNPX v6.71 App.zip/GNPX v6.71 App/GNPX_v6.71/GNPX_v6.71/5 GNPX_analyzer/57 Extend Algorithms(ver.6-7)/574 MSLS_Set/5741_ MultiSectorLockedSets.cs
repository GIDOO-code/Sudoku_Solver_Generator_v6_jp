using GIDOO_space;
using System;
using System.Buffers.Text;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Sockets;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
    public partial class MSLS_TechGen: AnalyzerBaseV2{
		private UInt128[] CellsOverlap;

		public bool Multi_Sector_Locked_Sets()	=> MSL_General( MSLS_name:"MSLS" );

		public bool MSLS_SK_Loop()				=> MSL_General( MSLS_name:"SK_Loop" );  // SK Loop = 8-Sector MSLS(2-Row, 2-Column, 4-Block)

		public bool MSLS_FM()					=> MSL_General( MSLS_name:"FM" );
		public bool MSL_General( string MSLS_name, int MSLS_Size=99, bool debugPrint=false ){

			// ===== Prepare =====
			if( stageNoP != stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
			}

			// ========================================================================================
			foreach( var sectorSet in  Generate_MSLS_SectorSet_Control( MSLS_name, debugPrint:false) ){
				if( pAnMan.Check_TimeLimit() ) return (SolCode>0);	// @@@ Limit the search time.

				var (_,sectorB,MultiSelect81) = sectorSet;
						//	WriteLine( $" sectorB: {sectorB.ToBitString27rcb()}  // {test.ToBitString27rcb()}" );

				//debugPrint = false;	 // ... for MSLS debug

				// Ensure all CoverSets are concatenated
				if( _IsConnectedWhole(sectorB,debugPrint:false) is false )  continue;	
								if(debugPrint){ __Get_UInt128_Single_Two_More_with_HouseNo( sectorB, debugPrint:debugPrint); }

				// Aggregate the set of intersections of sectors.
				var (_,crossCells,_)  = _Get_UInt128_Single_Two_More(sectorB, qZero, debugPrint:false);
				if( crossCells.BitCount() < 3 )  continue;

			
				// Excluding confirmed cells, aggregate the intersection sets of sectors.
				var (oneF,twoF,moreF) = _Get_UInt128_Single_Two_More(sectorB, BOARD_Fixed81,  debugPrint:false);
								if(debugPrint) G6_SF.__MatrixPrint( Flag:qZero, crossCells, oneF, twoF, moreF, "crossCells, oneF, twoF, moreF" );
					CellsOverlap = new UInt128[]{ qZero, oneF,twoF,moreF };

					//if( moreF != qZero ) continue;	//!!! Triple overlaps is available !!!
				// =================================================================================================
	
				// Number of links at the free cell intersection.
				int noB9 = twoF.Get_FreeB_or();

				var (linksCount, CoverLinkSet) = Get_MSLS_Links_Count( noB9, twoF, debugPrint:false );

				// Number of free cells at the intersection
				int cellsCount = twoF.BitCount();// Only intersections of double overlaps are included.

				if( cellsCount == linksCount ){
					// :::::::::::::::::: Reporting the results ::::::::::::::::::
									UInt128[] MSLS_CrossCells_B9 = new UInt128[9];
									foreach( int no in noB9.IEGet_BtoNo(9) ){
										MSLS_CrossCells_B9[no] = BOARD_Free81B9[no] & crossCells;
											if(debugPrint){
												G6_SF.__MatrixPrint( Flag:qZero, BOARD_Free81B9[no], twoF, MSLS_CrossCells_B9[no], oneF,
																	$" BOARD_Free81B9[{no+1}], twoF, MSLD_CrossCells_B9[{no+1}], oneF" );
											}
									}

					bool solFound = MSLS_SolResult( MSLS_name, noB9, sectorB, crossCells, linksCount, CoverLinkSet, debugPrint:false);	// ::: Results report
					if( solFound is false )  continue;

					if( !pAnMan.IsContinueAnalysis() )  return true;

					// :::::: Final processing ::::::
					foreach( var UC in pBOARD.Where(p=>p.No!=0) ) UC.CancelB=0;
					pBOARD.ForEach( UC => UC.ECrLst=null );
				}
			}
			return (SolCode>0);


					(int,List<int>[]) Get_MSLS_Links_Count( int noB9, UInt128 twoF, bool debugPrint=false ){ 
						int   linksCount = 0;
						List<int>[] CoverLinkSet = new List<int>[9];	// There may be multiple types of linkSets(Cover Link Sets). 

											if(debugPrint)  WriteLine( $"noB9:{noB9.TBS()}" );
						foreach( int no in noB9.IEGet_BtoNo(9) ){
							List<int> CoverLinkSet_no = new();
							UInt128 IntSecNo = BOARD_FreeOrFixed81B9[no] & twoF;	// twoF:Intersection cells
							if( IntSecNo == qZero )  continue;
											if(debugPrint)  G6_SF.__MatrixPrint( Flag:qZero, BOARD_Free81B9[no], twoF, IntSecNo, $"BOARD_Free81B9[#{no+1}], twoF, IntSecNo" );

							int rcbFrame = IntSecNo.Ceate_rcbFrameOr();

											if(debugPrint)  WriteLine( $"rcbFrame:{rcbFrame.ToBitString27rcb_Omit_null()}" );
							var (frame_r_CC,frame_c_CC,frame_b_CC) = _ToRCBCount(rcbFrame);     // count of rows in the frame
							int linkCC_no = Min( frame_r_CC, Min(frame_c_CC, frame_b_CC) );

							var rcbList = rcbFrame.BitToNumList(from0:true);
							bool coveredB=false;
							for( int mCC=1; mCC<=linkCC_no; mCC++ ){				// Unnecessary matching is eliminated. Elegant!
								Combination cmb = new( rcbFrame.BitCount(), mCC);
										
								while( cmb.Successor() ){
									UInt128 cover = cmb.Index.Aggregate(qZero, (a,p)=> a| HouseCells81[rcbList[p]] );
											if(debugPrint)  G6_SF.__MatrixPrint( Flag:qZero, cover, $"cover" );
	
									if( (IntSecNo&~cover) == qZero ){	
										if( coveredB is false ){
											linksCount += mCC;
											int w = cmb.Index.Aggregate(0, (a,p)=> a| 1<<rcbList[p] );
											CoverLinkSet_no.Add(w); 
											coveredB = true;
										}
									}
								}
							}
							CoverLinkSet[no] = CoverLinkSet_no;
								
											if(debugPrint){
												var stLst = CoverLinkSet_no.ConvertAll(p=> p.ToBitString27rcb_Omit_null());
												string stL = string.Join("/",stLst);
												WriteLine( $" CoverLinkSet[#{no+1}]: ({stL})#{no+1}" );
											}
						}

						return  (linksCount, CoverLinkSet);
					}
		}


		private bool MSLS_SolResult( string MSLS_name, int noBF, int sectorB, UInt128 crossCells, int linksCount, List<int>[] CoverLinkSet, bool debugPrint ){
			UInt128 MSLSpat = qZero;
			string stExclude = "";
			bool solFound = false;

			string  stMSLSLinks="";//, stCoverLinks="";
			foreach( int no in noBF.IEGet_BtoNo(9) ){
				int noB=1<<no;

				List<int> CoverLinkSet_no = CoverLinkSet[no];
				var stLst = CoverLinkSet_no.ConvertAll(p=> p.ToBitString27rcb_Omit_null());
				string stL = string.Join("/",stLst);
				if( CoverLinkSet_no.Count > 1 )  stL = $"({stL.Trim()})";  
				stMSLSLinks  += $"{stL}#{no+1} ";

				UInt128 exclude = qZero;
				foreach( var P in CoverLinkSet_no ){
					foreach( int eh in P.IEGet_BtoNo(27) ){
						exclude |= (BOARD_Free81B9[no] & HouseCells81[eh]) & ~crossCells;
					}
				}
				if( exclude != qZero ){
					solFound = true;
					foreach( var uc in exclude.IEGet_UCell(pBOARD) )  uc.CancelB |= noB;
					string  stE = exclude.TBScmp();
					if( exclude.BitCount() >1 )  stE = $"({stE})";
					stExclude +=  $"{stE}#{no+1} ";
				}
			}
			stMSLSLinks = stMSLSLinks.Trim();
			stExclude = stExclude.Trim();


			if( solFound && pBOARD.Any(U=>U.FixedNo!=0 || U.CancelB>0) ){
				foreach( var h in sectorB.IEGet_BtoNo(27) ){						// 1)single(no overlap)
					(HouseCells81[h]&~crossCells).IE_SetNoBBgColor_All( pBOARD, noBF, AttCr, SolBkCr2 );
				}

				crossCells.IE_SetNoBBgColor_All( pBOARD, noBF, AttCr, SolBkCr3 );	// 2)intersection

				string st3OverLap = "";
				if( CellsOverlap[3] != qZero ){										// 3)Three layers overlap
					CellsOverlap[3].IE_SetNoBBgColor_All( pBOARD, noBF, AttCr, SolBkCr );
					st3OverLap = CellsOverlap[3].TBScmp();
				}

				SolCode = 2;
				int sz = sectorB.BitCount();	
				int szCells = (crossCells & ~BOARD_Fixed81).BitCount();

				string stL = $" Size: {sz}-sectors, {szCells}-Int.Cells, {linksCount}-Links"; 
				stL += $"\n sectors: {sectorB.ToBitString27rcb_Omit_null()}\n Digits: #{noBF.TBScmp()}";
				string name = (MSLS_name=="MSLS")? "Multi-Sector Locked Set": "MSLS_SK_Loop";

				ResultLong = $"{name}\n\n{stL}\n Links: {stMSLSLinks}";	//\n CoverLinks: {stCoverLinks}";
				if( st3OverLap != "" )  ResultLong += $"\n Triple overlap: {st3OverLap}";
				ResultLong += $"\n Exclude: {stExclude}";

				string stL0 = $" Size: {sz}/{szCells}/{linksCount}"; 
				stL0 += $" sectors: {sectorB.ToBitString27rcb_Omit_null()} Digits: #{noBF.TBScmp()}";
				Result	   = ($"{MSLS_name} {stL0}");		

				return true;
			}
				
			return false;

		}
    }
}