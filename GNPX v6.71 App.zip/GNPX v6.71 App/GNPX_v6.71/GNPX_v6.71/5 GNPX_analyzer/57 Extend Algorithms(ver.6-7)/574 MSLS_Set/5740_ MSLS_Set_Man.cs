using GIDOO_space;
using System;
using System.Buffers.Text;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Text;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
    public partial class MSLS_TechGen: AnalyzerBaseV2{

		private int stageNoPMemo = -9;	

		public (int,int,int) _ToRCB(int F)      => (F&0x1FF,(F>>9)&0x1FF,(F>>18)&0x1FF);
		public (int,int,int) _ToRCBCount(int F) => ((F&0x1FF).BitCount(),((F>>9)&0x1FF).BitCount(),((F>>18)&0x1FF).BitCount());
		public string ToStringSector(UInt128 F) => $"{(F&qMaxB81).TBS()}  {((int)(F>>100)).ToBitString27rcb()}";   

		public MSLS_TechGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }



		private IEnumerable<(int,int,UInt128)>  Generate_MSLS_SectorSet_Control( string  MSLS_name, bool debugPrint ){ 

			switch(MSLS_name){
				case "MSLS":	
					int MSLSMaxSize = G6.nud_MSLSMaxSize;

					for( int sz=2; sz<=MSLSMaxSize; sz++ ){
						if( pAnMan.Check_TimeLimit() ) yield break;	// @@@ Limit the search time.
						Combination cmbB = new( 27, sz );
						int nxt=99;
						while( cmbB.Successor(nxt) ){
							int houseB = cmbB.Index.ToList().Aggregate(0,(a,h)=> a| 1<<h);
							var (noB,MultiSelect81) = _Generate_MSLS_SectorSet_sub( houseB, debugPrint:debugPrint );
							yield return (noB,houseB,MultiSelect81);
						}			
					}
					break;
				// ----------------------------------------------------------------------------------------------------------

				case "SK_Loop":
					debugPrint = false;
					foreach( var cntrl in Generate_MSLS_SectorSet_SK_Loop( sz:12, debugPrint:debugPrint) )  yield return  cntrl;
					break;
/*
				case "FM":
					debugPrint = false;
					foreach( var cntrl in Generate_MSLS_SectorSet_FM( sz:12, debugPrint:debugPrint) )  yield return  cntrl;
					break;
*/
				// ----------------------------------------------------------------------------------------------------------
				default:
					string stException = $"\n\n MSLS_name : \"{MSLS_name}\" "
									   + "... Next development. Next development. Next development. Next development.\n"
									   + Environment.StackTrace;
					WriteLine( $"\n\n {stException}" );
					throw new Exception( $"Operation Error. MSLS_Type : {MSLS_name}");
			}
			yield break;
		}



		private IEnumerable<(int,int,UInt128)>  Generate_MSLS_SectorSet_SK_Loop( int sz, bool debugPrint ){ 
			foreach( int b0 in Enumerable.Range(0,9) ){
				List<int>  rc_List = new();
				int houseB0=0, Q;
				foreach( int r0 in (7&~(1<<(b0/3))).IEGet_BtoNo() ){ rc_List.Add( Q=0x7<<(r0*3) ); houseB0|=Q; }
				foreach( int c0 in (7&~(1<<(b0%3))).IEGet_BtoNo() ){ rc_List.Add( Q=0x7<<(c0*3+9) ); houseB0|=Q; }
				int house_b0rev = (0x1FF & ~(7<<(b0/3*3))  & ~(73<<(b0%3)) ) << 18;  // 7=1+2+4(Block Row)  73=1+8+64(Block Column)
						if(debugPrint){											
							WriteLine( $"  b0:{b0}" );
							foreach( var P in rc_List ){ WriteLine( $"    {P.ToBitString(27)} {P.ToBitString27rcb()}" ); }	
							WriteLine( $" house_b0rev: {house_b0rev.ToBitString(27)} {house_b0rev.ToBitString27rcb()}" );
						}
				

				var  houseB0List = houseB0.BitToNumList().ConvertAll(p=>p-1);

				Combination cmbB = new( houseB0.BitCount(), 4 );
				int nxt=99;
				while( cmbB.Successor(nxt) ){
					int houseB=0, m=0;
					for( int k=0; k<4; k++ ){
						houseB |= 1<<houseB0List[cmbB.Index[k]];											
						nxt=k;
						if( (rc_List[m]&houseB).BitCount() != 1 )  goto Lnext;
						m++;
					}
					houseB |= house_b0rev;
					var (noB,MultiSelect81) = _Generate_MSLS_SectorSet_sub( houseB, debugPrint:debugPrint );
					yield return (noB,houseB,MultiSelect81);

			  Lnext:
					continue;
				}
		
			}
			yield break;
		}


		private (int,UInt128) _Generate_MSLS_SectorSet_sub( int houseB, bool debugPrint ){  
			UInt128 MultiSelect81  = houseB.IEGet_BtoHouse27().Aggregate(qZero,(a,h)=>a|HouseCells81[h]);
			int noB = MultiSelect81.IEGet_UCell(pBOARD).Aggregate(0,(a,p)=>a| p.noB_FixedFreeB); //Collect digits in the cells contained
					if(debugPrint) G6_SF.__MatrixPrint( Flag:qZero, MultiSelect81, "Base81" );
			return (noB,MultiSelect81);
		}

		// ----------------------------------------------------------------------------------------------------------------

		private (UInt128,UInt128,UInt128) _Get_UInt128_Single_Two_More( int houseB, UInt128 Exclude, bool debugPrint=false ){  
			// Excluding the "Exclud" cells from the 81 cells on the board, the links are counted.
			// The links are determined from the overlap of sectors.
			UInt128 oneF=0, twoF=0, moreF=0;

			foreach( var h in houseB.IEGet_BtoNo(sz:27) ){
				UInt128 F = HouseCells81[h] & ~Exclude;     // Exclude some cells if needed
					if(debugPrint) G6_SF.__MatrixPrint( Flag:qZero, HouseCells81[h],BOARD_Fixed81,F, " HouseCells81[h],BOARD_Fixed81, HouseCells81[h]-BOARD_Fixed81" );
				moreF |= twoF & F;			// exist in more than two places
				twoF |= oneF & F;			// exist in more than one place
				twoF &= ~moreF;
				oneF |= F;                  // exist somewhere
				oneF &= ~(twoF|moreF);
			}
				if(debugPrint) G6_SF.__MatrixPrint( Flag:qZero, oneF,twoF,moreF, "oneF, twoF, moreF" );
			return (oneF,twoF,moreF);		// only one
		}

		private (UInt128,UInt128,UInt128) __Get_UInt128_Single_Two_More_with_HouseNo( int houseB, bool debugPrint=false ){  // ... for Debug
			string ToStringHouse(UInt128 F) => $"{(F&qMaxB81).TBS()}  {((int)(F>>100)).ToBitString27rcb()}";
			UInt128 oneF=0, twoF=0, moreF=0;

			foreach( var h in houseB.IEGet_BtoNo(sz:27) ){
				UInt128 F = HouseCells81[h] | (qOne<<(h+100));     // Exclude some cells if needed
					if(debugPrint) G6_SF.__MatrixPrint( Flag:qZero, HouseCells81[h], $"HouseCells81[{h}]" );
				moreF |= twoF & F;			// exist in more than two places
				twoF |= oneF & F;			// exist in more than one place
				twoF &= ~moreF;
				oneF |= F;                  // exist somewhere
				oneF &= ~(twoF|moreF);

				WriteLine( $"   F:{ToStringHouse(F)}\n   1:{ToStringHouse(oneF)}\n   2:{ToStringHouse(twoF)}\n   3:{ToStringHouse(moreF)}" );
			}
					if(debugPrint) G6_SF.__MatrixPrint( Flag:qZero, oneF, twoF, moreF, "oneF, twoF, moreF" );

			return (oneF,twoF,moreF);		// only one
		}



		private bool  _IsConnectedWhole( int houseB, bool debugPrint=false ){ 				
			List<UInt128>  houseList = houseB.IEGet_BtoNo(27).ToList().ConvertAll( h=> HouseCells81[h] | (qOne<<(h+100)) );
						//houseList.ForEach( P => WriteLine( ToStringHouse(P) ) ); 
			L_rerun:
			// If two CoverSets are connected, connect them into one.
			Combination cmb = new( houseList.Count, 2 );
			int nxt=9;
			while( cmb.Successor(nxt) ){
				UInt128 P=houseList[cmb.Index[0]], Q=houseList[cmb.Index[1]];
						//WriteLine( $"  P: {ToStringHouse(P)}\n  Q: {ToStringHouse(Q)}" );

				//if( ((P&qMaxB81) & (Q&qMaxB81) & BOARD_Fixed81) > qZero ){ // linked
				if( (P & Q & BOARD_Free81) > qZero ){ // linked with "free cells"
					houseList.Remove(P); houseList.Remove(Q); houseList.Add(P|Q);
						//houseList.ForEach( P => WriteLine( $"1: {ToStringHouse(P)}" ) ); 
					if( houseList.Count() == 1 )  return true; // Combined into one
					goto L_rerun;
				}
			}
			return  false; //(houseList.Count()==1);				
		}
    }
}