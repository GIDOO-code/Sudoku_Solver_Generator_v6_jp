using GIDOO_space;
using GNPX_space;
using System;
using System.Diagnostics;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv7)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);


    public partial class Exocet_TechGen: AnalyzerBaseV2{
		public  UInt128 Board81_Free_with_FreeB;
		private UInt128	Board81_Fixed_with_FreeB;
		private UInt128	Board81_Fixed_with_nonFreeB;

		private IEnumerable<UExocetA>  IE_Exocet_Generate_Unit( string ExoMtdName, bool debugPrint=false ){

			// ::: #1 Basic Form :::::::::::::::::::::::::::::::::::::
			foreach( UExocetA Exo in IE_Exocet_BasicForm( ExoMtdName:ExoMtdName, debugPrint:false) ){	
				_BaseObj_ = Exo.Base81;	//( for debug. ... G6_SF.__MatrixPrint(...) )
						//if( Exo.dir!=0 || Exo.rcStem!=2 )  continue;   // DEBAG Ver6.1 ===============

					{// BOARD Digits distribution ... Exocet constants used in analysis
						Board81_Fixed_with_FreeB    = BOARD_FixedB9_noB(Exo.FreeB);				  // Cells with confirmed Base candidate digits.
						Board81_Fixed_with_nonFreeB = BOARD_Fixed81 & ~Board81_Fixed_with_FreeB;  // Cells with confirmed non-Base candidate digits.
						Board81_Free_with_FreeB     = BOARD_FreeB9_noB( Exo.FreeB );			  // Freecell with Base candidate digits.
								if(debugPrint) G6_SF.__MatrixPrint( Flag:Exo.Base81, Board81_Fixed_with_FreeB, Board81_Fixed_with_nonFreeB, Board81_Free_with_FreeB,
												"Board81_Fixed_with_FreeB, Board81_Fixed_with_nonFreeB, Board81_Free_with_FreeB" );
					}

				// ::: #2 Cross-Line House numbers  :::::::::::::::::::::::::::::::::::::
					// [Att] The house number that defines the shape of the Exocet.
					//		 In the case of the Senior Exocet, this may differ from the Cross-Line's House depending on the Object definition.
				foreach( (int,int,int,int,int)  h012A in IE_Exocet_CrossLine( Exo, debugPrint:debugPrint) ){	
						//if(	h012A != (11,12,15,-1,-1) ) continue;   // DEBAG Ver6.1 ===============		

					// ::: #3 Objects :::::::::::::::::::::::::::::::::::::
					foreach( var (ExG0,ExG1,ExG2) in IE_Exocet_Object( Exo, debugPrint:false) ){
							//if( ExG1.Object81!=(qOne<<12|qOne<<21) || ExG2.Object81!=(qOne<<15|qOne<<24) )  continue;   // DEBAG Ver6.1 ===============	


						Exo.ExG0=ExG0; Exo.ExG1=ExG1; Exo.ExG2=ExG2;
						_BaseObj_ = Exo.Base81 | (ExG1.Object81 | ExG2.Object81 );	//( for debug. ... G6_SF.__MatrixPrint(...) )

						var (h0, h1, h2, h3, h4) = Exo.h012A;
						UInt128 CL0 = ExG0.CrossLine;
						UInt128 CL1 = ExG1.CrossLine;
						UInt128 CL2 = ExG2.CrossLine;
						UInt128 CL3 = (h3>=0)? HouseCells81[h3]: qZero;
						UInt128 CL4 = (h4>=0)? HouseCells81[h4]: qZero;	
						Exo.CL012A = (CL0, CL1, CL2, CL3, CL4);

						// ::: #4 Companion, SLine :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
						if( Set_Companion_and_Test(Exo, debugPrint:debugPrint) is false )  continue;	//###1022

						Set_Mirror(Exo, debugPrint:false);	
						if( Set_SLine_and_Test( Exo, debugPrint:false) is false )  continue;

						yield return Exo;
					}
				}
			}		
			yield break;
			// -------------------------------------------------------------------------------------------------------------
					void Set_Mirror( UExocetA Exo, bool debugPrint=false ){
						if( Exo.ExG0.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG1, Exo.ExG2 );
						if( Exo.ExG1.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG2, Exo.ExG0 );
						if( Exo.ExG2.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG0, Exo.ExG1 );

						void Set_Mirror_sub( UExocetA Exo, UCrossLine ExGA, UCrossLine ExGB ){
							ExGA.Mirror81 = HouseCells81[ExGB.ObjectBlockNo+18] & ~(Exo.Escape81 | Exo.CrossLine_012);
							if( ExGA.Object81.BitCount()==1 )  ExGA.Mirror81 &= ~HouseCells81[(Exo.dir,ExGA.rcTarget).DirRCtoHouse()];

							ExGB.Mirror81 = HouseCells81[ExGA.ObjectBlockNo+18] & ~(Exo.Escape81 | Exo.CrossLine_012);
							if( ExGB.Object81.BitCount()==1 )  ExGB.Mirror81 &= ~HouseCells81[(Exo.dir,ExGB.rcTarget).DirRCtoHouse()];

								if(debugPrint){
									G6_SF.__MatrixPrint( Flag:_BaseObj_, ExGA.Object81, ExGA.Mirror81, "ExGA.Object81, ExGA.Mirror81" );
									G6_SF.__MatrixPrint( Flag:_BaseObj_, ExGB.Object81, ExGB.Mirror81, "ExGB.Object81, ExGB.Mirror81" );
								}
						}
					}
		}
	}
}