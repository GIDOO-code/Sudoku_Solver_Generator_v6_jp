using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
    using POM3type = (UInt128,int,bool);
    public partial class PatternOverlayMethod_Man: AnalyzerBaseV2{

        public bool POM_Rule2_Interactions( ) => POM_Rule2_Interactions( Analysis_only:false );

        public bool POM_Rule2_Interactions( bool Analysis_only=false ){    // Interaction
                                                       
            // ===== Prepare =====
            POM_Prepare( );
            Simple_POM( PomSet );

//debugPrint = false;
		
			UInt128[] BOARD_Free81B9_Tmp = new UInt128[9];
            List<UInt128>[] PP_ListB9 = new List<UInt128>[9];
			foreach( var k in Enumerable.Range(0,9) ){
                BOARD_Free81B9_Tmp[k] = BOARD_Free81B9[k];
                PP_ListB9[k] = new List<UInt128>();											    // @ Patterns without interaction effects.
            }


        // ===== POM-Interactions analysis =====
            List<(int,int,int)>  POI_list = new();		// #no, pat, #no2
            foreach( int noE in FreeB.IEGet_BtoNo() ){	// ===== POI Rule-2
				foreach( var P in PomSet.POMU[noE] ){							// @ Assume that #noE k-pattern is true.

					bool IsInteraction = false;  
					{  //@ Confirmation of the interaction
						int noXB = 0; 
						foreach( int noX in FreeB.IEGet_BtoNo().Where(n=>n!=noE) ){

							if( (BOARD_Free81B9_Tmp[noX]&P.Pat81) == 0 )  continue;               // @ Skip if there is no impact from the assumption.

							// @ The pattern is affected by the assumptions.
							UInt128 BitPat = BOARD_Free81B9_Tmp[noX] & ~P.Pat81;
							var Q = Generate_POM_Pattern_List(noX, BitPat, debugPrint:false);   // @ Generate a pattern.
							
							if( Q==null || Q.Count==0 ){                                        // @ no patterns, the assumption is wrong.
                                IsInteraction = true;	
								POI_list.Add( (noE,P.sq,noX) );                                 // @ Record interactions.
                                break;
							}
						}
					}
					if(IsInteraction is false)	PP_ListB9[noE].Add(P.Pat81);					    // @ No interaction, then save the pattern.
                }
            }
            if( POI_list.Count == 0 )  return false;
           
            // @@ Set the results of the POM-Interactions analysis to the POM-pattern.
            foreach ( var (noE,kx,noX) in POI_list )  PomSet.POMU[noE][kx].InteractionB = true;  // Set InteractionB
        // ----------------------------------------------------------------------


                //WriteLine( POM_Pattern_ToString(PomSet.POMU, title: stPOMpattern) );
            PomSet.Set_Processed_Rules( ruleNo:2 );

            if( Analysis_only is false )   _POM_SolResult_Interactions( POI_list );      // ... Standard behavior
            return (SolCode > 0);
        }


     // : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

        private bool _POM_SolResult_Interactions( List<(int,int,int)>  POI_list=null ){
            stInteractions = "Interactions\n";
            if( POI_list is not null ){ 
                foreach ( var (noE,kx,noX) in POI_list ){
                    stInteractions += $"   #{noE+1} pat_{kx} -> #{noX+1}\n";
                }
                stInteractions += "\n\n";
            }
            extResult = "";  
            foreach ( int noE in FreeB.IEGet_BtoNo() ){
                // In the case of "Single Pattern,"
                //  there is a possibility of matching both "all-pattern" and "no-pattern."      

                // ===== All Pattern ==========
                var AllPattern = PomSet.POMU[noE].Where(p=>p.avail).Aggregate(qMaxB81, (a,u) => a& u.Pat81);
                if( AllPattern != null ){	// === All Pattern ===
                    extResult = stInteractions;
                    string POMName = "Pattern Overlay Interaction";
                    bool solFound = POM_SolResult_AllPattern( POMName, no:noE, AllPattern);
                    if( solFound ){
                        SolCode = 1;
                        if (!pAnMan.IsContinueAnalysis()) return true;
                    }
                }

                // ===== No Pattern ==========
                var NoPattern = BOARD_Free81B9[noE] & ~PomSet.POMU[noE].Where(p=>p.avail).Aggregate(qZero, (a,u) => a| u.Pat81);
				if( NoPattern != null){       // === No Pattern ===	
                    extResult = stInteractions;
                    string POMName = "Pattern Overlay Interaction";
                    bool solFound = POM_SolResult_NoPattern( POMName, no: noE, NoPattern);
                    if ( solFound ){
						SolCode = 2;
						if (!pAnMan.IsContinueAnalysis()) return true;
					}
				}
			}

            return (SolCode > 0);
        }

        
	}
}