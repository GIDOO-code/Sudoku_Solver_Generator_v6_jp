using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Windows.Documents;
using System.Windows.Media;

using GIDOO_space;

using Microsoft.VisualBasic;

using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
    using POM3type = (UInt128,int,bool);
    public partial class PatternOverlayMethod_Man: AnalyzerBaseV2{

        public ExtendedNetwork_App eNW;
        public eNW_Man             eNWobj => eNW.eGLink_ManObj;



        public bool POM_Rule3_NiceLoop_Contradiction( )      => POM_NiceLoop_Contradiction_Base( szPOM_min:2, szPOM_max:20 );
      //public bool POM_Rule3_NiceLoop_Contradiction0202( )  => POM_NiceLoop_Contradiction_Base( szPOM_min:2, szPOM_max:2 ); 
      //public bool POM_Rule3_NiceLoop_Contradiction0320( )  => POM_NiceLoop_Contradiction_Base( szPOM_min:3, szPOM_max:20 ); 

        public bool POM_NiceLoop_Contradiction_Base( int szPOM_min=2,int szPOM_max=2 ){    // Interaction      

            // ===== Prepare =====
            POM_Prepare( );

            // If Rule 2 has not been executed, execute Rule 2.
            if( PomSet.Check_IsProcessed(ruleNo:2) is false )  POM_Rule2_Interactions( Analysis_only:true );
                    if(debugPrint) WriteLine( POM_Pattern_ToString(PomSet.POMU, title: stPOMpattern) );
          
//Simple_POM( PomSet );
//eNW_Link.debugPrint = true;
//debugPrint = true;

            // ----- eNetwork Setup
            eNW = new( pAnMan);
            eNW.eNW_Prepare( ALS_plus:2, minSize:2 );
	                    int  searchCC = PomSet.POMU.Where(p=>p!=null && (p.Count>=szPOM_min && p.Count<=szPOM_max) ).Sum(p=>p.Count);
                        int  patternCC_X = 0;
                        double FreeBC_T = 100.0 / searchCC;

            List<eNW_Link>[,]  eNListList = new List<eNW_Link>[2,PomSet.POMU.Count()];


            foreach( var (POMPatLst,no) in PomSet.POMU.WithIndex().Where(p=> p.item!=null) ){
                int POM_State_Func( PomUnits PS,int no) => (PS.POMU[no]==null)? -1: Min( PS.POMU[no].Count(p=>p.avail), 3 );   //@@@@@

                int POM_State = POM_State_Func(PomSet,no);  
                        //WriteLine( $"@@@@@ szPOM_min:{szPOM_min} POM_Statte:{POM_State}  {((POM_State==1)? " single":"" )}" );  
        
                if( POM_State == 1 ){   //POM_single
                    UInt128 POM_singlePattern = POMPatLst.Find(p=>p.avail) .Pat81;
                    POM_SolResult_AllPattern( "POM_Rule-2 Interactions", no, POM_singlePattern );
                    POM_SolResult_NoPattern( "POM_Rule-2 Interactions", no, POM_singlePattern );
                				
                    SolCode = 2;
					if (!pAnMan.IsContinueAnalysis()) return true;
                    continue;
                }

                if( szPOM_min != POM_State )  continue;
                int POM_patten_no = POMPatLst.Count(p=>p.avail);
                if( POM_patten_no > G6.nud_NL_POM_pattern_Max )  continue;
                if( POM_patten_no<szPOM_min || POM_patten_no>szPOM_max )  continue;


                        double ratio = (++patternCC_X) * FreeBC_T;
                        G6.Additional_Message = $"  {ratio:F1} % ({patternCC_X}/{searchCC})"; // for Progress Report


                int POMPat_neg = POMPatLst.WithIndex().Where(p=>p.item.avail).Aggregate(0,(a,b)=>a|1<<b.item.sq);
                int POMPat_pos = 0;
                int noB = 1<<no;
                string stPOM = $"POM Pattern #{no+1}\n";
                string stPOM_neg = "";
                ULogical_Node ULGstart=null;
                int kxPositive = -1;

                foreach( var (UPom,kx) in POMPatLst.WithIndex().Where(p=>p.item.avail) ){
                                if(debugPrint)  WriteLine( $"\n@@@ POM #{no+1} _Pattern_ {kx} {UPom.Pat81.TBS()}" );
                    ULGstart = new( noB9:noB, b081:UPom.Pat81, pmCnd:1, ID:-1, hNo:-1 );


                    // extNW_QSearch_Radical_Multi
                    var (solType,eL_tail) = eNWobj.extNW_QSearch_Radical( ULGstart, rcno_Break:(-1,-1), rcProhibit:qZero, debugPrint:debugPrint );
                                if(debugPrint){
                                    WriteLine( $"\n@@@POM  solType:{solType} eL_tail:{eL_tail}" );
                                    _debug_RoutePrint( eL_tail.eN_Des_nPM );
                                }   

                    if( solType == 3 ){ // Found Contradiction;  
                        POMPat_neg &= ~(1<<kx);  
                        eNW_Node eN_Des = eL_tail.eN_Des_nPM;
                        var (stLM,stLP,eNList) = eNWobj.Get_ContradictionLinks_Info( eN_Des );
                        
                        stPOM_neg += $"\n\n{new string('-',80)}\n #{no+1} Pattern-{kx} is Contradiction \n{stLP}\n{stLM}";
                        eNListList[0,kx] =  eNList[0];
                        eNListList[1,kx] =  eNList[1];
                    }
                    else{
                        POMPat_pos |= (1<<kx);
                        if( POMPat_pos.BitCount() >=2 )  goto LineBreak; // It was confirmed that this algorithm cannot verify that it is true.
                        kxPositive = kx;
                        eNListList[0,kx] = eNListList[1,kx] =  null;
                    }
                    string stPE = (solType==3)? "-negative": "+positive";
                    stPOM += $"\n  pattern[{kx}] {UPom.Pat81.TBS()}  {stPE}";
                }  
                
                if( kxPositive>=0 && POMPat_neg.BitCount()==1 ){
                    _NiceLoopExtPOM_SolResult_Contradiction_base( ULGstart, kxPositive, stPOM+stPOM_neg, eNListList ); 

        			SolCode = 2;
					if (!pAnMan.IsContinueAnalysis()) return true;
                }

              LineBreak:
                continue;
            }

            G6.Additional_Message = "";
            return (SolCode > 0);
            // ==========================================================================================================

                void _debug_RoutePrint( eNW_Node eND ){
                    // Trace the path from the eND and display the sequence of links leading to the search starting point.
                    // P(+) indicates that the eND is on the true path; M(-) indicates that the eND is on a false path.
                    var (stLM,stLP,eNList) = eNWobj.Get_ContradictionLinks_Info( eND );
                    WriteLine( $"{stLP}\n{stLM}" );
                }

            
                void _NiceLoopExtPOM_SolResult_Contradiction_base( ULogical_Node ULGstartNeg, int kxPositive, string stPOM_neg, List<eNW_Link>[,] eNListList){
                    int  no=ULGstartNeg.no, noB=1<<no;
                    
                    List<PomUnit> POM_Pat_no = PomSet.POMU[no];
                    PomUnit  POM_Pos = POM_Pat_no[kxPositive];
                    UInt128  excludePom = BOARD_Free81B9[no] & ~POM_Pos.Pat81;

                    foreach( UCell uc in excludePom.IEGet_UCell(pBOARD))  uc.CancelB = noB;
                    foreach( UCell uc in POM_Pos.Pat81.IEGet_UCell(pBOARD))  uc.FixedNo = no+1;

                    int nx = 0;
                    for( int k=0; k<POM_Pat_no.Count; k++ ){
                        if( k==kxPositive || eNListList[0,k]==null )  continue;
                        foreach( var P in eNListList[0,k] ){
                            Color cr = PastelColors[(nx++)%100];
                            P.eObject.IE_SetNoBBgColor(pBOARD,(1<<P.noOrg | 1<<P.noDes),AttCr,cr);
                        }
                        var Q = eNListList[0,k].Last();

                        foreach( var P in eNListList[1,k] ){
                            Color cr = PastelColors[(nx++)%100];
                            P.eObject.IE_SetNoBBgColor(pBOARD,(1<<P.noOrg | 1<<P.noDes),AttCr,cr);
                        }
                        //var Q2 = eNListList[1,k].Last(); // Q2 is the same as Q, where the contradiction occurred.
                        pBOARD[Q.DesN.rc].Set_CellFrameColor(AttCr5);
                    }            

                    // result report 
			        string st2 = $"{POM_Pattern_no_ToString(no,POM_Pat_no,"")}";
                    string st3 = $" Fixed : {POM_Pos.Pat81.TBScmp()} #{no+1}.";
                    st3 += $"\n Exclude : {excludePom.TBScmp()} #{no+1}";

                    ResultLong = $"POM NiceLoop Contradiction\n {st3}";
                    Result     = $"POM NL Contradiction {st3.Replace("\n","").Replace(" : ",":")}";

                    extResult = $"POM NiceLoop Contradiction\n\n {st3}\n\n{stPOM_neg}\n";
                }
        }                
	}
}