using GIDOO_space;
using System;
using System.Buffers.Text;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Text;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;

    public partial class PatternOverlayMethod_Man: AnalyzerBaseV2{

        private class PomUnit: IComparable{
			public int     sq;
			public int	   no;
			public UInt128 Pat81;

			public bool    hit;
			public bool    InteractionB;

			public int     no2B;			// for  Lv2 Interaction 
			public bool    InteractionBLv2; // for  Lv2 Interaction 

			public bool	   avail => !InteractionB;	//

            public PomUnit( int sq, int no, UInt128 pat81, bool InteractionB ){
				this.sq=sq; this.no=no; this.Pat81=pat81; this.InteractionB = InteractionB;
            }

			public int CompareTo( object obj ){  // for IComparable. ... don't delete
				PomUnit? PU = obj as PomUnit;
				if( this.no != PU.no )  return (this.no-PU.no);
				if( this.sq != PU.sq )  return (this.sq-PU.sq);
				return  this.no2B-PU.no2B;
			}

			public string ToStringLv2(){
				string st = $"#{no+1} _ {sq}] #{no2B.TBS()} is excluded due to an interaction effect.";
				return st;
			}
		}


		private class PomUnits{
			private int				 Processed_Rules;
			public  List<PomUnit>[]  POMU;
		//	public  int avail_Patt_Count(int no) => POMU[no].Count(q=> q.avail);

			public PomUnits( ){
				POMU = new List<PomUnit>[9];
			}

			public int  Set_Processed_Rules( int ruleNo ) => Processed_Rules |= (1<<ruleNo);
			public bool Check_IsProcessed( int ruleNo )  => (Processed_Rules & (1<<ruleNo)) > 0;
		}



        private int stageNoPMemo = -9;	


        private int			    _noFixedCC_;
		private int			    _POM_StageNo_;	   
		private int[]		    _DecisionA_ = new int[10];	//( 10 is used for recursive processing.
		private bool		     debugPrint = false;
	
		private int				FreeB;
		private PomUnits		PomSet;
		//private  List<PomUnit>[]  PomSet.POMU;
		internal List<UInt128>    __PatNoList__;
        private string			stInteractions = "";

//		private List<PomUnit>[]	   BOARD_Free81B9_POM;


// Templates + ALS Hybrid

        private string stPOMpattern = "\n@HTML_Delete@\n\n" /*+ new string('-',100)*/ + "\n\n  POM Patterns";
        private string stInteration(PomUnit P ) => P.InteractionB? $"Disabled by interaction{(P.InteractionBLv2? " Lv2":"")}": "";

        public PatternOverlayMethod_Man( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }


        public void POM_Prepare( bool debugPrint=false ){
            if (stageNoP != stageNoPMemo){
                stageNoPMemo = stageNoP;
                base.AnalyzerBaseV2_PrepareStage();

                FreeB = pBOARD.Where(u=>u.No==0).Aggregate(0,(a,u)=> a |= u.FreeB);
				PomSet = new();
				foreach( int no in FreeB.IEGet_BtoNo() ){
					var Q = Generate_POM_Pattern_List(no, BOARD_Free81B9[no], debugPrint: debugPrint);
					int sq = 0;
					PomSet.POMU[no] = Q.ConvertAll( q => new PomUnit(sq++,no,q,false) );
				}
			}
//            BOARD_Free81B9_POM = new List<PomUnit>[9];
            return;
		}



		private string POM_Pattern_ToString( List<PomUnit>[] qPOM_Pattern_ListB9, string title="POM patterns", string stPOMLv2=""){
            FreeB = pBOARD.Where(u => u.No == 0).Aggregate(0, (a, u) => a |= u.FreeB);

			string st = title + stPOMLv2;
            foreach ( int no in FreeB.IEGet_BtoNo()){
				st += $"\n\n  #{no+1}";
				st += $"\n      BOARD: {BOARD_Free81B9[no].TBScells()}";
				foreach( var P in qPOM_Pattern_ListB9[no]) st += $"\n_Pattern_{P.sq,2}: {P.Pat81.TBS()} {stInteration(P)}";
            }
			return st;
		}

		private string POM_Pattern_no_ToString( int no, List<PomUnit> qPOM_Pattern_ListB9_no, string title="POM patterns" ){
			string st = $"      BOARD: {BOARD_Free81B9[no].TBScells()}";
			foreach( var P in qPOM_Pattern_ListB9_no ) st += $"\n_Pattern_{P.sq,2}: {P.Pat81.TBS()} {stInteration(P)}";
			return st;
		}



		//########################################################################################
		private bool Simple_POM( PomUnits PomSet ){
			// under development. 

			bool SolvedB = false;
			// Rule-1
			UInt128 R;
			foreach (int no in FreeB.IEGet_BtoNo().Where(n => PomSet.POMU[n] != null)){
				var AllPattern = PomSet.POMU[no].Where(p=>p.avail).Aggregate(qMaxB81, (a, u) => a & u.Pat81);	// ... All Pattern
				if( AllPattern!=null && AllPattern>qZero ){
					SolvedB = true;
					List<PomUnit> PP = PomSet.POMU[no];

					//WriteLine( $"{stSimplePOS(no, PP)}" );
				}
			}

			return SolvedB;

					string stSimplePOS( int no, List<PomUnit> PP ){
						string stPOM = $"#{no + 1} Fixed";
						stPOM += $"\n___Board[#{no + 1}]: {BOARD_Free81B9[no].TBS()}";
						foreach( var P in PP )  stPOM += $"\n_Pattern[{P.sq,2}]: {P.Pat81.TBS()} {stInteration(P)}";
						return stPOM;
					}

		}
/*
		private void  Check_BOARD_Free81B9_POM(){
			foreach( int no in Enumerable.Range(0,9) ){
				WriteLine( $"\n #{no+1} Base: {BOARD_Free81B9[no].TBScc()}\n     POM: {BOARD_Free81B9[no].TBScc()}" );
			}
		}
*/


       // NZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZNZ

        private List<UInt128> Generate_POM_Pattern_List( int no, UInt128 BitPat, bool debugPrint=false ){

            _noFixedCC_ = BOARD_Fixed81B9[no].BitCount();
			
			__PatNoList__ = new();
			UInt128  Used=qZero, SolutionB=qZero;	
			_POM_StageNo_ = -1;
			_Search_BitPattern_Recursive( no, BitPat, Used );

            return __PatNoList__;
		
				(bool,int)  _Search_BitPattern_Recursive( int no, UInt128 BnoTmp, UInt128 Used, int rcStart=0){	
					_POM_StageNo_++;

				  LreSearch:
					int rcSel = (BnoTmp&~Used).FindFirst_rc(rcStart);	// next candidate
					_DecisionA_[_POM_StageNo_] = (rcSel>=0)? rcSel: -9999;

					if( rcSel >= 0 ){
						// Variables for each stage
						UInt128  Selected = qOne<<rcSel;
						UInt128  Used2 = Used | Selected;
						UInt128  BnoTmp2  = BnoTmp & ~Connected_81[rcSel];
				
						var (cancelB,rcRet) = _Search_BitPattern_Recursive( no, BnoTmp2, Used2, rcStart:0 );	// Proceed to the next stage
						_POM_StageNo_--;
						if( cancelB && _POM_StageNo_>=0 ){
							if( _POM_StageNo_>=0 && rcRet>=0 ){
								if( _DecisionA_[_POM_StageNo_] == rcRet ){
									BnoTmp &= ~(qOne<<rcRet);	// Restore current status:
									goto  LreSearch;
								}
								else{ return (true,rcRet); }
							}
							else{  return (false,-999); }
						}

						if( rcRet < 0 ){	// If it fails, disable rcSel and try again.
							Used |= Selected;	
							goto LreSearch;	
						}
					}

					if( _noFixedCC_+BnoTmp.BitCount() == 9 )	__PatNoList__.Add( BnoTmp );

					// Renegate the decision made in the previous stage.
					int rcLast = Used.FindLast_rc();
					if( rcLast >= 0 ){ return (true,rcLast); }			
					return (false,-1);
				}
		}
    }
}