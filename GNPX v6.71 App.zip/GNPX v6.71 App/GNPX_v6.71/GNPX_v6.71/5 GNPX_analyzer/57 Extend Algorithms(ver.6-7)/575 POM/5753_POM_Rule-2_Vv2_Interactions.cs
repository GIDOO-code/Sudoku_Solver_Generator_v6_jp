using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Windows.Shapes;

using GIDOO_space;

using Microsoft.VisualBasic;

using Windows.Media.Audio;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
    using POM3type = (UInt128,int,bool);
    public partial class PatternOverlayMethod_Man: AnalyzerBaseV2{

        public bool POM_Rule2_Lv2_Interactions( ) => POM_Rule2_Lv2_Interactions( Analysis_only:false );

        public bool POM_Rule2_Lv2_Interactions( bool Analysis_only=false ){    // Interaction
                                                       
            // ===== Prepare =====
            POM_Prepare( );
            Simple_POM( PomSet );

            //@@ The number of POM patterns is limited to a max. 32. It is also possible to switch to the Uint128 type.
            int PomSize_Max = PomSet.POMU.ToList().ConvertAll(p=>p.Count()).Aggregate(0,(a,b)=>Max(a,b));
            if( PomSize_Max > 31 )  return false;


//debugPrint = true;

            // If Rule 2 has not been executed, execute Rule 2.
            if( PomSet.Check_IsProcessed(ruleNo:2) is false )  POM_Rule2_Interactions( Analysis_only:true );
                            if(debugPrint) WriteLine( POM_Pattern_ToString(PomSet.POMU, title: stPOMpattern) );


            // ===== POM-Interactions Lv2 analysis =====
            List<PomUnit>  POM_IntsLv2A_List = new();

            foreach( var (no1,no2) in _Gen_noPair(PomSet) ){

                int[] POM_IE = new int[PomSet.POMU[no1].Count];     // Interaction Effect;
                int pat2tmp = PomSet.POMU[no2].WithIndex().Where(p=>p.item.avail). Aggregate(0, (a,b) => a | 1<<b.item.sq);
                foreach( var (pat,kx1) in PomSet.POMU[no1].WithIndex() )  POM_IE[kx1] = (pat.avail is true)?  pat2tmp: 0;

                // @ Test Interaction Level2
                int avail_no1 = PomSet.POMU[no1].Where(p=>p.avail).Aggregate(0, (a,b)=> a| (1<<b.sq));
                int avail_no2 = PomSet.POMU[no2].Where(p=>p.avail).Aggregate(0, (a,b)=> a| (1<<b.sq));
                foreach( var (P1,pt1) in PomSet.POMU[no1].WithIndex().Where(p=>p.item.avail) ){					 // @ Assume that #no1 P1-pattern is true.
                    foreach( var (P2,pt2) in PomSet.POMU[no2].WithIndex().Where(p=>p.item.avail) ){				 // @ Assume that #no2 P2-pattern is true.
                        bool IsInteraction = false;
                        int noE = (1<<no1) | (1<<no2);
                        foreach( int noX in FreeB.IEGet_BtoNo().Where(n=> (noE&(1<<n))==0) ){
                            UInt128 pat12_and = P1.Pat81 & P2.Pat81;
                            if( pat12_and > qZero )  IsInteraction = true;
                            else{
                                UInt128 BitPat = BOARD_Free81B9[noX] & ~P1.Pat81 & ~P2.Pat81;                    // @ The pattern is affected by the assumptions.
							    var Q = Generate_POM_Pattern_List(noX, BitPat, debugPrint:false);                // @@ Generate a pattern.
                                if( Q==null || Q.Count==0 ) IsInteraction = true;                                // @ no patterns, the assumption is wrong.
                            }

                            if( IsInteraction )  POM_IE[pt1] &= ~(1<<pt2);
                        }
                    }
                }
                int no2cc = PomSet.POMU[no2].Count;
                            if(debugPrint){
                                WriteLine($"{new string(' ',40)} {avail_no2.TBS(no2cc)}" );
                                foreach( var (pat,kx1) in PomSet.POMU[no1].WithIndex() ){
                                    WriteLine( $"              ----- no1:#{no1+1} no2:#{no2+1} [{kx1}] {(avail_no1>>kx1)&1,1}: {POM_IE[kx1].TBS(no2cc)}" ); 
                                }
                            }
                var Pcol = avail_no2;
                foreach( var Pat1 in PomSet.POMU[no1] ){
                    if( ((avail_no1>>Pat1.sq)&1)==1 && POM_IE[Pat1.sq]==0 ){
                        Set_Lv2Interaction( POM_IntsLv2A_List, PomSet.POMU[no1][Pat1.sq], no2 );
                    }
                    Pcol &= ~POM_IE[Pat1.sq];
                }
                foreach( var pat2 in Pcol.IEGet_BtoNo(no2cc) ){
                    Set_Lv2Interaction( POM_IntsLv2A_List, PomSet.POMU[no2][pat2], no1 );
                }
            }

            POM_IntsLv2A_List.Sort( );
                            if(debugPrint) foreach( var Q in POM_IntsLv2A_List )  WriteLine( $" **** POM_IntsLv2A_List : {Q.ToStringLv2()}" );

            if( Analysis_only is false )   _POM_SolResult_Lv2_Interactions( POM_IntsLv2A_List,Analysis_only );      // ... Standard behavior

            return (SolCode > 0);

                 // : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

                    IEnumerable<(int,int)> _Gen_noPair( PomUnits POMU ){
                        List<int> noCountList = new();
                        foreach( int no in Enumerable.Range(0,9)){ 
                            if( PomSet.POMU[no]!=null )  noCountList.Add( PomSet.POMU[no].Count(p=>p.avail)<<16 | no );
                        }
                        noCountList.Sort();
                        noCountList = noCountList.ConvertAll(p=>p&0xFF);

                        Combination cmb = new( noCountList.Count, 2 );
                        while( cmb.Successor() )  yield return (noCountList[cmb.Index[0]], noCountList[cmb.Index[1]]);
                        yield break;
                    }

                    void Set_Lv2Interaction( List<PomUnit> POM_IntsLv2A_List, PomUnit POMU , int no2 ){
                        PomUnit? Q = POM_IntsLv2A_List.Find( q=> (q.no==POMU.no) && (q.sq==POMU.sq) );
                        if( Q == null )  POM_IntsLv2A_List.Add( Q=POMU );
                        Q.no2B |= (1<<no2);
                        Q.InteractionBLv2 = Q.InteractionB = true;
                    }
        }




        private bool _POM_SolResult_Lv2_Interactions( List<PomUnit> POM_IntsLv2A_List, bool Analysis_only ){
            if( POM_IntsLv2A_List==null || POM_IntsLv2A_List.Count==0 )  return false;  
//            stInteractions = "\n  Iinteraction LV2_effect.\n";
//            foreach( var Q in POM_IntsLv2A_List ) stInteractions += $"    #{Q.no+1} pat.{Q.sq,2} <--> #{Q.no2B.TBS()}\n";
//            stInteractions += "\n\n";
                    
            string POMName = "Pattern Overlay Interaction Lv2";
            string stPOMLv2 = $"\n@HTML_Delete@ {Set_stInteractions(POM_IntsLv2A_List,-1)}\n {new string('-',100)}";
            foreach ( int noE in FreeB.IEGet_BtoNo() ){
                // In the case of "Single Pattern", there is a possibility of matching both "all-pattern" and "no-pattern."      

                        // ===== All Pattern ==========
                var AllPattern = PomSet.POMU[noE].Where(p=>p.avail).Aggregate(qMaxB81, (a,u) => a& u.Pat81);
                if( AllPattern != null ){	// === All Pattern ===
                    extResult = POMName + "\n"+ Set_stInteractions(POM_IntsLv2A_List,noE);
                    bool solFound = POM_SolResult_AllPattern( POMName, no:noE, AllPattern, stPOMLv2);
                    if( solFound ){
                        SolCode = 1;
                        if (!pAnMan.IsContinueAnalysis()) return true;
                    }
                }

                // ===== No Pattern ==========
                var NoPattern = BOARD_Free81B9[noE] & ~PomSet.POMU[noE].Where(p=>p.avail).Aggregate(qZero, (a,u) => a| u.Pat81);
				if( NoPattern != null){       // === No Pattern ===	
                    extResult = POMName + "\n"+ Set_stInteractions(POM_IntsLv2A_List,noE);
                    bool solFound = POM_SolResult_NoPattern( POMName, no: noE, NoPattern, stPOMLv2);
                    if( solFound ){
						SolCode = 2;
						if (!pAnMan.IsContinueAnalysis()) return true;
					}          
				}
			}

            return (SolCode > 0);

                    string Set_stInteractions( List<PomUnit> POM_IntsLv2A_List, int no=-1 ){
                        string st = " Iinteraction LV2_effect.\n";
                        int noB = (no<0)? 0x1FF: (1<<no);
                        foreach( var Q in POM_IntsLv2A_List.Where(q=> (noB&(1<<q.no)) >0) ) st += $"    #{Q.no+1} pat.{Q.sq,2} <--> #{Q.no2B.TBS()}\n";
                        st += "\n";
                        return st;
                    }
        }



        
	}
}