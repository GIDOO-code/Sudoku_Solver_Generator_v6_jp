using GIDOO_space;
using Microsoft.VisualBasic;
using System;
using System.Buffers.Text;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Sockets;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
	using colorWM = System.Windows.Media.Color;
    public partial class PatternOverlayMethod_Man: AnalyzerBaseV2{

        public bool POM_Rule1_all_no_Patten( ){

			// ===== Prepare =====
			POM_Prepare( );

            extResult = "";
			foreach( int no in FreeB.IEGet_BtoNo().Where(n=> PomSet.POMU[n]!=null) ){
                var pPattern = PomSet.POMU[no];
                var AllPattern = pPattern.Aggregate(qMaxB81, (a, u) => a & u.Pat81);					 // ... All Pattern
                if( AllPattern != null ){		// === All Pattern ===		
					string POMName = "Pattern Overlay Method";
                    bool solFound = POM_SolResult_AllPattern( POMName, no:no, AllPattern );
					if( solFound ){
						SolCode = 1;
						if (!pAnMan.IsContinueAnalysis()) return true;
					}
				}

                var NoPattern = BOARD_Free81B9[no] & ~pPattern.Aggregate(qZero, (a, u) => a | u.Pat81);  // ... No Pattern
                if( NoPattern != null){       // === No Pattern ===		
                    string POMName = "Pattern Overlay Method";
                    bool solFound = POM_SolResult_NoPattern( POMName, no:no, NoPattern );
					if( solFound ){
						SolCode = 2;
						if (!pAnMan.IsContinueAnalysis()) return true;
					}
				}
			}
            return (SolCode>0);
		}


		//-------------------------------------------------------------------------------------------------

		private bool POM_SolResult_AllPattern( string POMName, int no, UInt128 POM_allPattern_no, string stPOMLv2="" ){

            foreach( var U in POM_allPattern_no.IEGet_UCell(pBOARD))  U.FixedNo = no+1;
            int cnt = pBOARD.Count(U => (U.FixedNo != 0));

			if( cnt>0 ){
				SolCode = 1;

				int noB = 1<<no;
				int crLstSize = PastelColors.Length;
				foreach( var (POM,kx) in PomSet.POMU[no].WithIndex() ){//.Where(p=>p.item.avail) ){
	                colorWM cr = PastelColors[ kx%crLstSize ];
					UInt128 remainingCells = BOARD_Free81B9[no] & ~POM_allPattern_no;
                    if( remainingCells > qZero )  remainingCells .IE_SetNoBBgColor(pBOARD,noB,AttCr,cr);
				}

				string stFixed = POM_allPattern_no.TBScmp();
				if( cnt > 1 ) stFixed = $"({stFixed})";

				string stE = "", stPOM = "";
				stE += $" {stFixed}#{no+1}";
				stPOM += $"#{no+1} Fixed";
				stPOM += $"\n___Board[#{no + 1}]: {BOARD_Free81B9[no].TBS()}";
				foreach (var (P, nx) in PomSet.POMU[no].WithIndex()) stPOM += $"\n_Pattern[{P.sq,2}]: {P.Pat81.TBS()} {stInteration(P)}";
				stPOM += $"\n_______Fixed: {POM_allPattern_no.TBScells()}";

				string mName = POMName.Replace("Pattern Overlay Method","POM").Replace("Pattern Overlay Interaction", "POI");
                ResultLong = $"{POMName} _ All Pattern Fixed\n\n   Fixed: {stE.Trim()}";

				Result = $"{mName}_All-Pattern Fixed: {stE.Trim()}";

				extResult += $"{POMName} _ All Pattern Fixed\n\n Fixed: {stE.Trim()}\n\n@HTML@{stPOM}";  // @HTML@: for HTML
				extResult += POM_Pattern_ToString(PomSet.POMU, title:stPOMpattern, stPOMLv2);
			}

            return (SolCode > 0);
		}


		//-------------------------------------------------------------------------------------------------
		private bool POM_SolResult_NoPattern( string POMName, int no, UInt128 POM_noPattern_no, string stPOMLv2="" ){
		
			int noB = 1<<no;
			foreach( var U in POM_noPattern_no.IEGet_UCell(pBOARD) )  U.CancelB |= (U.FreeB&noB);
			int cnt = pBOARD.Count(U=>(U.CancelB&noB)>0);

			if( cnt > 0 ){
				SolCode = 2;

				int crLstSize = PastelColors.Length;
				foreach( var (POM,kx) in PomSet.POMU[no].WithIndex() ){
                    colorWM cr = PastelColors[ kx%crLstSize ];
                    (POM.Pat81& ~POM_noPattern_no) .IE_SetNoBBgColor(pBOARD,noB,AttCr,cr);
				}

				string stExclude = POM_noPattern_no.TBScmp();
				if( cnt>1 ) stExclude = $"({stExclude})";

				string stE="", stPOM="";
				stE += $" {stExclude}#{no+1}";
						
				if( stPOM != "" )  stPOM += "\n";
				stPOM += $"\n#{no+1} Exclude";
				stPOM += $"\n___Board[#{no+1}]: {BOARD_Free81B9[no].TBS()}";
				foreach( var P in PomSet.POMU[no] )  stPOM += $"\n_Pattern[{P.sq,2}]: {P.Pat81.TBS()} {stInteration(P)}";
                stPOM += $"\n_____Exclude: {POM_noPattern_no.TBScells()}";

                string mName = POMName.Replace("Pattern Overlay Method", "POM").Replace("Pattern Overlay Interaction", "POI");
                ResultLong = $"{POMName} _ No Pattern exclusion\n\n   Exclued: {stE.Trim()}";

                Result = $"{mName}_No-Pattern exclusion: {stE.Trim()}";

                extResult += $"{POMName} _ No Pattern Exclusion\n\n Exclued: {stE.Trim()}\n\n@HTML@{stPOM}";  // @HTML@: for HTML
				if( stPOMLv2!="" )  extResult += $"\n{stPOMLv2}";
				extResult += POM_Pattern_ToString(PomSet.POMU, title: stPOMpattern, stPOMLv2);
            }

			return (SolCode>0);	
		}
	}
}