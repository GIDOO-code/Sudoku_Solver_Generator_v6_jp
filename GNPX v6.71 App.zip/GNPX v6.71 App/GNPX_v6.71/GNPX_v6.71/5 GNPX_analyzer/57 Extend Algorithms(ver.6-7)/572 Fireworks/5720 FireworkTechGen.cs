using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.IO;
using System.Text;
using System.Security.Policy;

namespace GNPX_space{

    public partial class Firework_TechGen: AnalyzerBaseV2{
        static private   UInt128 qZero  = UInt128.Zero;
        static private   UInt128 qOne   = UInt128.One; 
		private int		 stageNoPMemo = -9;

		public UInt128   BOARD_Free81;

		public List<UFirework> Firework_List;	
		public List<UFirework> FireworkAgg_List;

	#region 4Debug
		internal bool		debugPrint = false;
		internal string     debug_Result = "";
		internal string		fName_debug = "Firework_Triple.txt";	
	#endregion 4Debug


		public Firework_TechGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }


		public void  Prepare_Firework_TechGen(){

			// ===== Prepare =====
			if( stageNoP == stageNoPMemo )  return;
			stageNoPMemo = stageNoP;
			base.AnalyzerBaseV2_PrepareStage();
	
			Firework_List = IEGet_UFirework().ToList();						// Single Firework
			if( Firework_List==null || Firework_List.Count<=0 )  return ;
					//foreach( var (p,m) in Firework_List.WithIndex() ){ WriteLine( $"0-{m} {p}" ); };
					//WriteLine( "" );
			
			{// Aggregation of candidate digits <<< rcStem >>>
				FireworkAgg_List = new();
				var querySL = Firework_List.GroupBy(x => x.rcStem);
				foreach( var group in querySL.Where(p=>p.Count()>=2) ){
					var groupList = group.ToList();

					if( group.Count() >= 2 ){
						Combination cmb2 = new( groupList.Count, 2 );
						while( cmb2.Successor() ){
							UFirework UFW0 = groupList[ cmb2.Index[0] ];
							UFirework UFW1 = groupList[ cmb2.Index[1] ];

							UFirework UFWadd = new( UFW0, UFW1 );
							if( UFWadd.rcStem >= 0 )  FireworkAgg_List.Add(UFWadd);
						}
					}

					if( group.Count() >= 3 ){
						Combination cmb3 = new( groupList.Count, 3 );
						while( cmb3.Successor() ){
							UFirework UFW0 = groupList[ cmb3.Index[0] ];
							UFirework UFW1 = groupList[ cmb3.Index[1] ];
							UFirework UFW2 = groupList[ cmb3.Index[2] ];

							UFirework UFWadd2 = new( UFW0, UFW1 );
							if( UFWadd2.rcStem <= 0 ) continue;

							UFirework UFWadd3 = new( UFWadd2, UFW2 );
							if( UFWadd3.rcStem >= 0 )  FireworkAgg_List.Add(UFWadd3);
						}
					}
				}
					//foreach( var (p,m) in FireworkAgg_List.WithIndex() ){ WriteLine( $"  2-{m} {p}  FreeBC:{p.FreeBC}" ); };
					//WriteLine( "" );
			}	
		}

		private void __debug_sol_check( ) {
			foreach( var P in pBOARD.Where( p=> (p.FixedNo>0 && p.FixedNo!=sol_int81[p.rc]) ) ){
				WriteLine( $"\n   <<< error >>> :  P.FixedNo:{P.FixedNo}  sol:{sol_int81[P.rc]}\n         {P}" );
			}
			foreach( var P in pBOARD.Where( p=> (p.CancelB>0 && (p.CancelB & (1<<(sol_int81[p.rc]-1)))>0)) ){
				WriteLine( $"\n   <<< error >>> : P.FixedNo:{P.FixedNo}  sol:{sol_int81[P.rc]}\n         {P}" );
			}
		}
	}

}