using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Resources;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;

using GNPX_space;

using static System.Diagnostics.Debug;


namespace GIDOO_space{

	// https://mamesfactory.com/2747/
    static public partial class GNPX_Utilitie{

		static PerformanceCounter pc = new PerformanceCounter();


		static private double _MDay = 29.53059;
		static public int Get_MoonAge( this DateTime dt ){
			System.TimeSpan diffD = dt .Subtract( new DateTime(2025,01,29, 21,37,0) );
			double  Totalday = diffD.TotalDays;
			double moonAge_Day = Totalday - (int)(Totalday/_MDay)*_MDay;
			return (int)moonAge_Day;
		}


		static void Get_PCInformation(){
			pc.CategoryName = "Processor Information";
			pc.CounterName = "% Processor Utility";
			pc.InstanceName = "_Total";

			// Check if a category exists
			if (!System.Diagnostics.PerformanceCounterCategory.Exists(pc.CategoryName))  WriteLine("unregistered category");

			// Check if a counter exists
			else if (!PerformanceCounterCategory.CounterExists(pc.CounterName, pc.CategoryName, "."))  WriteLine("Counter not registered!");
			else{
				do{
					float m = pc.NextValue();
					WriteLine("{0}", m);
				}while (true);
			}
		}

	    static public string StackTrace_4GNPXdev( bool sysIgnore=false ){
            StackTrace stackTracer = new StackTrace(true);
            string st, stT="";
			int line;

            foreach( StackFrame frame in stackTracer.GetFrames() ){
                var method = frame.GetMethod();
                st = $"\nmethod: {method.Name} L:{line=frame.GetFileLineNumber()}     ";
                st += $" class {method.DeclaringType?.FullName}";
                st += $" method:{method.Name}";
                st += $" file: {frame.GetFileName()}";
                st += $" line: {frame.GetFileLineNumber()}";
				if( !st.Contains("System") && !st.Contains("MS.Win32") && !st.Contains("StackTrace") )  stT += st;
            }

            return stT;
        }

	    static public string StackTrace_0( bool sysIgnore=false ){
            StackTrace stackTracer = new StackTrace(true);
            string st, stT="";
			int line;

            foreach( StackFrame frame in stackTracer.GetFrames() ){
                var method = frame.GetMethod();
                st = $"\n class {method.DeclaringType?.FullName}";
                st += $" method:{method.Name}";
                st += $" file: {frame.GetFileName()}";
                st += $" line: {frame.GetFileLineNumber()}";
				if( !st.Contains("System") && !st.Contains("MS.Win32") && !st.Contains("StackTrace") )  stT += st;
            }

            return stT;
        }



// ====================================================================================================
        static public List<T> GetControlsCollection<T>( object parent ) where T :DependencyObject{
            //WPF - Getting a collection of all controls for a given type on a Page
            //http://stackoverflow.com/questions/7153248/wpf-getting-a-collection-of-all-controls-for-a-given-type-on-a-page
            //using: List<Button> buttons = GetControlsCollection<Button>(yourPage);

			// @Attension : Use with care during initialization. The controls must already be defined.

            List<T> logicalCollection = new List<T>();
            GetControlsCollection( parent as DependencyObject, logicalCollection );
            return logicalCollection;
        }
        static private void GetControlsCollection<T>( DependencyObject parent, List<T> logicalCollection ) where T: DependencyObject{
            var children = LogicalTreeHelper.GetChildren(parent);
            foreach( object child in children ){
                if(child is DependencyObject){
                    DependencyObject depChild = child as DependencyObject;
                    if( child is T )logicalCollection.Add(child as T);
                    GetControlsCollection(depChild, logicalCollection);
                }
            }
        }

        static public void EnumVisual( Visual myVisual, ref List<Visual> Vis ){
            for(int i=0; i<VisualTreeHelper.GetChildrenCount(myVisual); i++){
                // Retrieve child visual at specified index value.
                Visual childVisual = (Visual)VisualTreeHelper.GetChild(myVisual, i);
                Vis.Add(childVisual);
                WriteLine(childVisual.ToString());
                // Do processing of the child visual object.

                // Enumerate children of the child visual object.
                EnumVisual(childVisual, ref Vis);
            }
        }

        static public bool Inner( this MouseButtonEventArgs e, FrameworkElement Q ){
            Point pt = e.GetPosition(Q);
            if(pt.X<=0.0 || pt.Y<=0.0)  return false;
            if(pt.X>=Q.Width  || pt.Y>=Q.Height)  return false;
            return true;
        }

#if false
		static public IEnumerable<IEnumerable<T>> Chunk<T>( this IEnumerable<T> source, int chunkSize ){
			if(chunkSize <= 0) throw new ArgumentException("Chunk size must be greater than 0.", nameof(chunkSize));
			while (source.Any()){
				yield return source.Take(chunkSize);
				source = source.Skip(chunkSize);
			}
		}

		static　public IEnumerable<IEnumerable<T>> Chunk<T>(this IEnumerable<T> source, int chunkSize){
			if( chunkSize <= 0 ) throw new ArgumentException("Chunk size must be greater than 0.", nameof(chunkSize));
			return source.Select((v, kx) => new { v, kx })
				.GroupBy( x => x.kx/chunkSize)
				.Select( g => g.Select(x => x.v));
		}
#endif

        static public void ProcessExe( string url ){
            // Process.Start for URLs on .NET Core
            // https://brockallen.com/2016/09/24/process-start-for-urls-on-net-core/
            try{  
                Process.Start(url);  
            }  
            catch{  
                if( RuntimeInformation.IsOSPlatform(OSPlatform.Windows) ){      //for Windows  
                    url = url.Replace("&", "^&");  
                    Process.Start(new ProcessStartInfo("cmd", $"/c start {url}") { CreateNoWindow=true });  
                }  
                else if( RuntimeInformation.IsOSPlatform(OSPlatform.Linux) ){   //for Linux  
                    Process.Start("xdg-open", url);  
                }  
                else if( RuntimeInformation.IsOSPlatform(OSPlatform.OSX) ){     //for Mac  
                    Process.Start("open", url);  
                }  
                else{ throw; }  
            }  
        }


		static public void ScrollToCenter( ListBox listBox, int index ){
			var border = VisualTreeHelper.GetChild(listBox, 0) as Border;
			var scrollViewer = border?.Child as ScrollViewer;

			if (scrollViewer != null){
				// By subtracting half of the viewport (display area), the image is centered.
				double halfViewport = scrollViewer.ViewportHeight / 2;
				scrollViewer.ScrollToVerticalOffset(index - halfViewport + 0.5);
			}
		}

    }
}
