using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Resources;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

using GNPX_space;

using static System.Diagnostics.Debug;

namespace GIDOO_space{
    static public partial class GNPX_Utilitie{


		static private UInt128[]    pConnectedCells81 => /*AnalyzerBaseV2.*/Connected_81;

        //========================================================================
        // Note: UInt128 instance variables do not change the original variable.
        //========================================================================

        static public bool IsHit( this UInt128 A, int rc )        => (A & (qOne<<rc)) != qZero;
        static public bool IsHit( this UInt128 A, UInt128 B )     => (A & B) != qZero;

        static public bool IsZero( this UInt128 A )               => (A == qZero); 
    
        static public bool IsNotZero( this UInt128 A )            => (A != qZero);


        static public int FindFirst_rc( this UInt128 A, int start0=0 ){
            UInt128 w = A & _filter0081;
            for( int rc=start0; rc<81; rc++ ){
                if( (w&0x1FF) == 0 ){ w>>=9; rc+=8; continue;}
                if( (w&UInt128.One)>0 )  return rc;
                w >>= 1;
            }
            return -1;
        }
		static public int FindLast_rc( this UInt128 A ){
            for( int rc=80; rc>=0; rc-- ){
                if( (A&(qOne<<rc))>0 )  return rc;
            }
            return -1;
        }

        static public int BitToNum( this UInt128 U128, int sz ){    
            if(U128.BitCount()!=1) return -1;
            for( int k=0; k<sz; k+=8 ){
                uint w = ((uint)(U128>>k)) & 0xFF;
                if( w == 0 )  continue;
                for( int n=0; n<8; n++ ){
                    if( (w & (1<<n)) > 0 ) return (k+n);
                }
            }
            return -1;
        } 
        static public List<int> BitToNumList( this UInt128 U128, int sz=81 ){
			int cnt= U128.BitCount(), cc=0;
            if( cnt <= 0 ) return   null;
			List<int> UList = new();   
            for( int k=0; k<sz; k+=8 ){
                uint w = ((uint)(U128>>k)) & 0xFF;
                if( w == 0 )  continue;
                for( int n=0; n<8; n++ ){
                    if( (w & (1<<n)) > 0 ){
						UList.Add( (k+n) );
						if( (++cc) >= cnt ) break;
					}
                }
            }
            return UList;
        } 
		static public (int,int) BitToTupple( this UInt128 U128 ){
			var L = U128.BitToNumList( 81 );
			switch (L.Count()){
				case 2: return (L[0], L[1]);
				case 1: return (L[0], -1);
				case 0: return (-1,-1);
				default: return (-9999,-9999);
			}
			throw new ArgumentException( $" BitToTupple Exception  U128:{U128.ToBitString81N()}" );
		}

        static public string ToBitStringWSP( this int num, int ncc, bool with_sp ){
            int numW = num;
            string st="";
            for(int k=0; k<ncc; k++ ){
                st += ((numW&1)!=0)? ((k%9)+1).ToString(): ".";
                if(k==8)  st += " ";
                numW >>= 1;
            }
            return st;
        }

        static public string ToBitString81( this UInt128 A ){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( A >> (n*27) );
                int tmp=1;
                for(int k=0; k<27; k++){
                    st += ((bp&tmp)>0)? "1": "."; //External expression
                    tmp = (tmp<<1);
                    if(k==26)         st += " /";
                    else if((k%9)==8) st += " ";
                }
            }
            return st;
        }

        
        
        // @@@ "TBS" is an abbreviation for "ToBitString".


		static public string TBS( this UInt128 A, bool withSlashB=false )   => A.ToBitString81N( withSlashB:false );		// For debugging purposes only
		static public string TBScc( this UInt128 A, bool withSlashB=false ) => $"{A.ToBitString81N( withSlashB:false)}_*{A.BitCount()}";
		static public string TBScells( this UInt128 A, bool withSlashB=false ) => $"{A.ToBitString81N( withSlashB:false)}_{A.BitCount()} cells";
		static public string TBSComp( this UInt128 A, bool withSlashB=false )   => A.ToBitString81( );		// For debugging purposes only

        static public string ToBitString81N( this UInt128 A, bool withSlashB=false){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( A >> (n*27) );
                int tmp=1;
                for(int k=0; k<27; k++){
                  //st += ((bp&tmp)>0)? ((k%9)+0).ToString(): ".";	// Internal expression
                    st += ((bp&tmp)>0)? ((k%9)+1).ToString(): ".";	// External expression
                    tmp = (tmp<<1);
                    if(withSlashB && k==26)  st += " /";
                    else if((k%9)==8) st += " ";
                }
            }
            return st;
        }

        static public string ToBitString128( this UInt128 A, int size=128 ){
            string st="";
              
            UInt128 w = A;
            for(int k=0; k<size; k++){
                st += (w&1)>0? $"1": "."; 
                if( k%8==7 ) st += " ";
                w >>=1 ;
            }
            return st;
        }
        static public string ToStringN( this UInt128 A ){
            string st="";
              
            UInt128 w = A;
            for(int k=0; k<128; k++){
                st += (w&1)>0? $"{k%8+1}": "."; 
                if( k%8==7 ) st += " ";
                w >>=1 ;
            }
            return st;
        }



        static public string ToBitString128(this UInt128? A, int size=128){
            string st = "";

            UInt128? w = A;
            for( int k=0; k<size; k++ ){
                st += (w&1)>0? $"1" : ".";
                if( k%8==7 ) st += " ";
                w >>= 1;
            }
            return st;
        }


        static public int BCC(this UInt128 arg) => arg.BitCount();
        static public (int,int) BCrc(this UInt128 arg){
            int cc = arg.BitCount();
            int rc = (cc==1)? arg.FindFirst_rc(): -1;
            return  (cc,rc);
        }
        static public UInt128 B81_IsSingle( this UInt128 arg ) => (arg.BitCount()==1)? arg: qZero;
     

        public static int BitCount( this UInt128 arg ) => (int)UInt128.PopCount(arg);


        static public string ToString81( this UInt128 arg81 ){
            string st="";
            for(int n=0; n<9; n++){
                int w = (int)arg81&0x1FF;
                st += w.ToBitString(9);
                if( n%3 == 2 )  st += " ";       
                if( n<8 ) st += " ";
                arg81 >>= 9;
            }
            return st;
        }


        static public bool Is_pure_LockedSet( this UInt128 LS, List<UCell> board){
            int nSZ = LS.BitCount();
            if( nSZ<=2 ) return true;

            // If it includes a smaller _LockedSet, it's not a pure pattern.
            for (int sz=2; sz<nSZ; sz++){
                Combination_81B cmb81B = new(nSZ, sz, LS);
                while( cmb81B.Successor() ){
                    int FreeB_LS = cmb81B.valueBT.IEGet_UCell(board).Aggregate(0, (a, U) => a | U.FreeB);
                    if( FreeB_LS.BitCount() == sz ) return  false;   // not pure Locked-Set.
                }
            }
            return  true;
        }
	
        static public int Get_rcFirst( this UInt128 arg, int sz=128 ){
            for( int k16=0; k16<sz; k16+=16 ){
                int w = (int)(arg>>k16) & 0xFFFF;
                for( int k=0; k<16; k++ ){
                    if( (w&(1<<k)) != 0 )  return (k+k16);
                }
            }
            return -1;
        }

		static public int Get_rc_ifUnique( this UInt128 arg, int sz=128, int notUnique=-1 ){
			if( arg.BitCount() != 1 )  return notUnique;
			return arg.Get_rcFirst();
		}

		static public (int,int) Get_rc1_rc2( this UInt128 arg, int sz=128 ){
			if( arg.BitCount() != 2 )  return (-1,-1);
			var rcList = arg.IEGet_rc().ToList();
			return (rcList[0],rcList[1]);
		}

		static public int[] ToArray( this UInt128 A, int sz=81 ){
			int[] AL = new int[sz];
			for(int rc=0; rc<sz; rc++) AL[rc] = (A&(UInt128.One<<rc))>0 ? 1 : 0;
			return AL;
		}

        static public UInt128 ToUInt128( this IEnumerable<int> A ) => A.Aggregate(qZero,(a,rc)=>a|qOne<<rc);

        static public IEnumerable<int> IEGet_rc( this UInt128 A, int mx=81){
            for(int rc=0; rc<mx; rc++){
                if( (A&(UInt128.One<<rc)) > 0  ) yield return rc;
            }
            yield break;
        }
        static public IEnumerable<UInt128> IEGet_rc128( this UInt128 A, int mx=81){
            for(int rc=0; rc<mx; rc++){
                if( (A&(UInt128.One<<rc)) > 0  ) yield return UInt128.One<<rc;
            }
            yield break;
        }

		static public (UInt128,UInt128,UInt128) Get_UInt128_Single_Two_More( this List<UInt128> UList, bool debugPrint=false ){  
			UInt128 oneF=0, twoF=0, moreF=0;
			foreach( var F in UList ){
				moreF |= twoF & F;			// exist in more than two places
				twoF |= oneF & F;			// exist in more than one place
				twoF &= ~moreF;
				oneF |= F;                  // exist somewhere
				oneF &= ~(twoF|moreF);
			}
			return (oneF,twoF,moreF);		// only one
		}

        static public string To_Line_String( this int[] board1D ){
            string st = board1D.ToList().Aggregate("",(a,b)=> a+(b>0? $"{b}":".") );
            st = st.ToStringWithSpace(size:9);
            return st;
        }

        static public string To_Line_String( this int[,] board ) => board.Cast<int>().ToArray().To_Line_String();

		
        static public bool IsNumeric( this char chTarget ){ //Test whether a string is a number
            int nNullable;
            return int.TryParse( chTarget.ToString(), NumberStyles.Any, null, out nNullable );
        }

	    static public int[]? stringToIntArray( this string st ){
            try{
			    int[] PZL = new int[81];
			    string st2 = st.Replace(".","0").Replace(" ","").Replace("\n","").Replace("\r","");			
			
			    int rc=0;
			    for(int k=0; rc<81; ){
				    while(!st2[k].IsNumeric()) k++;
				    PZL[rc] = int.Parse(st2[k++].ToString());
				    rc++;
			    }
                return PZL;
		    }
            catch(Exception e){ throw new( $"Agorithm Error {e.Message}\n{e.StackTrace}"); }
        }
    }
}