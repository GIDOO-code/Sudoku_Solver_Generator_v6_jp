using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Windows.Documents;

using GIDOO_space;

using static System.Diagnostics.Debug;
using static System.Math;

namespace GIDOO_space{

	static public class GLX_Lib{
        static private readonly char[]  _sep=new Char[]{ ' ', ',', '\t' };
/*
		static public int[] stringToIntArray( this string st ){
			int[] PZL = new int[81];
			string st2 = st.Replace(".","0").Replace(" ","").Replace("\n","").Replace("\r","");			
			
			int rc=0;
			for(int k=0; rc<81; ){
				while(!st2[k].IsNumeric()) k++;
				PZL[rc] = int.Parse(st2[k++].ToString());
				rc++;
			}
			return PZL;
		}
*/

		static public string PrintBoard33( this int[] board33, string title="", bool OnlyNum=false ){
			string st = title+"\n";
            for( int r=0; r<3; r++ ){
                for( int c= 0; c<3; c++ ){
                    st += (board33[r*3+c]==0)? ". ": board33[r*3+c]+" ";
                }
                st += "\n";
            }
           
			WriteLine( st );
            return st;
        }

		static public string PrintBoard( this int[] board, string title="", bool OnlyNum=false ){
			string st = title+"\n";
            for( int r=0; r<9; r++ ){
                if( r%3==0 && r!=0 && !OnlyNum ) st += "------+-------+-------\n";
                for( int c= 0; c<9; c++ ){
                    if( c%3==0 && c!=0 && !OnlyNum )  st += "| ";
                    st += (board[r*9+c]==0)? ". ": board[r*9+c]+" ";
                }
                st += "\n";
            }
			WriteLine( st );
            return st;
        }

        static public string PrintBoard( int[] board1,int[] board2, string title ){
            string st1 = _BoardToString( board1 );
            string st2 = _BoardToString( board2 );
            List<string>  st1_List = _Split(st1,22).ToList();
            List<string>  st2_List = _Split(st2,22).ToList();
            
            string st = ____splitPad22(title,spN:0)+"\n";
            for( int k=0; k<11; k++ )  st += $" {st1_List[k]}  {st2_List[k]}\n";   
            WriteLine(st);
            return st;
        }

        static public string PrintBoard( int[] board1,int[] board2,int[] board3, string title ){
            string st1 = _BoardToString( board1 );
            string st2 = _BoardToString( board2 );
            string st3 = _BoardToString( board3 );
            List<string>  st1_List = _Split(st1,22).ToList();
            List<string>  st2_List = _Split(st2,22).ToList();
            List<string>  st3_List = _Split(st3,22).ToList();

            string st = ____splitPad22(title,spN:0)+"\n";
            for( int k=0; k<11; k++ )  st += $" {st1_List[k]}  {st2_List[k]}  {st3_List[k]}\n";   
            WriteLine(st);
            return st;
        }
        static public string PrintBoard( int[] board1,int[] board2,int[] board3,int[] board4, string title ){
            string st1 = _BoardToString( board1 );
            string st2 = _BoardToString( board2 );
            string st3 = _BoardToString( board3 );
            string st4 = _BoardToString( board4 );
            List<string>  st1_List = _Split(st1,22).ToList();
            List<string>  st2_List = _Split(st2,22).ToList();
            List<string>  st3_List = _Split(st3,22).ToList();
            List<string>  st4_List = _Split(st4,22).ToList();

            string st = ____splitPad22(title,spN:0)+"\n";
            for( int k=0; k<11; k++ )  st += $" {st1_List[k]}  {st2_List[k]}  {st3_List[k]}  {st4_List[k]}\n";   
            WriteLine(st);
            return st;
        }

        static public string PrintBoard( int[] board1,int[] board2,int[] board3,int[] board4,int[] board5, string title ){
            string st1 = _BoardToString( board1 );
            string st2 = _BoardToString( board2 );
            string st3 = _BoardToString( board3 );
            string st4 = _BoardToString( board4 );
            string st5 = _BoardToString( board5 );
            List<string>  st1_List = _Split(st1,22).ToList();
            List<string>  st2_List = _Split(st2,22).ToList();
            List<string>  st3_List = _Split(st3,22).ToList();
            List<string>  st4_List = _Split(st4,22).ToList();
            List<string>  st5_List = _Split(st5,22).ToList();

            string st = ____splitPad22(title,spN:0)+"\n";
            for( int k=0; k<11; k++ )  st += $" {st1_List[k]}  {st2_List[k]}  {st3_List[k]}  {st4_List[k]}  {st5_List[k]}\n";   
            WriteLine(st);
            return st;
        }

        static private int  ToBlock( this int rc ) => rc/27*3+(rc%9)/3;

		//static public int		ToRCBFrame( this int rc) => (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9);  //rc.ToRCBFrame( );
		

        static private string _BoardToString( int[] board ){
            string st = "";
            for( int r=0; r<9; r++ ){
                if( r%3==0 && r!=0 ) st += "------+-------+-------";
                for( int c= 0; c<9; c++ ){
                    if( c%3==0 && c!=0 )  st += "| ";
                    st += (board[r*9+c]==0)? ". ": board[r*9+c]+" ";
                }
            }
            return st;
        }

		static public IEnumerable<string> _Split( string stP, int size ){
			for( int k=0; k<stP.Length; k+=size){
				yield return  stP.Substring(k, size)+" ";
			}
			yield break;
		}
		static private string ____splitPad22( this string st, int spN=7 ){ // Split the title of the debug matrix display.
			List<string> eList = st.Split(_sep,StringSplitOptions.RemoveEmptyEntries).ToList().ConvertAll(p=>p.PadLeft(22) );
			string stTmp = "\n" + (new string(' ',spN)) + string.Join("   ",eList);
			return  stTmp;
		}

        //static public int BitCount( this int value) => BitOperations.PopCount((uint)value);


        static public string ToRCString( this int rc ){
			int rcAbs = Abs(rc); 
			string st = $"r{rcAbs/9+1}c{(rcAbs%9)+1}";
			if( rc<0 )  st = "-" + st;
            return st;
        }

        static public void Swap<T>( ref T a, ref T b ){ T w=b; b=a; a=w; }
	}
}

