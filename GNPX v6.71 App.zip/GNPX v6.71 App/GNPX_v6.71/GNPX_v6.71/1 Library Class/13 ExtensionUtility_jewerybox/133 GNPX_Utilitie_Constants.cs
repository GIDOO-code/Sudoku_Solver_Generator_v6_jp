using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Resources;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

using GNPX_space;

using static System.Diagnostics.Debug;

namespace GIDOO_space{
    static public partial class GNPX_Utilitie{
		static private readonly UInt128 _filter0081 = (UInt128.One<<81)-1;    // b081
        static private readonly UInt128 qZero   = UInt128.Zero;
        static private readonly UInt128 qOne    = UInt128.One;
	    static private readonly UInt128 qMaxB81 = (UInt128.One<<81)-qOne;
        static private readonly UInt128 _b9     = 0x1FF;
		static public UInt128 UInt128tMask_PosWid( int start_pos, int width ) => ((qOne<<width)-1) << start_pos;

        static private UInt128 Storage = qZero;

        static public UInt128[]  Connected_81;    //Connected Cells
        static public UInt128[]  HouseCells81;   //Row(0-8) Collumn(9-17) Block(18-26)
		static public int[]		 Connected33;

    //    static public int[][]    Band_Block = new int[][]{ new int[]{0,1,2}, new int[]{3,4,5}, new int[]{6,7,8}, new int[]{0,3,6}, new int[]{1,4,7}, new int[]{2,5,8} };
    //    static public (int,int,int)[]  BandBlock_Tuple = new(int,int,int)[]{(0,1,2),(3,4,5),(6,7,8), (0,3,6),(1,4,7),(2,5,8)};
        static public int[] Band_BlockB = new int[]{ 0b111,0b111000,0b111000000, 0b1001001,0b10010010,0b100100100 };


        static GNPX_Utilitie(){
            Connected_81    = new UInt128[81];

            for( int rc=0; rc<81; rc++ ){
                UInt128 BS128 = 0;
                foreach( var q in __IEGetCellsConnectedRC(rc).Where(q=>q!=rc)) BS128 |= (UInt128)1<<q;
                Connected_81[rc]    = BS128;       // {ATT} Does not include stem cell!
					//WriteLine( $" BS128 rc:{rc} {BS128.ToString81()}");
            }

			Connected33 = new int[9];
            for( int rc=0; rc<9; rc++ ){
                int  B33 = 0;
                foreach( var q in __IEGet_Connected33(rc).Where(q=>q!=rc)) B33 |= 1<<q;
                Connected33[rc] = B33;       // {ATT} Does not include stem cell!
					//WriteLine( $" BS128 rc:{rc} {B33.ToBitString(9)}");
            }

            HouseCells81 = new UInt128[27];
            for( int h=0; h<27; h++ ){
                UInt128 tmp = 0;
                foreach( var q in __IEGetCellInHouse(h) ) tmp |= UInt128.One<<q;
                HouseCells81[h] = tmp;
	                //WriteLine( $" HouseCells81:{h} {tmp.ToString81()}");
            }           

            // -----------------------------------------------------------------------------------------------
                    IEnumerable<int> __IEGetCellsConnectedRC( int rc ){ 
                        int r=0, c=0;
                        for(int kx=0; kx<27; kx++ ){
                            switch(kx/9){
                                case 0: r=rc/9; c=kx%9; break; //row 
                                case 1: r=kx%9; c=rc%9; break; //collumn
                                case 2: int b=rc/27*3+(rc%9)/3; r=(b/3)*3+(kx%9)/3; c=(b%3)*3+kx%3; break;//block
                            }
                            yield return r*9+c;
                        }
                    }
            
                    IEnumerable<int> __IEGet_Connected33( int rc ){ 
                        int r, c;
			            for( int k=0; k<3; k++ ){ r=rc/3; c=k; yield return r*3+c; }
			            for( int k=0; k<3; k++ ){ r=k;    c=rc%3; yield return r*3+c; }
                    }

                    IEnumerable<int> __IEGetCellInHouse( int h ){ //nx=0...8
                        int r=0, c=0, tp=h/9, fx=h%9;
                        for(int nx=0; nx<9; nx++ ){
                            switch(tp){
                                case 0: r=fx; c=nx; break;  //row
                                case 1: r=nx; c=fx; break;  //collumn
                                case 2: r=(fx/3)*3+nx/3; c=(fx%3)*3+nx%3; break;  //block
                            }
                            yield return (r*9+c);
                        }
                    }
        }
    }
}