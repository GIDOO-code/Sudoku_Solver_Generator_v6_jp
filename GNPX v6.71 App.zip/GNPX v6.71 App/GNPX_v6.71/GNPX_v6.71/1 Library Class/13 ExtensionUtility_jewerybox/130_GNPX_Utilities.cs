using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;

using GNPX_space;

using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;


namespace GIDOO_space{

    static public partial class GNPX_Utilitie{


		static uint uintMask( int width ) => ((1U<<width)-1);
		static uint uintMask_PosWid( int start_pos, int width ) => ((1U<<width)-1) << start_pos;

		static uint get_bits( this uint num, int start_pos, int width)			  => (num>>start_pos) & uintMask(width);
		static uint set_bits( this uint num, int start_pos, int width, int value) => (num & ~(uintMask(width)<<start_pos)) | ((uint)value << start_pos);



        static readonly int[] __BC=new int[512]; //Number of 1's in binary expression 0-511


        static public void Swap<T>( ref T a, ref T b ){ T w=b; b=a; a=w; }

		static public void ForEach<T>(this List<T> input, Action<T,int> action){
			for( int k=0; k<input.Count; k++){ action(input[k],k); }
		}


        static public int ToInt( this string st )       => (st=="")? 0: int.Parse( st );

        static public int ToInt( this char ch )         =>	int.Parse( ch.ToString() );
       

        static public bool IsHit( this int A, int n )   => (A & (1<<n)) > 0;


        static public int BitReset( this int X, int n ) => X &= (1<<n)^0x7FFFFFFF;


        // Fast bit counting (counting the number of 1s)
        static public int BitCount( this int value) => BitOperations.PopCount((uint)value);

#if false
        static public int BitCount( this int nF ){      //by Hacker's Delight
			return ((uint)nF).BitCount();
/*
            if( nF < 512 )  return __BC[nF];  //for 9 bits or less, refer to the table. fast.
            int x = nF;
            x = (x&0x55555555) + ((x>>1)&0x55555555);
            x = (x&0x33333333) + ((x>>2)&0x33333333);
            x = (x&0x0F0F0F0F) + ((x>>4)&0x0F0F0F0F);
            x = (x&0x00FF00FF) + ((x>>8)&0x00FF00FF);
            x = (x&0x0000FFFF) + ((x>>16)&0x0000FFFF);
            return x;
*/
        }

        static public int BitCount( this uint nF ){     //by Hacker's Delight
            if( nF < 512 )  return __BC[nF];  //for 9 bits or less, refer to the table. fast.
            uint x = nF;
            x = (x&0x55555555) + ((x>>1)&0x55555555);
            x = (x&0x33333333) + ((x>>2)&0x33333333);
            x = (x&0x0F0F0F0F) + ((x>>4)&0x0F0F0F0F);
            x = (x&0x00FF00FF) + ((x>>8)&0x00FF00FF);
            x = (x&0x0000FFFF) + ((x>>16)&0x0000FFFF);
            return (int)x;
        }
#endif
        static public bool IsNumeric( this string stTarget ){ //Test whether a string is a number
            int nNullable;
            return int.TryParse( stTarget, NumberStyles.Any, null, out nNullable );
        }
/*
        static public bool IsNumeric( this char chTarget ){ //Test whether a string is a number
            int nNullable;
            return int.TryParse( chTarget.ToString(), NumberStyles.Any, null, out nNullable );
        }
*/

		static public string TimespanToString( this System.TimeSpan ts, bool stUnit=true ){
            string st = "";
            if( ts.TotalMinutes>2.0 ) st += ts.TotalMinutes.ToString("0.00") + (stUnit? " min":"");
			else if( ts.TotalSeconds>1.0 ) st += ts.TotalSeconds.ToString("0.0") + (stUnit? " sec":"");
            else                      st += ts.TotalMilliseconds.ToString("0.0") + (stUnit? " msec":"");
            return st;
        }

		static public string  RemainingTimeToString( this System.TimeSpan ts, int nc, int ncMax ){
			double ncD = Max(nc,1);
			System.TimeSpan tsT = ts * (ncMax/ncD - 1.0);
			return  tsT.TimespanToString();
		}

		static public string[] ToStringArray( this string st ){
			int len = st.Length;
			string[] stL = new string[len];
			for( int n=0; n<len; n++ ) stL[n] = st.Substring(n,1);
			return stL;
		}

   //http://stackoverflow.com/questions/677373/generate-random-values-in-c-sharp
        static public long NextInt64( this Random rnd ){
            byte[] bytes = new byte[8];
            rnd.NextBytes(bytes);
            return BitConverter.ToInt64(bytes,0);

            // Assume rng refers to an instance of System.Random
            //byte[] bytes = new byte[8];
            //rng.NextBytes(bytes);
            //long int64 = BitConverter.ToInt64(bytes, 0);
            //ulong uint64 = BitConverter.ToUInt64(bytes, 0);
            //Note that using Random.Next() twice, shifting one value and then ORing/adding doesn't work.
            //Random.Next() only produces non-negative integers, i.e.
            //it generates 31 bits, not 32, so the result of two calls only produces 62 random bits
            //instead of the 64 bits required to cover the complete range of Int64/UInt64.
            //(Guffa's answer shows how to do it with three calls to Random.Next() though.)
        }


		static public List<T> Copy<T>( this List<T> L ){
			List<T> LCopy = new List<T>();
			L.ForEach( Q => LCopy.Add(Q));
			return LCopy;
		}



		static�@public IEnumerable<(T item, int index)> WithIndex<T>( this IEnumerable<T> source ){
			return source.Select((item, index) => (item, index));
		}


		static public IEnumerable<int> stringToInt( this string source ){
			foreach( int k in Enumerable.Range(0,source.Length) )  yield return source[k].ToInt();
		}

		static public IEnumerable<string> ToLower(this IEnumerable<string> source){
			return source.Select(v => v.ToLower());
		}
		static public IEnumerable<string> ToUpper(this IEnumerable<string> source){
			return source.Select(v => v.ToUpper());
		}

        static private char[] sepDef=new Char[]{ ' ', ',', '\t' };

		static public string[] SplitEx( this string st, char[] sep, bool withTrimB=true ){  
		    // The string "..." is processed as a single unit.
			// "2 3 4 5 6" "a b12"x y  Z"" 123 "z z" "y  // ... Bad test data
			string[] eLst = null;

			int nx = st.IndexOf( "\"", 0 );
			if( nx < 0 ){ 
				eLst = st.Split(sep,StringSplitOptions.RemoveEmptyEntries);
				if(withTrimB){ 
					for( int k=0; k<eLst.Length ; ++k ){ eLst[k] = eLst[k].Trim(); }
				}
				return  eLst;
			}
			
			string st2 = st.Substring( 0, nx );
			st2 = st2.Replace( " ", "\b" ) + "\b"; 
			foreach( char _sp in sep )  st2 = st2.Replace( _sp, '\b' );
			st2 += "\b"; 


			bool   Qin = false;
			for( int k=nx; k<st.Length; k++ ){
				char s = st[k];
				if( s == '\"' ){
					Qin = !Qin;
					st2 += '\b';
				}
				else{
					if( !Qin && IsSeparator(s,sep) ) s = '\b';
					st2 += s;
				}
			}

			eLst = st2.Split("\b",StringSplitOptions.RemoveEmptyEntries);
			if(withTrimB){ 
				for( int k=0; k<eLst.Length ; ++k ){ eLst[k] = eLst[k].Trim(); }
			}
			return eLst;

			bool IsSeparator( char s, char[] sep ){
				foreach( char _sp in sep ){
					if( s == _sp )  return true;
				}
				return  false;
			}
        }

		static public string ToStringWithSpace( this string text, int size=9 ){
			string st = "";
			foreach( int n in Enumerable.Range(0,text.Length/size) ) st += " "+text.Substring(n*size,size);
			return st.Trim();
		}

/*
        static public string ToStWithSp( this string st, int size=9 )  => string.Concat(_Split(st,size));

		static public IEnumerable<string> _Split( string stP, int size){
			for( int k=0; k<stP.Length; k+=size){
				yield return  stP.Substring(k, size)+" ";
			}
			yield break;
		}
*/




		static public string AddSpace9_81( this string st, int n=9 ) => st.Insert_Space_every_n( n );
		static public string Insert_Space_every_n( this string st, int n=9 ){
			string stA = "";
			for( int k=0; k<st.Length-1; k+=n ){
				int n2 = Min( st.Length-k, n);
				stA += " " + st.Substring( k, n2 );
				//stA += " " + st.Substring( k, n );
			}
			return stA.Trim();
		}




/*   *****   Scheduled for deletion ... Learning.
		static public string DBVal<T>( this T val ) => val.DegugValue<T>( );

		static public string DegugValue( this string val ) => $"{nameof(val)} : {val}";
		static public string DegugValue( this int val ) => $"{nameof(val)} : {val}";
		static public string DegugValue( this uint val ) => $"{nameof(val)} : {val}";

		static public string DegugValue<T>( this T val ){
			string st = nameof(val);
			var t = typeof(T);
			foreach (var f in t.GetFields())	st += $"{f.Name} : {f.GetValue(f) }";

			foreach (var f in typeof(val).GetFields())	st += $"{f.Name} : {f.GetValue(f) }";
			return st;
		}

		static public string DegugValue( this UCell val ){
			string st = nameof(val);
			var t = typeof(UCell);
			foreach (var f in t.GetFields())	st += $"{f.Name} : {f.GetValue(f) }";
			foreach (var f in typeof(UCell).GetFields())	st += $"{f.Name} : {f.GetValue(f) }";
			return st;
		}
*/
        public static T DeepCopy<T>(this T source){
            // usage : var clone = original.DeepCopy(); 

            if( source == null ) return default;
            var json = JsonSerializer.Serialize(source);
            return JsonSerializer.Deserialize<T>(json);
        }

        static public T DeepCopy2<T>(this T src){
            using( MemoryStream stream = new MemoryStream() ){
                var serializer = new XmlSerializer(typeof(T));
                serializer.Serialize(stream, src);
                stream.Position = 0;

                return (T)serializer.Deserialize(stream);
            }
        }

    }

        

}