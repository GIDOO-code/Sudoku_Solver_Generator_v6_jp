//using Accessibility;
namespace GIDOO_space {
    static public class GIDOO_Hash {
        static private int _NSZ = 8192;
        static public long[] hashBase = new long[_NSZ];
        static GIDOO_Hash( ){
            Random rnd = new Random(314);
            for(int k=0; k<hashBase.Length; k++) hashBase[k] = rnd.NextInt64();
        }
    }
}