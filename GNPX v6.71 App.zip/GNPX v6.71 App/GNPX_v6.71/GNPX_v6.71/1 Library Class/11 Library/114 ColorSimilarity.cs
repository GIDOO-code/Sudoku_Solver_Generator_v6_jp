using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
//using System.Drawing;
using System.Windows.Media;
using GNPX_space.Properties;

using static System.Math;


// base idia  http://blog.functionalfun.net/2008/07/random-pastel-colour-generator.html
namespace GNPX_space{
    public static class Color_Library{
    // Weighted distance accounting for human perceptual characteristics
        static private readonly double rWeight = 0.299;
        static private readonly double gWeight = 0.587;
        static private readonly double bWeight = 0.114;      
        
        public static double Get_Distance_Colors( Color c1, Color c2 ){
            int rDiff = c1.R - c2.R;
            int gDiff = c1.G - c2.G;
            int bDiff = c1.B - c2.B;

            // Calculation based on a weighted average
            //  (weighting based on coefficients from sources such as international ITU-R recommendations)
            double distance = Math.Sqrt( rWeight*rDiff*rDiff + gWeight*gDiff*gDiff + bWeight*bDiff*bDiff );

            // Normalized to the range of 0.0 to 1.0
            return distance / 255.0;
        }

            // Generate distinct pastel colors.
        public static List<Color> Generate_Distinct_PastelColors( int count=50, bool RandomizeB=false ){
            var colors = new List<Color>();

            foreach( int m in Enumerable.Range(0,count) ){
                // 1. Distribute the hue (H) evenly across 360 degrees (0.0 to 360.0)
                double hue = (360.0/count) * m;

                // 2. Configure the "high brightness, low-to-medium saturation" settings characteristic of pastel colors.
                double saturation = 0.70;  // 70% (Retains some vibrancy to make it easier to distinguish)
                double lightness  = 0.85;  // 85% (Make it a bright, gentle pastel tone)

                // 3. Convert from HSL to a Color object and add it to the list.
                Color color = FromHsl(hue, saturation, lightness);
                colors.Add(color);
            }

            if( RandomizeB ){
                Random _random = new Random();
                int n = colors.Count;
                while( n > 1){
                    n--;
                    int k = _random.Next(n+1);
                    Color value = colors[k];
                    colors[k] = colors[n];
                    colors[n] = value;
                }
            }

            return colors;
        }

        // Convert from HSL to a Color object and add it to the list.
        private static Color FromHsl(double H, double S, double L){
            double r=L, g=L, b=L;
            double v=(L<=0.5)? (L*(1.0+S)): (L+S-L*S);

            if(v>0){
                double m  = L+L-v;
                double sv = (v-m)/v;
                H /= 60.0;
                int sex = (int)Math.Floor(H);
                double fract = H-sex;
                double vsf  = v*sv*fract;
                double mid1 = m+vsf;
                double mid2 = v-vsf;

                switch (sex){
                    case 0: r=v;    g=mid1; b=m;    break;
                    case 1: r=mid2; g=v;    b=m;    break;
                    case 2: r=m;    g=v;    b=mid1; break;
                    case 3: r=m;    g=mid2; b=v;    break;
                    case 4: r=mid1; g=m;    b=v;    break;
                    case 5: r=v;    g=m;    b=mid2; break;
                }
            }

            return Color.FromArgb(
                (byte)255,
                (byte)Math.Clamp(r*255, 0, 255),
                (byte)Math.Clamp(g*255, 0, 255),
                (byte)Math.Clamp(b*255, 0, 255)
            );
        }
        
    }
}