using static System.Diagnostics.Debug;


namespace GNPX_space {
    using System.Drawing.Text;

    using pGPDM = GNPX_Puzzle_Database_Manager;

    public partial class GNPX_Puzzle_Analysis_Support {

        public void GNPX_Solver_using_Queue( CancellationTokenSource ctsAPQ ){
        // GNPX soover waits until a read signature (LS) arrives in the queue.
        // Once it arrives, analysis begins immediately.
            try{ 
                int nc = 0;
                do{
                    if(ctsAPQ.IsCancellationRequested)  break;
                                // WriteLine($"GNPX_Solver_using_Queue  nc:{++nc}  {DateTime.Now}");

                    if( QuePuzzle.Count <= 0 )　 Thread.Sleep(10);      // If LS_Queue is empty, sleep temporarily,
                    else{                                               // If LS_Queue is not empty, perform analysis using GNPX.

                        lock(obj ){
                            LatinSquare_9x9 LSQ_PZL = QuePuzzle.Dequeue();
                            if(LSQ_PZL == null) continue;
                          //G6.LS_Queue = LSQ_PZL .stSolX9p .Replace("  ","\n");
                            G6.LS_Queue = LSQ_PZL.stSolX9pp;
                            {
                               try{
                                    GNPX_Solver_in_Puzzle_Creator(LSQ_PZL);
                               }
                               catch(Exception ex ){ WriteLine(ex.Message + "\n" + ex.StackTrace); }
                            }
                            
                            if( G6.SolutionCounter >= G6.NoOfPuzzlesToCreate ){
                            	ctsAPQ.Cancel();
                            	break;
                            }
                        }
                    }

                }while(ctsAPQ.IsCancellationRequested is false);

                WriteLine($" stop nc:{nc}  {DateTime.Now}---------------- cts:{ctsAPQ.IsCancellationRequested} ");
            }
            catch(Exception e ){ WriteLine($"{e.Message}\n{e.StackTrace}"); }
            return;

                     void GNPX_Solver_in_Puzzle_Creator( LatinSquare_9x9 LSQ_PZL ){
                        try{ 
                            v7_UPuzzle_Base bPzl = new( LSQ_PZL.SolX);
                            UPuzzle qPZL = new UPuzzle(bPzl);                   // Create new UPuzzle

                            pGNPX_Eng.Set_NewPuzzle(qPZL);                    // Set Puzzle to Engin

                            // <2> Solve Puzzle 
                            pGNPX_Eng.AnalyzerCounterReset();           // (Not necessary)
                                                                        // ===================================================================================
                            string stRet = pGNPX_Eng.GNPX_SolvCompletely(ctsAPQ.Token); // Apply algorithms
                                                                                        // -----------------------------------------------------------------------------------
                            if(ctsAPQ.Token.IsCancellationRequested)  return;

                            //  <3> Solved 
                            if(stRet == "SolveUp" )  Register_and_Save_Puzzles( qPZL);
                            return;
                        }                     
                        catch(Exception e ){ WriteLine($"{e.Message}\n{e.StackTrace}"); }
                     }
        }


        private void Register_and_Save_Puzzles( UPuzzle qPZL ){
            #region Solved
            var bPzl = pGNPX_Eng.ePZL.v7B_Puzzle;

            // <<< The difficulty of the puzzle is acceptable? >>>
            int diffLvl = bPzl.difficulty;
            if( !G6.Only_LS && (diffLvl<G6.Puzzle_LevelLow || G6.Puzzle_LevelHigh<diffLvl) )  return;

            // randomize
            if(G6.Digits_Randomize)  qPZL.BOARD = _Randomize_Puzzle_Digits(qPZL);

            // <<< Set attributes >>>
            qPZL.pMethod = bPzl.method_MostDiffcul;
            qPZL.difficultyLevel = diffLvl;
            qPZL.BOARD.ForEach(p => p.Reset_All());

            // <<< Save >>>
            pGPDM.v7_GNPX_Puzzle_List_Add(qPZL.v7B_Puzzle);                               // -> GNPX internal list							
            if(G6.Save_CreatedPuzzle)  pGPDM.v7_current_Puzzle_No = int.MaxValue;

            G6.SolutionCounter++;
            Gidoo_EventHandler se = new Gidoo_EventHandler(eName: "PuzzleCreated", ePara0: G6.NoOfPuzzlesToCreate, G6.SolutionCounter);
            Send_Command_to_FCreateAuto2(this, se);

            // Forced pattern LS change
            if(++G6.GenPar00[0] >= G6.GenPar00[1] ){  //If puzzles with the same pattern are generated, the pattern will be forcibly changed.
                Send_Command_to_FCreateAuto2(this, new Gidoo_EventHandler(eName: "Force_ChangePattern")); //Instructions for changing patterns.
                QuePuzzle.Clear();
                G6.GenPar00[0] = 0;
            }

            // The required number of solutions has been found.
            if(!G6.Search_AllSolutions && G6.SolutionCounter>=G6.NoOfPuzzlesToCreate) return;
            if( G6.CbxNextLSpattern )   rxCTRL = 0;      //Change LS pattern at next puzzle generation
            #endregion Solved
        
            return;

                    // --------------------------------------------------------------------------------
                    List<UCell> _Randomize_Puzzle_Digits(UPuzzle qPZL ){
                        List<int> ranNum = new List<int>();
                        for(int no = 0; no < 9; no++) ranNum.Add( GNPX_Random.Next(0,9)*10+no );
                        ranNum.Sort((x,y) => (x-y));
                        for( int no=0; no<9; no++ )  ranNum[no] %= 10;

                        int[] P = new int[81];
                        for( int rc=0; rc<81; rc++ ){
                            int no = qPZL.BOARD[rc].No;
                            if( no>0 )  P[rc] = ranNum[no-1] + 1;
                        }

                        int rcX = 0;
                        List<UCell> Board = P.ToList().ConvertAll(q => new UCell(rcX++, q));
                        return Board;
                    }
        }



        public void task_GNPX_PuzzleCreatorAuto_QueB_new( Func_CreateAuto _fCreateAuto, CancellationTokenSource ctsG643 ){
            //WriteLine( $" --1 task_GNPX_PuzzleCreatorAuto_1" );
            if( FCreateAuto == null ){
                this.FCreateAuto = _fCreateAuto;
                Send_Command_to_FCreateAuto2 += new GNPX_EventHandler(FCreateAuto.GNPX_Event_Handling_man);
            }

            AnalyzerBaseV2.__SimpleAnalyzerB__ = true;
            G6.SolutionCounter = 0;

            try{ 
                G6.GenPar00[0] = 0;
                G6.GenPar00[2] = 0;
                do{
                    if(ctsG643.IsCancellationRequested)  break;

                    // =======================================================
                    LatinSquare_Creator( ctsG643, G6.GenPar00[3] );
                    // -------------------------------------------------------

                    if( G6.SolutionCounter >= G6.NoOfPuzzlesToCreate )  return;
                    if( G6.LS_PatternChangeCommand ){
                        if(QuePuzzle != null)  QuePuzzle.Clear();
                        G6.LS_PatternChangeCommand = false;
                    }

                    else if( ++G6.GenPar00[2] >= G6.GenPar00[3] ){  // Force pattern change
                        Send_Command_to_FCreateAuto2(this, new Gidoo_EventHandler(eName: "Force_ChangePattern"));
                        G6.GenPar00[0] = 0;
                        G6.GenPar00[2] = 0;
                    }
                    else   break;

                }while(!ctsG643.IsCancellationRequested);
            }
            catch(TaskCanceledException ){ WriteLine("...Canceled by user."); }
            catch(Exception ex ){ WriteLine(ex.Message + "\n" + ex.StackTrace); }
              
            return;
        }
    }
}
