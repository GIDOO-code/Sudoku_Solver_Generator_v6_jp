using GIDOO_space;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space {
    public partial class GNPX_Puzzle_Analysis_Support{
        static private int validTCC2;
        private LatinSquareGen LSG2 = new LatinSquareGen();
        private DLX_V2.SudokuSolver SDK_Solver = new();

        private void LatinSquare_Creator( CancellationTokenSource ctsG643, int LS_sizeX ){

            try{ 
                // step1: Generate LatinSquare frames (block-1,2,3,47).

                int sizeUnit = G6.GenPar00[4], sizeLS_Total = 0;            // #####			
                int nS = 0, nE;
                do {
                    nE = Min(nS + sizeUnit, LS_sizeX);
                    int sizeStep = nE - nS;
                    //WriteLine($"\n ###  G6.GenPar00:{string.Join(",", G6.GenPar00)}  nS-nE:({nS},{nE})  LS_sizeX:{LS_sizeX}  sizeStep:{sizeStep}");
                    if(sizeStep <= 0)  break;

                    // Generate the initial frames (block-1,2,3,4,7) for Latin Square generation.
                    string[] LS_block12347_List = new string[sizeStep];
                    foreach( var (mx, cc) in Enumerable.Range(0, sizeStep).WithIndex() ){
                        var (_, _, stP) = LSG2.Set_Parameter(randomB: true);
                        LS_block12347_List[mx] = stP;
                    }

                    G6.GenPar00[2] = nE;
                    int nc = LS_ListLatinSquare_Creator_sub(ctsG643, LS_block12347_List);
                    if( G6.Only_LS && nc==-99999 )  return;

                    nS = nE;
                }while(true);

                return;
            }
            catch(Exception e ){ WriteLine($"{e.Message}\n{e.StackTrace}"); }
            return;
        }


        private int LS_ListLatinSquare_Creator_sub( CancellationTokenSource ctsG643, string[] LS_block12347_List ){
            int candidateCC = 0, sizeStep = LS_block12347_List.Length;
            try{ 
                // step2  Generate a LatinSquare from the frame (block-1,2,3,47).
                // G6.GenMessage = "Generate a LatinSquare from the fram";
                List<LatinSquare_9x9>[] LSs_List = new List<LatinSquare_9x9>[sizeStep];

                int MaxDegreeOfParallelism = (int)(Environment.ProcessorCount * G6.Processor_Utilization);
                ParallelOptions options = new( ){ CancellationToken = ctsG643.Token, MaxDegreeOfParallelism=MaxDegreeOfParallelism };

                // Generate LatinSquare from "control frame". There is no limit(int.MaxValue) to the number of LS generated.
                //foreach(int mx in Enumerable.Range(0, sizeStep) ){    // Sequence
                Parallel.For( 0, sizeStep, options, (mx,state) => {    // Parallel
                    if( ctsG643.IsCancellationRequested ){ state.Stop(); /*throw new Exception("cancel");*/ }
                    Research_trial RTrial = new();
                    List<string> solList = RTrial.TrialAndErrorApp(LS_block12347_List[mx], filePutB:false, upperLimit:int.MaxValue);

                    // Apply "Pattern" and set "hash value".
                    LSs_List[mx] = solList.ConvertAll(P => new LatinSquare_9x9(P, ApplyPatternB: true, GPat81: PatGen.GPat81, debugB: false));
                } );
                int LS_Total = LSs_List.Aggregate(0, (a, b) => a + b.Count);
                // -----------------------------------------------------------------------------------------------






                // step3  Remove the same pattern LS.
                // G6.GenMessage = "Remove the same pattern";
                List<LatinSquare_9x9> aLS_List = new List<LatinSquare_9x9>();
                foreach( int mx in Enumerable.Range(0,sizeStep) ){
                    var LSs_List_single = LSs_List[mx].DistinctBy(P => P.hashVal).ToList();
                    aLS_List.AddRange(LSs_List_single);
                }
                aLS_List = aLS_List.DistinctBy(P => P.hashVal).ToList();
                // -----------------------------------------------------------------------------------------------



                // step4
                if( aLS_List!=null && aLS_List.Count>0 ){
                    int nc = Select_Unique_LatinSquare_Sequence( ctsG643, LS_Total, aLS_List);              // Sequence                                                                                   //int nc = Select_Unique_LatinSquare_Parallel(options3,  LS_Total, aLS_List );	// Parallel ###
                //    int nc = Select_Unique_LatinSquare_Parallel( ctsG643, options, LS_Total, aLS_List);     // Parallel  
    
                    if( G6.Only_LS && G6.SolutionCounter>=G6.NoOfPuzzlesToCreate )  return -99999;
                }

                aLS_List = aLS_List.FindAll(Q => Q.validCC == 1);
                aLS_List.Sort((a, b) => a.CompareTo2(b));   // Sorting by actual pattern
                                                            // -----------------------------------------------------------------------------------------------
                candidateCC = aLS_List.Count();
            }
            catch(Exception e ){ WriteLine($"{e.Message}\n{e.StackTrace}"); }
            return candidateCC;
        }




        int Select_Unique_LatinSquare_Sequence( CancellationTokenSource ctsG643, int LS_Total, List<LatinSquare_9x9> aLS_List ){
            int validTCC = 0;
            try{ 
                int RTQcc = 0, RTQccT = aLS_List.Count;

                int aLS_List_Count = aLS_List.Count;
                foreach(var (P, mx) in aLS_List.WithIndex() ){
                    if( ctsG643.IsCancellationRequested )  break;
                    //if( (mx%50) == 0 )  WriteLine( $"{mx} / {aLS_List.Count}" );
                    Research_trial RTrialQ = new( );                   
                    var stList = RTrialQ.TrialAndErrorApp(P.SolX.ToList(), filePutB: false, upperLimit:2);
                    P.validCC = stList.Count;
             
                    if( (++RTQcc%100) == 0 ) G6.GenMessage = $"Latin Squares : {RTQcc:N0} / {RTQccT:N0}";

                    if( stList.Count == 1 ){
                        validTCC++;
                         if( !G6.Only_LS ){ if( QuePuzzle.Count<200 ) this.QuePuzzle.Enqueue(P); }

                        // [Research] Searching for the limits of Sudoku Puzzle
                        if(G6.zPowerUserCC >= 20 ){  // Preventive measures against parallel operation.
                            int nn = P.SolX.Count(p => p>0);
                            if( nn<=40 && G6.Only_LS ){ // 20 ### debug    
                                pGNPX_App.fPuzzleFile_IO.Save_LS_Puzzle_ToFile(nn, P.stSolX, stList[0]);
                                
                                v7_UPuzzle_Base bPzl = new(P.SolX);
                                UPuzzle qPZL = new UPuzzle(bPzl);                 // Create new UPuzzle
                                pGNPX_Eng.Set_NewPuzzle(qPZL);                    // Set Puzzle to Engin
                                Register_and_Save_Puzzles(qPZL);

                                if( G6.SolutionCounter >= G6.NoOfPuzzlesToCreate )  break;
                            }
                        }
                    }
                }
            }
            //		catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }
            catch(OperationCanceledException e ){ WriteLine($"{e.Message}\n{e.StackTrace}"); }
            return validTCC;
        }



        private int Select_Unique_LatinSquare_Parallel( CancellationTokenSource ctsG643, ParallelOptions options, int LS_Total, List<LatinSquare_9x9> aLS_List ){
            int validTCC = 0;
            try{ 
                int RTQcc = 0, RTQccT=aLS_List.Count;
                Parallel.ForEach( aLS_List, options, (P,state) => {
                    if( ctsG643.IsCancellationRequested )  state.Stop();
                    
                    Research_trial RTrialQ = new( );
                    var stList = RTrialQ.TrialAndErrorApp( P.SolX.ToList(), filePutB: false, upperLimit:2);

                    lock(obj){
                        if( (++RTQcc%100) == 0 ) G6.GenMessage = $"Latin Squares : {RTQcc:N0} / {RTQccT:N0}";
                    }
                    
                    if( stList.Count==1 ){
                        lock(obj){
                            validTCC++;
                            if( !G6.Only_LS ){ if( QuePuzzle.Count<200 ) this.QuePuzzle.Enqueue(P); }
                            
                            // [Research] Searching for the limits of Sudoku Puzzle
                            if(G6.Only_LS ){  // Preventive measures against parallel operation.
                                int nn = P.SolX.Count(p => p>0 );
                                // This function works only when the number of cells is 20 or fewer.
                                if( nn <= 40 ){ // 20 ### debug           
                                    pGNPX_App.fPuzzleFile_IO.Save_LS_Puzzle_ToFile(nn, P.stSolX, stList[0]);

                                    v7_UPuzzle_Base bPzl = new(P.SolX);
                                    UPuzzle qPZL = new UPuzzle(bPzl);                 // Create new UPuzzle
                                    pGNPX_Eng.Set_NewPuzzle(qPZL);                    // Set Puzzle to Engin
                                    Register_and_Save_Puzzles(qPZL);

                                    if( G6.SolutionCounter >= G6.NoOfPuzzlesToCreate )  state.Stop();
                                }
                            }
                        }
                    }
                } );
            }
            catch(OperationCanceledException e ){ WriteLine($"{e.Message}\n{e.StackTrace}"); }
            return validTCC;
        }
    }

}

