﻿using System;
using System.Linq;
using System.Collections.Generic;
using static System.Diagnostics.Debug;
using static System.Math;
using System.Threading;
using System.Threading.Tasks;
using System.Reflection.Metadata.Ecma335;
using System.Windows.Threading;

using GIDOO_space;
using System.Windows.Controls;

namespace GNPX_space{

    // ...  This class will change in the future.  ............
    //     Organize items into the following classes. ---> GNPX_AnalyzerMan, GNPX_Puzzle_Analysis_Support, GNPX_Engin, ...

    public partial class GNPX_Puzzle_Analysis_Support{    
        static public event GNPX_EventHandler Send_Command_to_GNPXwin; 
		static public event GNPX_EventHandler Send_Command_to_FCreateAuto2; 
		static public event GNPX_EventHandler Send_Command_to_FGenerateAllLS; 
        static private G6_Base G6 => GNPX_App_Man.G6;
        static private G7_Base G7 => GNPX_App_Man.G7;

        static public Random	GNPX_Random;






        static public int    rxCTRL = -1;      //=0:


        public Queue<LatinSquare_9x9> QuePuzzle;
        public LatinSquareGen_v5      LSGen;     // V5.87@@
        private object                obj = new();
        private Func_CreateAuto       FCreateAuto;

        private bool _DEBUGmode_ = false; //false; //true;// 

		public GNPX_Engin		pGNPX_Eng;
		public GNPX_AnalyzerMan pAnMan => pGNPX_Eng.AnMan; 

        private GNPX_App_Man	pGNPX_App;
        private GNPX_win		pGNP00win{ get=> pGNPX_App.pGNP00win; } 

        public PatternGenerator PatGen;         //Puzzle Pattern
												 
        public GNPX_Puzzle_Analysis_Support( GNPX_App_Man  pGNPX_App, int FirstCellNum ){
            this.pGNPX_App = pGNPX_App;
			pGNPX_Eng	= pGNPX_App.GNPX_Eng;
            Send_Command_to_GNPXwin     += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  
			Send_Command_to_FCreateAuto2 += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  
			Send_Command_to_FGenerateAllLS += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  
            
            G6.CellNumMax = FirstCellNum; 

            PatGen = new PatternGenerator( this );

            LSGen  = new LatinSquareGen_v5();	//LatinSquareGen_v5( );	//
//			LSGenV6  = new LatinSquareGen();	//LatinSquareGen( );	// V5.87@@
        }



        public Random Set_RandomSeed( int rs ){
			int rsVal = rs;     
            if(rs==0){
              //rsVal=Environment.TickCount&Int32.MaxValue;
                rsVal = (int)DateTime.Now.Ticks;
                WriteLine($"DateTime.Now.Ticks:{DateTime.Now.Ticks}  randomSeedVal:{rsVal}");
            }
			//G6.RandomSeedVal = Abs(rsVal);	// Debug with fixed conditions.

            GNPX_Random = new Random(rsVal);
				WriteLine( $"GNPX_Puzzle_Analysis_Support/SetRandomSeed : {rsVal}" );
			return GNPX_Random;
        }


    #region Analizer
        public void task_Analyzer_SingleStage( CancellationToken cts, bool methodSet=true ){      //Analysis[step]
            try{
                G6.retNZ = -1;
                pGNPX_Eng.GNPX_Solver_SingleStage( cts:cts, Set_Solution_Info:true );
				G6.EnginState = cts.IsCancellationRequested? 3: 2; 
            }
            catch(TaskCanceledException){ WriteLine("...Canceled by user."); }
            catch(Exception ex){ WriteLine( $"{ex.Message}\n{ex.StackTrace}"); }   
        }
    #endregion Analizer

    }
}
    