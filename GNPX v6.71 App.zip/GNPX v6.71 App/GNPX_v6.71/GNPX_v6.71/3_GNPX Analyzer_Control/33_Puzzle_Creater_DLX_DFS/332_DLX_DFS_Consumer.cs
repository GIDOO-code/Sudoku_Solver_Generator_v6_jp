﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using static System.Numerics.BitOperations;

using GIDOO_space;

using GNPX_space;

using static System.Diagnostics.Debug;
using static System.Net.Mime.MediaTypeNames;
using System.Numerics;


namespace GNPX_space {    
	using pGPDM = GNPX_Puzzle_Database_Manager;

    public partial class DLX_DFS_Solver_Consumer_Shrinker{
        GNPX_App_Man  pGNPX_App => Func_CreateAuto2.pGNPX_App;

        private readonly CancellationToken _linkedCts331;
        private static readonly Random Rand = new Random();
        private string  sp140 = new string(' ',140);

		static private G6_Base G6 => GNPX_App_Man.G6;
		static private G7_Base G7 => GNPX_App_Man.G7;


        // To support thread parallelization, `ThreadStatic` is used to assign an independent bitmask to each thread.
        [ThreadStatic] private static int[]   _rowMask;
        [ThreadStatic] private static int[]   _colMask;
        [ThreadStatic] private static int[]   _boxMask;

        private static int[] RowMask => _rowMask ??= new int[9];
        private static int[] ColMask => _colMask ??= new int[9];
        private static int[] BoxMask => _boxMask ??= new int[9];

        private readonly SDK_DLX_DFS_Solver pSDK_X3C;
        private readonly ConcurrentQueue<int[]> pDLX_SudokuQueue;
        private readonly int    DLX_Prod_Cells;  
        private readonly int    DLX_Prod_Sym_Type = 2;

        public Page      func_auto2;
        public  int      WorkCount = 0;          // Thread-safe cumulative counter
        private long    _totalActiveTicks = 0;  // Internal tick count for thread-safe time accumulation

        private object  lockObj = new object();

        public double ActiveSeconds {
            get { return (double)Interlocked.Read(ref _totalActiveTicks) / System.TimeSpan.TicksPerSecond; }
            set { Interlocked.Exchange(ref _totalActiveTicks, (long)(value * System.TimeSpan.TicksPerSecond)); }
        }

        public DLX_DFS_Solver_Consumer_Shrinker( SDK_DLX_DFS_Solver SDK_X3C,  CancellationToken linkedCts331 ){
            this.pSDK_X3C = SDK_X3C;
            this.func_auto2 = SDK_X3C.func_auto2;

            this._linkedCts331 = linkedCts331;

            this.pDLX_SudokuQueue   = pSDK_X3C.DLX_SudokuQueue;
            this.DLX_Prod_Cells     = pSDK_X3C.DLX_Prod_Cells;
            this.DLX_Prod_Sym_Type  = pSDK_X3C.DLX_Prod_Sym_Type;
        }


        public void A3_StartEngine_Parallel( bool debugPrint ){
            WriteLine( $"[Consumer] +++++ Parallel, Scraping Engine has started.");
            var activeWatch = new Stopwatch();
            
            try{
                var parallelOptions = new ParallelOptions{
                    CancellationToken = _linkedCts331,
                    MaxDegreeOfParallelism = Environment.ProcessorCount
                };

                Parallel.For(0, int.MaxValue, parallelOptions, (i, loopState) => {
                                if( _linkedCts331.IsCancellationRequested ){ return; }

                    int[] basePuzzle;
                    if( !pDLX_SudokuQueue.TryDequeue(out basePuzzle) ){ Thread.Sleep(50); return; }
                                if( _linkedCts331.IsCancellationRequested ){ return; }

                    int startSize = basePuzzle.Count(x=>x!=0);
                    WriteLine( $" --- TryDequeue[[{pDLX_SudokuQueue.Count,2}] {basePuzzle.To_Line_String()}  {startSize} cells  Ghost Differential DFS" );

                    long startTicks = System.DateTime.UtcNow.Ticks;
                    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
                    int[] boad1D = basePuzzle.Cast<int>().ToArray();
                    var (IsShrink,boadDshrink) = DfsShrink_man( boad1D );
                    if( !IsShrink || boadDshrink==null ){ return; }

                    int diff = Shrink_size - startSize;
                    if(diff<0){
                        string  st20 = (Shrink_size<=21)? new string('*',(Shrink_size-20)): "";
                        WriteLine($"{sp140} --- [Prog-1]  {startSize} -> {Shrink_size} cells  {diff,3} {st20}");
                    }       
                    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
                    // <<< Save >>>

                    lock(lockObj){
                        v7_UPuzzle_Base bPzl = new(boadDshrink);
                        pGPDM.v7_GNPX_Puzzle_List_Add(bPzl);                               // -> GNPX internal list	
// /*  @@@ RBD       
G6.SolutionCounter++;
Gidoo_EventHandler se = new Gidoo_EventHandler(eName: "PuzzleCreated", ePara0: G6.NoOfPuzzlesToCreate, G6.SolutionCounter);
((Func_CreateAuto2)func_auto2).GNPX_Event_Handling_man(this, se);
// */
                        if( (bool)G6.CreateAuto2_Save_auto )  pGNPX_App.fPuzzleFile_IO.Save_Puzzle_ToFile(bPzl, fNameS:"Puzzle_DLX_DFS_P_");  // -> File    /* @@@ */
                    }

                    long elapsedTicks = System.DateTime.UtcNow.Ticks - startTicks;
                    Interlocked.Add(ref _totalActiveTicks, elapsedTicks);

                    Interlocked.Increment( ref G6.CreateAuto2_Puzzlis[Shrink_size-17] );

                    Interlocked.Increment(ref WorkCount);


                });
            }

            catch (OperationCanceledException e ){
                WriteLine( $"{e.Message}\n{e.StackTrace}");
            }
            catch(AggregateException ae) when (ae.InnerExceptions.All(e => e is OperationCanceledException) ){ }
            catch(Exception e ){
                WriteLine($"!!! [Consumer Error] : {e.Message}\n{e.StackTrace}");
            }
            finally{
                WriteLine("[Consumer] Detected the stop command from the app or a session termination, and completely exited the loop.");
            }
        }

        public void A3_StartEngine_Sequence( bool debugPrint ){
            WriteLine("[Consumer] ----- Sequence, Scraping Engine has started.");
            var activeWatch = new Stopwatch();
            
            try{
                var parallelOptions = new ParallelOptions{
                    CancellationToken = _linkedCts331,
                    MaxDegreeOfParallelism = Environment.ProcessorCount
                };

                while(true){
                                if( _linkedCts331.IsCancellationRequested ){ return; }

                    int[] basePuzzle;
                    if( !pDLX_SudokuQueue.TryDequeue(out basePuzzle) ){ Thread.Sleep(50); continue;; }
                                if( _linkedCts331.IsCancellationRequested ){ return; }

                    int startSize = basePuzzle.Count(x=>x!=0);
                    WriteLine( $" --- TryDequeue[[{pDLX_SudokuQueue.Count,2}] {basePuzzle.To_Line_String()}  {startSize} cells  Ghost Differential DFS" );
                    
                    long startTicks = System.DateTime.UtcNow.Ticks;
                    
                    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
                    int[] boad1D = basePuzzle.Cast<int>().ToArray();
                    var (IsShrink,boadDshrink) = DfsShrink_man( boad1D );
                    if( !IsShrink || boadDshrink==null ){ return; }
                    int diff = Shrink_size - startSize;
                    if( Shrink_size<=20 && diff<0 ){
                        string stars = new string('*', Math.Abs(diff));
                        WriteLine( $"{sp140} ***** [Prog-1]  {Shrink_size} cell！ {diff,3} {stars}");
    //                    SaveToSingleLineFile( srShrink, Shrink_size );
                    }
                    else if(diff<0){
                        WriteLine($"{sp140} --- [Prog-1]  {startSize} -> {Shrink_size} cells  {diff,3}");
                    }       
                    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
                    // <<< Save >>>
                    v7_UPuzzle_Base bPzl = new(boadDshrink);
                    UPuzzle qPZL = new UPuzzle(bPzl);
                    pGPDM.v7_GNPX_Puzzle_List_Add(bPzl);                               // -> GNPX internal list	
/*  @@@ RBD      
G6.SolutionCounter++;
Gidoo_EventHandler se = new Gidoo_EventHandler(eName: "PuzzleCreated", ePara0: G6.NoOfPuzzlesToCreate, G6.SolutionCounter);
Send_Command_to_FCreateAuto2(this, se);
*/
                    if( (bool)G6.CreateAuto2_Save_auto )  pGNPX_App.fPuzzleFile_IO.Save_Puzzle_ToFile(bPzl,fNameS:"Puzzle_DLX_DFS_S_");  // -> File      

                    long elapsedTicks = System.DateTime.UtcNow.Ticks - startTicks;
                    Interlocked.Add(ref _totalActiveTicks, elapsedTicks);
                    Interlocked.Increment( ref G6.CreateAuto2_Puzzlis[Shrink_size-17] );
                    Interlocked.Increment(ref WorkCount);
                }
            }

            catch (OperationCanceledException ){ }
            catch (AggregateException ae) when (ae.InnerExceptions.All(e => e is OperationCanceledException) ){ }
            catch (Exception e ){
                WriteLine($"!!! [Consumer Error] : {e.Message}\n{e.StackTrace}");
            }
            finally{
                WriteLine("[Consumer] Detected the stop command from the app or a session termination, and completely exited the loop.");
            }
        }



        private (bool,int[]) DfsShrink_man( int[] boad1D ){ // DFS : Depth-First Search
          try{
            UInt128 fixedCell = UInt128.Zero;
            foreach( var (x,kx) in boad1D.ToList().WithIndex() ){ if(x>0) fixedCell |= UInt128.One<<kx; }
            int SizeLevel = (int)UInt128.PopCount(fixedCell);

            Shrink_size = SizeLevel;
            Shrink_fixedCell = fixedCell;

            DfsShrink( boad1D, fixedCell, SizeLevel-1 );
            
            bool retB = (Shrink_size<SizeLevel);
            return (retB,boad1D);
          }
          catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }
            return (false,null);
        }

        private int     Shrink_size;
        private UInt128 Shrink_fixedCell;

        private void  DfsShrink( int[] board1D, UInt128 fixedCell, int SizeLevel ){
            Research_trial RT = new();

            int[]  boadDshrink = (int[])board1D.Clone();;
            foreach( int rcX in fixedCell.IEGet_rc() ){
                UInt128 fixedCell2 = fixedCell & ~(UInt128.One<<rcX);

                board1D.CopyTo(boadDshrink,0);
                boadDshrink[rcX] = 0;
                
                List<int[]> solList = RT.TE_Solver(boadDshrink, maxSol:2);

                if( solList.Count == 1 ){
                            //WriteLine( $" *** Succeed" );

                    if( SizeLevel < Shrink_size ){
                        Shrink_size = SizeLevel;
                        Shrink_fixedCell = fixedCell2;
                    }
                    DfsShrink( boadDshrink, fixedCell2, SizeLevel-1);
                }
            }
        }

    }
}