﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

using GIDOO_space;
using GIDOO_space;

using static System.Diagnostics.Debug;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space {    
    public partial class DLX_DFS_Solver_ver_1{

       static UInt128[] pHouseCells81 => GNPX_Utilitie.HouseCells81;
       static UInt128[] pConnected_81 => GNPX_Utilitie.Connected_81;
		static private G6_Base G6 => GNPX_App_Man.G6;
		static private G7_Base G7 => GNPX_App_Man.G7;

        private readonly CancellationToken _linkedCts331;

        private readonly SDK_DLX_DFS_Solver pSDK_X3C;
        private readonly ConcurrentQueue<int[]> pDLX_SudokuQueue;
        private readonly int    DLX_Prod_Cells;  
        private readonly int    DLX_Prod_Sym_Type = 2;
        private readonly string DLX_Prod_Mode_Type = "layout";

        public int ProductionCount = 0;


        [ThreadStatic]
//        private static Random _localRand;
//        private static Random Rand => _localRand ??= new Random(Guid.NewGuid().GetHashCode());

    //  private static Random Rand = new Random(1);     // @@@ Fixed during development
        private static Random Rand = new Random();

                    private class Node {
                        public Node Up, Down, Left, Right;
                        public ColumnNode Column;
                        public int RowIndex;
                    }

                    private class ColumnNode : Node {
                        public int Size;
                        public int ColumnIndex;
                    }
        public DLX_DFS_Solver_ver_1( SDK_DLX_DFS_Solver SDK_X3C,  CancellationToken linkedCts331Token ){
            this.pSDK_X3C = SDK_X3C;
            this._linkedCts331 = linkedCts331Token;

            this.pDLX_SudokuQueue   = pSDK_X3C.DLX_SudokuQueue;
            this.DLX_Prod_Cells     = pSDK_X3C.DLX_Prod_Cells;
            this.DLX_Prod_Sym_Type  = pSDK_X3C.DLX_Prod_Sym_Type;
        }

            
        public void A4_StartEngine_Parallel( ){
            WriteLine($"[Producer] Parallel [{DLX_Prod_Mode_Type}]モード Type[{DLX_Prod_Sym_Type}] The supply engine has started.");
            try {
                int targetThreads = Math.Max(1, (int)(Environment.ProcessorCount * 0.7));
                
                var parallelOptions = new ParallelOptions {
                    CancellationToken = _linkedCts331,
                    MaxDegreeOfParallelism = targetThreads
                };

                Parallel.For(0, int.MaxValue, parallelOptions, (i, loopState) => {
                            if( _linkedCts331.IsCancellationRequested ){ loopState.Stop(); return; }
                    if( pDLX_SudokuQueue.Count >= 50 ){ Thread.Sleep(100); return; }
                            if( _linkedCts331.IsCancellationRequested ){ loopState.Stop(); return; }

                    var (puzzle,nc) = A4_Generate_Symmetric_nn_Puzzle( DLX_Prod_Mode_Type, DLX_Prod_Sym_Type );
                    if( puzzle != null ){
                        pDLX_SudokuQueue.Enqueue(puzzle);
                        Interlocked.Increment(ref ProductionCount);
                    }
                });
            }
            catch (OperationCanceledException ){ }
            catch (AggregateException ae) when (ae.InnerExceptions.All(e => e is OperationCanceledException) ){ }
            catch (Exception e ){ 
                WriteLine($"!!! [Producer error] : {e.Message}\n{e.StackTrace}"); 
            }

            WriteLine("[Producer] Received a stop command from the app and completely terminated the loop.");
        }


        public void A4_StartEngine_Sequence( ){
            WriteLine($"[Producer] Parallel [{DLX_Prod_Mode_Type}] mode Type[{DLX_Prod_Sym_Type}] The supply engine has started.");
            try{
                while(true){
                    if( pDLX_SudokuQueue.Count >= 50 ){ Thread.Sleep(100); continue; }
                            if( _linkedCts331.IsCancellationRequested ){ return; }

                    var (puzzle,nc) = A4_Generate_Symmetric_nn_Puzzle( DLX_Prod_Mode_Type, DLX_Prod_Sym_Type );
                    if( puzzle != null ){
                        pDLX_SudokuQueue.Enqueue(puzzle);
                        Interlocked.Increment(ref ProductionCount);
                    }
                }
            }
            catch (OperationCanceledException ){ }
            catch (AggregateException ae) when (ae.InnerExceptions.All(e => e is OperationCanceledException) ){ }
            catch (Exception e ){ 
                WriteLine($"!!! [Producer error] : {e.Message}\n{e.StackTrace}"); 
            }

            WriteLine("[Producer] Received a stop command from the app and completely terminated the loop.");
        }



        // Optionally, cell distribution density information can be added.
        private (int[],int) A4_Generate_Symmetric_nn_Puzzle( string mode, int type ){
            int genTarget = DLX_Prod_Cells;

            DLX_V2.SudokuSolver SDK_Solver = new();　// standard DLX solver

            while( !_linkedCts331.IsCancellationRequested ){
                // (11) Generates a different completed board state each time.
                int[] board_A51 = _A51_GenerateSolutionBoard();                            // ___ A51
                if( board_A51 == null)  continue;
                var board_A51copy = board_A51.Cast<int>().ToArray();

                var cellGroups = A41_GetSymmetricGroups_81B(type);
                cellGroups = cellGroups.OrderBy(x => Rand.Next()).ToList();                 // Rand #################  

                int currentCount = 81;
                foreach( var (group81B,kx) in cellGroups.WithIndex() ){
                    if( _linkedCts331.IsCancellationRequested) return (null,-1);

                    foreach( var rc in group81B.IEGet_rc() )  board_A51[rc] = 0;
                    int[] testBoard = (int[])board_A51.Clone();
                    if( _A52_CountSolutionsDLX(testBoard,2) == 1 ){                        // _A52 #################  
                        currentCount -= group81B.BitCount();
                        if( currentCount <= genTarget )  break;         
                    }
                    else{
                        foreach( var rc in group81B.IEGet_rc() )  board_A51[rc] = board_A51copy[rc];
                    }
                }
                
                // Symmetry is not guaranteed.
                List<int> singles = new();
                for( int rc=0; rc<81; rc++ ){
                        if( board_A51[rc] != 0) singles.Add((rc));
                }
                singles = singles.OrderBy(x => Rand.Next()).ToList();                       /// Rand #################

                foreach( var rc in singles ){
                    if( _linkedCts331.IsCancellationRequested) return (null,-1);

                    board_A51[rc] = 0;                          // Exclude target diita.
                    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
                    int[] testBoard = (int[])board_A51.Clone();
                    if( _A52_CountSolutionsDLX(testBoard,2) == 1 ){
                        currentCount--;  
                        if( currentCount == genTarget )  break;
                    }
                    else  board_A51[rc] = board_A51copy[rc];    // Recovery.
                    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
                }
                return  (board_A51,currentCount);

            }
            return (null,-1);


                // --------------------------------------------------------
                    int[] _A51_GenerateSolutionBoard( ){
                        int[] board = new int[81];

                        // @@@ Element selection is performed randomly.
                        //     Functional changes are required to replace it with the standard DLX solver.

                        SDK_Dlx_Solver dlx = new( board, randomMode:true);    //@@@ Use the object definition and `solve` together.
                        if( dlx.Solve(1)>0 ) return dlx.GetFirstSolution(); 

                        return null;
                    }


                /*
                    int _A52_CountSolutionsDLX(int[] board, int limit ){
                        SDK_Dlx_Solver dlx = new( board, randomMode:false );
                        return dlx.Solve(limit);
                    }
                */
        
                    // @@@ standard DLX solver
                    int _A52_CountSolutionsDLX(int[] board, int limit ){
                        var solutions = SDK_Solver.Solve( board, maxSolutions:limit /*,ct*/); 
                        return solutions.Count;
   
                    }

        }
    }
}