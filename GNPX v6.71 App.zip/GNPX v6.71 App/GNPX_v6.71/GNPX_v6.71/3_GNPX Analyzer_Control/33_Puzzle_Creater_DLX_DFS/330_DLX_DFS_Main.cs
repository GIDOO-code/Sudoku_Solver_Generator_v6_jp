﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

using Windows.Data.Xml.Dom;

using static System.Diagnostics.Debug;

namespace GNPX_space {    

    public class SDK_Puzzle_Creator_2520{
		static private G6_Base G6 => GNPX_App_Man.G6;
		static private G7_Base G7 => GNPX_App_Man.G7;

        static public ConcurrentQueue<int[,]> DLX_SudokuQueue = new ConcurrentQueue<int[,]>();

        static public CancellationTokenSource DLX_Cts330;  // @@@2520

        static public Task DLX_RunnerTask;

        public        Page   func_auto2;
        public int    DLX_Prod_Cells;  
        public int    DLX_Prod_Sym_Type = 2;

        public SDK_Puzzle_Creator_2520( Page func_auto2 ){
            this.func_auto2 = func_auto2;
            DLX_Prod_Sym_Type  = G6.CreateAuto2_type;
        }

/*
        // <<< Func_CreateAuto2 >>>
        public int CreateAuto2_type;
        public int CreateAuto2_NoToCreate;
        public int CreateAuto2_sizeMax;
        public int CreateAuto2_sizeMin;
        public int[] CreateAuto2_Puzzlis; //[0]17 - [13]30 
*/

        public void A_SDK_2520_Solver( int maxTime ){  // "DLX_RunnerTask_Start up"

            #region If the old runner task (DLX_RunnerTask) is active, stop it. Confirm its complete termination.
                if( DLX_RunnerTask!=null && !DLX_RunnerTask.IsCompleted && !DLX_RunnerTask.IsCanceled && !DLX_RunnerTask.IsFaulted ){
                    WriteLine("[Main] The DLX_runner is already running normally in the background. Skipping startup.");
                    return;
                }
                // -------------------------------------------------------------------------------------------------------------------

                // Reliably monitors the legacy runner task (DLX_Runner Task) at 50-millisecond intervals without halting the thread,
                // until it fully concludes with a "completed" status.
                if( DLX_RunnerTask!=null ){
                    var timeoutWatch = Stopwatch.StartNew();
                    while( !DLX_RunnerTask.IsCompleted && !DLX_RunnerTask.IsCanceled && !DLX_RunnerTask.IsFaulted ){
                        Thread.Sleep(50); 
                        if( timeoutWatch.ElapsedMilliseconds > 3000 ) break;
                    }
                    DLX_RunnerTask = null;
                }
                // -----------------------------------------------------------------

                while( DLX_SudokuQueue.TryDequeue(out _)  ){ }
                // -----------------------------------------------------------------
            #endregion

            // Start in a clean state
            DLX_Cts330 = new CancellationTokenSource();
            var runner = new SDK_DLX_DFS_Solver( func_auto2, DLX_Prod_Cells, DLX_Prod_Sym_Type );

            DLX_RunnerTask = Task.Run(() => runner.A2_Run_Auto_Creator_Loop( maxTime,DLX_Cts330.Token), DLX_Cts330.Token);
                WriteLine("[Main] Launched a new task in a completely reset, clean state.");
        }



        public void SDK_2520_Solve_suspend(){
            if( DLX_Cts330 != null && !DLX_Cts330.IsCancellationRequested ){
                DLX_Cts330.Cancel(); 
                DLX_Cts330.Dispose(); 
                DLX_Cts330 = null;
                    WriteLine("[Main] A command to completely stop the entire application has been sent.");
            }
        }
    }
}