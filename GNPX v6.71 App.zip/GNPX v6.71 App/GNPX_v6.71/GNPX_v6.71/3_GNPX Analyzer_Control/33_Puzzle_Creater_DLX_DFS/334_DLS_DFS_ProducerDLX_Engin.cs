﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

using GIDOO_space;

using static System.Diagnostics.Debug;


namespace GNPX_space{    
    public partial class DLX_DFS_Solver_ver_1{
        // ================================================= GLX Engin Class ===================
        
        public class SDK_Dlx_Solver {  // DLX_Solver_ver_2
            private ColumnNode  root;
            private List<int[]> solutions = new();
            private List<Node>  answer = new List<Node>();
            private bool        randomMode;

                    private class Node {
                        public Node Up, Down, Left, Right;
                        public ColumnNode Column;
                        public int RowIndex;

                        public override string ToString( ){
                            string st = $"{this.Left.RowIndex,3} <-- {this.RowIndex,3} --> {this.Right.RowIndex,3}";
                            return st;
                        }
                    }

                    private class ColumnNode: Node {
                        public int Size;
                        public int ColumnIndex;
                        public override string ToString( ){
                            string st = $"{((ColumnNode)this.Left).ColumnIndex,3} <-- {this.ColumnIndex,3} --> {((ColumnNode)this.Right).ColumnIndex,3}";
                            return st;
                        }
                    }



            public SDK_Dlx_Solver( int[] board, bool randomMode ){
                this.randomMode = randomMode;

                // Represent the board and the constraints regarding Sudoku rows, columns, blocks, and cell numbers using DLX.
                _Build_Matrix( board ); 
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

                    void _Build_Matrix(int[] board ){
                        root = new ColumnNode{ColumnIndex=-1};
                        root.Left=root; root.Right=root;
                                //WriteLine( $"j:{0}  root:{root}" );

                        ColumnNode[] colHeaders=new ColumnNode[324];    // colHeaders are concatenated horizontally from the root.
                        for( int j=0; j<324; j++  ){
                            colHeaders[j]=new ColumnNode{ColumnIndex=j,Size=0};
                            colHeaders[j].Up=colHeaders[j];      colHeaders[j].Down=colHeaders[j];
                            colHeaders[j].Left=root.Left;  colHeaders[j].Right=root;

                            root.Left.Right=colHeaders[j]; root.Left=colHeaders[j];    
/*
                             root <--> Header_0 <--> header_1 <--> header_2 <--> ...  Header_n-1 <--> root
                                WriteLine( $"\nj:{j}  root:{root}" );
                                for( int k=0; k<=j; k++ )  WriteLine(  $"   colHeaders[{k}]: {colHeaders[k]}" );
j:0  root: -1 <--  -1 -->  -1

j:0  root:  0 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->  -1

j:1  root:  1 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->   1
   colHeaders[1]:   0 <--   1 -->  -1

j:2  root:  2 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->   1
   colHeaders[1]:   0 <--   1 -->   2
   colHeaders[2]:   1 <--   2 -->  -1

j:3  root:  3 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->   1
   colHeaders[1]:   0 <--   1 -->   2
   colHeaders[2]:   1 <--   2 -->   3
   colHeaders[3]:   2 <--   3 -->  -1

j:4  root:  4 <--  -1 -->   0
   colHeaders[0]:  -1 <--   0 -->   1
   colHeaders[1]:   0 <--   1 -->   2
   colHeaders[2]:   1 <--   2 -->   3
   colHeaders[3]:   2 <--   3 -->   4
   colHeaders[4]:   3 <--   4 -->  -1
 ...
*/
                        }

                        // Constraint matrix (DLX structure)
                        for( int rc=0; rc<81; rc++ ){
                            int val = board[rc];
                            int startV = (val==0)? 1: val;
                            int endV = (val==0)? 9: val;

                            int r=rc/9, c=rc%9;
                            for( int v=startV; v<=endV; v++ ){
                                int rowIndex = r*81 + c*9 + (v-1);
                                int cellIndex = r*9 + c; 
                                int boxIndex = (r/3)*3 + (c/3);

                                List<int> satisfiedCols = new List<int>{
                                    cellIndex,
                                    81  + (r*9) + (v-1),
                                    162 + (c*9) + (v-1),
                                    243 + (boxIndex*9) + (v-1)
                                };
                                _AddRow( rowIndex, satisfiedCols.ToArray(), colHeaders);
                            }
                        }

                                void _AddRow( int rowIndex, int[] colIndices, ColumnNode[] colHeaders ){
                                    Node firstX = null;
                                    foreach( int cIdx in colIndices ){

                                        ColumnNode colH = colHeaders[cIdx]; // column header

                                        // Concatenate vertically (top-to-bottom) starting from colHeader.
                                        Node nodeX = new Node{RowIndex=rowIndex, Column=colH };
                
                                        // Link the new nodeX to the colH(column header).
                                        nodeX.Up=colH.Up;   nodeX.Down=colH;
                                        colH.Up.Down=nodeX; colH.Up=nodeX;
                                        colH.Size++;
                            
                                        // Concatenate the new node X in the row direction.
                                        if( firstX==null ){ firstX=nodeX; firstX.Left=firstX; firstX.Right=firstX; }
                                        else{ nodeX.Right=firstX; nodeX.Left=firstX.Left; firstX.Left.Right=nodeX; firstX.Left=nodeX; }
                                    }
                                }
                    }
            }


            public int Solve( int maxSolutions=1 ){
                int count = 0;
                _Search( 0, ref count, maxSolutions );
                return count;
                    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

                    void _Search( int k, ref int count, int maxSolutions ){
                        if( k%4==0 ){ if( count >= maxSolutions ) return; }
                        if( root.Right==root ){
                            count++;
                            var Q = _DecodeSolution();
                            solutions.Add( Q );
                           // solutions.Add( _DecodeSolution() );
                            return;
                        }

                        ColumnNode c = _ChooseColumn();
                        if( c.Size==0) return;
                    //=================================
                        _Cover(c);
                        if( Rand ==null )  Rand = new();
                        var rowNodes = new List<Node>();
                        for( Node r=c.Down; r!=c; r=r.Down ) rowNodes.Add(r);
                        if( randomMode ) rowNodes = rowNodes.OrderBy(x => Rand.Next()).ToList();   // @@@ randomMode
                    //---------------------------------


                        foreach( Node r in rowNodes ){
                            if( k==0 && count>=maxSolutions ) return;

                            answer.Add(r);
                            for( Node j=r.Right; j!=r; j=j.Right) _Cover(j.Column);

                            // *==*==*==*==*==*==*==*==*==*==*==*==*==*==
                            _Search(k+1, ref count, maxSolutions);
                            // *==*==*==*==*==*==*==*==*==*==*==*==*==*==

                            for( Node j=r.Left; j!=r; j=j.Left) _Uncover(j.Column);
                            answer.RemoveAt(answer.Count-1);
                            if( count >= maxSolutions) return;
                        }
                        _Uncover(c);
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

                                void _Cover(ColumnNode colNode ){
                                    colNode.Right.Left = colNode.Left; colNode.Left.Right = colNode.Right;
                                    for( Node r=colNode.Down; r!=colNode; r=r.Down ){
                                        for( Node j=r.Right; j!=r; j=j.Right  ){ j.Down.Up=j.Up; j.Up.Down=j.Down; j.Column.Size--; }
                                    }   
                                }

                                void _Uncover(ColumnNode colNode ){
                                    for( Node r=colNode.Up; r!=colNode; r=r.Up ){
                                        for( Node j=r.Left; j!=r; j=j.Left ){ j.Column.Size++; j.Down.Up=j; j.Up.Down=j; }
                                    }
                                    colNode.Right.Left = colNode; colNode.Left.Right = colNode;
                                }

                                ColumnNode _ChooseColumn(){
                                    ColumnNode best = null; int min = int.MaxValue;
                                    for( ColumnNode col=(ColumnNode)root.Right; col!=root; col=(ColumnNode)col.Right ){
                                        if( col.Size<min ){ min=col.Size; best=col; }
                                    }
                                    return best;
                                }

                                int[] _DecodeSolution( ){
                                    int[] sol = new int[81];
                               //     foreach( Node n in answer) sol[n.RowIndex/81, (n.RowIndex%81)/9] = (n.RowIndex%9)+1;
                                    foreach( Node n in answer) sol[n.RowIndex/81*9+(n.RowIndex%81)/9] = (n.RowIndex%9)+1;
                                    return sol;
                                }
                    }
            }

            public int[] GetFirstSolution() => (solutions.Count>0)? solutions[0] : null;
        }


    }
}
