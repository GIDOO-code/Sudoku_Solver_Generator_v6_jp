﻿using System;
using System.Collections.Generic;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space{



    public partial class DLX_DFS_Solver_ver_1{
        static private readonly UInt128 qZero   = UInt128.Zero;
        static private readonly UInt128 qOne    = UInt128.One;

        protected int            typeSave =-9;
        protected List<UInt128>  groupsSave;


        private List<UInt128> A41_GetSymmetricGroups_81B( int type ){

            if( type == typeSave ){ return (new List<UInt128>(groupsSave)); }

            List< UInt128 > groups = new ();
            UInt128 visited = UInt128.Zero;

            for( int rc=0; rc<81; rc++ ){
                int r=rc/9, c=rc%9;
                if( (visited&(qOne<<rc)) > qZero ) continue;

                UInt128 equiv = qZero;
                void Set_equiv( int r, int c ){ equiv |= qOne<<(r*9+c); }

                Set_equiv(r,c);
                switch (type){
                    case 0: // 0: No Symmetry
                        break;

                    case 1: // 1: Point Symmetry (90 degrees)
                        Set_equiv(c, 8-r);
                        Set_equiv(8-r, 8-c);
                        Set_equiv(8-c, r);
                        break;     
        
                    case 2: // 2: Point Symmetry (90 degrees)
                        Set_equiv(8-r, 8-c);
                        break;

                    case 3: // 3: Line Symmetry (vertical)
                        Set_equiv(r, 8-c);
                        break;

                    case 4: // 4: Line Symmetry (horizontal)
                        Set_equiv(8-r, c);
                        break;

                    case 5: // 5: Line Symmetry (lower right)
                        Set_equiv(c, r);
                        break;

                    case 6: // 6: Line Symmetry (upper right)
                        Set_equiv(8-c, 8-r);
                        break;

                    case 7: // 7: Line Symmetry (V & H)
                        Set_equiv(r, 8-c);
                        Set_equiv(8-r, c);
                        Set_equiv(8-r, 8-c);
                        break;

                    case 8: // 8: Line Symmetry (Two Diagonal)
                        Set_equiv(c, r);
                        Set_equiv(8-c, 8-r);
                        Set_equiv(8-r, 8-c);
                        Set_equiv(8-c, r);
                        Set_equiv(c, 8-r);
                        Set_equiv(8-r, c);
                        Set_equiv( r, 8-c);
                        break;
                }
                visited |= equiv;

                if( equiv != qZero )  groups.Add(equiv);
            }

            typeSave = type;
            groupsSave = new List<UInt128>(groups);

            return groups;
        }
    }
}