﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;

using Windows.Data.Xml.Dom;

using static System.Diagnostics.Debug;

namespace GNPX_space{
    public class SDK_DLX_DFS_Solver{
        private G6_Base G6 => GNPX_App_Man.G6;

        private static readonly object FileLock = new object();
        private const string LogFilename = "sudoku_experiment_stats.csv";
        private readonly int _targetClues;

        public ConcurrentQueue<int[]> DLX_SudokuQueue = new ConcurrentQueue<int[]>();

        public Page   func_auto2;

        public int    DLX_Prod_Cells;  
        public int    DLX_Prod_Sym_Type = 2;

        public SDK_DLX_DFS_Solver( Page func_auto2, int DLX_Prod_Cells, int DLX_Prod_Sym_Type ){
            this.func_auto2         = func_auto2;
            this.DLX_Prod_Cells     = DLX_Prod_Cells; 
            this.DLX_Prod_Sym_Type  = DLX_Prod_Sym_Type;
            InitCsvFile();
        }


        public void A2_Run_Auto_Creator_Loop( int maxTime,  CancellationToken cts330_DLX ){
            string[] modes = { "layout", "constraint" };

            WriteLine("[Runner] Start A2_Run_Auto_Creator_Loop.");

            while(true){
                if( cts330_DLX.IsCancellationRequested )  return;

                var initialLineCounts = GetCurrentFileLines();

                using(var sessionCts = new CancellationTokenSource())
                using(var linkedCts331 = CancellationTokenSource.CreateLinkedTokenSource(cts330_DLX )){

                    var producer = new DLX_DFS_Solver_ver_1( this, linkedCts331.Token );
                    var consumer = new DLX_DFS_Solver_Consumer_Shrinker( this, linkedCts331.Token );

                    WriteLine($"\n===============================================================================");
                    WriteLine($"[Session Start]  SymmetryType: {DLX_Prod_Sym_Type} / DLX_Prod_Cells: {DLX_Prod_Cells}  ({DateTime.Now:HH:mm:ss})");
                    WriteLine($"===============================================================================");

                    var watch = Stopwatch.StartNew();


               // var cTask = Task.Run( () => consumer.A3_StartEngine_Sequence( debugPrint:false ), linkedCts331.Token);
                  var cTask = Task.Run( () => consumer.A3_StartEngine_Parallel( debugPrint:false ), linkedCts331.Token);

               // var pTask = Task.Run( () => producer.A4_StartEngine_Sequence(), linkedCts331.Token);
                  var pTask = Task.Run( () => producer.A4_StartEngine_Parallel(), linkedCts331.Token);


                    // ==========================================================================================
                    try{
                        Task.Delay( maxTime*60000 , cts330_DLX ).Wait(cts330_DLX);
                        //   Task.Delay( 5000 , externalToken ).Wait(externalToken);   // ..... debug
                    }
                    catch(Exception){ 
                        sessionCts.Cancel();
                        WriteLine("[Runner] Detects a stop command from the app and immediately terminates the task completely.");
                        return; 
                    }
                    linkedCts331.Cancel();
                    // ------------------------------------------------------------------------------------------

                    {   // Output of Reports and Summary Tables
                        sessionCts.Cancel();
                        try { Task.WhenAll(pTask, cTask).Wait(); } catch { }

                        watch.Stop();
                        double elapsedSeconds = watch.Elapsed.TotalSeconds;

                        int pCount = producer.ProductionCount;
                        int wCount = consumer.WorkCount;
                        double pwRatio = wCount > 0 ? (double)pCount / wCount : 0;
                        double cActiveSeconds = consumer.ActiveSeconds;

                        int[] sessionResults = new int[10];
                        for( int k=17; k<=26; k++ )  sessionResults[k-17] = G6.CreateAuto2_Puzzlis[k-17];
                        string stResult = string.Join(",", sessionResults);
                        WriteLine($"\n----------------------------------------------------------------");
                        WriteLine($"Session Statistics] Uptime: {elapsedSeconds:F2} seconds (C Active Time: {cActiveSeconds:F2} seconds)");
                        WriteLine($"  Production (P): {pCount} units / Consumption (W): {wCount} units");
                        WriteLine($"  P/W Ratio     : {pwRatio:F2}");
                        WriteLine($"  Squares 17–26 created: {stResult} units");
                        WriteLine($"----------------------------------------------------------------\n");

                        LogSessionToCsv( DLX_Prod_Sym_Type, sessionResults, pCount, wCount, pwRatio, cActiveSeconds);  /* @@@ */
                    }
                    break;
                }
  
            }

            WriteLine("[Runner] The entire loop has fully terminated, and the process has concluded successfully.");

                        Dictionary<int,int> GetCurrentFileLines(){
                            var lineCounts = new Dictionary<int, int>();
                            for( int size=17; size<=22; size++){
                                string filename = $"sudoku_line_size_{size}.txt";
                                if( File.Exists(filename)){
                                    try{
                                        int count = File.ReadLines(filename).Count();
                                        lineCounts[size] = count;
                                    }
                                    catch { lineCounts[size] = 0; }
                                }
                                else{
                                    lineCounts[size] = 0;
                                }
                            }
                            return lineCounts;
                        }
        }


        private void InitCsvFile(){
            lock (FileLock){
                if( !File.Exists(LogFilename)){
                    string sb = "Timestamp,Mode,SymmetryType,Clues_17,Clues_18,Clues_19,Clues_20,Clues_21,Clues_22,P_Count,W_Count,PW_Ratio,C_ActiveSeconds";
                    using (StreamWriter sw = new StreamWriter(LogFilename, append: true, Encoding.UTF8)){
                        sw.WriteLine(sb);
                    }
                }
            }
        }

        private void LogSessionToCsv( int symType, int[] results, int pCount, int wCount, double pwRatio, double cActive){
            lock (FileLock){
                string sb = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss},";
                sb += string.Join(",", results) + ",";
                sb += $"{pCount},{wCount},{pwRatio:F2},{cActive:F2}";

                using (StreamWriter sw = new StreamWriter(LogFilename, append: true, Encoding.UTF8)){
                    sw.WriteLine(sb);
                }
            }
        }
    }
}