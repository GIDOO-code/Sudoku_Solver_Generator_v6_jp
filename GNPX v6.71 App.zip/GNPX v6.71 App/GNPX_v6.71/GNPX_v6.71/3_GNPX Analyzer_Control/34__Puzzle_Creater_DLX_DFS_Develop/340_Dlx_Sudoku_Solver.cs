﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;

using Windows.System;

using static System.Diagnostics.Debug;

namespace GNPX_DLX3{

    public interface ISudokuSolver{
        List<int[]> Solve(int[] givens, int maxSolutions);
    }


    #region Solver
        // =====================================================================
        // 1. Sudoku Solver Implementation Using Dancing Links
        //    Solve it as an Exact Cover problem with 729 rows x 324 columns.
        //      729 rows(81 cells × 9 digits) ×
        //      324 columns(81 cell constraints + 81 row constraints + 81 column constraints + 81 block constraints)
        // =====================================================================
        public sealed class DLX_Sudoku_Solver: ISudokuSolver{

            #region Node, Column
                private class Node{
                    public Node Left = null!, Right = null!, Up = null!, Down = null!;
                    public Column Column = null!;
                    public int RowId; // Row ID（0〜728）
                }

                private sealed class Column: Node{
                    public string Name = "";
                    public int Size; // Number of nodes belonging to this column
                }
            #endregion  Node, Column

            private const int NumCells = 81;
            private const int NumRows = 729;   // 81 cells × 9 digits
            private const int NumCols = 324;   // 81 cell constraints + 81 row constraints + 81 column constraints + 81 block constraints

            // Since the matrix structure is independent of the Givens values ​​and remains constant (729×324), 
            //  it is constructed once during instance creation and reused in subsequent calls to Solve().
            // Since this Matrix represents mutable shared state,
            //  calling Solve() on the same instance from multiple threads simultaneously is not permitted.

            private readonly Matrix _matrix;

            public DLX_Sudoku_Solver(){
                _matrix = BuildMatrix();
            }

            public List<int[]> Solve(int[] givens, int maxSolutions){
                if( _matrix == null )  throw new InvalidOperationException( "Incorrect usage: _matrix is ​​undefined");

                if( givens.Length != NumCells ) throw new ArgumentException("givens must have length 81.");

                var selected = new List<int>();
                var givenRowIds = new List<int>(); // Record the selected order for restoration.
                {  // Pre-select (cover) the rows corresponding to known hints.
                    for( int i=0; i<NumCells; i++ ){
                        int v = givens[i];
                        if( v == 0 ) continue;

                        int r = i/9, c=i%9, d=v;
                        int rowId = RowId(r, c, d);
                        SelectRow(_matrix, rowId, selected);
                        givenRowIds.Add(rowId);
                    }
                }

                var solutions = new List<int[]>();
                _Search(_matrix, selected, solutions, maxSolutions);



        // The _Search() function itself is self-restoring because it always performs an Undercover operation 
        //  that corresponds to Cover during backtracking.
        // The selection of "givens" (specifically, the SelectRow operation) made at the start of Solve()
        //  must be explicitly undone.
        // Due to DLX invariants, Cover/Uncover operations must be undone in the reverse order of their selection.
                {
                    for( int k=givenRowIds.Count-1; k>=0; k-- )  UnselectRow(_matrix, givenRowIds[k]);
                }
                return solutions;
            }




            #region Build Matrix-----------------------------
                private sealed class Matrix{
                    public Column Header = null!;
                    public Node[] FirstNodeOfRow = new Node[NumRows];
                    public (int r, int c, int d)[] RowInfo = new (int, int, int)[NumRows];
                }

                private Matrix BuildMatrix(){
                    // Construct a DLX representation of Sudoku constraints (rows, columns, blocks, and cells).
                    // The initial state of the board is not set.
                    var m = new Matrix();
                    var header= new Column { Name = "header" };
                    header.Left=header; header.Right=header; m.Header=header;

                    var columns = new Column[NumCols];
                    for( int i=0; i<NumCols; i++ ){
                        var col= new Column{ Name = $"c{i}", Size = 0 };
                        col.Up=col; col.Down=col; col.Column=col;

                        // Link to the left side of the header (circular list)
                        col.Left=header.Left; col.Right=header; header.Left.Right=col; header.Left=col;
                        columns[i] = col;
                    }

                    int rowId = 0;
                    for( int r=0; r<9; r++){
                        for( int c=0; c<9; c++){
                            for( int d=1; d<=9; d++){
                                m.RowInfo[rowId] = (r,c,d);

                                int[] colIdx ={ CellConstraint(r,c), RowConstraint(r,d), ColConstraint(c,d), BoxConstraint(r,c,d) };

                                Node? first = null;
                                Node? prev = null;

                                foreach (var idx in colIdx){
                                    var col = columns[idx];
                                    var node = new Node { Column=col, RowId=rowId };

                                    // Insert at the bottom of the column
                                    node.Down=col; node.Up=col.Up; col.Up.Down=node; col.Up=node; col.Size++;
                                    if( first == null ){ first=node; node.Left=node; node.Right=node; }
                                    else{ node.Left=prev!; node.Right=first; prev!.Right=node; first.Left=node; }
                                    prev = node;
                                }

                                m.FirstNodeOfRow[rowId] = first!;
                                rowId++;
                            }
                        }
                    }
                    return m;

                            // ----------------------------------------------------
                            int RowId(int r, int c, int d)   => r*81 + c*9 + (d-1);      // 0..728
                            int CellConstraint(int r, int c) => r*9+c;                   // 0..80
                            int RowConstraint(int r, int d)  => 81 + r*9 + (d-1);        // 81..161
                            int ColConstraint(int c, int d)  => 162 + c*9 + (d-1);       // 162..242
                            int BoxConstraint(int r, int c, int d){
                                int box = (r/3)*3 + (c/3);
                                return 243 + box*9 + (d-1);                              // 243..323
                            }
                }
                public int RowId(int r, int c, int d)   => r*81 + c*9 + (d-1);      // 0..728


            #endregion Build Matrix


            #region Column covering/de-covering
                private static void Cover(Column col){
                    col.Right.Left=col.Left;  col.Left.Right=col.Right;

                    for( var i=col.Down; i!=col; i=i.Down){
                        for( var j=i.Right; j!=i; j=j.Right){
                            j.Down.Up=j.Up; j.Up.Down=j.Down; j.Column.Size--;
                        }
                    }
                }

                private static void Uncover(Column col){
                    for( var i=col.Up; i!=col; i=i.Up){
                        for( var j=i.Left; j!=i; j=j.Left){
                            j.Column.Size++; j.Down.Up=j; j.Up.Down=j;
                        }
                    }

                    col.Right.Left=col; col.Left.Right=col;
                }


                // Select the entire specified row (i.e., cover all four columns of that row). 
                // This is used to fix known hints (givens) before the _Search for a solution begins.

                private static void SelectRow(Matrix m, int rowId, List<int> selected){
                    var start = m.FirstNodeOfRow[rowId];
                    var j=start;
                    do{
                        Cover(j.Column);
                        j=j.Right;
                    }while( j!=start );

                    selected.Add(rowId);
                }

                // Accurately undo the covering operation performed by SelectRow.
                // As an invariant of DLX, Uncover must be called in the exact reverse order of the corresponding Cover operations;
                // otherwise, the linked list will become corrupted. 
                // Since SelectRow performed the Cover operations in the order of ColIdx[0..3],
                // the four columns are Uncovered here in reverse order ([3], [2], [1], [0]).
                private static void UnselectRow(Matrix m, int rowId){
                    var n0 = m.FirstNodeOfRow[rowId];
                    var n1 = n0.Right;
                    var n2 = n1.Right;
                    var n3 = n2.Right;

                    Uncover(n3.Column);
                    Uncover(n2.Column);
                    Uncover(n1.Column);
                    Uncover(n0.Column);
                }
            #endregion Column covering/de-covering


        #region Seearch
            private bool _Search( Matrix m, List<int> selected, List<int[]> solutions, int maxSolutions ){
                if( m.Header.Right == m.Header){
                    // All constraints have been covered = one complete solution has been found.
                    solutions.Add(BuildGrid(m, selected));
                    return solutions.Count >= maxSolutions;
                }

                // Select the column with the fewest remaining options (S-heuristic: minimize branching).
                Column? best = null;
                int bestSize = int.MaxValue;
                for( var col=(Column)m.Header.Right; col!=m.Header; col=(Column)col.Right){
                    if( col.Size < bestSize ){ bestSize=col.Size; best=col;
                    }
                }

                if( best==null || best.Size==0)  return false; // This branch has no solution (dead end).

                Cover(best);

                for( var r=best.Down; r!=best; r=r.Down){
                    selected.Add(r.RowId);
                    for( var j=r.Right; j!=r; j=j.Right) Cover(j.Column);

                    bool stop = _Search( m, selected, solutions, maxSolutions);

                    for( var j=r.Left; j!=r; j=j.Left) Uncover(j.Column);
                    selected.RemoveAt(selected.Count-1);

                    if( stop ){ Uncover(best); return true; }
                }

                Uncover(best);
                return false;

                        int[] BuildGrid(Matrix m, List<int> selected){
                            var grid = new int[NumCells];
                            foreach (var rowId in selected){
                                var (r,c,d) = m.RowInfo[rowId];
                                grid[r*9+c] = d;
                            }
                            return grid;
                        }
            }
        #endregion Seearch
        }
    #endregion Solver

}