﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Documents;
using System.Windows.Shapes;

using DLX_V2;

using GIDOO_space;

using GIDOO_space;
using GIDOO_space;

using GNPX_space;

using Microsoft.Win32;

using STD_SDK;

using static System.Diagnostics.Debug;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static GNPX_space.SubsetTechGen;

namespace GNPX_DLX2{
	using pGPDM = GNPX_Puzzle_Database_Manager;
    using pRes = GNPX_space.Properties.Resources;
    using SDK_Dlx_Solver = DLX_DFS_Solver_ver_1.SDK_Dlx_Solver;


    public partial class Puzzle_17cell_Explore {
        static private readonly UInt128 qZero = UInt128.Zero;
        static private readonly UInt128 qOne  = UInt128.One;

    //    static public UInt128[]  pConnected_81;   //Connected Cells
    //    static public UInt128[]  HouseCells81;   //Row(0-8) Collumn(9-17) Block(18-26)

        static private UInt128[]   pConnected_81     => GNPX_Utilitie.Connected_81;
		static private UInt128[]   pHouseCells81    => GNPX_Utilitie.HouseCells81; 


        private G6_Base G6 => GNPX_App_Man.G6;

        private List<v7_UPuzzle_Base>	    v7_GNPX_Puzzle_List => pGPDM.v7_GNPX_Puzzle_List;
        static public (int,int,int,int)     progressCounters; 
        standardization_Man STDman = new();

        private string          ToRC(int rc) => $"({rc})r{rc/9+1}c{rc%9+1}";

    // @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    //
    //     -N+N under development
    //
    // @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

    #region  -N +N
        public async void Test_Nx_Replace_Cells( int N, bool autoSaveB, CancellationToken ct ){

            int index = 0;
            var indexLock = new object();     

            List<string> qPZL_List = new();
        
            string fName = $"17Clues_N{N}_Replace_Cells" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".txt";
		    string dir_fName = $"../GNPX_ExecutionSpace/{pRes.folder_AutoGen_Puzzles}/{fName} ";

            int  ncNew=0, nCandidate=0, ncTrials=0;
            foreach( var (pPZL,kx) in v7_GNPX_Puzzle_List.WithIndex() ){
                ncTrials++;
                int[]  intPZL = pPZL.Get_board();

              //List<int[]> Pzl_List = Generate_Mutant_1_Cell_List( intPZL );  
                List<int[]> Pzl_List = Generate_Mutant_N_Cell_List( intPZL, N:N ); // @@@@@@@@@@@@@@

                var options = new ParallelOptions { CancellationToken=ct };
                Parallel.ForEach( Pzl_List, options, (puzzle_1mp, state) =>{
                    if( ct.IsCancellationRequested){ state.Stop(); return; }

                    int myIndex;
                    lock(indexLock){ myIndex=index++; }
                    
                    var solver = SudokuSolverPool.Current;  // Just fetch the per-thread solver; reuse is automatic.
                    var solutions = solver.Solve( puzzle_1mp, maxSolutions:2, ct );

                    if( solutions.Count == 1 ){
                        nCandidate++;
                        lock(indexLock){
                            STDman.Standardization( puzzle_1mp );
                            string  PuzzleStandardCode = STDman.STD_form.PuzzleStandardCode;

                            int nx = v7_GNPX_Puzzle_List.FindIndex( P => P.PuzzleStandardCode == PuzzleStandardCode );
                            if( nx < 0 ){
                                ncNew++;
                                int Shrink_size = puzzle_1mp.Count( p => p>0 );
                                Interlocked.Increment( ref G6.CreateAuto2_Puzzlis[Shrink_size-17] );
                                string  eval = nx<0? "new": $"Idx:{nx}@@@";
                               // GLX_Lib.PrintBoard( intPZL, puzzle_1mp, $" pPZL, puzzle:{eval}" );     


                                if( autoSaveB ){
                                    string stPzlS = STDman.STD_form.stStandardPuzzle;
                                    string line = $"\"{stPzlS}\", \"{PuzzleStandardCode} {DateTime.Now:yyyy/MM/dd_HH:mm:ss}\"\n";
                                    qPZL_List.Add( line );

                                }
                            }                        
                        }
                    }
                });

                
                progressCounters = (ncNew,nCandidate,ncTrials, pGPDM.v7_GNPX_Puzzle_Count);
                if( autoSaveB && N>=2 )  File.AppendAllText(dir_fName, $"{kx+1}, {progressCounters}\n");    
            }

            qPZL_List = qPZL_List.Distinct().ToList();
            if( autoSaveB ){             
			  //  string dir_fName = $"../GNPX_ExecutionSpace/{pRes.folder_AutoGen_Puzzles}/{fName} ";
                File.WriteAllText(dir_fName, "PuzzleNo, StandardPuzzle, PuzzleStandardCode\n", Encoding.UTF8);       

                foreach( var (line,kx) in qPZL_List.WithIndex() ){
                    File.AppendAllText(dir_fName, $"{kx+1}, {line}");
                }
            }

            return;
        }

        public List<int[]> Generate_Mutant_1_Cell_List( int[] BasePzl ){
            UInt128 hintPos81    = BasePzl.WithIndex().Where((p,rc)=>(p.item>0)).Aggregate(qZero, (a,b)=>a| qOne<<b.index);
            UInt128 hintPos81Rev = ((qOne<<81)-1) & ~hintPos81;

            List<int[]> Pzl_List = new();
            foreach( var rcRem in hintPos81.IEGet_rc() ){
                int[] curPzl_0 = (int[])BasePzl.Clone();
                curPzl_0[rcRem] = 0;

                UInt128[]  used81B = Create_FixedBitExp81_9( curPzl_0 );  
                    //for( int no=0; no<9; no++ ){ WriteLine( $"#{no+1} {used81B[no].TBS()}" ); }

                foreach( int rcAdd in hintPos81Rev.IEGet_rc() ){
                    UInt128  rcConn81B = pConnected_81[rcAdd];
                    for( int no=0; no<9; no++ ){
                        if( (used81B[no]&rcConn81B) > qZero ) continue;
        
                        int[] curPzl_1 = (int[])curPzl_0.Clone();
                        curPzl_1[rcAdd] = no+1;
                        Pzl_List.Add( curPzl_1 );

                    //string stRep = GLX_Lib.PrintBoard( BasePzl, curPzl_0, curPzl_1, $"BasePzl, curPzl_0:{rcRem.ToRCst()}, curPzl_1:{rcAdd.ToRCst()}#{no+1}" );
                    }
                }
            }
            return  Pzl_List;
        }


        public List<int[]> Generate_Mutant_N_Cell_List( int[] BasePzl, int N ){
            UInt128 hintPos81    = BasePzl.WithIndex().Where((p,rc)=>(p.item>0)).Aggregate(qZero, (a,b)=>a| qOne<<b.index);
            UInt128 hintPos81Rev = ((qOne<<81)-1) & ~hintPos81;
            int size17 = hintPos81.BitCount();

            List<int[]> Pzl_List = new();
            Combination_81B cmb81Rem = new( size17, N, hintPos81 );
            while( cmb81Rem.Successor() ){
                int[] curPzl_0 = (int[])BasePzl.Clone();
                foreach( var rcRem in cmb81Rem.valueBT.IEGet_rc() )  curPzl_0[rcRem] = 0;

                        //GLX_Lib.PrintBoard( BasePzl, curPzl_0, $"BasePzl, curPzl_0" );  
                UInt128[]  used81B = Create_FixedBitExp81_9( curPzl_0 );  
                        // for( int no=0; no<9; no++ )  WriteLine( $"used81B[#{no+1}] {used81B[no].TBS()}" );
                        // GLX_Lib.PrintBoard( BasePzl, curPzl_0, $"curPzl_0" );
                var Q = Generate_IntArray_Combination( curPzl_0, N, hintPos81Rev, used81B );
                Pzl_List.AddRange( Q );
            }
            return  Pzl_List;

                // -----------------------------------------------------------------------------------------------------------------------
                    IEnumerable< int[] > Generate_IntArray_Combination( int[] basePzl, int N, UInt128 hintPos81Rev, UInt128[] used81B ){
                        Combination_81B cmb81Add = new( size17, N, hintPos81Rev );  
                        int[]  noAddList = new int[N];
                        while( cmb81Add.Successor() ){
                            int[]  rcAddList = cmb81Add.value;
  
                            if( N == 1 ){
                                int rc_0 = rcAddList[0];
                                for( int no_0=0; no_0<9; no_0++ ){
                                    if( (used81B[no_0]&pConnected_81[rc_0]) > qZero ) continue;
                                    int[]  Pzl = (int[])basePzl.Clone();
                                    Pzl[rc_0] = no_0+1;
                                    yield return Pzl;
                                }
                            }

                            else if( N == 2 ){
                                int rc_0=rcAddList[0], rc_1=rcAddList[1];
                                for( int no_0=0; no_0<9; no_0++ ){
                                    if( (used81B[no_0]&pConnected_81[rc_0]) > qZero ) continue;
                                    used81B[no_0] |= qOne<<rc_0;

                                    for( int no_1=0; no_1<9; no_1++ ){
                                        if( (used81B[no_1]&pConnected_81[rc_1]) > qZero ) continue;

                                        int[]  Pzl = (int[])basePzl.Clone();
                                        Pzl[rc_0] = no_0+1;
                                        Pzl[rc_1] = no_1+1;
                                        yield return Pzl;
                                    }
                                    used81B[no_0] &= ~(qOne<<rc_0);
                                }
                            }

                            else if( N == 3 ){
                                int rc_0=rcAddList[0], rc_1=rcAddList[1], rc_2=rcAddList[2];
                                for( int no_0=0; no_0<9; no_0++ ){
                                    if( (used81B[no_0]&pConnected_81[rc_0]) > qZero ) continue;
                                    used81B[no_0] |= qOne<<rc_0;

                                    for( int no_1=0; no_1<9; no_1++ ){
                                        if( (used81B[no_1]&pConnected_81[rc_1]) > qZero ) continue;
                                        
                                        used81B[no_1] |= qOne<<rc_1;
                                        for( int no_2=0; no_2<9; no_2++ ){
                                            if( (used81B[no_2]&pConnected_81[rc_2]) > qZero ) continue;

                                            int[]  Pzl = (int[])basePzl.Clone();
                                            Pzl[rc_0] = no_0+1;
                                            Pzl[rc_1] = no_1+1;
                                            Pzl[rc_2] = no_2+1;
                                            yield return Pzl;
                                        }
                                        used81B[no_1] &= ~(qOne<<rc_1);
                                    }   
                                    used81B[no_0] &= ~(qOne<<rc_0);
                                }
                            }
                        }
                        yield break;
                    }
                    
        }

        private  UInt128[] Create_FixedBitExp81_9( int[] board ){
            UInt128[] B128 = new UInt128[9];
			foreach( var (noP,rc) in board.WithIndex().Where(P=>P.item!=0) ) B128[noP-1] |= UInt128.One<<rc;
            return B128;
        }

        #endregion  -N +N

    }
}