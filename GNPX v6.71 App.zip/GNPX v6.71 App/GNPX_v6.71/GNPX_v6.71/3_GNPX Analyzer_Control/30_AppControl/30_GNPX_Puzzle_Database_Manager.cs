﻿using GNPX_space;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;

using GIDOO_space;

namespace GNPX_space{


	public static class GNPX_Puzzle_Database_Manager{
		static string __bPzlZero = new String('0',81);

        static public   GNPX_Engin      pGNPX_Eng;

		static private List<v7_UPuzzle_Base> _v7_GNPX_Puzzle_List = new();	// Puzzle DB(List)
		static public  List<v7_UPuzzle_Base> v7_GNPX_Puzzle_List{ get => _v7_GNPX_Puzzle_List; }

		static public int				v7_GNPX_Puzzle_Count => (v7_GNPX_Puzzle_List!=null)? v7_GNPX_Puzzle_List.Count: 0;


		static public v7_UPuzzle_Base	v7_current_Puzzle;

		static private int				_v7_current_Puzzle_No;

	//	static bool __setting=false;
		static public int				v7_current_Puzzle_No{  // Consecutive numbers starting with 0
            get=> _v7_current_Puzzle_No;
            set{ 
				if( v7_GNPX_Puzzle_Count <= 0 )  return;
                int nn = Max( value, 0 );;
				nn = Min( nn, v7_GNPX_Puzzle_Count-1 );
				_v7_current_Puzzle_No = nn;
				v7_current_Puzzle = v7_GNPX_Puzzle_List[nn];

				pGNPX_Eng.Set_NewPuzzle( v7_current_Puzzle );  // Set to engine
            }
        }


		static GNPX_Puzzle_Database_Manager(){
		
		}




		// ***** Registration to v7_GNPX_Puzzle_List shall be performed only at this location. *****
		static public void	v7_GNPX_Puzzle_List_Add( v7_UPuzzle_Base bPzl ){
			if( bPzl==null || bPzl.stPuzzle==__bPzlZero )  return;
			_v7_GNPX_Puzzle_List.Add(bPzl);
		}

		static public void Set_v7_GNPX_Puzzle_List( List<v7_UPuzzle_Base> v7_Pz_List ){
			_v7_GNPX_Puzzle_List = v7_Pz_List;
			v7_current_Puzzle_No = 0;
		}

		// -----------------------------------------------------------------------

		static public void v7_GNPX_Remove(){
			v7_GNPX_Puzzle_List.RemoveAt(_v7_current_Puzzle_No);
			v7_current_Puzzle_No = _v7_current_Puzzle_No;
		}


		static public v7_UPuzzle_Base CreateNewPuzzle( UPuzzle ePzl=null ){
			int[] board = (ePzl==null)? Enumerable.Repeat(0,81).ToArray(): ePzl.BOARD.ConvertAll(p=>Max(p.No,0)).ToArray();
			v7_UPuzzle_Base bPzl = new v7_UPuzzle_Base(board);
			v7_GNPX_Puzzle_List_Add(bPzl);
			return  bPzl;
		}


		static public long Get_hashValue_int81( this int[] SolX ){
			long hv = 0;
			for( int rc=0; rc<81; rc++ ){
				if( SolX[rc]>0 )  hv ^= GIDOO_Hash.hashBase[ ((rc)<<6)  | SolX[rc] ];
			}
			return hv;
		}

	}
}