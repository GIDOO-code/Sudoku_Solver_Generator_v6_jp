using GIDOO_space;
using GNPX_space;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using static GNPX_space.GNPX_Puzzle_Analysis_Support;
using static System.Diagnostics.Debug;
using static System.Math;



namespace GNPX_space{
	using pRes = Properties.Resources;
    public partial class GNPX_Engin{                        // This class-object is unique in the system.
		static public  UInt128 b081_all  = (UInt128.One<<81)-1;
        private UInt128[]   pConnectedCells81 => GNPX_Utilitie.Connected_81;
		private UInt128[]   pHouseCells81    => GNPX_Utilitie.HouseCells81; 

		public  string      TandE_st_Puzzle="";

        public int[]		sol_int81 => ePZL.v7B_Puzzle.Solution;
		public  string      TandE_st_sol_int81="";
        public string       Result{   get=>ePZL.Sol_Result; set=>ePZL.Sol_Result=value; }
        public string       ResultLong{   get=>ePZL.Sol_ResultLong; set=>ePZL.Sol_ResultLong=value; }
		public string       ResultHTML{   get=>ePZL.Sol_ResultHTML; set=>ePZL.Sol_ResultHTML=value; }
		public string       extResult{   get=>ePZL.extResult; set=>ePZL.extResult=value; }

		private string		fName_BugInApplication;


		private object		obj = new object();
		private string		dirDebugStr = "Debug";


        public List<string>  IsSudokuPuzzle_DLX_Check( bool debugPrint=false ){
	 		//if( IsCreatePuzzle ){ sol_int81=null; return true; }   // This will not work in @CreatePuzzle.

			List<int> intBoard = ePZL.BOARD.ConvertAll( P=> Max(P.No,0) );
			TandE_st_Puzzle = string.Join("",intBoard);

			Stopwatch sw = new Stopwatch();
			sw.Start();
				
				fName_BugInApplication = $"{DateTime.Now.ToString("yyyyMMdd_hhMM")}.txt";
				
				// RT -> DLX solver(v7.0)
				int[] puzzle = ePZL.BOARD.ConvertAll(p => Abs(p.No)).ToArray();
				var solutions = SDK_Solver.Solve( puzzle, maxSolutions:int.MaxValue );		
				List<string>  stList = solutions.ConvertAll( P => string.Join("",P).ToStringWithSpace() );

				if( solutions.Count!=1 ){
					if( !Directory.Exists(dirDebugStr) ){ Directory.CreateDirectory(dirDebugStr); }
					string stFname = $"dirDebugStr/{fName_BugInApplication}";
				}

			var elps = sw.ElapsedMilliseconds;
			if(debugPrint){
				if( sol_int81 !=null ){	WriteLine( $"{string.Join("",sol_int81)} ... elapsed time:{elps}ms" ); }
				else{					WriteLine( $"There are multiple solutions ... elapsed time:{elps}ms" ); }
			}

			return stList;
        }





		public bool IsSolutionValid( ){

			bool test_Error( UCell p ) => (p.FixedNo>0 && p.FixedNo!=sol_int81[p.rc]) | (p.CancelB>0 && p.CancelB.IsHit(sol_int81[p.rc]-1) );

			bool errorB = false;
			List <UCell> pBOARD = ePZL.BOARD;

			// This will not work in @CreatePuzzle.
			if( !G6.PG6Mode.Contains("Func_Create") ){
				// Based on the final solution, "Determined Digits" are correct.
				errorB = pBOARD.Any( p=> (p.FixedNo>0 && p.FixedNo!=sol_int81[p.rc] ) );

				// Based on the final solution, the "Excluded Eigits" are not part of the solution.
				errorB |= pBOARD.Any( p=> (p.CancelB>0 && (p.CancelB & (1<<(sol_int81[p.rc]-1)))>0 ) );
			}
			if( !errorB ) return (!errorB);



			#region ===== Algorithm Error =====
					string dirError = "Algorithm_Error";
					if( !Directory.Exists(dirError) )  Directory.CreateDirectory(dirError);

					fName_BugInApplication = $"{dirError}/{DateTime.Now.ToString("yyyyMMdd_hhMM")}.txt";
					Result += "  ... error ...";
					string stError = $"\n\n ... error ...\n  file:{G6.GNPX_PuzzleFileName}"; 	
					ResultLong += stError; 			
			
					if( extResult == "" )  extResult = ResultLong; 
					extResult += stError;

				//	G7.g7CurrentState = pBOARD.Copy();  // .... ver. 7.0

					G7.g7CurrentState = new();
					pBOARD.ForEach( Q => G7.g7CurrentState.Add(Q.Copy()) ); // .... ver. 7.0

					string st0 = string.Join("",pBOARD.ConvertAll(p=>Max(p.No,0))).Replace("0","."). AddSpace9_81();
					string st1 = string.Join("",pBOARD.ConvertAll(p=> Abs(p.No))).Replace("0","."). AddSpace9_81();
					string st2 = string.Join("",sol_int81.ToList()). AddSpace9_81();

						string[]  Marks = new string[81];
						string stLT2 = $"\n file:{G6.GNPX_PuzzleFileName}";
						stLT2 += $"\n Puzzle sq:{ePZL.ID+1} stage:{ePZL.stageNo} Method:{G7.AnalyzingMethod.NameM}  IsSolutionValid ... error ...";
						G6.stopped_StatusMessage = stLT2;
						pBOARD._Dynamic_CellsPrint_withFrame( Marks, stLT2 );
						ePZL.v7B_Puzzle.g7Error = true;
						G7.g7Error = true;


					string stLT = $"Puzzle sq:{ePZL.ID+1} stage:{ePZL.stageNo} Method:{G7.AnalyzingMethod.NameM}  IsSolutionValid ... error ...\n         < Current >                   < Puzzle >";
					string stL  = Utility_Display.__DBUG_Print2( pBOARD, sqF:true, stLT );

					string stUnmatch = pBOARD.Aggregate( "", (a,p) => a + (test_Error(p)? "X": "@") ). AddSpace9_81(). Replace("@", " ") ;

					foreach( var P in pBOARD.Where( p=> (p.FixedNo>0) && (p.FixedNo!=sol_int81[p.rc]) ) ){
						string stF = $"\n error P.FixedNo: {P.rc.ToRCString()}#{P.FixedNo} is false, #{sol_int81[P.rc]} is true";
						stL += stF; 
						WriteLine( stF );
					}
					foreach( var P in pBOARD.Where( p=> (p.CancelB>0 && (p.CancelB & (1<<(sol_int81[p.rc]-1)))>0)) ){
						string stC = $"\n error CancelB: {P.rc.ToRCString()}#{P.CancelB.ToBitStringN(9)} is false,  The true solution to the Puzzle is #{sol_int81[P.rc]}.";
						stL += stC; 
						WriteLine( stC );
					}

					string st012 = $"\n\n  {st0}   Puzzle\n  {st1}   Current\n  {st2}   Solution\n  {stUnmatch}   Error";
					stL += st012;
					extResult += stL;
					WriteLine( st012 );

					using( var fpW=new StreamWriter( fName_BugInApplication, append:true, encoding:Encoding.UTF8) ){
						fpW.WriteLine( $"\n ... error ...\n file:{G6.GNPX_PuzzleFileName}\n {DateTime.Now} MethodName : {G7.AnalyzingMethod.MethodName}" );					
						fpW.WriteLine( stL );
					}
			#endregion ===== Algorithm Error =====

            return (!errorB);
        }
    }
}