using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Threading;

using GIDOO_space;

using static System.Diagnostics.Debug;
using static System.Math;



namespace GNPX_space{
	using pGPDM = GNPX_Puzzle_Database_Manager;
    public partial class GNPX_Engin{                        // This class-object is unique in the system.




      #region Puzzle management
//@@@ Puzzle �Ǘ�

        public void Clear_0(){
            ePZL.ToInitial( ); // Clear all.
            AnMan.Update_CellsState( ePZL.BOARD );
        }

        public bool IsSolved() => ePZL.BOARD.All(p=> p.No!=0);

		// <<< Use DLX solver to find the solution >>>

		public (bool,string) IsValidPuzzle(){ // v7.0-
			bool ret = false;
			try{
				G6.VerifyingPuzzle = "Verifying Puzzle";

				// using the DLX solver.
				int[] puzzle = ePZL.v7B_Puzzle.Get_board();
                var solutions = SDK_Solver.Solve( puzzle, maxSolutions:int.MaxValue /*,ct*/);   //ct:undefine			
				List<string>  stList = solutions.ConvertAll( P => string.Join("",P).ToStringWithSpace() );

				G6.VerifyingPuzzle = null;

				ePZL.SolCode = 0;	// Cancel the�gSolCode=1�hsetted by TrialAndErrorApp.
				ret = (solutions.Count==1);
			}
			catch(Exception ex){
				// ... not a latin square
				//    Index was out of range. at "991 GNPZ_An99_Research_trial.cs:line 83"
				ret = false;
				ePZL.extResult  = $"Invalid Puzzle\n  not a latin square";
				WriteLine( $"Invalid Puzzle\n{ex.Message}\n{ex.StackTrace}" );
			}
			return (ret,ePZL.extResult);
		}


		// Basic helper functions
		static int _HV_control = int.MaxValue;

		public void Set_NewPuzzle( v7_UPuzzle_Base v7PZL ){
			if( _HV_control == v7PZL.hasgValue )  return;
			_HV_control = v7PZL.hasgValue;

			this.ePZL = new UPuzzle(v7PZL);
			AnMan.Update_CellsState( ePZL.BOARD );
	//		G6.SolverState = 0;
			this.rootPZL = ePZL;	// *==*==*==*==*==*==*==*==*==*==*
			AnMan.Update_CellsState( rootPZL.BOARD, Initial_stateB:true );
				//WriteLine( $"@@@ rootPzl:{rootPZL.v7B_Puzzle}  hv:{_HV_control}  stage:{rootPZL.stageNo}");	// 																									// *==*==*==*==*==*==*==*==*==*==
				
		}


		// Load a new puzzle into the engine
        public void Set_NewPuzzle( UPuzzle aPZL ){   
			if( aPZL.BOARD == null )  return;

            ePZL = aPZL.Copy();
            ePZL.selectedIX = -1;
        }

		// Install the sub-puzzle into the engine.
        public void Set_selectedChild( int selX ){
            int count = ePZL.Child_PZLs.Count;
            if( selX<0 || count<=0 || selX>=count ) return;
            ePZL = ePZL.Child_PZLs[selX];
        }


		// Updating constraints based on analysis from the preceding stage
		public bool Adjust_Candidates(  ){   //Cell true/false setting processing  
			if( ePZL.BOARD.All( u => (u.FixedNo==0 && u.CancelB==0) ) )  return true;

			var Analysis_results = AnMan.Execute_Fix_Exclude( ePZL.BOARD );
						// Analysis_results = 0 : Complete. Go to next stage.
						//                  = 1 : Solved. 

			var (confirmedAll,nP,nZ,nM) = AnMan.Aggregate_CellsPZM( ePZL.BOARD );
			if( nZ==0 ){ AnMan.SolCode=0; return true; }
			return true;
		}






		//  Preparation for the next stage
		// <<< Stage Management >>>
		public string Set_NextStage( bool skip_valid_check=false ){      // update the state and create the next stage.
      
		  // Initial check 
			if( AnMan is null )  return "AnMan is null";
			if( ePZL  is null )  return "ePZL is null";
			if( ePZL.BOARD.All(p=>p.No!=0) )  return "solved";

		 // Set Puzzle for next stage
			if( ePZL.stageNo == 0 ){
				ePZL = rootPZL;
				AnMan.Update_CellsState( ePZL.BOARD, Initial_stateB:true );
			}
			else{ 
				int nIX = ePZL.selectedIX;
				if( nIX<0 || ePZL.Child_PZLs==null || nIX>=ePZL.Child_PZLs.Count )  return "solved";
				var next_ePZL = ePZL.Child_PZLs[nIX];
			}

			UPuzzle PZL_nextStage   = ePZL.Copy();
			PZL_nextStage.pre_PZL   = ePZL;
			PZL_nextStage.stageNo   = ePZL.stageNo+1;	
		
			ePZL = PZL_nextStage;

			var Analysis_results = AnMan.Execute_Fix_Exclude(ePZL.BOARD);  //
			if( Analysis_results == 1 ) return "solved";
			if( Analysis_results < 0 ){ return "Error. Conditions are broken."; }	
			
			// Updating constraints
			AnMan.Update_CellsState( ePZL.BOARD );	// Update based on the analysis results from the preceding stage

            ePZL.Child_PZLs = new List<UPuzzle>();		// Set List for Children's Puzzles

            return "";            //"No problem, continue"  
        }





        public void ReturnToInitial(){
            this.ePZL.stageNo = 0;
            this.Add_Trial_No100();
			this.ePZL.ToInitial( ); //to initial stage
		}
      #endregion Puzzle management




      #region Methods_for_Solving functions
        public void MethodLst_Run__Reset_UsedCC(){
            Add_Trial_No100();

            v7_SolverList_GNPX.ForEach(P=>P.UsedCC=0);
        } 

        public string DGView_MethodCounterToString(){
            var Q = v7_SolverList_GNPX.Where(p=>p.UsedCC>0).ToList();
            return Q.Aggregate("",(a,q) => a+$" {q.MethodName}[{q.UsedCC}]" );
        }

        public void AnalyzerCounterReset(){
			if( v7_SolverList_GNPX==null )  return;
			v7_SolverList_GNPX.ForEach(P=>P.UsedCC=0);  //Clear the algorithm counter. 
		}

        public (int,string)  Get_difficultyLevel( ){
            int DifL=0;
            string pzlName="";
            if( v7_SolverList_GNPX.Any(P=>(P.UsedCC>0) )){
                DifL = v7_SolverList_GNPX.Where(P=>P.UsedCC>0).Max(P=>Abs(P.difficultyLevel));
                var R = v7_SolverList_GNPX.FindLast(Q=>(Q.UsedCC>0)&&(Abs(Q.difficultyLevel)==DifL));
                pzlName = (R!=null)? R.MethodName: "";
            }
            return (DifL,pzlName);
        }
      #endregion Methods_for_Solving functions
	}
}