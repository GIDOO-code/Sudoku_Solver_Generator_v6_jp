using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Threading;

using GIDOO_space;

using static System.Diagnostics.Debug;
using static System.Math;



namespace GNPX_space{
	using pGPDM = GNPX_Puzzle_Database_Manager;
    public partial class GNPX_Engin{                        // This class-object is unique in the system.


        public  GNPX_App_Man     pGNPX_App;							// main control     
		public  GNPX_win         pGNP00win => pGNPX_App.pGNP00win;
		private G6_Base			 G6 => GNPX_App_Man.G6;
		private G7_Base			 G7 => GNPX_App_Man.G7;
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 

        public  GNPX_AnalyzerMan AnMan;								// analyzer(methods)





      #region ===== Phase management of the Puzzle-solving process =====
        private int              stageNo{ get  => ePZL.stageNo; }
        private  int             __Trial_No100; 
        public  int              Add_Trial_No100() => __Trial_No100 +=100;    

        public int               stageNoP{ get => __Trial_No100 + stageNo; }
      #endregion ===== Phased management of the Puzzle-solving process =====






        static public bool       SolverBusy=false;

		private DLX_V2.SudokuSolver SDK_Solver = new();				// DLX Solver for SUDOKU.
        private List<UAlgMethod> v7_SolverList_GNPX => pGNPX_App.SolverList_GNPX; // List of algorithms to be applied.



		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
		public  UPuzzle          rootPZL;	// root Puzzle
		
        public  UPuzzle          ePZL;		// Puzzle to analyze	
		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
		
//		private Stopwatch		 timer_Analyzer;	

		public  bool			 AnalysisResult = false;






		//=====================================================================================================
        private bool            __Tracking_Solver_Execution = false;	//### For debug, display the method.
		private int				debugCC=0;
		//-----------------------------------------------------------------------------------------------------





		// @@@ �R���X�g���N�^�[

		public GNPX_Engin( GNPX_App_Man  pGNPX_App ){           //Execute once at GNPX startup.
            this.pGNPX_App = pGNPX_App; 
            AnMan = new GNPX_AnalyzerMan(this);
//			timer_Analyzer = new Stopwatch();
			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  
        }








		// ################### GNPX_SolvCompletely ##############################################
        public string GNPX_SolvCompletely( CancellationToken cts ){

			string stSolver_Results = "";
			if( ePZL.BOARD.All(p=>p.No==0) ){ stSolver_Results="SolveUp"; return stSolver_Results; }		// <<< Already solved >>>

			stSolver_Results = "--";
            try{
                ePZL.stageNo = 0;			// Return to initial state
	//			timer_Analyzer.Restart(); 

				// <<<<< Repeatedly apply the SingleStage solver. >>>>> 
				while( ePZL.BOARD.Sum(p=>p.FreeBC)>0 ){  
					if( cts.IsCancellationRequested ){ stSolver_Results="Canceled"; break; }

					string retST = Set_NextStage( );
					if( retST=="solved" ){ stSolver_Results="SolveUp"; break; }			
					if( retST!="" ){	   stSolver_Results="Not Sudoku"; break; }	

					// Measure the search time for each stage of multiple solution search.
					// Incorporating an "upper time check" function into algorithms that require a lot of time
					pGNPX_App.MultiSolve_StartTime = DateTime.Now;

					var (ret,ret2) = GNPX_Solver_SingleStage( cts:cts, Set_Solution_Info:false ); // <<< 1-step solver >>>

					if( ret2 == "SolveUp" ){ stSolver_Results="SolveUp"; break; }
					if( !ret ){ stSolver_Results=ret2; break; }
				}
				// -----------------------------------------------------
    //            timer_Analyzer.Stop();     
            }
			catch(Exception e){ WriteLine( $"---{DateTime.Now} {e.Message}\n{e.StackTrace}" ); }

			return stSolver_Results;
        }








		// ################### Solver Single Stage ##############################################



        // 1-step solver
        public (bool,string) GNPX_Solver_SingleStage( CancellationToken cts, bool Set_Solution_Info ){
			bool Sel_Mark_Break = (G6.PG6Mode=="Func_SolveMulti" || G6.PG6Mode=="Func_SelectPuzzle");

			string    stResult="";
			if( ePZL.BOARD.All(p=>p.No!=0) ){ stResult="SolveUp"; goto LProcessEnd; }

			int Puzzle_LevelHigh = SingleStage_Initialize();

			Stopwatch Alg_sw = new();
			Alg_sw.Restart();
			foreach( var (MTHD,MTHD_idx) in v7_SolverList_GNPX.WithIndex() ){
				if( cts.IsCancellationRequested ){ _PostProcessing(); return (false,"canceled"); }		
		
				if( MTHD.IsChecked is false )  continue;  // Is the method enabled?
				MTHD.ResetSearch_Ccriteria();



				var (availableB,breakB) =Method_Eevaluation(MTHD);
				if( breakB )  break;
				if( !availableB ) continue;;

				try{ // *==* Execute *==*==*==*==*==*==*==*==*==*==*
					G7.AnalyzingMethod = MTHD;
					G6.stopped_StatusMessage = "";

						if(__Tracking_Solver_Execution)  Alg_sw.Restart();						
					AnalysisResult = MTHD.Method();		// <<< excute method >>>
						if(__Tracking_Solver_Execution)  Observation_of_Algorithms( MTHD, MTHD_idx, Alg_sw, AnalysisResult);

					if( MTHD.ErrorB || (MTHD.SuccessfulB && MTHD.Sel_mark) )  Set_SelectedMark(MTHD,ePZL);
					if( MTHD.SuccessfulB )  G6.LastSuccessfullMethod = $"Lv.{MTHD.difficultyLevel} {MTHD.MethodName}";
					if( G6.stopped_StatusMessage!="" )  break; // "time over"...
					// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*
				}
				    
				catch( Exception e ){
					string stException = e.Message + "\n" + e.StackTrace;
					WriteLine( $"{stException}\n{e.Message}\n{e.StackTrace}" );
					G6.stopped_StatusMessage = stException;
					Utility_Display.GNPX_StreamWriter_WithTime(fName:"Solver_Exception.txt", message:stException, append:true );
					_PostProcessing();
					return (false,"Exception occurred");
				}
				

				if( AnalysisResult ){ // Solved
					ePZL.pMethod = MTHD;
					_AnalysisSuccessful(MTHD);
					if( G7.MltAnsSearch is false )  break;		// *** In simple search, end here. ***
				}

				if( Sel_Mark_Break && ePZL.Child_PZLs.Any(p=>p.pMethod.Sel_mark) ){ G7.Sel_mark_Solved=true; break; }
			}

		  LProcessEnd:

		//	{
				var ePZL_Child_PZLz = ePZL.Child_PZLs;
				if(  stResult=="SolveUp" ){ AnalysisResult=true; }
				else if( ePZL_Child_PZLz!=null && ePZL_Child_PZLz.Count>0 ){  // solution found
					ePZL.selectedIX=0; ePZL=ePZL_Child_PZLz[0]; 
					AnalysisResult=true;
					if( stResult != "SolveUp" )  stResult="Solved";
				}
				else{
					AnalysisResult=false; stResult="Unsolved";
					string culture = App_Environment.culture;

					string __stNotSolved = "\n This is a Sudoku Puzzle,\n There is no algorithm that can solve this.";
					       __stNotSolved += "\n\n It is necessary to adjust the difficulty level or\n develop a new algorithm.";
					ePZL.Sol_Result = __stNotSolved;
				}
		//	}
			_PostProcessing();
			return (AnalysisResult,stResult);
			// ======================================================================================================	



						void Observation_of_Algorithms( UAlgMethod MTHD, int MTHD_idx, Stopwatch sw, bool AnalysisResult ){
							double ts = sw.Elapsed.TotalMilliseconds;
							string stStep = $"--->GNPX_Solver_SingleStage/debugCC:{debugCC++:00} stageNo:{stageNo}";
									stStep += $"  difficultyLevel:{MTHD.difficultyLevel}";
									stStep += $"  (lap time: {ts:0.0} msec)";
									stStep += $"  method: {(MTHD_idx)} - {MTHD.MethodName}";
									if( MTHD.Sel_mark )  stStep += $"    MTHD.mark_Sel:����{MTHD.Sel_mark}";
									stStep += $" @@:{G6.stopped_StatusMessage}  "; 
							WriteLine( stStep );
							if(AnalysisResult) WriteLine($"                  ========================> solved  @@{MTHD}");
						}

						(bool,bool) Method_Eevaluation( UAlgMethod MTHD ){

					
							if( G6.zPowerUserCC>0 && !G6.GeneralLogic_StopSearch ){}
							else{
								if( G6.GeneralLogic_on && !MTHD.ID_caseGL )  return (false,false);
								if( !G6.GeneralLogic_on && MTHD.GenLogB )    return (false,false);
							}

							// Execution/interruption of analysis method by difficulty 
							if( G6.chk_analysisStop_at_levels_2 ){
								if( G6.Found_level_Solution && Abs(MTHD.difficultyLevel)>2 )  return (false,true);;	//Break if there is a solution with a difficulty level of 2 or less.
							}

							int lvl = MTHD.difficultyLevel;
							if( G6.PG6Mode!="Func_SolveMulti" && lvl<0 )  return (true,false);;;     // The negative level algorithm is used only with multiple soluving. 				
					
							// In "Func_CreateAuto" or "Func_SolveMulti",
							// Puzzles that require the specified difficulty or higher method are invalid.
							// Therefore, the method is excluded.
							if( G6.PG6Mode=="Func_CreateAuto" || G6.PG6Mode=="Func_SolveMulti" ){
								if( Abs(lvl)>Puzzle_LevelHigh )  return (false,false);;;
							}
			
							if( G6.PG6Mode == "Func_SelectPuzzle" ){	
								// The algorithm being screened raises the upper bound to increase the probability of detecting errors.
		#if DEBUG
								G6.MSlvr_MaxNoAlgorithm = MTHD.developB? 10: 1;
		#else
								G6.MSlvr_MaxNoAlgorithm = MTHD.Sel_mark? 10: 1;	
		#endif
							}

							return (true,false);
						}


						int  SingleStage_Initialize(){
							if( stageNo == 1 ){
								v7_UPuzzle_Base bPzl = ePZL.v7B_Puzzle;
								bPzl.method_MostDiffcul = null;
								bPzl.stPuzzleName = "";
								bPzl.difficulty = 0;
							}

							// --- Initialize global ---
							G6.stResult			= "...";
							G6.Canceled			= "";
							G6.Found_level_Solution = false;
							ePZL.Sol_ResultLong = "";
							ePZL.extResult		= "";
							G7.AdditionalMessage   = "";
							ePZL.SolCode		= -1;

							AnalysisResult		= false;

							// --- set search conditions ---
							var (_,Puzzle_LevelHigh) = _Set_AcceptableLevel( );
									(int,int) _Set_AcceptableLevel( ){
										int _lvlLow=1, _lvlHgh=15;
										switch(G6.PG6Mode){	
											case "Func_CreateAuto":	 _lvlLow=G6.Puzzle_LevelLow; _lvlHgh=G6.Puzzle_LevelHigh; break;	
											case "Func_SolveMulti":  _lvlLow=1;					 _lvlHgh=G6.MSlvr_MaxLevel; break;	
										}
											//WriteLine( $" * * * Set_AcceptableLevel {G6.PG6Mode} : {_lvlLow} - {_lvlHgh}" );
										return (_lvlLow,_lvlHgh);
									}

							return Puzzle_LevelHigh;
						}


						void _AnalysisSuccessful( UAlgMethod MTHD ){			// ###... This code needs to be rebuilt
							// @@ Basic solutions were applied. No advanced solutions were applied to the multiple solution search.
							int diffLevel = Abs(MTHD.difficultyLevel);			// method difficult level
							if( diffLevel <= 2 )  G6.Found_level_Solution = true;

							if( (G6.PG6Mode=="Func_SolveMulti" || G6.PG6Mode=="Func_SelectPuzzle") && MTHD.Sel_mark )  G7.Sel_mark_Solved=true;

							// for Create Puzzle
							v7_UPuzzle_Base bPzl = ePZL.v7B_Puzzle;
							if( diffLevel >= bPzl.difficulty ){
								bPzl.difficulty = diffLevel;	// Record the difficulty of the puzzle
								bPzl.method_MostDiffcul = MTHD;					// Record the Method
							}

							switch(G6.PG6Mode){
								case "Func_SolveMulti":
								case "Func_SelectPuzzle":
									if( MTHD.Sel_mark )  G7.Sel_mark_Solved = true;
									break;
							}

							// for SolveUp
							MTHD.UsedCC++;			// Counter for the number of times the algorithm has been applied.
							ePZL.pMethod = MTHD;	// Methods applied to the analysis phase of the puzzle.
						}

						void _PostProcessing( ){
							G6.AnalysisResult = AnalysisResult;
							G6.stResult = stResult;

							var ePZL_Child_PZLz = ePZL.Child_PZLs;
							if( ePZL_Child_PZLz!=null && ePZL_Child_PZLz.Count>0 ){	ePZL.selectedIX=0; ePZL=ePZL_Child_PZLz[0]; } // solution found
						}   



						void Set_SelectedMark( UAlgMethod MTHD, UPuzzle aPZL ){
							v7_UPuzzle_Base v7_PzlB = ePZL.v7B_Puzzle;
							if(MTHD.SuccessfulB){
								aPZL.v7B_Puzzle.g7MarkA = true;		//##@@ Needs organization and confirmation
								G7.g7MarkA0 = true;             // Record what was solved using the marked method

								if( G7.g7MarkA_MLst0 == null ) G7.g7MarkA_MLst0 = new();							
								G7.g7MarkA_MLst0.Add($"{stageNo}-{MTHD.MethodName}");
								v7_PzlB.difficulty = MTHD.difficultyLevel;
							}
							if(MTHD.ErrorB){
		// 						WriteLine( $" Error {ePZL.stPZL_withSP}" );

								v7_PzlB.g7MarkA = true;		//##@@ Needs organization and confirmation
								G7.g7Error = true;                // Record what was solved using the marked method

								if( G7.g7MarkA_MLst0 == null ) G7.g7MarkA_MLst0 = new();
								G7.g7MarkA_MLst0.Add($"{stageNo}-{MTHD.MethodName}");
							}
						}
		

		}
	}
}