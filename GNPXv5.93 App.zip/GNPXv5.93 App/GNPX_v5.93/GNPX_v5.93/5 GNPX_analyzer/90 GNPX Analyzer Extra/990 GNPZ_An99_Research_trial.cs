using System;
using System.Collections.Generic;
using System.Linq;
using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Reflection.Emit;
using System.Windows.Documents;
using System.Diagnostics;

namespace GNPX_space{

    public partial class Research_trial: AnalyzerBaseV2{
		static private UInt128  qOne  = UInt128.One;
		static private UInt128  qZero = UInt128.Zero;
		
		// ... output ...
		private List<string> solList;
		private int			 upperLimit = int.MaxValue;
	
		// ... ... ...
		private string		 dirName = "Debug";
		private string		 TE_fileName => $"Multiple_Solutions {DateTime.Now.ToString("yyyyMMdd")}.txt";
	  //private bool		 devPrintB  = false;

					  
		public Research_trial( GNPX_AnalyzerMan AnMan ): base(AnMan){ }


        public List<string> TrialAndErrorApp( string stPZL, bool filePutB, int upperLimit=int.MaxValue ){
			int[]  PZL = stPZL.Replace(".","0").stringToInt().ToArray(); 
			return TrialAndErrorApp( PZL, filePutB, upperLimit:upperLimit );
		}

		public List<string> TrialAndErrorApp( List<int> PZLlist, bool filePutB, int upperLimit=int.MaxValue ){
			return TrialAndErrorApp(  PZLlist.ToArray(), filePutB, upperLimit );
		}

        public List<string> TrialAndErrorApp( int[] PZL, bool filePutB, int upperLimit=int.MaxValue ){
						//if( devPrintB )  debug_puzzle( PZL, "input" );
			this.upperLimit = upperLimit;

			int[]     Row_CN = new int[9];
			UInt128   ColFrame = qZero;
			UInt128   BlkFrame = qZero;
			foreach( var rc in Enumerable.Range(0,81).Where(rc=>PZL[rc]>0) ){
				int n=PZL[rc]-1, r=rc/9, c=rc%9, b=rc.B();
				Row_CN[r] |= (1<<(c+9)) + (1<<n);
				ColFrame  |= qOne<<(c*9+n);
				BlkFrame  |= qOne<<(b*9+n);
			}

			// === 
			int[]  PZLX = new int[81];
			foreach( int rc in Enumerable.Range(0,81) )  PZLX[rc] = PZL[rc]; 

			
			bool retCode=true;
			solList = new();
			int rowX=0;
			Search_rowX( rowX, Row_CN, ColFrame, BlkFrame );
				
			if(filePutB)  fileOutput_TE_multisolution();
			G7.TandE_NumberOfPuzzleSolution = solList.Count;
			G7.TandE_solList = solList;
			Result = (solList.Count==1)? "valid": "invalid";

			return solList;

			// ############################################################################################
				bool Search_rowX( int rowX, int[] Row_CN, UInt128 ColFrameX, UInt128 BlkFrameX ){

					try{
										//if(devPrintB)  WriteLine( $"\n rowX:{rowX}  FreeX:{rowXFree.TBS()}  PosX:{rowXPos.TBS()}" );

						int rowXFree = 0x1FF & ~(Row_CN[rowX]&0x1FF);		// Free digits in row-X
						int rowXPos  = 0x1FF & ~((Row_CN[rowX]>>9)&0x1FF);				// Blank on the row-X


						List<int> nList = rowXFree.IEGet_BtoNo().ToList();	// 0..8
						List<int> pList = rowXPos .IEGet_BtoNo().ToList();

						int sz = nList.Count;		// When all cells in a row are confirmed, "sz"(the number of remaining cells) is zero.
													// There is special treatment(@@).
						Permutation prm = new(sz);
						int skip = 9;
						while( prm.Successor(skip) || sz==0 ){
							UInt128  ColFrameXnext = ColFrameX;
							UInt128  BlkFrameXnext = BlkFrameX;

							if( sz == 0 )  goto LNextRow;	// (@@) If sz==0, no permutation generation and cell value setting are performed.

										//if(devPrintB)  WriteLine( $"prm : {prm}" );
							bool breakF = false;
							for( int k=0; k<sz; k++ ){
								skip = k;

							//	if( k<0 || k>=pList.Count )  WriteLine( $" k:{k}  pList.Count:{pList.Count}  nList.Count:{nList.Count}" );

								int c = pList[k];
								int n = nList[ prm.Index[k] ];
										//WriteLine( $"{(rowX*9+c).ToRCString()}#{n+1}" );

								UInt128 c9n = qOne<<( c*9 + n);
								if( (ColFrameX & c9n) != 0 ){ breakF=true; break; }

								int b = (rowX*9+c).B();
								UInt128 b9n = qOne<<( b*9 + n);
								if( (BlkFrameX & b9n) != 0 )  { breakF=true; break; }
							}
							if(breakF)  continue;

							 // --- Current level setting
							for( int k=0; k<sz; k++ ){
								int c=pList[k], n=nList[ prm.Index[k] ];
								ColFrameXnext |= qOne<<( c*9 + n);
								int b = (rowX*9+c).B();
								BlkFrameXnext |= qOne<<( b*9 + n);
								PZLX[rowX*9+c] = -(n+1);	//[ATT]
							}
										//if(devPrintB)  debug_puzzle( PZLX, $"row-{rowX}" );

						LNextRow:
							// --- next row
							if( rowX < 8 ){
								bool ret = Search_rowX( rowX+1, Row_CN, ColFrameXnext, BlkFrameXnext );
								if( !ret )  return false;
							}
							else{
								if( solList.Count > upperLimit ){ retCode=false; return retCode; }

								int[]  PZLcopy = new int[81];
								foreach( int k in Enumerable.Range(0,81) )  PZLcopy[k] = Abs(PZLX[k]); 
								string LRecord = string.Join("",PZLcopy);//.Replace("0",".");
								solList.Add( LRecord );
							}
							if( sz == 0 )  break;			// (@@) If sz==0, recovery processing is not performed.

							// --- recover
							for( int k=0; k<sz; k++ ){
								int c = pList[k];
								PZLX[rowX*9+c] = 0;
							}
								//if(devPrintB)  debug_puzzle( PZLX, $"row-{rowX} After recovery" );
						
						}
					}
					catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }

					return retCode;
				}
				
				// --------------------------------------------------------------------------------------------
				void fileOutput_TE_multisolution( ) {
					if( !filePutB || TE_fileName=="" || solList.Count<=1 )  return;
					if( !Directory.Exists(dirName) )  Directory.CreateDirectory(dirName);

					using(var fpW = new StreamWriter( $"{dirName}/{TE_fileName}", append: true, Encoding.UTF8)) {
						fpW.WriteLine($"\n{DateTime.Now}  {solList.Count} solutions");

						int mx = 0;
						solList.ForEach( Q => fpW.WriteLine( $"{Q} solution:{++mx}") );
					}
				}
		}


		private void debug_puzzle( int[] pzl, string title="" ){
			WriteLine( $"  *{title}\n      {string.Join("  ",Enumerable.Range(1,9))}" );

			string st="";
			foreach( var rc in Enumerable.Range(0,81) ){
				if( (rc%9) == 0 )  st = $"  {rc/9+1}:";
				int n=pzl[rc]; 
				st += (n==0)?  "  .": ($"{n}").PadLeft(3);
				if( (rc%9) == 8 )  WriteLine(st);
			}
		}
	}



	public partial class Research_trial{//: AnalyzerBaseV2{
		public string          Result;

		public  List<string>   RT_Get_SolList => solList;
		public  int[]		   RT_Get_Solution_iArray => solList[0].stringToInt().ToArray();
		public  List<int>	   RT_Get_Solution_iList => solList[0].stringToInt().ToList();
		public  List<UCell>    RT_Get_Board(){
			int rc=0;
			return  RT_Get_Solution_iList. ConvertAll( no => new UCell(rc++,no) );
		}
    }
}