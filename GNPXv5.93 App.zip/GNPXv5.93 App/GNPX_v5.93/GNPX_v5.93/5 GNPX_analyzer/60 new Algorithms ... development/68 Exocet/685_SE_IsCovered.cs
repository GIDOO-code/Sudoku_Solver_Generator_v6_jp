﻿using GIDOO_space;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Policy;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	using G6_SF = G6_staticFunctions;

	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	// Needs organization. Needs organization. Needs organization.

    public partial class Exocet_TechGen_68 : AnalyzerBaseV2{

		private bool Check_SLine_Condition_635B( UExocet Exo, bool debugPrint=false ){
			int[] CL_noB = Exo.CL_bySize_noB;
			int[] CL_bySize_Count = CL_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();


			// $$$@@@ @@@@　The Base Digits are completely covered by [CL1+Cl2+CL3].
			int FreeB_Covered123 = CL_noB[1] | CL_noB[2] | CL_noB[3];
			if( Exo.FreeB.DifSet(FreeB_Covered123) > 0 )  return false;	// If not full coverage, it's not eligible.


			// :::::::::::: Junior Exocet ::::::::::::::::::::::::::::::::::::::::::
			if( Exo.ExoMtdName.Contains("JE2") ){			// ... JE2, JE2+, JE2++
				if( CL_bySize_Count[2]<2 || CL_noB[3]>0 )  return false;
			}
			else if( Exo.ExoMtdName.Contains("JE1") ){		// ... JE1
				if( CL_bySize_Count[3]!=1 || Exo.FreeB .DifSet(CL_noB[2] | CL_noB[3])>0 )  return false;
			}

			// :::::::::::: Senior Exocet ::::::::::::::::::::::::::::::::::::::::::
			else if( Exo.ExoMtdName=="SE" ){ 	// ... SE_Standard, SE_SingleBase, SE_FM
				if( Exo.ExoType=="" || Exo.ExoType=="FM" ){
					if(  CL_bySize_Count[2]<2 || CL_noB[3]>0 )  return false;
				}
			
				else if( Exo.ExocetNamePlus=="SE_Single" ){	// ... SE_Single
					if( CL_bySize_Count[3]!=1 || Exo.FreeB .DifSet(CL_noB[2] | CL_noB[3]) > 0 )  return false;
				}
						
				else if( Exo.ExocetNamePlus=="SE_SingleBase" ){	// ... SE_SingleBase
					if(	CL_bySize_Count[2]!=2 || CL_bySize_Count[1]>0 || CL_bySize_Count[3]>0 )  return false;
				}
#if false
	@@@ FM
				else if( Exo.ExocetNamePlus == "SE_FM" ){
					if(  CL_bySize_Count[2]<2 || CL_noB[3]>0 )  return false;
					//int szCL = Exo.SLineList.Count();
					//if(  CL_bySize_Count[szCL-1]<2 || CL_noB[szCL]>0 )  return false;
					//int F0 = (Exo.FreeB0 & SE_ph45_Check_ExtendCondition(Exo, debugPrint:debugPrint) ) ;
					//if( F0.BitCount() < 2 )  return false;
				}
#endif				
				if( Test_overlapping_Slines_SEFM(Exo) is false )  return false;		
			}


			// :::::::::::: Algorithm Error ::::::::::::::::::::::::::::::::::::::::::
			else{
				WriteLine( $"\n\n ExocetNamePlus : {Exo.ExocetNamePlus} ... \n\n {System.Environment.StackTrace}" );
				throw new Exception( $"Operation Error. Exo.ExocetNamePlus : {Exo.ExocetNamePlus}");
			}

			return true;
				
#if false
	@@@ FM
				// ==============================================================================================
				int SE_ph45_Check_ExtendCondition( UExocet Exo, bool debugPrint=false ){
					UInt128 Base_Object = Exo.Base81 | Exo.Object81;
					//debugPrint = true;

					int vno1 = _SE_ph45_Check_ExtendConditionsub(Exo,Exo.ExG1,debugPrint:debugPrint);
					int vno2 = _SE_ph45_Check_ExtendConditionsub(Exo,Exo.ExG2,debugPrint:debugPrint);

					return  (vno1|vno2);
				
						int _SE_ph45_Check_ExtendConditionsub( UExocet Exo, UCrossLine68 ExGM, bool debugPrint=false ){
							UInt128 SLN = Exo.SLine012e & House_81[ExGM.hno];	
							if(debugPrint){
								G6_SF.__MatrixPrint( Flag:Base_Object, Exo.SLine012e, House_81[ExGM.hno], SLN, $"Exo.SLine012e, House_81[ExGM.hno], SLN_#" );
							}

							int noValid = 0;
							foreach( int no in Exo.FreeB.IEGet_BtoNo() ){
								UInt128 SB = SLN & BOARD_FreeOrFixed81B9[no];
								if(debugPrint) G6_SF.__MatrixPrint( Flag:Base_Object, SLN, BOARD_FreeOrFixed81B9[no], SB, $"SLN, BOARD_FreeOrFixed81B9[no], SB_#{no+1}" );
								if( SB.BitCount() <= 2 )  noValid |= 1<<no;
							}
							return (noValid & ExGM.FreeB_Object81);
						}
				}
#endif
		}


		public bool SLine_Covering_635A( UExocet Exo, bool debugPrint=false ){
			UCrossLine68  ExG1=Exo.ExG1, ExG2=Exo.ExG2;
			int		FreeB = Exo.FreeB;
			UInt128 Base_Object = Exo.Base81 | Exo.Object81;
						if(debugPrint) _Information_4_Debugging(Exo);

			Exo.CoverStatusList = new UCoverStatus[9];
			Exo.CL_bySize_noB   = new int[10];			// $$$@@@ For cases where there are multiple extended SLines

			int rcbHouse =  (Exo.ExoType=="Complex" || Exo.ExoType=="FM")? 0x7FFFFFF: 0x3FFFF;	// For Type="FM,Commplex", the Block_CoverLIne is also checked.
			int[] house_CL = _Generate_house_for_CoverLines( Exo, B_18_27:rcbHouse );


			int CL0 = Exo.h012.Item1;
			foreach( var no in FreeB.IEGet_BtoNo() ){
				int noB = 1<<no;
				UInt128 SLine_no = Exo.SLine012e & BOARD_FreeOrFixed81B9[no];	// Test SLine for #no
						if(debugPrint){ 
							G6_SF.__MatrixPrint( Flag:Base_Object, BOARD_FreeOrFixed81B9[no], Exo.SLine012e, SLine_no, 
												 $"BOARD_FreeOrFixed81B9[#{no+1}] SLine012e(#{no+1}) SLine_no(#{no+1})" );
						}

				if( SLine_no==qZero ){ Exo.CL_bySize_noB[0] |= noB; }
				else{	// <<< _Get_CoverLine
					UCoverStatus UCL = __Get_CoverLine_Ext( Exo, no, SLine_no, house_CL, debugPrint:false );				
					if( UCL != null ){ 	// $$$@@@ not covered
						if( (UCL.CLH_0%100) == CL0 )  return false; // $$$@@@ CrossLine-0 and Cross CoverLine match is incorrect

						Exo.CoverStatusList[no] = UCL;
						Exo.CL_bySize_noB[UCL.sz] |= noB;	// sz=3 ... Wildcard or ... Type:Extension
					}
				}
			}
			
			int szCL = Exo.SLineList.Count() - 1;			// $$$@@@ Complex @@@
			int FreeB_Covered_CL = Exo.CL_bySize_noB[szCL];	//　[Att]  Bird　Doc. Rule-1
						if(debugPrint){ 
							string  stCoverLines = Exo.CoverStatusList.Where(p=>p!=null).Aggregate(" ",(a,ch)=> a+ $"\n {ch}");
							WriteLine( $"\nCoverLines\n{stCoverLines}" );

							WriteLine( $"FreeB_Covered_2CLtest2:{FreeB_Covered_CL.TBS()}" );
							foreach( var (P,kx) in Exo.CL_bySize_noB.WithIndex() ) WriteLine( $"  Exo.CL_bySize_noB[{kx}] : {P.TBS()}" );
						} 


			int[] CL_bySize_Count = Exo.CL_bySize_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();

			if( Exo.ExoMtdName.Contains("JE1") ){
				int FreeB_Covered = Exo.FreeB.DifSet(Exo.CL_bySize_noB[2] | Exo.CL_bySize_noB[3]);
				if( CL_bySize_Count[3]!=1 || FreeB_Covered > 0 )  return false;
			}
			
			else if( Exo.ExocetNamePlus.Contains("SE_Single") ){
				int frB1 = ExG1.FreeB_Object81 & FreeB;
				int frB2 = ExG2.FreeB_Object81 & FreeB;
				foreach( var no in Exo.FreeB.IEGet_BtoNo() ){
					var CLn = Exo.CoverStatusList[no];
					if( CLn==null || CLn.CLH_0>27 ){		// If CL is Cross, it is not candidates, so exclude it.
						int noB = 1<<no;
						frB1 = frB1.DifSet(noB);
						frB2 = frB2.DifSet(noB);
					}
				}
				if( (ExG1.Object81&BOARD_Free81)!=qZero && frB1==0 )  return false;		// False if it contains free cells and zero.
				if( (ExG2.Object81&BOARD_Free81)!=qZero && frB2==0 )  return false;
			}
			else{	
				bool Is_pureSEFM = (Exo.ExocetNamePlus=="SE_FM") && ((Exo.Object81&~Exo.Band81)>0);	// Is pure SE_FM?
				if( Is_pureSEFM & !_Is_Linked_ObjectToObject_SEFM(Exo,debugPrint:false) )  return false;	//Is linked?

				//@@@ Complex @@@	
				int FreeBa = Exo.CL_bySize_noB[szCL];
				if( (Exo.FreeB &FreeBa).BitCount()< 3 )  return false;		
					//@@@  All Base_Digits must be covered. This condition is mandatory.
					//     Relaxing this condition will destroy the Exocet.
			}

			//if( Connected_Object_SLine(Exo,ExG1) > 0 ) return false;	// ===== Exocet_Nxt Debug =====
			//if( Connected_Object_SLine(Exo,ExG2) > 0 ) return false;

			return  true;
		// ======================================================================================================================


				void  _Information_4_Debugging( UExocet Exo ){
					UCrossLine68  ExG1=Exo.ExG1, ExG2=Exo.ExG2;

					// =========================================
						string st = $"\n Exo_0 dir:{Exo.dir} rcStem:{Exo.rcStem}  baseCells:{Exo.Base81.TBScmp()}" ;
						st += $"  Object 1-2 : {ExG1.stObject} - {ExG2.stObject}";
						WriteLine( st );

					// =========================================
						string[]  Marks = new string[81];
						var (rcB1,rcB2) = Exo.Base81. BitToTupple();
						if( rcB1>=0 ) Marks[rcB1] = "b"; 
						if( rcB2>=0 ) Marks[rcB2] = "b"; 
						foreach( var rc in ExG1.Object81.IEGet_rc() )  Marks[rc] = "t1";
						foreach( var rc in ExG2.Object81.IEGet_rc() )  Marks[rc] = "t2";

						//pBOARD.__CellsPrint_withFrame( Marks,  "SEBase,ExG1,ExG2" );
						pBOARD._Dynmic_CellsPrint_withFrame( Marks,  "***" );

					// =========================================
						WriteLine( $"\n dir:{Exo.dir}  Base:{Exo.stBase}  T1:{Exo.ExG1.stObject}  T2:{Exo.ExG2.stObject}" );
						UInt128 _Flag = Exo.Base81 | ExG1.Object81 | ExG2.Object81;
				
						G6_SF.__MatrixPrint( Flag:_Flag, Exo.CrossLine_012, Exo.SLine012e, "CrossLine_012, SLine_012_Ext" );
					// =========================================
				}

				int[] _Generate_house_for_CoverLines( UExocet Exo, int B_18_27=0x3FFFF, bool debugPrint=false ){
					int  dir = Exo.dir;

					// Generate a list of cover lines (houses) from the distribution of candidate/determined values ​​on SLine.
					int rcbFrame = (Exo.SLine012e & BOARD_FreeB9_noB(Exo.FreeB)) .Ceate_rcbFrameOr() & B_18_27;		// FreeCells -> Frame

					UInt128 FixedinSLines = (Exo.SLine012e & BOARD_Fixed81);
					rcbFrame |= (dir==0)? FixedinSLines.IEGet_rc() .Aggregate( 0, (a,rc) => a| 1<<(rc/9) ):		// FixedCells -> Frame
										  FixedinSLines.IEGet_rc() .Aggregate( 0, (a,rc) => a| 1<<(rc%9+9) );

					List<int> house_CL = rcbFrame.IEGet_BtoHouse27().ToList();
					house_CL = house_CL.ConvertAll( cl => (cl<18 && (cl/9)!=dir)? cl+100: ((cl%100)>=18)? cl+200: cl );
					// @@@  +100:Cross-CoverLine  +200:Brock-CoverLine
					house_CL.Sort();
					
						if(debugPrint){
							string st = $"{string.Join( " ",house_CL)}";
							WriteLine( $"_Generate_house_for_CoverLinesst: {st}" );
						}
					return house_CL.ToArray();
				}

				UCoverStatus __Get_CoverLine_Ext( UExocet Exo, int no, UInt128 SLine_no, int[] house_CL, bool debugPrint=false  ){
					int nxt=9;
					UInt128 SLine012e = Exo.SLine012e;
					UInt128 hclSel = SLine_no & BOARD_FreeOrFixed81B9[no];
					List<int> HCL_List = house_CL.ToList().FindAll( h => (House_81[h%100]&hclSel) != qZero);

					// :::::::::: 1-CoverLine :::::::::: ====================================================================================
					foreach( int h0 in HCL_List.Where(h=>h<100) ){
						UInt128 CLH = House_81[h0];
						if( __CoverCount(SLine012e, CLH,no) <= 0 )  continue;

						if( SLine_no.DifSet(CLH) == qZero ){
							int h0N = Change_fixed_CrossToParallel(Exo,h0,no);	//@@@
							return  new UCoverStatus( no, 1, h0N, -1, -1 );
							//WriteLine( $"1-cl {h0,4}" );
						}
					}

					// :::::::::: 2-CoverLine :::::::::: ====================================================================================
					Combination cmb2 = new(HCL_List.Count,2);
					while( cmb2.Successor(skip:nxt) ){
						int h0=HCL_List[cmb2.Index[0]], h1=HCL_List[cmb2.Index[1]];
						if( h0 >= 100 )  break;

						nxt=0;
						UInt128 CLH0 = House_81[h0%100];
						if( (SLine_no & CLH0) == qZero ){  continue; }
						if( __CoverCount(SLine012e,CLH0,no) <= 0 )  continue;

						nxt = 1;
						UInt128 CLH1 = House_81[h1%100];
						if( __CoverCount(SLine012e,CLH1,no) <= 0 )  continue;

						if( SLine_no.DifSet(CLH0|CLH1) == qZero ){
							int h0N = Change_fixed_CrossToParallel(Exo,h0,no);	//@@@
							int h1N = Change_fixed_CrossToParallel(Exo,h1,no);	//@@@
							return  new UCoverStatus( no, 2, h0N, h1N, -1 );
							//WriteLine( $"2-cl {h0,4} {h1,4}" );
						}
					}

					// :::::::::: 3-CoverLine :::::::::: ====================================================================================
					//	if(  Exo.ExoType=="Complex" & HCL_List.Count()>=3 ){
					if( HCL_List.Count()>=3 ){
						Combination cmb3 = new(HCL_List.Count,3);
						while( cmb3.Successor(skip:nxt) ){
							int h0=HCL_List[cmb3.Index[0]], h1=HCL_List[cmb3.Index[1]], h2=HCL_List[cmb3.Index[2]];
							//if( (h0/100!=0) || (h1/100>=1) && (h2/100>=1) )  continue;
									
							nxt=0;
							UInt128 CLH0 = House_81[h0%100];
							if( (SLine_no & CLH0) == qZero )  continue;
							if( __CoverCount(SLine012e,CLH0,no) <= 0 )  continue;
							
							nxt=1;
							UInt128 CLH1 = House_81[h1%100];
							if( (SLine_no & CLH1) == qZero )  continue;
							if( __CoverCount(SLine012e,CLH1,no) <= 0 )  continue;

							nxt=2;
							UInt128 CLH2 = House_81[h2%100];
							if( __CoverCount(SLine012e,CLH2,no) <= 0 )  continue;

							if( SLine_no.DifSet(CLH0|CLH1|CLH2) == qZero ){
								int h0N = Change_fixed_CrossToParallel(Exo,h0,no);	//@@@
								int h1N = Change_fixed_CrossToParallel(Exo,h1,no);	//@@@
								int h2N = Change_fixed_CrossToParallel(Exo,h2,no);	//@@@
								return  new UCoverStatus( no, 3, h0N, h1N, h2N );		
								//WriteLine( $"3-cl {h0,4} {h1,4} {h2,4}  {stX}" );
							}
						}
					}
					Exo.CL_bySize_noB[9] |= (1<<no);

					return  null;
				}

				int __CoverCount( UInt128 SLine012, UInt128 CLH, int no ){
					UInt128  CLHSLine = CLH & SLine012;
					if( (BOARD_Fixed81B9[no] & CLHSLine) > 0 )  return 1;		// In the case of "fixed Digit cell"
					int CLcount = (BOARD_Free81B9[no] & CLHSLine).BitCount();
					return  CLcount;
				}

				int Change_fixed_CrossToParallel( UExocet Exo, int h, int no ){ 
					//Specification change. Chang the fixed digit CoverLine from Parallel to Cross.
					if( h >= 100 )  return h;
								
					UInt128 U = House_81[h] & Exo.SLine012e & BOARD_Fixed81B9[no];
					if( U == qZero )  return h;

					int rc = U.BitToNum(81);
					int h2 = (rc/9) + (rc%9+9) - h + 100;
					return h2;
				}	



				// $$$@@@ In the Companion area, 2-CoverLine condition is valid if Object-Object link chain is established.
				bool _Is_Linked_ObjectToObject_SEFM( UExocet Exo, bool debugPrint=false ){		
					UCrossLine68 ExG1=Exo.ExG1, ExG2=Exo.ExG2;

					bool chk1 = __Is_Linked_ObjectToObjectSub(Exo, ExG1, ExG2, debugPrint);
					bool chk2 = __Is_Linked_ObjectToObjectSub(Exo, ExG2, ExG1, debugPrint);
					 
					return (chk1 | chk2); 

							bool __Is_Linked_ObjectToObjectSub( UExocet Exo, UCrossLine68 ExGMorg, UCrossLine68 ExGMdes, bool debugPrint=false ){
								foreach( var no in (Exo.FreeB & ExGMorg.FreeB_Object81).IEGet_BtoNo() ){
									UInt128 SLineNo = Exo.SLine012e & BOARD_FreeOrFixed81B9[no];	
									if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.SLine012e, BOARD_FreeOrFixed81B9[no], SLineNo, $"Exo.SLine012e, BOARD_FreeOrFixed81B9[#{no+1}], SLineNo" );

									int turn=0;
									UInt128[] Conn = new UInt128[2];
									Conn[0] = ExGMorg.Object81; Conn[1] = qZero;
									while(true){
										UInt128 X = Conn[turn].IEGet_rc().Aggregate(qZero, (a,rc) => a| CN81[rc]);
										if( (X & ExGMdes.Object81) > qZero )  break;
										X &= SLineNo;
										UInt128 preConn = Conn[1-turn];
										UInt128 Xnext = preConn | X;
										Conn[1-turn] = Xnext;
										if(debugPrint)  G6_SF.__MatrixPrint( Flag:qZero, Conn[turn], preConn, X, Xnext, $"Conn[{1-turn}], preConn[{turn}], X, Xnext[{turn}]" );

										if( preConn==Xnext )  return false;
										turn = 1 - turn;
									}
								}
								return true;
							}
				}
		}	

		bool Test_overlapping_Slines_SEFM( UExocet Exo ){
			if(	Exo.ExocetNamePlus != "SE_FM" )  return true;

			UCrossLine68  ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;
			UInt128		SLine0=ExG0.SLine, SLine1=ExG1.SLine, SLine2=ExG2.SLine;
			UInt128     FreeFix_noB = Exo.FreeB.IEGet_BtoNo().Aggregate(qZero, (a,no) => a| BOARD_Fixed81B9[no] | BOARD_Free81B9[no] );

			if( _Test_overlapping_Slines_Sub( Exo, FreeFix_noB, SLine1, SLine2) is false )  return false;
			if( _Test_overlapping_Slines_Sub( Exo, FreeFix_noB, SLine0, SLine1) is false )  return false;
			if( _Test_overlapping_Slines_Sub( Exo, FreeFix_noB, SLine0, SLine2) is false )  return false;

			return true;

				bool _Test_overlapping_Slines_Sub( UExocet Exo, UInt128 FreeFix_noB, UInt128 SLineA, UInt128 SLineB ){
					UInt128 SL = SLineA & SLineB;
					if( SL == qZero )  return true;
					if( (SL&FreeFix_noB) >= qZero )  return false;
					return  true;
				}

		}
	}
}