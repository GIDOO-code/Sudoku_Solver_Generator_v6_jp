using GIDOO_space;
using GNPX_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Linq;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;



namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		// ... Generate CrossLine Object ...

		private IEnumerable< (int,int,int) >  IE_Exocet_CrossLine( UExocet Exo, bool debugPrint=false ){
			int  dir=Exo.dir, rcStem=Exo.rcStem, b0=rcStem.B();
			int  h0 = (dir==0)? (rcStem%9+9): rcStem/9, h1, h2;

			// =============== standard =============== =============== ===============	
			if( Exo.ExoMtdName.Contains("FM") is false ) {
				// blockHouse : {r0,r1,r2}, {r3,r4,r5}, {r6,r7,r8},  {c0,c1,c2}, {c3,c4,c5}, {c6,c7,c8},  {b0,b1,b2}, {b3,b4,b5}, {b6,b7,b8}  
				int  blockHouseB =   (dir==0)? (0b111000&~(1<<(b0%3)+3)):  0b111&~(1<<b0/3);
				List<int[]>  hno_List = blockHouseB.IEGet_BtoNo(18).Where(p=> p>=0).ToList() .ConvertAll(n=>new int[]{n*3,n*3+1,n*3+2});

				int[] h1X=hno_List[0], h2X=hno_List[1];
				foreach( int kx in Enumerable.Range(0,3*3) ){
					Exo.h012 = (h0, h1=h1X[kx/3], h2=h2X[kx%3] );
							if(debugPrint) WriteLine( $" h012 : {Exo.h012}" );

					yield return  Exo.h012;
				}
			}

			// ===== Franken/Mutant (v6.1-) =============== =============== =============== 
/*
				// --- this code is triky, and excelent!  You can verify that it works as intended by setting "debagprint=true".
			//debugPrint=true;
			#region Franken/Mutant
			if( Exo.ExoMtdName.Contains("FM") ){  // It's good to understand "standard" first.
				int  blockHouseB = 0xFF & ~(1<<(b0/3) | (1<<(b0%3+3)) );	// 0xFF(8bit) = rowBlock(3bit) / columnBlock(3bit) + Block(2bit)
					 //blockHouseB = blockHouseB & 0x3F;				// $$$@@@ SE_Mutant is not confirmed. Changed to Franken only.
				int  b_Bit = 0x1FF & ~( (0b111<<(b0/3*3) | 0b1001001<<(b0%3)) );	// block

				int[]  hList = blockHouseB.IEGet_BtoNo(8).Where(p=> p>=0).ToArray();
				int[]  bList = (b_Bit<<18).IEGet_BtoNo(27).Where(p=> p>=0).ToArray();
						if(debugPrint){
							WriteLine( $" rcStem:{rcStem}  b0:{b0}" );
							WriteLine( $" blockHouseB:{blockHouseB.ToBitString(18,withDot:true)}  b_Bit:{b_Bit.ToBitString(27,withDot:true)}" ); 
							WriteLine( $" hList {string.Join(",",hList)}" );
							WriteLine( $" bList {string.Join(",",bList)}\n" );
						}

				Combination cmb = new(hList.Count(),2);
				int nxt=999;
				while( cmb.Successor(skip:nxt) ){
					int n1=hList[cmb.Index[0]], n2=hList[cmb.Index[1]];
					if( n1>=6 && n2>=6 )  continue;			// // $$$@@@ Combination of two HouseBlocks is excluded.
						
			//if( (n1/3==0 && n2/3==0) || (n1/3==1 && n2/3==1) ) continue;		// $$$@@@ To exclude SEs other than FM, uncomment.

					int[] h1X = (n1<=5)? (new int[]{n1*3,n1*3+1,n1*3+2}): bList;
					int[] h2X = (n2<=5)? (new int[]{n2*3,n2*3+1,n2*3+2}): bList;
						if(debugPrint)  WriteLine( $"h1X h2X  {n1}-{n2}   {string.Join(",",h1X)}    {string.Join(",",h2X)}" );

					int sz1=h1X.Length, sz2=h2X.Length;
					for( int h1n=0; h1n<sz1; h1n++){
						int h1=h1X[h1n];
						for( int h2n=0; h2n<sz2; h2n++ ){
							int h2=h2X[h2n];
							if( (BOARD_Free81 & (House_81[h1] & House_81[h2])) != qZero ) continue;
							if( (BOARD_Free81 & ((House_81[h1] | House_81[h2]) & House_81[h0])) != qZero ) continue;
							Exo.h012 = (h0, h1, h2 );
								if(debugPrint) WriteLine( $" h012 : {Exo.h012}" );
							yield return  Exo.h012;
						}
					}
				}
			}
			#endregion Franken/Mutant
*/
			 yield break;
		}
	}
}