﻿using GIDOO_space;
using System;
using System.Collections.ObjectModel;
using static System.Diagnostics.Debug;

namespace GNPX_space{

    // Corresponds to the following HP explanation.
    //
    // GIDOO-code/LatinSquare_Sudoku
    // https://gidoo-code.github.io/LatinSquare_Sudoku/
    //

    public partial class LatinSquareGen{

     // private int LatSqrParaMax = 56*6*6*6*6*6*6 = 56 * 216 * 216;
        private readonly int[,]  permList ={ {0,1,2},{0,2,1},{1,0,2},{2,0,1},{1,2,0},{2,1,0} };
		private readonly int[]   tr={ 1,4,7, 2,5,8, 3,6,9 };

		private List<(int,int)> UTop_s0s1;
		private List<(int,int)> ULeft_s0s1;

		public  int[]  Cntrl_Top;
		public  int[]  Cntrl_Left;
		private List<int>	BitToIntListP( int B) => (B.IEGet_BtoNo(sz:9)).ToList().ConvertAll(n=>n+1);
		private int[]		BitToIntArrayP( int B) => B.IEGet_BtoNo(sz:9).ToList().ConvertAll(n=>n+1).ToArray();


        public int[]		pSol99;

        public LatinSquareGen( ){ 

			// --- UTop_s0s1 ---
			List<int> Top_21_List = Enumerable.Range(0,512).Where(P=>P.BitCount()==3).ToList();
			Top_21_List = Top_21_List.FindAll( P => (P&0b000000111)==0 );
			Top_21_List = _Sort_UX(Top_21_List,topB:true);
					//LS	 foreach( var (P,kx) in Top_21_List.WithIndex() )   WriteLine( $"  {kx}  {P.ToBitString(9)}" );

			UTop_s0s1 = new();
			ULeft_s0s1 = new();
			foreach( int s0 in Top_21_List ){
				List<int> Top_22_List = Enumerable.Range(0,512).Where(P=>P.BitCount()==3).ToList();
				int  Q = s0|0b000111000;
				Top_22_List = Top_22_List.FindAll( P => (P&Q)==0 && ((0x1FF&~(s0|P)&(0b111000000))==0) );

				Top_22_List = _Sort_UX(Top_22_List,topB:true);	
				foreach( var s1 in Top_22_List ){
					UTop_s0s1.Add( (s0, s1) );
					ULeft_s0s1.Add( (Transpose(s0), Transpose(s1)) );	// ULef is created by symmetrically transforming UTop.
				}
			}
				//LS	foreach( var (P,kx) in UTop_s0s1.WithIndex() ){
				//LS		var Q = ULeft_s0s1[kx];
				//LS		WriteLine( $"\t 361a LatinSquareGen -- {kx:00}  {P.Item1.ToBitString(9)} - {P.Item2.ToBitString(9)}   {Q.Item1.ToBitString(9)} - {Q.Item2.ToBitString(9)}" );
				//LS	}

			Set_Parameter();

					int Transpose( int P ){
						if( P == 0 )  return P;
						var  sL = P.IEGet_BtoNo(9).ToList().ConvertAll( n=>tr[n] );
						int  Q = sL.Aggregate( 0, (a,n) => a | 1<<(n-1) );
						return  Q;
					}
					
					string _ToBitStringTrans( int noB, int ncc ){
						int[] nsft = new int[]{0,3,6, 1,4,7, 2,5,8};
						string st="";
						foreach( int n in nsft )  st += (((noB>>n)&1)!=0)? (n+1).ToString(): "."; 
						return st;
					} 		

					List<int> _Sort_UX( List<int> UX, bool topB=true ){
						var  UX_2 = topB? UX.ConvertAll( P => (P.ToBitString(9).Replace(".","X"), P) ):
										  UX.ConvertAll( P => (_ToBitStringTrans(P,9).Replace(".","_"), P) );
						UX_2.Sort( (a,b) => (a.Item1.CompareTo(b.Item1) ) );
						return UX_2.ConvertAll( P => P.Item2 );
					}
		}



		public (int[],int[],string)  Set_Parameter( bool randomB=false ){
			Cntrl_Top  = new int[7];
			Cntrl_Left = new int[7];

			if( randomB ){
				Cntrl_Top  = _Generate_Para( Cntrl_Top,  GNPX_App_Ctrl.GNPX_Random.Next(56*46656) );
				Cntrl_Left = _Generate_Para( Cntrl_Left, GNPX_App_Ctrl.GNPX_Random.Next(56*46656) );
			}
			string stP = Set_Top_Left( Cntrl_Top, Cntrl_Left, ToStringB:true );
			return  (Cntrl_Top, Cntrl_Left, stP );

				int[] _Generate_Para( int[] Cntrl_X, int A ){
					int Aw=A, v=46656;  // 46656= 6*6*6 * 6*6*6
					for( int k=0; k<7; k++ ){ Cntrl_X[k]=Aw/v; Aw%=v; v/=6; }
					return Cntrl_X;
				}
		}


		public string Set_Top_Left( int[] P_TopA, int[] P_LeftA, bool ToStringB ){
					//WriteLine( $"  P_Top:{string.Join(" ",P_Top)}\n P_Left:{string.Join(" ",P_Left)}" );

			pSol99 = new int[81];
			//foreach( int rc in Enumerable.Range(0,81) )	 pSol99[rc] = 999;
			foreach( int p in Enumerable.Range(0,9)  )  pSol99[(p/3)*9+(p%3)] = p+1;

			int[] P_Top=P_TopA, P_Left=P_LeftA;
			int s0 = P_Top[0];
			var (S1,S2) = UTop_s0s1[s0];
			int S3, S4, S5, S6;
			int[] S1A = BitToIntArrayP( S1 );
			int[] S2A = BitToIntArrayP( S2 );
			int[] S3A = BitToIntArrayP( S3=(0x1FF & ~(S1 | S2) ) );
			int[] S1P = _Func_Perm( S1A, P_Top[1] );
			int[] S2P = _Func_Perm( S2A, P_Top[2] );
			int[] S3P = _Func_Perm( S3A, P_Top[3] );
						
			int[] S4A = BitToIntArrayP( S4=(0b111111000 & ~S1) );
			int[] S5A = BitToIntArrayP( S5=(0b111000111 & ~S2) );
			int[] S6A = BitToIntArrayP( S6=(0b000111111 & ~S3) );
				
			int[] S4P = _Func_Perm( S4A, P_Top[4] );
			int[] S5P = _Func_Perm( S5A, P_Top[5] );
			int[] S6P = _Func_Perm( S6A, P_Top[6] );

			foreach( int k in Enumerable.Range(0,3) ){ 
				pSol99[03+k]=S1P[k]; pSol99[12+k]=S2P[k]; pSol99[21+k]=S3P[k]; 
				pSol99[06+k]=S4P[k]; pSol99[15+k]=S5P[k]; pSol99[24+k]=S6P[k]; 
			}


			
			int s1 = P_Left[0];
			var (S1L,S2L) = ULeft_s0s1[s1];
			int S3L, S4L, S5L, S6L;
			int[] S1AL = BitToIntArrayP( S1L );
			int[] S2AL = BitToIntArrayP( S2L );
			int[] S3AL = BitToIntArrayP( S3L=(0x1FF & ~(S1L | S2L)) );
			int[] S1PL = _Func_Perm( S1AL, P_Left[1] );
			int[] S2PL = _Func_Perm( S2AL, P_Left[2] );
			int[] S3PL = _Func_Perm( S3AL, P_Left[3] );
		
			int[] S4AL = BitToIntArrayP( S4L=(0b110110110 & ~S1L) );
			int[] S5AL = BitToIntArrayP( S5L=(0b101101101 & ~S2L) );
			int[] S6AL = BitToIntArrayP( S6L=(0b011011011 & ~S3L) );

			int[] S4PL = _Func_Perm( S4AL, P_Left[4] );
			int[] S5PL = _Func_Perm( S5AL, P_Left[5] );
			int[] S6PL = _Func_Perm( S6AL, P_Left[6] );

			foreach( int k in Enumerable.Range(0,3) ){ 
				int k9 = k*9;
				pSol99[27+k9]=S1PL[k]; pSol99[28+k9]=S2PL[k]; pSol99[29+k9]=S3PL[k]; 
				pSol99[54+k9]=S4PL[k]; pSol99[55+k9]=S5PL[k]; pSol99[56+k9]=S6PL[k]; 
			}

					// WriteLine( string.Join( "",pSol99) );
					// __DBUGprint( );

					// --- test ---
					(P_Top,P_Left) = Get_LS_PatternCode(pSol99);
					bool successB = true;
					foreach( int k in Enumerable.Range(0,7) ){
						if( P_Top[k]!=P_Top[k] || P_Left[k]!=P_Left[k] )  successB = false;
					}
					if( !successB ){
						WriteLine( $" P_Top :{string.Join(" ",P_Top)}  Left:{string.Join(" ",P_Top)}" );
						WriteLine( $"           :{string.Join(" ",P_Top)}      :{string.Join(" ",P_Left)}" );
					}

			string stRet = ToStringB?  string.Join("",pSol99): "";
			return stRet;

			// ---------------------------------------------------------------------------------------
				int[]  _Func_Perm( int[] souce, int kx ){
					int[] perm = new int[3];
						
					try{
						int k9 = kx*9;
						for( int k=0; k<3; k++ )  perm[k] = souce[ permList[kx,k] ];
					}
					catch(Exception e){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }
					return perm;
				}
		}

		private void __DBUGprint( ){
			string po = "";
			WriteLine("");

			foreach( int rc in Enumerable.Range(0,81) ){
				if( (rc%9)==0 )  po = (rc/9).ToString("##0:");
				int p = pSol99[rc];
				po += (p==0)? "  .": $"  {p}";
				if( (rc%9)==8 ) WriteLine(po);
			}
		}


		public (int[],int[])  Get_LS_PatternCode( int[] Q ){ // Get_Top_Left
			int[]  P_Top  = new int[7];
			int[]  P_Left = new int[7];

			var (s0,S1,S2) = _Get_Top_Left_B2r1B3r1( Q, rowColB:true );
			int S3 = 0x1FF & ~(S1 | S2);
			int S4 = 0b111111000 & ~S1;
			int S5 = 0b111000111 & ~S2;
			int S6 = 0b000111111 & ~S3;

			P_Top[0] = s0;
			P_Top[1] = Get_PatternCodeSub( Q, S1, 03, rowColB:true );
			P_Top[2] = Get_PatternCodeSub( Q, S2, 12, rowColB:true );
			P_Top[3] = Get_PatternCodeSub( Q, S3, 21, rowColB:true );

			P_Top[4] = Get_PatternCodeSub( Q, S4, 06, rowColB:true );
			P_Top[5] = Get_PatternCodeSub( Q, S5, 15, rowColB:true );
			P_Top[6] = Get_PatternCodeSub( Q, S6, 24, rowColB:true );

			var (s1,S1L,S2L) = _Get_Top_Left_B2r1B3r1( Q, rowColB:true );
			int S3L= 0x1FF & ~(S1L | S2L);
			int S4L= 0b110110110 & ~S1L;
			int S5L= 0b101101101 & ~S2L;
			int S6L= 0b011011011 & ~S3L;
			
			P_Left[0] = s0;
			P_Left[1] = Get_PatternCodeSub( Q, S1, 27, rowColB:false );
			P_Left[2] = Get_PatternCodeSub( Q, S1, 28, rowColB:false );
			P_Left[3] = Get_PatternCodeSub( Q, S1, 29, rowColB:false );

			P_Left[4] = Get_PatternCodeSub( Q, S1, 54, rowColB:false );
			P_Left[5] = Get_PatternCodeSub( Q, S1, 55, rowColB:false );
			P_Left[6] = Get_PatternCodeSub( Q, S1, 56, rowColB:false );

			return (P_Top,P_Left);
			
			// ---------------------------------------------------------------------------------------
				(int,int,int)  _Get_Top_Left_B2r1B3r1( int[] Q, bool rowColB ){
					int S1Q = IntVecToBit( Q, 03, rowColB:true);
					int S2Q = IntVecToBit( Q, 12, rowColB:true);

					foreach( int s0 in Enumerable.Range(0,UTop_s0s1.Count) ){
						var (S1,S2) = UTop_s0s1[s0];
						if( S1==S1Q && S2==S2Q )  return  (s0,S1,S2);
					}
					return  (-1,0,0);
				}
			
				int IntVecToBit( int[] Q, int startRC, bool rowColB ){
					int plus = rowColB? 1: 9;
					int val = 0;
					for( int k=0, rc=startRC; k<3; k++,rc+=plus )  val |= 1<<(Q[rc]-1);
					return val;
				}

				int Get_PatternCodeSub( int[] Q, int S, int startRC, bool rowColB ){
					int[] SA = BitToIntArrayP( S );
					int[] SQ = new int[3];
					int plus = rowColB? 1: 9;
					for( int k=0, rc=startRC; k<3; k++,rc+=plus )  SQ[k] = Q[rc];

					for( int kx=0; kx<6; kx++ ){
						for( int k=0; k<3; k++ ){ if( SQ[k] != SA[permList[kx,k]] )  break; }
						return kx;
					}

					return  -1;
				}
		}
    }

/*
       Block2
00  ...456...
01  ...45.7..
02  ...45..8.
03  ...45...9
04  ...4.67..
05  ...4.6.8.
06  ...4.6..9
07  ...4..78.
08  ...4..7.9
09  ...4...89
10  ....567..
11  ....56.8.
12  ....56..9
13  ....5.78.
14  ....5.7.9
15  ....5..89
16  .....678.
17  .....67.9
18  .....6.89
19  ......789
  
       Block2      Block3         Block4       Block7
00  ...456...   ......789      .2..5..8.    ..3..6..9
01  ...45.7..   1......89      .23.5....    1....6..9
02  ...45.7..   .2.....89      .23.5....    ...4.6..9
03  ...45.7..   ..3....89      .23.5....    .....67.9
04  ...45..8.   1.....7.9      .2..56...    1.3.....9
05  ...45..8.   .2....7.9      .2..56...    ..34....9
06  ...45..8.   ..3...7.9      .2..56...    ..3...7.9
07  ...45...9   1.....78.      .2..5...9    1.3..6...
08  ...45...9   .2....78.      .2..5...9    ..34.6...
09  ...45...9   ..3...78.      .2..5...9    ..3..67..
10  ...4.67..   1......89      .23....8.    1....6..9
11  ...4.67..   .2.....89      .23....8.    ...4.6..9
12  ...4.67..   ..3....89      .23....8.    .....67.9
13  ...4.6.8.   1.....7.9      .2...6.8.    1.3.....9
14  ...4.6.8.   .2....7.9      .2...6.8.    ..34....9
15  ...4.6.8.   ..3...7.9      .2...6.8.    ..3...7.9
16  ...4.6..9   1.....78.      .2.....89    1.3..6...
17  ...4.6..9   .2....78.      .2.....89    ..34.6...
18  ...4.6..9   ..3...78.      .2.....89    ..3..67..
19  ...4..78.   12......9      .23..6...    1..4....9
20  ...4..78.   1.3.....9      .23..6...    1.....7.9
21  ...4..78.   .23.....9      .23..6...    ...4..7.9
22  ...4..7.9   12.....8.      .23.....9    1..4.6...
23  ...4..7.9   1.3....8.      .23.....9    1....67..
24  ...4..7.9   .23....8.      .23.....9    ...4.67..
25  ...4...89   12....7..      .2...6..9    1.34.....
26  ...4...89   1.3...7..      .2...6..9    1.3...7..
27  ...4...89   .23...7..      .2...6..9    ..34..7..
28  ....567..   1......89      ..3.5..8.    1....6..9
29  ....567..   .2.....89      ..3.5..8.    ...4.6..9
30  ....567..   ..3....89      ..3.5..8.    .....67.9
31  ....56.8.   1.....7.9      ....56.8.    1.3.....9
32  ....56.8.   .2....7.9      ....56.8.    ..34....9
33  ....56.8.   ..3...7.9      ....56.8.    ..3...7.9
34  ....56..9   1.....78.      ....5..89    1.3..6...
35  ....56..9   .2....78.      ....5..89    ..34.6...
36  ....56..9   ..3...78.      ....5..89    ..3..67..
37  ....5.78.   12......9      ..3.56...    1..4....9
38  ....5.78.   1.3.....9      ..3.56...    1.....7.9
39  ....5.78.   .23.....9      ..3.56...    ...4..7.9
40  ....5.7.9   12.....8.      ..3.5...9    1..4.6...
41  ....5.7.9   1.3....8.      ..3.5...9    1....67..
42  ....5.7.9   .23....8.      ..3.5...9    ...4.67..
43  ....5..89   12....7..      ....56..9    1.34.....
44  ....5..89   1.3...7..      ....56..9    1.3...7..
45  ....5..89   .23...7..      ....56..9    ..34..7..
46  .....678.   12......9      ..3..6.8.    1..4....9
47  .....678.   1.3.....9      ..3..6.8.    1.....7.9
48  .....678.   .23.....9      ..3..6.8.    ...4..7.9
49  .....67.9   12.....8.      ..3....89    1..4.6...
50  .....67.9   1.3....8.      ..3....89    1....67..
51  .....67.9   .23....8.      ..3....89    ...4.67..
52  .....6.89   12....7..      .....6.89    1.34.....
53  .....6.89   1.3...7..      .....6.89    1.3...7..
54  .....6.89   .23...7..      .....6.89    ..34..7..
55  ......789   123......      ..3..6..9    1..4..7..
*/										   
}