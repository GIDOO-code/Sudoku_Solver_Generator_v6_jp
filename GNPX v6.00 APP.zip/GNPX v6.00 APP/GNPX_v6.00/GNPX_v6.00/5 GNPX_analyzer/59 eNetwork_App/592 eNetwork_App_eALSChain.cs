using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Reflection.Metadata.Ecma335;
using System.Diagnostics;
using System.Windows;

namespace GNPX_space{
    public partial class ALSTechGen: AnalyzerBaseV2{

		// !!! ALS-Chain is an algorithm that can find an extremely large number of solutions among Sudoku algorithms. !!!

        //ALS Chain is an algorithm that connects in a loop using ALS-RCC.
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page52.html

        // ALS (Almost Locked Set)
        // https://gidoo-code.github.io/Sudoku_Solver_Generator_v6/page26.html
         
        //Paste the next 81 digits onto the grid and solve with /Solve/MultiSolve/      
        // 6.14..5.7.3.7..4..9..35.....6..1.3.415.....688.4.3..1.....94..2..2..3.4.4.6..21.3
		// 7....5..9.9.4.7.8...8.3.7..81.3.9.6...6...9...3.7.2.18..3.7.1...4.5.1.2.1..6....4
		// 6..9....5.4.5.6.7...5.3.2...6.8.3.91..8...6..91.7.2.5...6.7.4...7.3.5.6.2....4..7

		private string spX(int g) => new string(' ',g*2);
		private bool   eALS_Chain_break;
		private bool   uniqueBreak;

		private bool   uniqueStemB;	
		private bool   overlapALSB;

		public bool eALS_Chain_uniqueStemB()			=> eALS_Chain_General( uniqueStemB:true, overlapALSB:false );
		public bool eALS_Chain_Overlap()				=> eALS_Chain_General( uniqueStemB:false, overlapALSB:true );
		public bool eALS_Chain_uniqueStemB_Overlap()	=> eALS_Chain_General( uniqueStemB:true, overlapALSB:true );
		public bool eALS_Chain_Unlimited()				=> eALS_Chain_General( uniqueStemB:false, overlapALSB:false );



        public bool eALS_Chain_General( bool uniqueStemB=false, bool overlapALSB=false ){
			this.uniqueStemB = uniqueStemB;
			this.overlapALSB = overlapALSB;

		  // ========== Prepare ================================================== 
			debugPrint = false;		// debug eALS_Chain ///[for debug]

			PrepareStage();
            if(ALSMan.ALSList==null || ALSMan.ALSList.Count<=3) return false;
			eALS_Chain_break = false;
		 // -----------------------------------------------------------------------			

			// *==*==* Origin Cell & no *==*==**==*==**==*==**==*==*
			foreach( (UAnLS,int) OriginALSno  in IE_Generate_Origin_Cell_No() ){
				if( pAnMan.Check_TimeLimit() ) return (SolCode>0);


				var (OriginALS,noOrigin) = OriginALSno;

					//WriteLine( $"\n@@@@@@@@@\n{OriginALS}\n@@@=>{noOrigin}" );

				OriginALS.preALS_no = (null,noOrigin);

				// *==*==* First Link *==*==**==*==**==*==**==*==*
				List<UAnLS> ALSs_conn = Find_ConnectedALS( GEN:0, OriginALS.bitExp, noOrigin, usedCells:OriginALS.bitExp, debugPrint:debugPrint );
				if( ALSs_conn==null || ALSs_conn.Count==0 ) continue;

				foreach( var (nextALS,nx) in ALSs_conn.WithIndex() ){	// First ALS of chain.
						if(debugPrint) WriteLine( $"{spX(0)} @ OriginALS:{OriginALS.ToStringA()} ===> UA{nextALS.ToStringA()}" );

					uniqueBreak = false;
					nextALS.preSubset_no = OriginALSno;
						if(debugPrint) WriteLine( $"nextALS:{nextALS.ToStringA()} <- {OriginALSno.Item1.ToStringA()}#{OriginALSno.Item2+1}" );
					var nextALSno = (nextALS,noOrigin);
					UInt128 usedCells = OriginALS.bitExp | nextALS.bitExp;	//origin_cell and next_Cells
					Recursive_Search_ALSChain( 0, OriginALSno, nextALSno, usedCells );

					if( eALS_Chain_break )  return (SolCode>0);
					if( uniqueBreak )  break;
				}
			}

            return (SolCode>0);

					// ===== ===== ===== ===== ===== ===== ===== ===== ===== ===== ===== =====
					IEnumerable<(UAnLS,int)> IE_Generate_Origin_Cell_No( ){
						foreach( UCell UC in pBOARD.Where(p=>p.FreeB>0) ){
							foreach( int no in UC.FreeB.IEGet_BtoNo() ){				
								UAnLS originALS = new( ID:0, U:UC );
									if(debugPrint) WriteLine( $"\n@000@  originALS:{originALS.ToStringA()}#{no+1}" );
								originALS.preALS_no = (null,no);

								yield return (originALS,no);
							}
						}
								
						yield break;
					}

		}

		private List<UAnLS> Find_ConnectedALS(int GEN, UInt128 BP, int no, UInt128 usedCells, bool debugPrint ){
			UInt128     filter = ~ BP.Aggregate_ConnectedAnd() & BOARD_Free81B9[no];
			List<UAnLS> UList = ALSMan.ALSList.FindAll( P=>{
				UInt128 Q = P.bitExp & BOARD_Free81B9[no];
				if( Q==qZero || (Q&filter)>qZero || (Q&usedCells)>qZero ) return false;
				return true;				
			} );
					if(debugPrint){ int nx=0; UList.ForEach(P=>WriteLine($"{spX(GEN)} {nx++:00} {P.ToStringA()}") ); }
			return UList;
		}


		private void Recursive_Search_ALSChain( int GEN, (UAnLS,int) orgALSno, (UAnLS,int) curALSno,  UInt128 usedCells ){
			var (curALS,noLink) = curALSno;  // current ALS(Link end ALS) and digit ... The second term is not a bit representation.
					//if(debugPrint)  WriteLine( $"\n{spX(GEN)} <<< {GEN} >>> {ALSChain_ToLink(orgALSno,curALSno)}" );	

			{	// ===== solution found =====
				var (orgALS,orgNo) = orgALSno;
				if( GEN>1 && (curALS.connected81_9[orgNo] & orgALS.bitExp) > UInt128.Zero ){  // "GEN>1" : The first and second links do not check for loops.					
					if( curALS.FreeB.DifSet(1<<noLink).IsHit(orgNo) ){ // Inconsistent Loop : "orgNo�hof current ALS is positive
								//if(debugPrint) WriteLine( $"\n  >>>>> {ALSChain_ToLink(orgALSno,curALSno)} *** ALS_Chain" );	

						ALS_Chain_SolResult( orgALSno, curALSno );
						SolCode = 2;
						if( !pAnMan.IsContinueAnalysis() ){ eALS_Chain_break=true; return; } // @is Valid
						uniqueBreak = uniqueStemB;				
						return;
					}
				}
			}

			// ===== Next Link =====
			int noBnext = curALS.FreeB .BitReset(noLink);
			foreach( int noSel in noBnext.IEGet_BtoNo() ){
				List<UAnLS>  nextALSs_connected = Find_ConnectedALS( GEN:GEN, curALS.bitExp, noSel, usedCells, debugPrint:debugPrint );
				if( nextALSs_connected.Count == 0 )  continue;

				// ===== Select next ALSs
				foreach( var (nextALS,nx) in nextALSs_connected.WithIndex() ){
					if( !overlapALSB && (usedCells & nextALS.bitExp)>qZero )  continue;

					nextALS.preSubset_no = curALSno;
							if(debugPrint) WriteLine( $"nextALS:{nextALS.ToStringA()} <- {curALSno.Item1.ToStringA()}#{curALSno.Item2+1}" );

					var nextALSno = (nextALS,noSel);
					UInt128 usedCells2 = usedCells | nextALS.bitExp;
					Recursive_Search_ALSChain( GEN+1, orgALSno, nextALSno, usedCells2 );  //�@<<< Recursive Search >>>
					if( eALS_Chain_break || uniqueBreak )  return;
				}
			}
			return;
		}



        private void ALS_Chain_SolResult( (UAnLS,int) orgALSno, (UAnLS,int) UAsol ){ 
            if( SolInfoB ){ 
				var (orgALS,orgNo) = orgALSno;

                List<(USubset,int)> ALSChainPlus = ALSChain_ToLink( orgALSno,UAsol );

                Color crBG, crElm=Colors.LightPink;
				int nx=0, solB=1<<orgNo;
                
				foreach( var (UA,no) in ALSChainPlus ){
                    crBG = _ColorsLst[ (nx++)%_ColorsLst.Length ]; 
                    UA.UCellLst.ForEach( UC => UC.Set_CellColorBkgColor_noBit( noB:1<<no, clr:AttCr, clrBkg:crBG) );
                }

				int noSol = orgNo;
				UCell UCstem = pBOARD[orgALS.rc];
				UCstem.CancelB = UCstem.FreeB & (1<<noSol);

				string st = $"ALS_Chain";
				if( overlapALSB  )  st += " overlapALS";
				if( uniqueStemB  )  st += " uniqueStem";
				if( st == $"ALS_Chain" ) st += " Unlimited";
				st += $"\n Stem:{orgALS.rc.ToRCString()}#{orgNo+1}"; 
                string stChain = ALSChain_ToString(orgALSno,ALSChainPlus);//ALSChain_ToLinksString(UAnext);

                Result = $"{st.Replace("\n","")}" ;
                ResultLong = $"{st}\n{stChain}";
				extResult  = ResultLong;
            }
			return;

				// ===== ===== ===== ===== ===== ===== ===== ===== ===== ===== ===== ===== ===== =====
				List<(USubset,int)> ALSChain_ToLink( (UAnLS,int) orgALSno, (UAnLS,int) UAsol ){ 
					List<(USubset,int)> ALSChainPlus = new();
					USubset Q;
					(USubset,int) P = UAsol;
					while(P.Item1!=null){ ALSChainPlus.Add(P); P=P.Item1.preSubset_no; } 
					ALSChainPlus.Reverse();
					return ALSChainPlus;
				}

				string ALSChain_ToString( (UAnLS,int) orgALSno, List<(USubset,int)> ALSChainPlus ){
					string st = "";// $" [{ULG_Origin}]";
					//string space = new string(' ',st.Length+5);
					bool first=true;
					foreach( var (q,no2) in ALSChainPlus ){
						if(!first)  st += $" -> #{no2+1}";
						st += $"\n   -> [{q.bitExp.TBScmp()} #{q.FreeB.TBScmp()}]";
						first = false;
					}
					var (orgALS,orgNo) = orgALSno;
					st += $" -> #{orgNo+1}\n   -> [{orgALS.rc.ToRCString()}#{orgNo+1}]";
					st = st.Replace("+","");
					return st;
				}
		}

	}
}