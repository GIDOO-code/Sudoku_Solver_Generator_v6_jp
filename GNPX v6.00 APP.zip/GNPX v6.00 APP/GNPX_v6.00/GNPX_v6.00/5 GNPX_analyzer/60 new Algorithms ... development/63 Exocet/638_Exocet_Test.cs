﻿using GIDOO_space;
using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Intrinsics.Arm;
using System.Security.Policy;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space{
	// Reference to SudokuCoach.
	// https://www.taupierbw.be/SudokuCoach/SC_Exocet.shtml 
		using G6_SF = G6_staticFunctions;

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		// ... Prefer clear code over efficiency ...


      #region ElementElimination_Manager

		private void ElementElimination_Manager_UT( string st ){
			switch(st){
				case "Initialize": 
					extResultLst.Clear(); 
					foreach( var P in pBOARD ){ P.CancelB=0; P.ECrLst=null; }
					break;

				case "@": extResultLst.Add("@"); break;
					
				case "Adjust": break;
			}
		}

		private bool ElementElimination_Manager_rB( UExocetA Exo, int rcE, int noB, string st="" ){
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);
			if( rcE == 999 )  return false;
			pBOARD[rcE%100].CancelB |= (pBOARD[rcE%100].FreeB)&noB;		
			return true;
		}
		private bool ElementElimination_Manager_Bn(  UExocetA Exo, UInt128 ELM81, int no, string st="" ){
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);

			int noB = 1<<no;
			foreach( int rc in ELM81.IEGet_rc(81) ){
				if( pBOARD[rc].No != 0 )  continue;
				pBOARD[rc].CancelB |= (pBOARD[rc].FreeB)&noB;
			}
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);
			return true;
		}
		
		private bool ElementElimination_Manager_BB( UExocetA Exo, UInt128 ELM81, int noB, string st="" ){
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);

			foreach( int rc in ELM81.IEGet_rc(81) ){
				if( pBOARD[rc].No != 0 )  continue;
				pBOARD[rc].CancelB |= (pBOARD[rc].FreeB)&noB;
			}
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);
			return true;
		}
		private bool ElementElimination_Manager_st( string st ){
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);
			return true;
		}
		// ====================================================================================
	  #endregion ElementElimination_Manager

	  #region Test Man
	  // :::::: Exocet Exclusion Test ::::::
		private bool Exo_Exclude_Test( UExocetA Exo ){
			int FreeB_Object = Exo.Object81_AB.Get_FixedFreeB();

			ElementElimination_Manager_UT("Initialize");
			if( (Exo.FreeB & ~(FreeB_Object)) > 0 ) return false;

					// ... for debug ..... <<< Check the exclusion rules that are causing the error >>>
						bool testOn = false;	//  Check if true	 // ===== Exocet_Nxt Debug =====

						UCell UCt = pBOARD[06];
						void test(int rule) => WriteLine( $"  === rule:{rule}  UC:{UCt.rc.ToRCString()}({UCt.rc})  FreeB:{UCt.FreeB.TBS()}  CancelB:{UCt.CancelB.TBS()}" ); 
				
						if(testOn){
							int n = 0;
							string st = Exo.CL_bySize_noB.Aggregate("  Exo.Covered:", (a,b) => a+$" [{n++}]"+b.TBS() );  
							WriteLine( $"\n{Exo}\n Exo.Covered {st}" );
							foreach( var p in Exo.CoverStatusList.Where(q => q!=null) )  WriteLine( $"{p}");
							if( UCt.CancelB > 0 )  WriteLine( "....." );

							foreach( var P in pBOARD.Where( uc => uc.CancelB>0) )  WriteLine( $"  ##TestOn: {P.rc.ToRCString_NPM()}.CancelB:{P.CancelB.TBS()}");
						}
					// ........................................

				int Retest=3, cancelT=0;

				// ..... ver6.0 .....
//				if( Exo.Exocet_Standard ){  // This process is not suitable for SE-Extend.
					Test_Exocet_Incompatible( Exo, debugPrint:false );	 // (Changed 'Exo.FreeB' internally.)
					if(testOn) test(100);
//				}
	/*
				else if( Exo.ExoType == "Complex" ){
					int FreeBa = Exo.CL_bySize_noB[3];
					int elmFreeB = Exo.FreeB .DifSet(FreeBa);
					foreach( var UC in Exo.Base81.IEGet_UCell(pBOARD).Where(P=> (P.FreeB&elmFreeB)>0) ){
						UC.CancelB = UC.FreeB & elmFreeB;
					}
				}
	*/
			LRetest:

				// ============= JE1 Rule =============
				Test_JE1_Rule( Exo, debugPrint:false );
					if(testOn) test(101);


				// ============= JE2 Rule =============	//@@@ This rule is invalid
				// [3] Any non-Base Candidate in a Target Cell is false.
				Test_Exocet_Rule03_non_Base_Candidate( Exo, debugPrint:false );
					if(testOn) test(3);

				// [4] If one base digit is valid in the target cell, it is negative in the other target cell.
				Test_Exocet_Rule04_Target_to_Target( Exo, debugPrint:false );
					if(testOn) test(4);

				// [5] A base candidate that has a cross-line must be negative.
				Test_Exocet_Rule05_Candidates_with_CrossLines( Exo, debugPrint:false );
					if(testOn) test(5);

						
				if( Exo.ExoMtdName=="Exocet_JE2" && Exo.FreeB.BitCount()==2 ){	
					// [6] Missing in the Mirror cells ... mirror
					Test_Exocet_Rule06_Object_Mirror_Connection( Exo, debugPrint:false );
						if(testOn) test(5);

					// [7] Missing in the Mirror cells ... Target
					Test_SE_Rule07_Missing_in_Mirror( Exo, debugPrint:false );
						if(testOn) test(7);

					// [8] Mirror contains only one possible non-Base Digit
					Test_SE_Rule08_Mirror_nonBase( Exo, debugPrint:false );
						if(testOn) test(8);

				// @@@ Rule-9 is not appropriate. No solution found.
					// [9] Mirror Node contains a locked digit.
					// When applying rule 9, pay attention to the Mirror_Locked and Base_Locked conditions.
					Test_Exocet_Rule09_Mirror_LockedDigits( Exo, debugPrint:false );
						if(testOn) test(9);	
				}


				// [10] Known Base Digit is false in all cells in full sight of either both Base Cells, or both Target Cells.
				Test_Exocet_Rule10_known_BaseDigit( Exo, debugPrint:false );
					if(testOn) test(10);


				// [11] Handling Escape Cells or non-S cells
				// Rule-11 is invalid because it does not meet the requirements of JE2.
				Test_Exocet_Rule11_EscapeCells_nonSCells( Exo, debugPrint:false );  
					if(testOn) test(11);

 				// =================================================================================
				// If any element is cancelled, parse again.
				// Even if repeat this command, the output of the same message will be suppressed.
				if( (--Retest) > 0 ){
					int cancelCC = pBOARD.Sum( uc=> uc.CancelB.BitCount() );
					if( cancelCC > cancelT ){ cancelT=cancelCC; goto LRetest; }
				}



				// ---------------------------------------------------------------------------------
				if( pBOARD.All(uc=> uc.No!=0 || uc.CancelB==0) ) return false;					// There is no processing.
				if( pBOARD.Any(P => P.No==0 && P.FreeB.DifSet(P.CancelB)==0) ){	pBOARD.ForEach(uc =>uc.CancelB=0); return false; }	// Inconvenient process

				if( pBOARD.Any(P => P.No==0 && P.FreeB==0) ){		
					foreach( var P in pBOARD.Where(P=>P.No==0 && P.FreeB==0) )  WriteLine( $"{P} FreeB:{P.FreeB.TBS()}" );
					throw new Exception( $"GNPX Algorithm Error. {Exo.ExoMtdName}");
				}
	
			// --- Solution found ---
			return true;
		}
	  #endregion Test Man




	  #region JE1 exclusion rules
		private void Test_JE1_Rule( UExocetA Exo, bool debugPrint=false ){
			// 1) Target Wildcard(#z) is negative.
			// 2) The Base wildcard has been confirmed as positive, but the other Base digits is yet to be determined.
			// 3) Wildcards in Escape are confirmed as negative.

		// ４),5)  are ripple effects and are not included in GNPX.

			// 4) The wildcard in line-1 is confirmed as positive.
			//    If there is only one, all other candidates other than the wildcard in the corresponding cell can be excluded.
			// 5) Once Base and Target wildcards have been determined, the wildcard digits for these scopes will be negative.

			if( !Exo.ExoMtdName.Contains("JE1") && !Exo.ExoMtdName.Contains("Single") )  return;
			if( Exo.wildcard_noB == 0 )  return;

		UCrossLine ExG1=Exo.ExG1, ExG2=Exo.ExG2;
			int	 FreeB = Exo.FreeB;
			int  wildcard_noB = Exo.wildcard_noB;

			try{
				ElementElimination_Manager_UT("@");
				if( ExG1.wildcardB )  wildcard_Elimination(ExG2);
				if( ExG2.wildcardB )  wildcard_Elimination(ExG1);
			}
			catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }

			return; 

				bool wildcard_Elimination( UCrossLine ExGm ){

					int noBWC = Exo.wildcard_noB;
					int noWC = noBWC.BitToNum();
					string  stSB = $"#{FreeB.TBScmp()}";
					string  stWildcard = $"[Rule-1] {Exo.stBase}{stSB} is {Exo.ExoMtdName}.";

					//1) Target Wildcard(#z) is negative.
					string st = $"{stWildcard} Target-{ExGm.sq} {ExGm.stObject}/Wildcard #{noBWC.TBScmp()} is negative.";
					ElementElimination_Manager_BB( Exo, ELM81:ExGm.Object81, noB:noBWC, st );

					//2) The Base wildcard has been confirmed as positive, but the other Base digits is yet to be determined.
					var (singleB,moreB) = Exo.Base81.Get_FreeB_Single_More();
					if( (singleB & noBWC) != 0 ){
						List<UCell> Ulst = Exo.Base81.IEGet_UCell(pBOARD).ToList().FindAll(P=> (P.FreeB & noBWC)!=0);
						if( Ulst.Count==1){
							Ulst[0].FixedNo = noWC+1;
							string st2 = $"{stWildcard} Base {Exo.stBase}/Wildcard #{noBWC.TBScmp()} is positive.";
							ElementElimination_Manager_st(st2);
						}
					}

					// 3) Wildcards in Escape are confirmed as negative.
					UInt128 Escape = Connected_81[Exo.rcStem] & Exo.Band81 & Exo.CrossLine_012;
					UInt128 Escape_Wildcard = Escape & BOARD_Free81B9[noWC];
					if( Escape_Wildcard != qZero ){
						string st3 = $"{stWildcard} Escape:{Escape_Wildcard.TBScmp_addSt($"#{noBWC.TBScmp()}")} is negative.";
						ElementElimination_Manager_BB( Exo, ELM81:Escape_Wildcard, noB:noBWC, st3 );
					}

/*
					// 4) The wildcard in line-1 is confirmed as positive.
					//    If there is only one, all other candidates other than the wildcard in the corresponding cell can be excluded.
					// Sline-1にある Wildcard は positive に確定。これが１つなら、対応セルの Wildcard 以外の候補は除外できる。
					UInt128 Sline1_Wildcard = ExGm.SLine & BOARD_Free81B9[noWC];
					if( Sline1_Wildcard.BitCount() == 1 ){
						UCell U4 = pBOARD[Sline1_Wildcard.BitToNum(81)];
						U4.FixedNo = noWC+1;
						string st4 = $"{stWildcard} Base {Exo.stBase}/Wildcard #{noBWC.TBScmp()} is positive.";
						ElementElimination_Manager_st(st4);
					}
*/
/*
					// 5) Once Base and Target wildcards have been determined, the wildcard digits for these scopes will be negative.
					UInt128 Influence_Wildcard = ((Exo.Base81 &BOARD_Free81B9[noWC]) | Sline1_Wildcard).Aggregate_ConnectedAnd();
					if( Influence_Wildcard != qZero ){
						string st5 = $"{stWildcard} Escape:{Escape_Wildcard.TBScmp_addSt($"#{noBWC.TBScmp()}")} is negative.";
						ElementElimination_Manager_BB( Exo, ELM81:Influence_Wildcard, noB:noBWC, st5 );
					}
*/
					int elmNo = ExGm.FreeB_Object & ~FreeB & ~Exo.wildcard_noB;
					if( elmNo != 0 ){
						string  stSB5 = $"#{FreeB.TBScmp()}";
						UInt128 elm  = ExGm.Object81;
						string st6 = $"[Rule-1] {Exo.stBase}{stSB} is the {Exo.ExoMtdName}, Then ({elm.TBScmp()})#{elmNo.TBScmp()} are negative.";
						ElementElimination_Manager_BB( Exo, ELM81:elm, noB:elmNo, st6 );
					}

					return  true;
				}
		}
	  #endregion JE1 exclusion rules



	  #region Exocet_Test 
		// Rule-3 :
		private void Test_Exocet_Rule03_non_Base_Candidate( UExocetA Exo, bool debugPrint=false ){
			ElementElimination_Manager_UT("@");		

			_Test_Rule03_non_Base_Candidate_sub( Exo, Exo.ExG1 );
			_Test_Rule03_non_Base_Candidate_sub( Exo, Exo.ExG2 );
			return;
				void _Test_Rule03_non_Base_Candidate_sub( UExocetA Exo, UCrossLine ExGM ){
					if( ExGM.Object81.BitCount() > 1 )  return;
 							// $$$@@@ For object type, non-FreeB contained in both cannot be excluded.
					var (singleB,_) = ExGM.Object81.Get_FreeB_Single_More();
					int FreeBObjNega = singleB & ~Exo.FreeB;
					if( FreeBObjNega > 0 ){
						string st = $"[Rule-3] Object{ExGM.sq} {ExGM.Object81.TBScmp()}#{FreeBObjNega.ToBitStringN(9)}";
							   st += $" is a non-Base candidate, then it is negative.";	
						ElementElimination_Manager_BB( Exo, ELM81:ExGM.Object81, noB:FreeBObjNega, st );
					}
				}
		}



		// Rule-4 :
		private void Test_Exocet_Rule04_Target_to_Target( UExocetA Exo, bool debugPrint=false ){
			//	E4.If the Base Digits is determined to be positive in one Target, it is negative in the other Target.
			//	Each Target has a different Base digit.
			//	If one Target is positive, the other Target will be negative.

			ElementElimination_Manager_UT("@");
			_Test_Rule04_Target_to_Target_sub( Exo, Exo.ExG1, Exo.ExG2 );
			_Test_Rule04_Target_to_Target_sub( Exo, Exo.ExG2, Exo.ExG1 );
			return;

				void _Test_Rule04_Target_to_Target_sub( UExocetA Exo, UCrossLine ExGA, UCrossLine ExGB ){
					int FreeBObject = ExGA.Object81.IEGet_UCell(pBOARD).Aggregate(0, (a,uc) => a | (uc.FreeB & ~uc.CancelB) );
					if( FreeBObject.BitCount()==1 ){
						int no = FreeBObject.BitToNum(9);
						if( !ExGB.FreeB_Object .IsHit(no) )  return;
						UInt128 elmAand = ExGA.Object81.IESelect81B_with_noB(pBOARD,1<<no).Aggregate(qMaxB81,(a,uc) => a & Connected_81[uc.rc] );
						UInt128 elmObj = ExGB.Object81 & elmAand;	// ObjectA -> ObjectB
						string stTgObj = ((ExGA.Object81.BitCount()==1)? "Target": "Object") + $"{ExGA.sq}";

						string st = $"[Rule-4] {stTgObj} {ExGA.stObject}#{no+1} is certin to be positive, then {ExGB.stObject}#{no+1} is negative";
						ElementElimination_Manager_Bn( Exo, ELM81:elmObj, no:no, st );
					}
				}
		}

			
		// Rule-5 :	A Base candidate that has a cross-line as an S cell cover house must be false in the target cell in that cross-line
		//          which may make other simple colouring eliminations available. 
		private void Test_Exocet_Rule05_Candidates_with_CrossLines( UExocetA Exo, bool debugPrint=false ){
			// Bird's definition: A Base candidate that has a cross-line as an 'S' cell cover house must be false in the target cell in that cross-line
				// E5. The Base Digit with Cross Cover-Line are excluded from the corresponding Target.

			ElementElimination_Manager_UT("@");
			int     FreeB_wildcard = Exo.FreeB;
			if( Exo.ExoMtdName.Contains("JE1") || Exo.ExoMtdName.Contains("Single") )  FreeB_wildcard = FreeB_wildcard.DifSet(Exo.wildcard_noB);
			foreach( var no in FreeB_wildcard.IEGet_BtoNo() ){
				if( !Exo.CL_bySize_noB[2].IsHit(no) )  continue;
				var UCL = Exo.CoverStatusList[no];	// Cover Line
				if( UCL == null )  continue;
					if(debugPrint)  WriteLine( $"{sp5}Test_Rule5_  no:#{no+1}  CoverStatusList:{Exo.CoverStatusList[no]}" );

				if( UCL.CLH_1 >= 100 ){
					int hh = UCL.CLH_1%100;
					if( hh == Exo.ExG1.hno ) _Test_Exocet_Rule05_sub( no, Exo.ExG1 );
					if( hh == Exo.ExG2.hno ) _Test_Exocet_Rule05_sub( no, Exo.ExG2 );
				}
				if( UCL.CLH_2 >= 100 ){
					int hh = UCL.CLH_2%100;
					if( hh == Exo.ExG1.hno ) _Test_Exocet_Rule05_sub( no, Exo.ExG1 );
					if( hh == Exo.ExG2.hno ) _Test_Exocet_Rule05_sub( no, Exo.ExG2 );
				}
			}
			return;

					void _Test_Exocet_Rule05_sub( int no, UCrossLine ExGx ){
						UInt128 Obj81 = ExGx.Object81;
						if( Obj81.BitCount()>1 || !ExGx.FreeB_Object.IsHit(no) )  return;

						if( (BOARD_Free81B9[no]&ExGx.SLine).BitCount() <= 1 )  return;	//

						string stTyp = (Obj81.BitCount()==1)? $"Target{ExGx.sq}": $"Object{ExGx.sq}";
						string st = $"[Rule-5] {stTyp} {Obj81.TBScmp()}#{no+1} has a Cross_Line, then negative.";
						ElementElimination_Manager_Bn( Exo, ELM81:Obj81, no:no, st );
					}
		}	


		// Rule-6 :	Any base candidate that can't be true in the mirror node for a target cell is false in the target cell.
		//			  => Base candidates that are not included in the Mirror are false in the corresponding Target.
		private void Test_Exocet_Rule06_Object_Mirror_Connection( UExocetA Exo, bool debugPrint=false ){
			UCrossLine ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;	

			ElementElimination_Manager_UT("@");
			_Rule_06_Mirrored(Exo,ExG1);
			_Rule_06_Mirrored(Exo,ExG2);
			return;

				void _Rule_06_Mirrored( UExocetA Exo, UCrossLine ExGM ){
					if( !ExGM.IsTargetType )  return;
					// If there is no Base candidate number #a in the SLine for the Object and
					//int F = Exo.FreeB & ExGM.FreeB_Object & ~ExGM.Mirror81.Get_FixedFreeB();
					int F = Exo.FreeB & ExGM.Object81.Get_FixedFreeB() & ~ExGM.Mirror81.Get_FixedFreeB();

					if( F == 0 ) return;
					Mirror_using = true;
					string stTyp = ((ExGM.Object81.BitCount()==1)? "Target": "Object") + $"{ExGM.sq}";
					string stMirr = $"#{F.TBScmp()}";
					string st = $"[Rule-6] Mirror-{ExGM.sq} {ExGM.stMirror} is missing {stMirr}, then {stTyp} {ExGM.Object81.TBScmp()}{stMirr} is negative.";
					ElementElimination_Manager_BB( Exo, ELM81:ExGM.Object81, noB:F, st );
				}
		}


		// Rule-7 :	If one mirror node cell can only contain nonBase digits, the second one will be restricted to the Base digits in the opposite object cells.
		private void Test_SE_Rule07_Missing_in_Mirror( UExocetA Exo, bool debugPrint=false ){// ... Je2/JE+ type supported
			if( Exo.Base81.BitCount()!=2 || Exo.FreeB.BitCount()!=2 )  return;
			UCrossLine ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;	

			ElementElimination_Manager_UT("@");		
			_Rule_07_Missing_in_MirrorSub(Exo,ExG1);
			_Rule_07_Missing_in_MirrorSub(Exo,ExG2);

			return;

					void _Rule_07_Missing_in_MirrorSub( UExocetA Exo, UCrossLine ExGM ){
						if( !ExGM.IsTargetType )  return;
						if( ExGM.Object81.Get_FreeB_or() == 0 )  return;
						int		FreeB = Exo.FreeB;
						List<UCell> ElmList = ExGM.Mirror81.IEGet_UCell(pBOARD).ToList().FindAll(u=> (u.FreeB&FreeB)>0);
						if( ElmList.Count != 1 )  return;

						UCell ELM = ElmList[0];
						int   nFreeB = ELM.FreeB & ~FreeB;
						if( nFreeB == 0 )  return;

						Mirror_using = true;
						string st = $"[Rule-7] Mirror-{ExGM.sq} {(ExGM.Mirror81.Reset(ELM.rc)).TBScmp()} does not contain #{FreeB.TBScmp()}";
						st += $", then {(qOne<<ELM.rc).TBScmp()}#{nFreeB.TBScmp()} is negative,";
						ElementElimination_Manager_rB(  Exo, ELM.rc, noB:nFreeB, st );
					}
		}


		// Rule-8 : Mirror contains only one possible non-Base Digit
		private void Test_SE_Rule08_Mirror_nonBase( UExocetA Exo, bool debugPrint=false ){	// ... Je2/JE+ type supported
			if( Exo.Base81.BitCount()!=2 || Exo.FreeB.BitCount()!=2 )  return;
			UCrossLine ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;	

			ElementElimination_Manager_UT("@");
			_Rule_08_lockedSub(Exo,ExG1);
			_Rule_08_lockedSub(Exo,ExG2);
			return;

					void _Rule_08_lockedSub( UExocetA Exo, UCrossLine ExGM ){
						if( !ExGM.IsTargetType )  return;
						int		FreeB = Exo.FreeB;
						int    nFreeB = ExGM.Mirror81.Get_FixedFreeB() & ~FreeB;
						if( nFreeB.BitCount() != 1 )  return;

						int no = nFreeB.BitToNum(sz:9);
						UInt128 Mirror_no = ExGM.Mirror81.IESelect81B_with_noB(pBOARD,nFreeB).Aggregate(qZero, (a,uc)=> a| qOne<<uc.rc );
						UInt128 Mirror_elm = Mirror_no.Aggregate_ConnectedAnd() & BOARD_Free81B9[no];
						Mirror_elm = Mirror_elm & ~( Exo.ExG1.Object81 | Exo.ExG2.Object81 );

						if( Mirror_elm != qZero ){
							Mirror_using = true;
							string stNo = $"#{no+1}";
							string st = $"[Rule-8] Mirrar-{ExGM.sq} {Mirror_no.TBScmp(stNo)} is only one possible non-Base Digit";
							st += $", then {Mirror_elm.TBScmp(stNo).Replace(" ",stNo+" ")} is negative.";
							ElementElimination_Manager_Bn( Exo, Mirror_elm, no, st );
						}
					}
		}	


		 //Rule 9 : if a Mirror Node contains a locked digit, any other digits it contains of the same type(base or non-base) are false.
		private void Test_Exocet_Rule09_Mirror_LockedDigits( UExocetA Exo, bool debugPrint=false ){  // ... Je2/JE+ type supported
																									// Rule-9 requires that another rule be applied to the object type.

			// @@@ This exclusion rule-9 is applicable only to "JE2", and Base is Locked(2 cells,2 digits).
			if( Exo.ExoMtdName != "Exocet_JE2" )  return;   
			if( Exo.Base81.BitCount()!=2 || Exo.FreeB.BitCount()!=2 )  return;

			UCrossLine ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;	

			ElementElimination_Manager_UT("@");
			_Rule_09_lockedSub(Exo,ExG1,ExG2);
			_Rule_09_lockedSub(Exo,ExG2,ExG1);
			return;

					void _Rule_09_lockedSub( UExocetA Exo, UCrossLine ExGM, UCrossLine ExGA ){
						//if( !ExGM.IsTargetType )  return;

						int sq = ExGM.sq;
						int FreeB=Exo.FreeB, FreeBA=ExGA.FreeB_Object;

						int FreeB_Mirror81 = ExGM.Mirror81.Get_FreeB_or() & ~FreeBA;	// @@@ 
						if( FreeB_Mirror81 == 0 )  return;

						int noB_locked = __Get_LockedHouse_no( ExGM );

						foreach( int no in FreeB_Mirror81.IEGet_BtoNo() ){
							
							int h_locked = noB_locked & (1<<no);
							if( h_locked == 0 )  continue;	// unlocked

							int noB = 1<<no;
							if( (FreeB&noB)==0 ){	// ... Case : Locked digit(#no) in Mirror is not BaseDigits.
								Mirror_using = true;
								int nFreeBF = FreeB_Mirror81 & ~(FreeB | noB);	
								UInt128 elm = ExGM.Mirror81.IESelect81B_with_noB(pBOARD,nFreeBF).Aggregate(qZero, (a,uc) => a | qOne<<uc.rc );
								string st = $"[Rule-9_nonBase] In Mirrar-{sq} {elm.TBScmp()}#{no+1} is locked non-BaseDigit.";
								st += $" then the other nonBase {ExGM.Mirror81.TBScmp()}#{nFreeBF.TBScmp()} is negative.";
								ElementElimination_Manager_BB( Exo, ELM81:elm, noB:nFreeBF, st );
							}

							else{					// ... Case : Locked digit(#no) in Mirror is BaseDigits.
								// Case :  Locked digit(#no) in Mirror is BaseDigits. Locked BaseDigits is a necessary condition.
								Mirror_using = true;
								int nFreeBF = FreeB_Mirror81 & FreeB & ~noB;
					//			if( (nFreeBF&FreeBA) > 0 )  continue;	// @@@ 
								UInt128 elm = ExGM.Mirror81.IESelect81B_with_noB(pBOARD,nFreeBF).Aggregate(qZero, (a,uc) => a | qOne<<uc.rc );

								string st = $"[Rule-9_Base] In Mirrar-{sq} {ExGM.Mirror81.TBScmp()}#{no+1} is locked BaseDigit.";
								st += $" Then {ExGM.Mirror81.TBScmp()}#{nFreeBF.TBScmp()} is negative.";
								ElementElimination_Manager_BB( Exo, ELM81:elm, noB:nFreeBF, st );
							}
		
						}
					}

					
					int __Get_LockedHouse_no( UCrossLine UCL ){
						int Frame27 = UCL.Mirror81.Ceate_rcbFrameAnd();	//WriteLine( $" Frame27:{Frame27.TBS27()}" ); 
						int FreeBMirror = UCL.Mirror81.Get_FixedFreeB();

						int FreeBMirror_Locked = 0;
						foreach( int h in Frame27.IEGet_BtoHouse27() ){
							UInt128 h81 = House_81[h];
							foreach( int no in FreeBMirror.IEGet_BtoNo() ){
								UInt128 F = (BOARD_Free81B9[no] & h81) & ~UCL.Mirror81;
								if( F == qZero ){	// ... Locked
									FreeBMirror_Locked |= 1<<no;
										// G6_SF.__MatrixPrint( Flag:Exo.Base81, BOARD_Free81B9[no], h81, UCL.Mirror81, F, $"BOARD_Free81B9[#{no+1}], h81, UCL.Mirror81, F" );
								}
							}
						}
							WriteLine( $"@@@@@@@@@@  FreeBMirror_Locked:{FreeBMirror_Locked.TBS()}" );
						return  FreeBMirror_Locked;
					}

		}	


		// Rule 10 : known Base Digit is false in all cells in full sight of either both Base Cells, or both Target Cells.
		private void Test_Exocet_Rule10_known_BaseDigit( UExocetA Exo, bool debugPrint=false ){	// ... Je2/JE+ type supported	
			//if( Exo.ExocetNamePlus.Contains("SE_single") )  return;	 // <<===== Exocet Debug =====

			// Base Digit is the solution in one of the Base Cells, then it must also be the solution in one of the Target Cells.
			var (rcB1,rcB2) = Exo.Base81.BitToTupple();
			int szBase = Exo.Base81.BitCount();
			if( rcB2 < 0 ){ szBase=1; rcB2=rcB1; }	// for SE_SingleBase.(When one is negative.)
			if( Exo.FreeB.BitCount() >= szBase )  return;	// "if both Base Digits are determined"

			UInt128  fullSight = (Connected_81[rcB1] & Connected_81[rcB2]);	// Base1 & Base2
			fullSight = fullSight & ~Exo.Base81;

			fullSight |= ( Exo.ExG1.Get_FullSight(withExclusion:true) & Exo.ExG2.Get_FullSight(withExclusion:true) );	// or Target1 & target2 ... Je2/JE+ type supported
					if(debugPrint)  WriteLine( fullSight.ToBitString81N() );

			ElementElimination_Manager_UT("@");
			string st_elm = "";
			foreach( int no in Exo.FreeB.IEGet_BtoNo() ){
				UInt128 elm = BOARD_Free81B9[no] & fullSight; 
				if( elm != qZero ){
					st_elm += " "+elm.TBScmp_addSt($"#{no+1}"); 
					ElementElimination_Manager_Bn( Exo, elm, no );
				}
			}

			if( st_elm!="" ){
				st_elm = st_elm.Replace(" } { "," ");
				string st = $"[Rule-10] Base({Exo.stBase}) are Fixed, then {st_elm.Trim()} are negative.\n          (Both bases or both targets are in focus)";
				ElementElimination_Manager_st( st );
			}

		}


		// Rule 11 : Handling Escape Cells and non-S cells
		//	A known base digit, or one that can only occur once in the escape cells in the cross-lines, is false in the non-S cells in its cover houses.
		//  The only cross-line cells a base digit can occupy in the JE band are one of the two target cells when its true or two of the escape cells when its false. When its can only occupy one of the escape cells then it too will be restricted to a single instance in the cross-line cells in the JE band and so must be true in two S cells.
		private void Test_Exocet_Rule11_EscapeCells_nonSCells( UExocetA Exo, bool debugPrint=false ){
			if( Exo.Base81.BitCount()!=2 || Exo.FreeB.BitCount()!=2 )  return;
			// Base Digits are both determined. 

			ElementElimination_Manager_UT("@");
			int dir = Exo.dir;
			foreach( int no in Exo.FreeB.IEGet_BtoNo() ){
				UInt128 CLno = Exo.CrossLine_012 & BOARD_Free81B9[no];
				UInt128 ELM  = CLno.IEGet_rc().Aggregate(qZero, (a,rc) => a | House_81[(dir,rc).DRCHf()] ) & ~Exo.CrossLine_012;
				if( ELM == qZero )  continue;
				string st = $"[Rule-11] Base({Exo.stBase})#{no+1} are Fixed, then {ELM.TBScmp_addSt($"#{no+1}")} is negative.";
				ElementElimination_Manager_Bn( Exo, ELM, no, st );
			}
		}


	  #endregion

	}
}
