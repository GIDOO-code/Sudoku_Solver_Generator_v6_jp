using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;

namespace GNPX_space{

	// Reference to SudokuCoach.
	// https://www.taupierbw.be/SudokuCoach/SC_Exocet.shtml 

	public partial class Exocet_TechGen: AnalyzerBaseV2{

		private void Test_Exocet_Incompatible( UExocetA Exo, bool debugPrint=false ){

			// @@@	Reconsideration is needed.

			//[ATT] ***** This test is invalid for Exocet_SingleBase. *****
			//  Exocet_SingleBase has only one Target, so it is not valid.
			if( Exo.ExoMtdName == "Exocet_JE1"|| Exo.ExoMtdName.Contains("Single")  )  return;		// 

			List<(int,int)> AllPairs=new();	// ###, UnsuitablePair=new();

			UInt128 Object1=Exo.ExG1.Object81, Object2=Exo.ExG2.Object81;

			foreach( var (no1,no2,UR4B) in _IEGet_Permutation_no(Exo) ){
				int       no1B=1<<no1, no2B=1<<no2, URBlk ;
				(int,int) noT12 = (no1,no2);
				AllPairs.Add(noT12);													// AllPairs : All permutation patterns
			}

			List<(int,int)> ValidPairs = AllPairs;	// ###.Except(UnsuitablePair).ToList();		// ValidPairs : Valid Pair patterns
					if( debugPrint ){
						if( ValidPairs!=null ) ValidPairs.ForEach( p=> WriteLine( $"ValidPairs (#{p.Item1+1},#{p.Item2+1})" ) );
						//### UnsuitablePair.ForEach( P=> WriteLine( $"UnsuitablePair (#{P.Item1+1},#{P.Item2+1})" ) );
					}

			var (rcB1,rcB2) = Exo.Base81.BitToTupple();	
			
			UCell UB1=pBOARD[rcB1], UB2=pBOARD[rcB2];	// for Exocet_singel

			if( ValidPairs!=null && ValidPairs.Count>0 ){ // Incompatibility exclusions in base digits
				int FreeB0_Valid = ValidPairs.Aggregate( 0, (a,p) => a |= (1<<p.Item1)|(1<<p.Item2) );
				UB1.CancelB |= UB1.FreeB & ~FreeB0_Valid;
				if( UB2 != null )  UB2.CancelB |= UB2.FreeB & ~FreeB0_Valid;
			}


			// --- Compatible digit check result ---
			if( ValidPairs!=null ){
				string stU = "";	// ### UnsuitablePair.Aggregate( "#", (a,p)=> a+ $"({p.Item1+1},{p.Item2+1}) " );
				stU = stU.Trim().Replace(")(", "),(");
				string stV = ValidPairs.Aggregate( "#", (a,p)=> a+ $"({p.Item1+1},{p.Item2+1}) " );
				stV = stV.Trim().Replace(")(", "),(");

				ElementElimination_Manager_UT("@");

				string st = $"Compatible digit check ... (in development)" ;
				st += $"\n incompatible pair(T1,T2) : {stU}";
				st += $"\n        valid pair(T1,T2) : {stV}";
				ElementElimination_Manager_rB( Exo, 999, 0, st );

				if( UB1.CancelB>0 && UB1.CancelB.BitCount()==1 && UB1.CancelB==UB2.CancelB ){
					int no = UB1.CancelB.BitToNum(9);	
					st = $" {Exo.Base81.ToRCStringComp()} #{no+1} is negative.";
					ElementElimination_Manager_Bn( Exo, ELM81:Exo.Base81, no:no, st );
				}	
				else{
					if( UB1.CancelB>0 ){
						st = $" {UB1.rc.ToRCString()}#{UB1.CancelB.ToBitStringN(9)} is negative.";
						ElementElimination_Manager_rB( Exo, rcE:UB1.rc, noB:UB1.CancelB, st );
					}
					if( UB2.CancelB>0 ){
						st = $" {UB2.rc.ToRCString()}#{UB2.CancelB.ToBitStringN(9)} is negative.";
						ElementElimination_Manager_rB( Exo, rcE:UB2.rc, noB:UB2.CancelB, st );
					}
					if( (UB1.CancelB|UB2.CancelB) == 0 ){
						st = $" No invalid pair(T1, T2) was found";
						ElementElimination_Manager_st( st );
					}
				}
			}
			return;


					// ===== inner function =====
					IEnumerable<(int,int,bool)> _IEGet_Permutation_no( UExocetA Exo ){
						int		FreeB = Exo.FreeB;
						int     FreeB_Obj1=Exo.ExG1.FreeB_Object, FreeB_Obj2=Exo.ExG2.FreeB_Object;
						int     digitsCommonToBase = FreeB_Obj1 & FreeB_Obj2;

						Permutation prm = new( FreeB.BitCount(), 2 );
						List<int>  noList = FreeB.BitToNumList().ConvertAll(p=>(p-1));
						int skip=2;
						while( prm.Successor(skip:skip) ){
							int no1=noList[prm.Index[0]];
							if( !FreeB_Obj1.IsHit(no1) ){ skip=0; continue; }

							skip = 1;
							int no2=noList[prm.Index[1]];
							if( !FreeB_Obj2.IsHit(no2) ) continue;
							 
							bool UR4B = digitsCommonToBase.IsHit(no1) & digitsCommonToBase.IsHit(no2);

							yield return (no1,no2,UR4B);
						}
						yield break;
					}
		}

	}


}
