using GIDOO_space;
using GNPX_space;
using System;
using System.Buffers.Text;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen_68;
using static GNPX_space.SubsetTechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine68,UCrossLine68,UCrossLine68);

    public partial class Exocet_TechGen_68 : AnalyzerBaseV2{

		private IEnumerable<UExocet> IE_Exocet_Generate_BasicForm_632( string ExoControl, bool debugPrint=false ){

			for( int dir=0; dir<2; dir++ ){		// direction  0:row 1:column
				foreach( int rcStem in Enumerable.Range(0,81) ){

					// ... Base cells
					int     h_Base = (dir,rcStem).DirRCtoHouse( );	// Row/Column house no.
					UInt128 Base81 = (House_81[h_Base] & House_81[rcStem.B()+18]) .Reset(rcStem) & BOARD_Free81;
					
					// ... Single Exocet : Base is a single-cell and bivalue.)  @@@ BIVALUE |||
					if( ExoControl.Contains("SingleBase") ){	
						foreach( UCell UC in Base81.IEGet_UCell(pBOARD).Where(uc=>uc.FreeBC==2) ){
							UExocet Exo = _Create_ExocetObject( ExoControl, dir, rcStem, qOne<<UC.rc, UC.FreeB );
							if( Exo != null )  yield return Exo;
						}
						continue;
					}


					else{ // ... Normal ........................................................
						if( Base81.BitCount() != 2 )  continue;					// ... Number of bits in Base. Base-cells are unfixed
						
						int FreeB  = Base81.Get_FreeB_or();		// ... Base candidates
						int FreeBC = FreeB.BitCount();
						if( FreeBC<3 || FreeBC>6 )  continue;	// Base Cells contain 3 or 6 Candidates.
			// @@@			int FreeB_and  = Base81.Get_FreeB_and();
			// @@@			if( FreeB_and == 0 )  continue;			// Base Cells have no candidates in common.  // @@@ Not a requirement

						UExocet Exo = _Create_ExocetObject( ExoControl, dir, rcStem, Base81, FreeB );
						if( Exo != null )  yield return Exo;
					}
				}
			}
			yield break;



					// ------------------------------------------------------------------------------------------------------------------------
					UExocet _Create_ExocetObject( string ExoMtdName, int dir, int rcStem, UInt128 Base81A,int FreeB ){
						UInt128 CrossLine0  =  House_81[(1-dir,rcStem).DRCHf()] .DifSet( House_81[rcStem.B()+18] );
						if( (CrossLine0 & BOARD_Free81) == qZero )  return null;	//There is nothing free on CrossLine_b

						UExocet Exo = new( ExoMtdName, dir, rcStem, Base81A, FreeB, BOARD_Free81 );	
						Exo.BOARD_Fixed_BaseDigits = FreeB.IEGet_BtoNo().Aggregate( qZero, (a,no) => a | BOARD_Fixed81B9[no] );

							if(debugPrint) WriteLine( $" CrossLine0:{CrossLine0.TBS()}" );

						return Exo;
					}
		}
	}

}