﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Windows.Media;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Security.Policy;
using System.Windows.Shapes;
using System.Net.Sockets;
using System.Windows;
using System.Windows.Documents;
using System.Xml.Linq;

namespace GNPX_space{
	// Reference to SudokuCoach.
	// https://www.taupierbw.be/SudokuCoach/SC_Exocet.shtml 


    public partial class Exocet_TechGen_68 : AnalyzerBaseV2{

		// ... Prefer clear code over efficiency ...


    #region ElementElimination_Manager

		private void ElementElimination_Manager_UT( string st ){
			switch(st){
				case "Initialize": 
					extResultLst.Clear(); 
					foreach( var P in pBOARD ){ P.CancelB=0; P.ECrLst=null; }
					break;

				case "@":
					extResultLst.Add("@");
					break;
					
				case "Adjust":
					break;
			}
		}

		private bool ElementElimination_Manager_rB( UExocet Exo, int rcE, int noB, string st="" ){
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);
			if( rcE == 999 )  return false;
			pBOARD[rcE%100].CancelB |= (pBOARD[rcE%100].FreeB)&noB;		
			return true;
		}
		private bool ElementElimination_Manager_Bn(  UExocet Exo, UInt128 ELM81, int no, string st="" ){
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);

			int noB = 1<<no;
			foreach( int rc in ELM81.IEGet_rc(81) ){
				if( pBOARD[rc].No != 0 )  continue;
				pBOARD[rc].CancelB |= (pBOARD[rc].FreeB)&noB;
			}
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);
			return true;
		}
		private bool ElementElimination_Manager_BB( UExocet Exo, UInt128 ELM81, int noB, string st="" ){
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);

			foreach( int rc in ELM81.IEGet_rc(81) ){
				if( pBOARD[rc].No != 0 )  continue;
				pBOARD[rc].CancelB |= (pBOARD[rc].FreeB)&noB;
			}
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);
			return true;
		}
		private bool ElementElimination_Manager_st( string st ){
			if( st!="" && !extResultLst.Contains(st) )  extResultLst.Add(st);
			return true;
		}
		// ====================================================================================
	#endregion ElementElimination_Manager

	#region Test Man
		private bool Exo_Exclude_Test( UExocet Exo ){
			int FreeB_Object = Exo.Object81.Get_FixedFreeB();
			if( Exo.FreeB.DifSet(FreeB_Object) > 0 ) return false;;

					//	WriteLine( $"pBOARD[14].CancelB:{pBOARD[14].CancelB.TBS()}" );	// ==================================
					// ... for debug ..... <<< Check the exclusion rules that are causing the error >>>
						bool testOn = false;	//  Check if true	 // ===== Exocet_Nxt Debug =====

						UCell UCt = pBOARD[06];
						void test(int rule) => WriteLine( $"  === rule:{rule}  UC:{UCt.rc.ToRCString()}({UCt.rc})  FreeB:{UCt.FreeB.TBS()}  CancelB:{UCt.CancelB.TBS()}" ); 
				
						if(testOn){
							int n = 0;
							string st = Exo.CL_bySize_noB.Aggregate("  Exo.Covered:", (a,b) => a+$" [{n++}]"+b.TBS() );  
							WriteLine( $"\n{Exo}\n Exo.Covered {st}" );
							foreach( var p in Exo.CoverStatusList.Where(q => q!=null) )  WriteLine( $"{p}");
							if( UCt.CancelB > 0 )  WriteLine( "....." );

							foreach( var P in pBOARD.Where( uc => uc.CancelB>0) )  WriteLine( $"  ##TestOn: {P.rc.ToRCString_NPM()}.CancelB:{P.CancelB.TBS()}");
						}
					// ........................................

			int Retest=3, cancelT=0;
			try{

				// ..... ver6.0 .....
				if( Exo.ExocetNamePlus.Contains("SE") is false ){  // This process is not suitable for SE-Extend.
					Test_Exocet_Incompatible( Exo, debugPrint:false );	 // (Changed 'Exo.FreeB0' internally.)
					if(testOn) test(100);
				}
	/*
				else if( Exo.ExoType == "Complex" ){
					int FreeBa = Exo.CL_bySize_noB[3];
					int elmFreeB = Exo.FreeB0 .DifSet(FreeBa);
					foreach( var UC in Exo.Base81.IEGet_UCell(pBOARD).Where(P=> (P.FreeB&elmFreeB)>0) ){
						UC.CancelB = UC.FreeB & elmFreeB;
					}
				}
	*/
			LRetest:



				// ============= JE1 Rule =============
				Test_JE1_Rule( Exo, debugPrint:false );
					if(testOn) test(101);


				// ============= JE2 Rule =============	//@@@ This rule is invalid
				// [3] Any non-Base Candidate in a Target Cell is false.
				Test_Exocet_Rule03_non_Base_Candidate( Exo, debugPrint:false );
					if(testOn) test(3);

				// [4] If one base digit is valid in the target cell, it is negative in the other target cell.
				Test_Exocet_Rule04_Target_to_Target( Exo, debugPrint:false );
					if(testOn) test(4);

				// [5] A base candidate that has a cross-line must be negative.
				Test_Exocet_Rule05_Candidates_with_CrossLines( Exo, debugPrint:false );
					if(testOn) test(5);

 			// =================================================================================
				// If any element is cancelled, parse again.
				// Even if repeat this command, the output of the same message will be suppressed.
				if( (--Retest) > 0 ){
					int cancelCC = pBOARD.Sum( uc=> uc.CancelB.BitCount() );
					if( cancelCC > cancelT ){ cancelT=cancelCC; goto LRetest; }
				}



			// ---------------------------------------------------------------------------------
				if( pBOARD.All(uc=> uc.No!=0 || uc.CancelB==0) ) return false;					// There is no processing.
				if( pBOARD.Any(P => P.No==0 && P.FreeB.DifSet(P.CancelB)==0) ){	pBOARD.ForEach(uc =>uc.CancelB=0); return false; }	// Inconvenient process

				if( pBOARD.Any(P => P.No==0 && P.FreeB0==0) ){		
					foreach( var P in pBOARD.Where(P=>P.No==0 && P.FreeB0==0) )  WriteLine( $"{P} FreeB0:{P.FreeB0.TBS()}" );
					throw new Exception( $"GNPX Algorithm Error. {Exo.ExocetNamePlus}");
				}
			}

			catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }
	
			// --- Solution found ---
			return true;
		}
	#endregion Test Man


	#region JE1 exclusion rules
		private void Test_JE1_Rule( UExocet Exo, bool debugPrint=false ){
			// 1) One of the digits that satisfy the S criteria for BaseDigit(#abc) is present in Target, and the other (#bc) is not present in Target.
			//    It is not certain which digit is TargetDigit.
			// 2) BaseDigits (#bc) other than TargetDigit are in Escape.
			// 3) The wildcard digits(#z) is in Base but does not exist in Target.
			// 4) here can be no BaseDigits in non-band, non-S regions.

			if( !Exo.ExoMtdName.Contains("JE1") && !Exo.ExocetNamePlus.Contains("Single") )  return;
			int	 FreeB = Exo.FreeB;
			int  wildcardB = Exo.WildCardB;
			
			ElementElimination_Manager_UT("@");

			if( Exo.ExocetNamePlus.Contains("SingleBase") ){
				UInt128 elm = Exo.ExG2.Object81;
				int elmNo = elm.Get_FixedFreeB() .DifSet(FreeB);
				if( elmNo > 0 ){
					string stSB = $"#{FreeB.TBScmp()}";
					string st = $"[Rule-1] {Exo.stBase}#{stSB} is the \"SingleBase\", Then ({elm.TBScmp()})#{elmNo.TBScmp()} are negative.";
					ElementElimination_Manager_BB( Exo, ELM81:elm, noB:elmNo, st );
				}
			}

			else if( wildcardB.BitCount()==1 ){
				int  noWC = wildcardB.BitToNum();
				UInt128 Object_nFix = (!Exo.ExG1.wildcardB)? Exo.ExG1.Object81: Exo.ExG2.Object81;

				UCrossLine68  nExGM = Exo.ExG1.wildcardB? Exo.ExG2: Exo.ExG1;
				UInt128 BaseWildcard = Exo.Base81 & BOARD_Free81B9[noWC];
				if( BaseWildcard.BitCount() == 0 )  return;
				UInt128 elm = BaseWildcard.Aggregate_ConnectedAnd() & BOARD_Free81B9[noWC];
				if( Object_nFix.BitCount()==1 )  elm |= Object_nFix;

				if( elm != 0 ){
					string stWC = $"#{wildcardB.ToBitStringN(9)}";
					string stW = $"[Rule-1]  {stWC} is the Wildcard,";
					stW += $" then exclude {elm.TBScmp_No(stWC)} connected to Base({Exo.stBase}#{noWC+1}). ";
					ElementElimination_Manager_BB( Exo, elm, noB:wildcardB, stW );
				}
			}
			return;
		}
	#endregion JE1_Test
	
	#region Exocet_Test

		// Rule-3 :
		private void Test_Exocet_Rule03_non_Base_Candidate( UExocet Exo, bool debugPrint=false ){
			ElementElimination_Manager_UT("@");		

			_Test_Rule03_non_Base_Candidate_sub( Exo, Exo.ExG1 );
			_Test_Rule03_non_Base_Candidate_sub( Exo, Exo.ExG2 );
			return;

				void  _Test_Rule03_non_Base_Candidate_sub( UExocet Exo, UCrossLine68 ExGM ){
					if( ExGM.Object81.BitCount() >= 2 )  return;	// ... Exclude Object(2 or more cells)
					// $$$@@@ For object type, non-FreeB contained in both cannot be excluded.
					var (singleB,_) = ExGM.Object81.Get_FreeB_Single_More();
					int FreeBObjNega = singleB & ~Exo.FreeB;
					if( FreeBObjNega > 0 ){
						string st = $"[Rule-3] Object{ExGM.sq} {ExGM.Object81.TBScmp()}#{FreeBObjNega.ToBitStringN(9)}";
							   st += $" is a non-Base candidate, then it is negative.";	
						ElementElimination_Manager_BB( Exo, ELM81:ExGM.Object81, noB:FreeBObjNega, st );
					}
				}
		}



		// Rule-4 :
		private void Test_Exocet_Rule04_Target_to_Target( UExocet Exo, bool debugPrint=false ){
			//	E4.If the Base Digits is determined to be positive in one Target, it is negative in the other Target.
			//	Each Target has a different Base digit.
			//	If one Target is positive, the other Target will be negative.

			ElementElimination_Manager_UT("@");
			_Test_Rule04_Target_to_Target_sub( Exo, Exo.ExG1, Exo.ExG2 );
			_Test_Rule04_Target_to_Target_sub( Exo, Exo.ExG2, Exo.ExG1 );
			return;

				void _Test_Rule04_Target_to_Target_sub( UExocet Exo, UCrossLine68 ExGA, UCrossLine68 ExGB ){
					int FreeBObject = ExGA.Object81.IEGet_UCell(pBOARD).Aggregate(0, (a,uc) => a | (uc.FreeB.DifSet(uc.CancelB) ) );
					if( FreeBObject.BitCount()==1 ){
						int no = FreeBObject.BitToNum(9);
						if( !ExGB.FreeB_Object81 .IsHit(no) )  return;
						UInt128 elmAand = ExGA.Object81.IESelect81B_with_noB(pBOARD,1<<no).Aggregate(qMaxB81,(a,uc) => a & Connected_81[uc.rc] );
						UInt128 elmObj = ExGB.Object81 & elmAand;	// ObjectA -> ObjectB
						string stTgObj = ((ExGA.Object81.BitCount()==1)? "Target": "Object") + $"{ExGA.sq}";

						string st = $"[Rule-4] {stTgObj} {ExGA.stObject}#{no+1} is certin to be positive, then {ExGB.stObject}#{no+1} is negative";
						ElementElimination_Manager_Bn( Exo, ELM81:elmObj, no:no, st );
					}
				}
		}

			
		// Rule-5 :	A Base candidate that has a cross-line as an S cell cover house must be false in the target cell in that cross-line
		//          which may make other simple colouring eliminations available. 
		private void Test_Exocet_Rule05_Candidates_with_CrossLines( UExocet Exo, bool debugPrint=false ){
			// Bird's definition: A Base candidate that has a cross-line as an 'S' cell cover house must be false in the target cell in that cross-line
				// E5. The Base Digit with Cross Cover-Line are excluded from the corresponding Target.

			ElementElimination_Manager_UT("@");
			int     FreeB_wildcard = Exo.FreeB;
			if( Exo.ExoMtdName.Contains("JE1") || Exo.ExoMtdName.Contains("Single") )  FreeB_wildcard = FreeB_wildcard.DifSet(Exo.WildCardB);
			foreach( var no in FreeB_wildcard.IEGet_BtoNo() ){
				if( !Exo.CL_bySize_noB[2].IsHit(no) )  continue;
				var UCL = Exo.CoverStatusList[no];	// Cover Line
				if( UCL == null )  continue;
					if(debugPrint)  WriteLine( $"{sp5}Test_Rule5_  no:#{no+1}  CoverStatusList:{Exo.CoverStatusList[no]}" );


				if( UCL.CLH_1 >= 100 ){
					int hh = UCL.CLH_1%100;
					if( hh == Exo.ExG1.hno ) _Test_Exocet_Rule05_sub( no, Exo.ExG1 );
					if( hh == Exo.ExG2.hno ) _Test_Exocet_Rule05_sub( no, Exo.ExG2 );
				}
				if( UCL.CLH_2 >= 100 ){
					int hh = UCL.CLH_2%100;
					if( hh == Exo.ExG1.hno ) _Test_Exocet_Rule05_sub( no, Exo.ExG1 );
					if( hh == Exo.ExG2.hno ) _Test_Exocet_Rule05_sub( no, Exo.ExG2 );
				}
			}
			return;

					void _Test_Exocet_Rule05_sub( int no, UCrossLine68 ExGx ){
						if( !ExGx.FreeB_Object81.IsHit(no) )  return;
						UInt128 Obj81 = ExGx.Object81;
						if( Obj81.BitCount()>1 )  return;
						string stTyp = (Obj81.BitCount()==1)? $"Target{ExGx.sq}": $"Object{ExGx.sq}";
						string st = $"[Rule-5] {stTyp} {Obj81.TBScmp()}#{no+1} has a Cross_Line, then negative.";
						ElementElimination_Manager_Bn( Exo, ELM81:Obj81, no:no, st );
					}
		}
				
	#endregion Exocet_Test

	}


}
