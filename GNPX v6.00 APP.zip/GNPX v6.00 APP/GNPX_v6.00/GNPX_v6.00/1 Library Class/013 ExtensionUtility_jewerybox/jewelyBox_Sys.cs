using ABI.System;
using GNPX_space;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Resources;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using static System.Diagnostics.Debug;

#if false
namespace GIDOO_space{

	// https://mamesfactory.com/2747/
    static public partial class Extension_Utility{

		static PerformanceCounter pc = new PerformanceCounter();

		static void Get_PCInformation(){
			pc.CategoryName = "Processor Information";
			pc.CounterName = "% Processor Utility";
			pc.InstanceName = "_Total";

			// Check if a category exists
			if (!System.Diagnostics.PerformanceCounterCategory.Exists(pc.CategoryName))  WriteLine("unregistered category");

			// Check if a counter exists
			else if (!PerformanceCounterCategory.CounterExists(pc.CounterName, pc.CategoryName, "."))  WriteLine("Counter not registered!");

			else{

				do{
					float m = pc.NextValue();
					WriteLine("{0}", m);
				}while (true);
			}
		}

    }
}
#endif