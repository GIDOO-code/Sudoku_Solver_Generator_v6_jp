﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;


namespace GIDOO_space{

	public partial class zip_Utility{

		public zip_Utility(){}


	// Create ZIP file
		public void Create(string zipPath){	// Create only
			//if( File.Exists(zipPath) )	throw new IOException("Same name File already exists.");

			var zip=ZipFile.Open(zipPath, ZipArchiveMode.Create);
			zip.Dispose();
		}
		public void Update(string zipPath){	// read and Wrtie
			var zip = ZipFile.Open(zipPath, ZipArchiveMode.Update);
			zip.Dispose();
		}


	// Examine ZIP file entries (files, directories)
		public bool Exists( string zipPath, string name){
			using( var zip=ZipFile.OpenRead(zipPath)){
				var selectedFile = zip.Entries.FirstOrDefault(p => p.FullName == name);
				return selectedFile != null;
			}
		}

		public IEnumerable< string> EnumerateFiles(string zipPath){
			var files = new List<string>();
			using( var zip=ZipFile.OpenRead(zipPath)){
				foreach( var entry in zip.Entries){
					files.Add(entry.FullName);
				}
			}
			return files;
		}



	// Read text data from ZIP file
		public string ReadToEnd(string zipPath, string name){
			using( var zip=ZipFile.OpenRead(zipPath)){
				var selectedFile = zip.Entries.FirstOrDefault(p => p.FullName==name);
				if( selectedFile == null) throw new FileNotFoundException();

				using( var reader=new StreamReader(selectedFile.Open())){ 
					return reader.ReadToEnd();
				}
			}
		}

		public IEnumerable<string> ReadLine(string zipPath, string name){
			var lines = new List<string>();

			using( var zip=ZipFile.OpenRead(zipPath)){
				var selectedFile = zip.Entries.FirstOrDefault(p => p.FullName==name);
				if( selectedFile == null) throw new FileNotFoundException();

				using( var reader = new StreamReader(selectedFile.Open())){
					string line;
					while( (line=reader.ReadLine()) != null){ lines.Add(line); }
				}
			}

			return lines;
		}


		
	// Add text data files to ZIP file
		public void Write( string zipPath, string name, string text, bool overwrite=false, bool append=false){
			var beforeText = "";

			if( Exists(zipPath, name)){
				if( overwrite==false) throw new IOException("Same name File already exists.");
				beforeText = ReadToEnd(zipPath, name);
				Delete(zipPath, name);
			}

			using( var zip=ZipFile.Open(zipPath, ZipArchiveMode.Update)){
				var newFile = zip.CreateEntry(name, CompressionLevel.Optimal);		//CompressionLevel: Optimal, Fastest, NoCompression
				using( var writer = new StreamWriter(newFile.Open(), System.Text.Encoding.UTF8)){
					if( !string.IsNullOrEmpty(beforeText) && append ){ writer.Write(beforeText); }
					writer.Write(text);
				}
			}
		}




		public void WriteLine(string zipPath, string name, string text, bool overwrite=false, bool append=false){
			var beforeText = "";

			if( Exists(zipPath, name)){
				if( overwrite==false ) throw new IOException();
				beforeText = ReadToEnd(zipPath, name);
				Delete( zipPath, name);
			}

			using( var zip=ZipFile.Open(zipPath, ZipArchiveMode.Update)){
				var newFile = zip.CreateEntry(name, CompressionLevel.Optimal);		//CompressionLevel: Optimal, Fastest, NoCompression

				using( var writer = new StreamWriter(newFile.Open(), System.Text.Encoding.UTF8)){
					if( !string.IsNullOrEmpty(beforeText) && append){ writer.Write(beforeText); }
					writer.WriteLine(text);
				}
			}
		}
		



	// Delete a file(entry) in a ZIP file
		public void Delete(string zipPath, string name){
			using( var zip=ZipFile.Open(zipPath, ZipArchiveMode.Update)){
				var selectedFile = zip.Entries.FirstOrDefault(p => p.FullName == name);
				if( selectedFile == null) throw new System.IO.FileNotFoundException();
				selectedFile.Delete();
			}
		}




	// Create directory within ZIP file
		public void MakeDirectory(string zipPath, string directoryName){
			if(  Directory.Exists(directoryName) ){
				throw new IOException("Same name Directory already exists.");
			}

			using( var zip=ZipFile.Open(zipPath, ZipArchiveMode.Update)){
				if( !directoryName.EndsWith("/") && !directoryName.EndsWith(@"\")){
					directoryName += "/";
				}

				zip.CreateEntry(directoryName);
			}

		}
	}
}
