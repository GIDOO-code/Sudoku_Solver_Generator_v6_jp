﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using static System.Diagnostics.Debug;

using GIDOO_space;


namespace GNPX_space{

    public partial class GNPX_App_Man { 

        public List<UAlgMethod> ReadXMLFile_AnalysisConditions_MethodList( ){
			//WriteLine( "          @@@@@2 ReadXMLFile_AnalysisConditions_MethodList" );

            SolverList_GNPX = new();
            SolverList_GNPX.AddRange(SolverList_SysDef);

            SolverList_GNPX.ForEach(P=>P.IsChecked=true);

			try{
			// ----- XML read ----- 
				var currentDir = Directory.GetCurrentDirectory();
				var _pfName = Path.Combine(currentDir, SDK_Methods_XMLFileName);	
				G6.Dir_SDK_Methods_XMLFileName = _pfName;

				if( File.Exists( _pfName ) ){
					using( StreamReader rd = new StreamReader(_pfName)){
						G6 = (G6_Base)G6.xmlSerializer.Deserialize(rd);
					}
			
					// ----- methodList ----- 
					G6.Set_SolverList_CheckUncheck( SolverList_GNPX ); // Setting the Solver +/- Information

					G6.MSlvr_MaxLevel = SolverList_GNPX.Max( p=>p.difficultyLevel );
					G6.stopped_StatusMessage = "";

					SolverList_GNPX.Sort( (p,q)=>(p.ID-q.ID) );
				}
			}
			catch(Exception e){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }
            return SolverList_GNPX;
		}


        public void WriteXMLFile_AnalysisConditions_MethodList( ){
            if( SolverList_GNPX==null || SolverList_GNPX.Count<=1 ) return;

			G6.Set_methodList( SolverList_GNPX );
			{ // ---- XML Write -----
				var currentDir = Directory.GetCurrentDirectory();
				var _pfName = Path.Combine(currentDir, SDK_Methods_XMLFileName);		

				using( StreamWriter wr = new StreamWriter(_pfName) ){
					G6.xmlSerializer.Serialize(wr, G6);
				}
			}
					WriteLine( $"===== WriteXMLFile_AnalysisConditions_MethodList() ... done " +  DateTime.Now.ToString("G") );
					WriteLine( $" path/file:{SDK_Methods_XMLFileName}" );

            bool B = G6.GeneralLogic_on;
			var QLst = SolverList_GNPX.FindAll(x=>x.MethodName.Contains("GeneralLogic"));
			QLst.ForEach( Q => Q.IsChecked=B );

			return;
        }


    }

}