﻿using System;
using System.Windows.Media;
using System.IO;
using System.Text.Json.Serialization;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using static System.Diagnostics.Debug;


//:::::::::::::::::::::::::::::::::::::
//	ver.7
//:::::::::::::::::::::::::::::::::::::


namespace GNPX_space{
	public class G7_Base{
		// ver.7 Features
		public int   SECode_A;
		public int   SECode_B;
		public int   SECode_succeed;
		public bool  HTML_output_on = true;
/*
		[XmlIgnore]  public List<UCell>  g7FinalState_TE;
		
		[XmlIgnore]  public List<UCell>  g7CurrentState; 
			//string st1 = string.Join("",pBOARD.ConvertAll(p=> Abs(p.No))).Replace("0","."). AddSpace9_81();

		[XmlIgnore]  public int[]		 g7_LSpattern = new int[10000];

		[XmlIgnore]  public bool		 g7MarkA0;					// ver.5.2- for Develop
		[XmlIgnore]  public bool		 g7Error;					// ver.5.2- for Develop
		[XmlIgnore]  public List<string> g7MarkA_MLst0 = null;	// ver.5.2- for Develop
*/


		// ===== Ver.7 Service =====================

		public string g7DirName = "../GNPX_ExecutionSpace/";

		[XmlIgnore]  public bool		 g7_GNPX_Solving = false;		// if canceled, then false.



		[XmlIgnore]  public List<UCell>  g7FinalState_TE;

		[XmlIgnore]  public List<UCell>  g7CurrentState; 
			//string st1 = string.Join("",pBOARD.ConvertAll(p=> Abs(p.No))).Replace("0","."). AddSpace9_81();

		[XmlIgnore]  public int[]		 g7_LSpattern = new int[10000];

		[XmlIgnore]  public bool		 g7MarkA0;					// ver.5.2- for Develop
		[XmlIgnore]  public bool		 g7Error;					// ver.5.2- for Develop

		[XmlIgnore]  public List<string> g7MarkA_MLst0 = null;		// ver.5.2- for Develop
		[XmlIgnore]  public int			 g7Max_Step;				// ver.5.2- for Develop
		[XmlIgnore]  public int          TandE_NumberOfPuzzleSolution = 0;
		[XmlIgnore]  public List<string> TandE_solList = null;
		[XmlIgnore]  public bool		 TandE_show_on_error = true;//false;
		[XmlIgnore]  public string		 g7IDName;					// ver.5.9-
		[XmlIgnore]  public UPuzzle		 g7_ePZL;

		[XmlIgnore]  public int			 g7_Develop_Exocet_difficulty;

		public G7_Base(){}
	}
}


