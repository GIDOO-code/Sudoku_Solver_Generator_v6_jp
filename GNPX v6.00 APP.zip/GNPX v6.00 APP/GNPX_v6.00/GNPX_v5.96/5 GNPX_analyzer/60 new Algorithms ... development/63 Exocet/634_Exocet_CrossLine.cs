﻿using GIDOO_space;
using GNPX_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Linq;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;



namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		// ... Generate CrossLine ...

		private int CrossLine_ToBit( (int,int,int,int,int) h012A ){
			int h012B = ( (h012A.Item1>=0)? (1<<h012A.Item1): 0 )
				      | ( (h012A.Item2>=0)? (1<<h012A.Item2): 0 )
				      | ( (h012A.Item3>=0)? (1<<h012A.Item3): 0 )
				      | ( (h012A.Item4>=0)? (1<<h012A.Item4): 0 )
				      | ( (h012A.Item5>=0)? (1<<h012A.Item5): 0 );

			return h012B;
		}



		private IEnumerable< (int,int,int,int,int) >  IE_Exocet_CrossLine( UExocetA Exo, bool debugPrint=false ){
			int  dir=Exo.dir, rcStem=Exo.rcStem, b0=rcStem.B();
			int  h0 = (dir==0)? (rcStem%9+9): rcStem/9;

			// Franken/Mutant, Complex
			if( Exo.ExoMtdName.Contains("FM") || Exo.ExoMtdName.Contains("_Complex") ){			
				foreach( var h012A in Generate_CrossLines_FM_Complex( Exo, debugPrint, dir, b0, h0) ){
					Exo.h012B = CrossLine_ToBit(Exo.h012A);
					if( Exo.ExoMtdName.Contains("FM") &&  !_Is_Exocet_FM(Exo.h012B) )  continue;
					yield return h012A;
				}
				yield break;

					bool _Is_Exocet_FM( int h012B ){
						int  row=h012B&0x1FF, col=(h012B>>9)&0x1FF, blk=(h012B>>18)&0x1FF;
						return ( (row>0 && col>0)  || blk>0 );
					}
			}

			// standard ... JE2, JE1, Exocet, Single, SingleBase
			else{  // standard
				foreach( var h012A in Generate_CrossLines_Standard( Exo, debugPrint, dir, b0, h0 ) ){	yield return h012A; }
				yield break;
			}

		}






	
		private IEnumerable< (int,int,int,int,int) > Generate_CrossLines_Standard( UExocetA Exo, bool debugPrint, int dir, int b0, int h0 ){
			
			// blockHouse : {r0,r1,r2}, {r3,r4,r5}, {r6,r7,r8},  {c0,c1,c2}, {c3,c4,c5}, {c6,c7,c8},  {b0,b1,b2}, {b3,b4,b5}, {b6,b7,b8}  
			int blockHouseB = (dir == 0) ? (0b111000 & ~(1 << (b0%3)+3)) : 0b111 & ~(1<<b0/3);
			List<int[]> hno_List = blockHouseB.IEGet_BtoNo(18).Where(p => p >= 0).ToList().ConvertAll(n => new int[] {n*3, n*3+1, n*3+2 });

			int[] h1X = hno_List[0], h2X = hno_List[1];
			foreach(int kx in Enumerable.Range(0, 3 * 3) ){
				int  h1 = h1X[kx/3];
				int  h2 = h2X[kx%3];
				Exo.h012A = (h0, h1=h1X[kx/3], h2=h2X[kx%3], -1, -1);
				Exo.h012B = CrossLine_ToBit( Exo.h012A );
						if(debugPrint) WriteLine( $" h012A : {Exo.h012A}  h012B : {Exo.h012B.ToBitString27rcb()}" );
				yield return Exo.h012A;
			}

		}

#if false

		// Planned integration  --> Generate_CrossLines_FM_Complex
		private IEnumerable< (int,int,int,int,int) > Generate_CrossLines_FM( UExocetA Exo, bool debugPrint, int dir, int b0, int h0 ){
			// ===== Franken/Mutant (v5.94-) =============== =============== =============== 
			// --- this code is triky, and excelent!  You can verify that it works as intended by setting "debagprint=true".
			//debugPrint=true;

			int  blockHouseB = 0xFF & ~(1<<(b0/3) | (1<<(b0%3+3)) );	// 0xFF(8bit) = rowBlock(3bit) / columnBlock(3bit) + Block(2bit)
					//blockHouseB = blockHouseB & 0x3F;				// $$$@@@ SE_Mutant is not confirmed. Changed to Franken only.
			int  b_Bit = 0x1FF & ~( (0b111<<(b0/3*3) | 0b1001001<<(b0%3)) );	// block

			int[]  hList = blockHouseB.IEGet_BtoNo(8).Where(p=> p>=0).ToArray();
			int[]  bList = (b_Bit<<18).IEGet_BtoNo(27).Where(p=> p>=0).ToArray();
					if(debugPrint){
						WriteLine( $" rcStem:{Exo.rcStem}  b0:{b0}" );
						WriteLine( $" blockHouseB:{blockHouseB.ToBitString(18,withDot:true)}  b_Bit:{b_Bit.ToBitString(27,withDot:true)}" ); 
						WriteLine( $" hList {string.Join(",",hList)}" );
						WriteLine( $" bList {string.Join(",",bList)}\n" );
					}

			UInt128 BOARD_Free81_no = Exo.FreeB.IEGet_BtoNo().Aggregate(qZero,(A,no)=> A| BOARD_FreeOrFixed81B9[no] );

			Combination cmb = new(hList.Count(),2);
			int nxt=999;
			while( cmb.Successor(skip:nxt) ){
				int n1=hList[cmb.Index[0]], n2=hList[cmb.Index[1]];
				if( n1>=6 && n2>=6 )  continue;			// // $$$@@@ Combination of two HouseBlocks is excluded.

				int   n1p = (n1>=3 && n1<=5)? 0: 0;
				int   n2p = (n2>=3 && n2<=5)? 0: 0;

				int[] h1X = (n1<=5)? (new int[]{n1*3+n1p,n1*3+1+n1p,n1*3+2+n1p}): bList;
				int[] h2X = (n2<=5)? (new int[]{n2*3+n2p,n2*3+1+n2p,n2*3+2+n2p}): bList;
					if(debugPrint)  WriteLine( $"h1X h2X  {n1}-{n2}   {string.Join(",",h1X)}    {string.Join(",",h2X)}" );

				int sz1=h1X.Length, sz2=h2X.Length;
				for( int h1n=0; h1n<sz1; h1n++){
					int h1fm=h1X[h1n];
					for( int h2n=0; h2n<sz2; h2n++ ){
						int h2fm=h2X[h2n];
					//	if( (BOARD_Free81 & (House_81[h1fm] & House_81[h2fm])) != qZero ) continue;
					//	if( (BOARD_Free81 & ((House_81[h1fm] | House_81[h2fm]) & House_81[h0])) != qZero ) continue;
						if( (BOARD_Free81_no & (House_81[h1fm] & House_81[h2fm])) != qZero ) continue;
						if( (BOARD_Free81_no & ((House_81[h1fm] | House_81[h2fm]) & House_81[h0])) != qZero ) continue;

						Exo.h012A = (h0, h1fm, h2fm, -1, -1 );
						Exo.h012B = CrossLine_ToBit( Exo.h012A );
							if(debugPrint) WriteLine( $" h012A : {Exo.h012A}  h012B : {Exo.h012B.ToBitString27rcb()}" );
						yield return  Exo.h012A;
					}
				}
			}
		}
#endif


		private IEnumerable< (int,int,int,int,int) > Generate_CrossLines_FM_Complex( UExocetA Exo, bool debugPrint, int dir, int b0, int h0 ){
			// ------------ (0) function parameter------------

			// --- this code is triky, and excelent!  You can verify that it works as intended by setting "debagprint=true".
			//debugPrint=true;

			int  blockHouseB = 0xFF & ~(1<<(b0/3) | (1<<(b0%3+3)) );	// 0xFF(8bit) = rowBlock(3bit) / columnBlock(3bit) + Block(2bit)
					//blockHouseB = blockHouseB & 0x3F;				// $$$@@@ SE_Mutant is not confirmed. Changed to Franken only.
			int  b_Bit = 0x1FF & ~( (0b111<<(b0/3*3) | 0b1001001<<(b0%3)) );	// block

			int[]  hList = blockHouseB.IEGet_BtoNo(8).Where(p=> p>=0).ToArray();
			int[]  bList = (b_Bit<<18).IEGet_BtoNo(27).Where(p=> p>=0).ToArray();
					if(debugPrint){
						WriteLine( $" rcStem:{Exo.rcStem}  b0:{b0}" );
						WriteLine( $" blockHouseB:{blockHouseB.ToBitString(18,withDot:true)}  b_Bit:{b_Bit.ToBitString(27,withDot:true)}" ); 
						WriteLine( $" hList {string.Join(",",hList)}" );
						WriteLine( $" bList {string.Join(",",bList)}\n" );
					}

			UInt128 BOARD_Free81_no = Exo.FreeB.IEGet_BtoNo().Aggregate(qZero,(A,no)=> A| BOARD_FreeOrFixed81B9[no] );

			Combination cmb = new(hList.Count(),2);
			int nxt=999;
			while( cmb.Successor(skip:nxt) ){
				int n1=hList[cmb.Index[0]], n2=hList[cmb.Index[1]];
				if( n1>=6 && n2>=6 )  continue;			// // $$$@@@ Combination of two HouseBlocks is excluded.

				int   n1p = (n1>=3 && n1<=5)? 0: 0;
				int   n2p = (n2>=3 && n2<=5)? 0: 0;

				int[] h1X = (n1<=5)? (new int[]{n1*3+n1p,n1*3+1+n1p,n1*3+2+n1p}): bList;
				int[] h2X = (n2<=5)? (new int[]{n2*3+n2p,n2*3+1+n2p,n2*3+2+n2p}): bList;
					if(debugPrint)  WriteLine( $"h1X h2X  {n1}-{n2}   {string.Join(",",h1X)}    {string.Join(",",h2X)}" );

				int sz1=h1X.Length, sz2=h2X.Length, usedH;;
				for( int h1n=0; h1n<sz1; h1n++){
					int h1fm=h1X[h1n];	// ------------ (1) ------------

					for( int h2n=0; h2n<sz2; h2n++ ){
						int h2fm=h2X[h2n];  // ------------ (2) ------------

						if( (BOARD_Free81_no & (House_81[h1fm] & House_81[h2fm])) != qZero ) continue;
						if( (BOARD_Free81_no & ((House_81[h1fm] | House_81[h2fm]) & House_81[h0])) != qZero ) continue;

						Exo.h012A = (h0, h1fm, h2fm, -1, -1 );
						Exo.h012B = CrossLine_ToBit( Exo.h012A );
							if(debugPrint) WriteLine( $" h012A : {Exo.h012A}  h012B : {Exo.h012B.ToBitString27rcb()}" );
						if( Exo.ExoMtdName.Contains("FM" ) )  yield return  Exo.h012A;


						// =========== Complex ===========
						usedH = (1<<h0) | (1<<h1fm) | (1<<h2fm);				Exo.h012B = CrossLine_ToBit( Exo.h012A );
						if( Exo.ExoMtdName.Contains("Complex") ){  // --- Complex ---
							// -------------- (Hypothesis) --------------
							if( h1fm>=18 || h2fm>=18 )  continue;   // [Hypothesis] In Complex, block_CrossLine does not hold.
							// ------------------------------------------

							foreach( int n3 in hList ){
								int   n3p = (n3>=3 && n3<=5)? 0: 0;
								int[] h3X = (n3<=5)? (new int[]{n3*3+n3p,n3*3+1+n3p,n3*3+2+n3p}): bList;
								int sz3=h3X.Length;
								for( int h3n=0; h3n<sz3; h3n++){
									int h3fm = h3X[h3n];	// ------------ (3) ------------

									// -------------- (Hypothesis) --------------
									if( h3fm>=18 )  continue;   // [Hypothesis] In Complex, block_CrossLine does not hold.
									// ------------------------------------------

									if( (usedH & (1<<h3fm)) !=0 )  continue;
									Exo.h012A = (h0, h1fm, h2fm, h3fm, -1 );

									_Get_CrossLine_Overlap(Exo);

									yield return Exo.h012A;
								}
							}
						}
					}
				}
					void _Get_CrossLine_Overlap( UExocetA Exo ){				
						UInt128  CrossLine_Overlap = qZero;
						if( Exo.ExoMtdName!="Exocet_FM" && Exo.ExoMtdName!="Exocet_Complex" )  return;

						var (h0,h1,h2,h3,h4) = Exo.h012A;
						List<int> hList = new(){h0,h1,h2,h3,h4};
						int nc = hList.Count(p=>p>=0);
						Combination cmb = new(nc,2);
						while( cmb.Successor() ){
							CrossLine_Overlap |= House_81[ hList[cmb.Index[0]] ] & House_81[ hList[cmb.Index[1]] ];
						}
						Exo.CrossLine_Overlap = CrossLine_Overlap;

							if(debugPrint)	G6_SF.__MatrixPrint( Flag:_BaseObj_, CrossLine_Overlap, "CrossLine_Overlap" );
						return;
					}
					
			}
		}

	}
}