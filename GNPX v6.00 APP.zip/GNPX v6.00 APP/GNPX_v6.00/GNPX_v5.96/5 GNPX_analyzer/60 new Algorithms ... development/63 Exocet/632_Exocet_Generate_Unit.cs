using GIDOO_space;
using GNPX_space;
using System;
using System.Diagnostics;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);


    public partial class Exocet_TechGen: AnalyzerBaseV2{
		public  UInt128 Board81_Free_with_FreeB;
		private UInt128	Board81_Fixed_with_FreeB;
		private UInt128	Board81_Fixed_with_nonFreeB;
		//private UInt128 Board81_FreeFix_noB;

		// ..6.59....9.....2...8.4.3.56..1.5...1.5...2.7...2.4..12.7.9.5...5.....4....51.9..

		private IEnumerable<UExocetA>  IE_Exocet_Generate_Unit( string ExoMtdName, bool debugPrint=false ){

			// ::: #1 Basic Form :::::::::::::::::::::::::::::::::::::
			foreach( UExocetA Exo in IE_Exocet_BasicForm( ExoMtdName:ExoMtdName, debugPrint:false) ){	
				_BaseObj_ = Exo.Base81;	//( for debug. ... G6_SF.__MatrixPrint(...) )
						//if( Exo.dir!=1 || Exo.rcStem!=40 )  continue;	// ===== Exocet Debug =====

					{// BOARD Digits distribution ... Exocet constants used in analysis
						Board81_Fixed_with_FreeB    = BOARD_FixedB9_noB(Exo.FreeB);				  // Cells with confirmed Base candidate digits.
						Board81_Fixed_with_nonFreeB = BOARD_Fixed81 & ~Board81_Fixed_with_FreeB;  // Cells with confirmed non-Base candidate digits.
						Board81_Free_with_FreeB     = BOARD_FreeB9_noB( Exo.FreeB );			  // Freecell with Base candidate digits.
								if(debugPrint) G6_SF.__MatrixPrint( Flag:Exo.Base81, Board81_Fixed_with_FreeB, Board81_Fixed_with_nonFreeB, Board81_Free_with_FreeB,
												"Board81_Fixed_with_FreeB, Board81_Fixed_with_nonFreeB, Board81_Free_with_FreeB" );
					}

				// ::: #2 Cross-Line House numbers  :::::::::::::::::::::::::::::::::::::
					// [Att] The house number that defines the shape of the Exocet.
					//		 In the case of the Senior Exocet, this may differ from the Cross-Line's House depending on the Object definition.
				foreach( (int,int,int,int,int)  h012A in IE_Exocet_CrossLine( Exo, debugPrint:debugPrint) ){	
						//if(debugPrint) WriteLine( $"-- h012A:{h012A}" );
						//if( h012A != (04,00,26,-1,-1))  continue; // ===== Exocet Debug =====

					// ::: #3 Objects :::::::::::::::::::::::::::::::::::::
					foreach( var (ExG0,ExG1,ExG2) in IE_Exocet_Object( Exo, debugPrint:false) ){
						Exo.ExG0=ExG0; Exo.ExG1=ExG1; Exo.ExG2=ExG2;
						_BaseObj_ = Exo.Base81 | (ExG1.Object81 | ExG2.Object81 );	//( for debug. ... G6_SF.__MatrixPrint(...) )
								//if( ExG1.Object81 != (qOne<<03 ) )  continue; // ===== Exocet Debug =====
								//if( ExG2.Object81 != (qOne<<79 ) )  continue; // ===== Exocet Debug =====
											//if( ExG1.Object81 != (qOne<<16 | qOne<<16) )  continue; // ===== Exocet Debug =====  JE2++
											//if( ExG2.Object81 != (qOne<<60 | qOne<<60) )  continue; // ===== Exocet Debug =====  JE2++

						var (h0, h1, h2, h3, h4) = Exo.h012A; // h012A is (h0,h1,h2,-1,-1) for Exocet_JE2P and (h0,h1,h2,h3,h4) for Exocet_FM.
						UInt128 CL0 = ExG0.CrossLine;
						UInt128 CL1 = ExG1.CrossLine;
						UInt128 CL2 = ExG2.CrossLine;
						UInt128 CL3 = (h3>=0)? House_81[h3]: qZero;
						UInt128 CL4 = (h4>=0)? House_81[h4]: qZero;	
						Exo.CL012A = (CL0, CL1, CL2, CL3, CL4);

						// ::: #4 Companion, SLine :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
						if( Set_Companion_and_Test(Exo, debugPrint:debugPrint) is false )  continue;	//###1022

						Set_Mirror(Exo, debugPrint:false);	
						if( Set_SLine_and_Test( Exo, debugPrint:false) is false )  continue;

						yield return Exo;
					}
				}
			}		
			yield break;

			// ====================

					void Set_Mirror( UExocetA Exo, bool debugPrint=false ){
						if( Exo.ExG0.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG1, Exo.ExG2 );
						if( Exo.ExG1.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG2, Exo.ExG0 );
						if( Exo.ExG2.Object81 == _na_ )  Set_Mirror_sub(Exo, Exo.ExG0, Exo.ExG1 );

						void Set_Mirror_sub( UExocetA Exo, UCrossLine ExGA, UCrossLine ExGB ){
							ExGA.Mirror81 = House_81[ExGB.ObjectBlockNo+18] & ~(Exo.Escape81 | Exo.CrossLine_012);
							if( ExGA.Object81.BitCount()==1 )  ExGA.Mirror81 &= ~House_81[(Exo.dir,ExGA.rcTarget).DirRCtoHouse()];

							ExGB.Mirror81 = House_81[ExGA.ObjectBlockNo+18] & ~(Exo.Escape81 | Exo.CrossLine_012);
							if( ExGB.Object81.BitCount()==1 )  ExGB.Mirror81 &= ~House_81[(Exo.dir,ExGB.rcTarget).DirRCtoHouse()];

								if(debugPrint){
									G6_SF.__MatrixPrint( Flag:_BaseObj_, ExGA.Object81, ExGA.Mirror81, "ExGA.Object81, ExGA.Mirror81" );
									G6_SF.__MatrixPrint( Flag:_BaseObj_, ExGB.Object81, ExGB.Mirror81, "ExGB.Object81, ExGB.Mirror81" );
								}
						}
					}
		}
	}
}