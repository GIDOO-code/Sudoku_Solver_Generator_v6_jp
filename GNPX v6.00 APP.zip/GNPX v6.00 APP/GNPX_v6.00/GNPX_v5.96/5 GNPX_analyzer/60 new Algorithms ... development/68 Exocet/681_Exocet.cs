using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Xml.Linq;
using static GNPX_space.Exocet_TechGen_68;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@

	// Important note
	//  Code based on flawed logic can still lead to correct results.
	//  Correctness of the output does not necessarily imply correctness of the logic.
	//  If the result is wrong, the logic(code) is also wrong.
	//
	// In GNPX(v6-), the solution to the puzzle is found through T&E.
	//  Any incorrect output is detected immediately.
	//
	//  The code for T&E is "TrialAndErrorApp(...) in GNPX".
	//    public bool TrialAndErrorApp( List<int> iBoard, bool filePutB, int upperLimit=2 )
	//
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	using G6_SF = G6_staticFunctions;
	//	using TapleUCL = (UCrossLine68,UCrossLine68,UCrossLine68);
	using pRes = Properties.Resources;

    public partial class Exocet_TechGen_68: AnalyzerBaseV2{
	//	static public PrimitiveContainer UPC = new PrimitiveContainer();


	// *** Junior Exocet is discontinued. Unified with Exocet. ***

		public bool Junior_Exocet_JE2( ) => Exocet_General( ExoControl:"name:JE2" );
		public bool Junior_Exocet_JE1( ) => Exocet_General( ExoControl:"name:JE1" );

		public bool Exocet()			 => Exocet_General( ExoControl:"name:SE" );				// (Including JE2)
		public bool Exocet_Single()	     => Exocet_General( ExoControl:"name:SE type:Single" );	// (Including JE1)
		public bool Exocet_SingleBase()  => Exocet_General( ExoControl:"name:SE type:SingleBase" );

		//public bool Exocet_FM()		    => Exocet_General( ExoControl:"name:SE type:FM" ); 

		private List<int>	SimpleUniqueSolutions_List;
//		public bool Exocet_Complex()    => Exocet_General( ExoControl:"name:SE type:Complex"  );       // Future development challenges. (ver. 6++)


/*
		// http://forum.enjoysudoku.com/mutant-exocet-t39245.html
		// Mutant Exocet
		             12                                                12
   +------------------------+------------------------+------------------------+
   | 679     24      3      | 69      1       468    | 78      269     5      |
   | 1569    8       24     | 7       4569    3456   | 2369   T12369   1269   | 12
   | 15679   16      1579   | 3569    2       3568   | 4       1369    78     |
   +------------------------+------------------------+------------------------+
   | 35678   346     4578   | 23569   5689    23567  | 1       2469    24679  |
   | 13567   9       157    | 4       56     T123567 | 2567    8       267    | 123
   | 2       146     14578  | 1569    5689    1567   | 5679    469     3      |
   +------------------------+------------------------+------------------------+
   | 4       7       6      | 12      3       12     | 89      5       89     |
   |B13      5      B12     | 8       7       9      | 236     12346   1246   |
   | 89      123     89     | 56      456     456    | 23      7       12     |
   +------------------------+------------------------+------------------------+
   ..3.1...5.8.7.........2.4........1...9.4...8.2.......34.6....5..5.879..........7.
   */



        public bool Exocet_General( string ExoControl ){

			// ::: Prepare :::
			if( stageNoP != stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
				Prepare_Exocet_TechGen_68( printB:false );	//debugPrint );
			
				UCoverStatus.pBOARD_Fixed81B9 = base.BOARD_Fixed81B9;
				UCoverStatus.pBOARD_Free81B9  = base.BOARD_Free81B9;
				
				SimpleUniqueSolutions_List = new();	// Prioritize simple solutions and eliminate redundant solutions.
			}


			ElementElimination_Manager_UT("Initialize");	
			foreach( var Exo in IE_Exocet_Generate_Unit(ExoControl) ){

				// ::: SLine Is covered? :::
				if( SLine_Covering_635A(Exo,debugPrint:false) is false )  continue;

				if( Check_SLine_Condition_635B(Exo) is false ) continue;


				// :::::: Check rule ::::::
				bool solFound = Exo_Exclude_Test( Exo );
				//WriteLine( $"stBase:{Exo.stBase}  ExG1.stObject:{Exo.ExG1.stObject}  ExG2.stObject:{Exo.ExG2.stObject}" );


				// :::::: Reporting the results ::::::
				if( solFound ){
					SimpleUniqueSolutions_List.Add(Exo.hashValue_stBaseObject12);	// Prioritize simple solutions and eliminate redundant solutions.

					Exocet_Result( Exo, debugPrint:false );	// ::: Results report
					if( !pAnMan.IsContinueAnalysis() )  return true;

					// :::::: Final processing ::::::
					foreach( var UC in pBOARD.Where(p=>p.No==0) ) UC.CancelB=0;
					pBOARD.ForEach( UC => UC.ECrLst=null );
					ElementElimination_Manager_UT("Initialize");
				}

			}
			return false;			
		}






		private void Exocet_Result( UExocet Exo, bool debugPrint ){
			string  ExoMtdName=Exo.ExoMtdName, ExocetNamePlus=Exo.ExocetNamePlus;

			UCrossLine68 ExG1=Exo.ExG1, ExG2=Exo.ExG2;
			var		 (rcBase1,rcBase2) = Exo.Base81.Get_rc1_rc2();
			
			int FreeB = Exo.FreeB;
			UInt128	 SLine1=ExG1.SLine, SLine2=ExG2.SLine;

			// <<<<< Result ...  coloring, create message  >>>>>
			try{
				SolCode = 2;
				pBOARD.ForEach( UC => UC.ECrLst=null ); 

			  // ::: Base
				Exo.Base81.IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr );	

				Color cr = SolBkCr2G;
				if( (ExoMtdName.Contains("JE1") || Exo.ExocetNamePlus.Contains("_Single")) && Exo.ExG1.wildcardB && ExG1.Object81 !=_na_){
					Exo.ExG1.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
				}

//				if( ExocetNamePlus.Contains("SE_SingleBase") ){
//					if( Exo.ExG1.phantomObjectB ) Exo.ExG1.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
//					if( Exo.ExG2.phantomObjectB ) Exo.ExG2.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
//				}

				Exo.ExG1.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
				Exo.ExG2.Object81.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 

				if(Exo.Companion!=_na_) Exo.Companion.IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr2A );

			// ::: SLine
				if( Exo.SLineList.Count()>3 )  Exo.SLineList[3].IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr3A );	
				Exo.SLineList[0].IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr4 );
				Exo.SLineList[1].IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr3 );
				Exo.SLineList[2].IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr3 );

			// ::: Report
				string stBase  = $"B:{Exo.Base81.TBScmp()}#{FreeB.ToBitStringN(9)} Companion:{Exo.stCompanions}";
				string stObjL1 = $"T1:{ExG1.stObject}";
				string stObjL2 = $"T2:{ExG2.stObject}";
				
				string stBaseL  = $"   Base: {Exo.Base81.TBScmp()}#{FreeB.ToBitStringN(9)}";
				string stObjL1L = $"Object1: {ExG1.stObject}";
				string stObjL2L = $"Object2: {ExG2.stObject}";

				string stWildcard = (Exo.WildCardB!=0)? $"Wildcard: #{Exo.WildCardB.ToBitStringN(9)}": "";
				string stSLine  = $"   SLine: {Exo.st_SLine_House()}";

				string stExocetP = (Exo.ExoType=="")? ExocetNamePlus: $"{ExoMtdName}_{Exo.ExoType}";
				Result     = $"��{stExocetP} {stBase} T1:{ExG1.stObject} T2:{ExG2.stObject}";
				
				string stL = $"{stBaseL}\n   {stObjL1L}\n   {stObjL2L}\n  {stSLine}\n   Companion:{Exo.stCompanions}";
				ResultLong = ($"Exocet_{stExocetP}\n   {stL}").Replace("FM","Franken/Mutant");

			  //extResult  = $"Senior Exocet_{stExocetP}\n  @dir:{Exo.dir}  @Stem:{Exo.rcStem.ToRCString()}\n\n   {stL}";
				extResult  = $"Exocet_{stExocetP}\n (dir:{Exo.dir} Stem:{Exo.rcStem.ToRCString()}\n\n   {stL}";
				extResult  = extResult.Replace("FM","Franken/Mutant");
				
				if( Exo.ExoMtdName.Contains("JE1") || Exo.ExocetNamePlus.Contains("_Single") ){
					ResultLong += $"\n   {stWildcard}";
					extResult  += $"\n   {stWildcard}";
				}

				extResult += $"\n\n CoverLines (p:Parallel x:Cross){Exo.stCoverLines}";
				//extResult += $"\n {Exo.stCrossCoverLineB}";

				extResult += $"\n\n{new string('-',80)}\n Explanation of candidate digits exclusion\n";
				
				string stE = string.Join( "\n", extResultLst );
					int n1=stE.Length, n2;
					do{
						stE = stE.Replace("@\n@","@");
						if( n1==(n2=stE.Length) ) break;
						n1 = n2;
					}while(true);
				extResult += stE.Replace("+\n","+").Replace("@","\n").Replace("\n\n","\n").Replace("\n","\n  ");
					if(debugPrint)  WriteLine( "@@"+extResult );

				if( G7.HTML_output_on )  HTML_output_on( Exo );
			}
			catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }

			return;		
		}

		private void HTML_output_on( UExocet Exo ){
			


		}

		private void Get_BOARD_BitMap(){
		            BitmapEncoder enc = new PngBitmapEncoder(); // JpegBitmapEncoder(); BmpBitmapEncoder();
			bool G6_sNoAssist = G6.sNoAssist;
			bool G6_sWhiteBack = G6.sWhiteBack;
			G6.sNoAssist  = true;
			G6.sWhiteBack = false;

			RenderTargetBitmap  bmpGZeroA = new ( 338, 338, 96,96, PixelFormats.Default );
			var bmp = pGNPX_App.gnpxGrp.GBoardPaint( bmpGZeroA, pBOARD,  sNoAssist:G6.sNoAssist, whiteBack:G6.sWhiteBack );
            var bmf = BitmapFrame.Create(bmp);
							//enc.Frames.Add(bmf);
							//try {
							//	Clipboard.SetData(DataFormats.Bitmap,bmf);
							//}
							//catch(System.Runtime.InteropServices.COMException){  }

            if( !Directory.Exists( pRes.folder_GNPX_HTML_image) ){ Directory.CreateDirectory(pRes.folder_GNPX_HTML_image); }																					  
            string fName = DateTime.Now.ToString("yyyyMMdd_HHmmss")+".png";
            using( Stream stream = File.Create(pRes.fldSuDoKuImages+"/"+fName) ){
                enc.Save(stream);
            }    
							//texb_bitmapPath.Text = "Path : "+ioPath.GetFullPath( pRes.fldSuDoKuImages+"/"+fName);
		}
	}
}