using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPX_space {
	// ==========================================================================
	//   ULogical_Node : he implementation of basic elements was changed and integrated.
	// ==========================================================================



    public partial class ULogical_Node: IComparable{   // Logical Unit Element
		public int       ID=0;
		
		public int       hno;       // House(0-26) digit(27-35)

		public UInt128   b081;		// 81 bit
		public int       noB9;		//  9 bit
		public int       pmCnd;		//  1 bit
		public int       lkType;
		public ULogical_Node preULN;
	// -------------------------------------------------------------
        public int       rc			=> b081.BitToNum(sz:81);					// rc for 1-cell case, -1 otherwise
		public int       no			=> noB9.BitToNum(sz:9);             // no for 1 digit case.

		public int	     rcbFrame	=> b081.Ceate_rcbFrameOr();			// (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9); }
		public long      rcbnFrame	=> ((long)rcbFrame)<<9 | (long)noB9;

        public int       b081Size	=> b081.BitCount();

		public UInt128   matchKey2  => b081 | ((UInt128)no)<<81;				//b081, no
		public UInt128   matchKey3  => b081 | ((UInt128)(no | pmCnd<<9))<<81;	//b081, no, pmCnd
        public string    TFmark		=> (pmCnd==1)? "+": "-";

		public bool      markTmp;
		// =============================================================

		static ULogical_Node(){ }  // static

        public ULogical_Node( int noB9, UInt128 b081, int lkType=0, int pmCnd=0, int ID=0 ){	// house link
 			this.noB9 = noB9;  	
			this.b081 = b081;

			this.lkType = lkType;
			this.pmCnd  = pmCnd;
			this.ID = ID;
			
			this.hno  = ID;  // and no;
		}
		public ULogical_Node( int no, int rc, int pmCnd, int ID=0 ){							// cell link
			this.noB9  = 1<<no;
			this.b081  = UInt128.One<<rc;
			this.lkType = 2;
			this.pmCnd = pmCnd;
			this.ID    = ID;

			this.hno   = 99;  // and rc
        }
		// --------------------------------------------------------------------------


	  #region CompareTo HashCode
		public int CompareTo( object obj ){		// @@@ eNetwork �ŗp���Ă���BGeneralLogic�ł͎g���Ă��Ȃ�
            var Xobj = obj as ULogical_Node;
            if( Xobj is null  )  return -1;
            var dif = this.matchKey3-Xobj.matchKey3;
            int ret = (dif<0)? -1: (dif>0)? 1: 0;
            return ret;
        }

		public int CompareToA( ULogical_Node B ){	// @@@ GeneralLogic�Ŏg���Ă���B
            var Xobj = B as ULogical_Node;
            if( Xobj is null  )  return -1;
			if( this.noB9 !=B.noB9 )  return (this.noB9-B.noB9);
            if( this.b081 == B.b081 ) return 0;
            return (this.b081<B.b081)? -1: +1;
        }

        public override int GetHashCode(){
			//UInt128  essentialULG4 = ((UInt128)pmCnd<<90) | ((UInt128)noB9<<81) | b081;
			UInt128  essentialULG4 = ((UInt128)pmCnd<<90) | matchKey2;
            int hashValue = essentialULG4.GetHashCode();  // <-- (b081,no,pmCnd)
            return hashValue;
        }
	  #endregion CompareTo HashCode

	  #region ToString()
		public override string ToString(){
			string st1 = $"lkType-h:{lkType}-{hno,2}  " + ((lkType==1)? "_rcb": "_noB");
			string st2 = $"{b081.TBScmp().PadRight(12)}#{noB9.TBScmp().PadRight(8)}" ;
			string st = $"ID:{ID,3} {st1}   {st2}  ___  {rcbnFrame.TBS36cmp()}" ;
            return st;
        }

		public string GL_ToString(){
			string st =$"{hno.HouseToString()}#{noB9.TBScmp()} ";
			return st.Trim();
		}

		public string ToString_SameHouseComp(){
            string st = $"{ToRCBString().ToString_SameHouseComp()}";
            return st.Trim();
        }

        public string ToRCBString(){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( b081 >> (n*27) );
                for(int k=0; k<27; k++){
                    if((bp&(1<<k))==0)  continue;
                    int rc=n*27+k;
                    st += $" {rc.ToRCString()}";
                }
            }
            return st.Trim();
        }

		public string HouseToString(){
			string st="";
			if( lkType==2 )	st = b081.FindFirst_rc().ToRCString();	//cell
			st += "#" + noB9.ToBitStringN(9);
			return st;
		}

		public string House_no_ToString( ){
			string noSt = "#"+ ((no>=0)? (no+1).ToString(): " ");
            string st="";
            if(hno<0 || hno>26)   st += "---";
            if(hno>=0 && hno<9)   st += "r"+(hno+1)+noSt;
            if(hno>=9 && hno<18)  st += "c"+(hno-9+1)+noSt;
            if(hno>=18)           st += "b"+(hno-18+1)+noSt;
            return st.Trim();
        }
	  #endregion ToString()
    }

}
