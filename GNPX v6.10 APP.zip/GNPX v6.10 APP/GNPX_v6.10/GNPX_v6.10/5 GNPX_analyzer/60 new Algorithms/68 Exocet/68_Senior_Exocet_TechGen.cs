using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;

using GIDOO_space;

namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6) ...  Not very elegant. Needs some code cleanup.
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;

    public partial class Exocet_TechGen_68: AnalyzerBaseV2{

		static private readonly string  spX		= new string(' ',10); 
		static private readonly string  sp5		= new string(' ',5); 
		static private UInt128[] House_81 => House_81;
		static private UInt128[] CN81 => Connected_81;

		private UInt128		  BOARD_Fixed81;		// Bit representation of Fixed cells on the board	

		private int			  stageNoPMemo = -9;
		private List<string>  extResultLst = new();

		private UInt128		  _BaseObj_;			// Used for debugging function (G6_SF.__MatrixPrint)


		public  Exocet_TechGen_68( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }

		public void Prepare_Exocet_TechGen_68(bool printB ){
            bool lkExtB = G6.UCellLinkExt;
			BOARD_Fixed81			  = pBOARD.Where(p=>p.No!=0).Select(p=>p.rc).Aggregate(qZero, (a,b) => a| qOne<<b);
//			BOARD_Free81			  = pBOARD.Create_Free_BitExp81();	// FreeCell Bit Representation		  

			G6_staticFunctions.pBOARD = base.pBOARD;
			UExocet.qBOARD			  = base.pBOARD;
			UCrossLine68.qBOARD		  = base.pBOARD;
		}
	}
}