using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Xml.Linq;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	using G6_SF = G6_staticFunctions;
	using pRes = Properties.Resources;

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		static private G6_Base	G6 => GNPX_App_Man.G6;
		public bool Exocet_JE2( )		=> Exocet_General( ExoMtdName:"Exocet_JE2" );

		public bool Exocet_JE1( )		=> Exocet_General( ExoMtdName:"Exocet_JE1" );

	// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
		public bool Exocet_JE2P( )		=> Exocet_General( ExoMtdName:"Exocet_JE2P" );		// JE2+, JE2++ 
	//		The logic behind JE2+ is still unclear.
	// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


		public bool Exocet()			=> Exocet_General( ExoMtdName:"Exocet" );			// (Including JE2)
		public bool Exocet_Single()	    => Exocet_General( ExoMtdName:"Exocet_Single" );	// (Including JE1)
		public bool Exocet_SingleBase() => Exocet_General( ExoMtdName:"Exocet_SingleBase" );


		public bool Exocet_FM()		    => Exocet_General( ExoMtdName:"Exocet_FM" );		// using CrossLine of FM type.  (FM:Franken Mutant)
		public bool Exocet_FM_Single()	=> Exocet_General( ExoMtdName:"Exocet_FM_Single" );		// using CrossLine of FM type.  (FM:Franken Mutant)
		public bool Exocet_FM_SingleBase() => Exocet_General( ExoMtdName:"Exocet_FM_SingleBase" );		// using CrossLine of FM type.  (FM:Franken Mutant)




	// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	  //public bool Exocet_Complex()    => Exocet_General( ExoMtdName:"Exocet_Complex" ); // Under development and consideration
	// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


		private List<int>	SimpleUniqueSolutions_List;	//### Prioritize simple solutions and eliminate redundant solutions.
		public bool Mirror_using;

        public bool Exocet_General( string ExoMtdName ){
					//WriteLine( $"stageNoP - stageNoPMemo : {stageNoP} - {stageNoPMemo}  ExoMtdName:{ExoMtdName}" );

			// ::: Prepare :::
			if( stageNoP != stageNoPMemo ){ //Run once per stage, including the derivation algorithm.
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
				Prepare_Exocet_TechGen( printB:false );	//debugPrint );
							
				SimpleUniqueSolutions_List = new();	// If there is a simple algorithm for the same Puzzle, omit the complex algorithm solution.
			}


			foreach( var Exo in IE_Exocet_Generate_Unit(ExoMtdName,debugPrint:false) ){

				// ================================================================================
				// Prioritize simple solutions and eliminate redundant solutions.
				if( SimpleUniqueSolutions_List.Contains(Exo.hashValue_stBaseObject12) )  return  false; // ### Already solved with a simpler solution.			
				// ================================================================================

				// ::: SLine Is covered? :::
	    		if( SLine_Covering(Exo,debugPrint:false) is false )  continue;
				if( Check_SLine_Condition(Exo) is false ) continue;

				// :::::: Check rule ::::::
				Mirror_using = false;
				bool solFound = Exo_Exclude_Test( Exo );
				//WriteLine( $"stBase:{Exo.stBase}  ExG1.stObject:{Exo.ExG1.stObject}  ExG2.stObject:{Exo.ExG2.stObject}" );



				// :::::: Reporting the results ::::::
				if( solFound ){
					SimpleUniqueSolutions_List.Add(Exo.hashValue_stBaseObject12);	//### Prioritize simple solutions and eliminate redundant solutions.

					Exocet_Result( Exo, debugPrint:false );	// ::: Results report
					if( !pAnMan.IsContinueAnalysis() )  return true;

					// :::::: Final processing ::::::
					foreach( var UC in pBOARD.Where(p=>p.No!=0) ) UC.CancelB=0;
					pBOARD.ForEach( UC => UC.ECrLst=null );
					ElementElimination_Manager_UT("Initialize");
				}
			}
			return false;			
		}




		private void Exocet_Result( UExocetA Exo, bool debugPrint ){
			string  ExoMtdName=Exo.ExoMtdName;

			UCrossLine ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;
			var		 (rcBase1,rcBase2) = Exo.Base81.Get_rc1_rc2();
			
			int FreeB = Exo.FreeB;
			UInt128	 SLine1=ExG1.SLine, SLine2=ExG2.SLine;

			// <<<<< Result ...  coloring, create message  >>>>>
			try{
				SolCode = 2;
				pBOARD.ForEach( UC => UC.ECrLst=null ); 

			  // ::: Base
				Exo.Base81.IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr );	

//				Color cr = SolBkCr2G;
//				if( (ExoMtdName.Contains("JE1") || Exo.ExoMtdName.Contains("_Single")) && Exo.ExG1.wildcardB && ExG1.Object81 !=_na_){
//					Exo.ExG1.Object81.IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr2G ); 
//				}

				Exo.ExG1.Object81.IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr2G ); 
				Exo.ExG2.Object81.IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr2G ); 

				if(Exo.Companion!=_na_) Exo.Companion.IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr2A );

			// ::: SLine
				Exo.SLineList[0].IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr3 ); //, SolBkCr4 );
				Exo.SLineList[1].IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr3 );
				Exo.SLineList[2].IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr3 );
				if( Exo.SLineList.Count()>3 )  Exo.SLineList[3].IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr3A );	
				if( Exo.SLineList.Count()>4 )  Exo.SLineList[3].IE_SetNoBBgColorNSel( pBOARD, FreeB, AttCr, SolBkCr3A );	

/*
			// ::: Mirror
				if( Mirror_using ){
					Exo.ExG0.Mirror81.IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr7 ); 
					Exo.ExG1.Mirror81.IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr7 ); 
					Exo.ExG2.Mirror81.IE_SetNoBBgColor_All( pBOARD, FreeB, AttCr, SolBkCr7 );
				}
*/
		// ::: Report
				string stBase  = $"B:{Exo.Base81.TBScmp()}#{FreeB.ToBitStringN(9)} Companion: {Exo.stCompanion_cells}";
				string stObjL1 = $"T1:{ExG1.stObject}";
				string stObjL2 = $"T2:{ExG2.stObject}";
				
				string stBaseL  = $"   Base: {Exo.Base81.TBScmp()}#{FreeB.ToBitStringN(9)}";
				string stObjL1L = $"Object1: {ExG1.stObject}";
				string stObjL2L = $"Object2: {ExG2.stObject}";
				if( Mirror_using ){
					stObjL1L += $"  Mirror1: {ExG1.stMirror}";
					stObjL2L += $"  Mirror2: {ExG2.stMirror}";
				}

				string stWildcard = (Exo.wildcard_noB!=0)? $"Wildcard: #{Exo.wildcard_noB.ToBitStringN(9)}": "";
				string stSLine  = $"   SLine: {Exo.st_SLine_House()}";

#if DEBUG
				Result     = "** ";
#else
				Result     = "";
#endif
		//				if( G6.zPowerUser )	Result = "@ @ ";
		//#if DEBUG
		//				if( G6.zPowerUser && stSLine.Contains("b") ) Result = "�� �� ";  // develop. Search for "Mutant"
		//#endif

				Result += $"{ExoMtdName} {stBase} T1:{ExG1.stObject} T2:{ExG2.stObject}";
				
				string stL = $"{stBaseL}\n   {stObjL1L}\n   {stObjL2L}\n  {stSLine}\n   Companion: {Exo.stCompanion_cells}";
				ResultLong = ($"{ExoMtdName}\n   {stL}").Replace("FM","Franken/Mutant");

				extResult  = $"{ExoMtdName}\n (dir:{Exo.dir} Stem:{Exo.rcStem.ToRCString()})\n\n   {stL}";
				extResult  = extResult.Replace("FM","Franken/Mutant");
				
				if( Exo.ExoMtdName.Contains("JE1") || Exo.ExoMtdName.Contains("_Single") ){
					ResultLong += $"\n   {stWildcard}";
					extResult  += $"\n   {stWildcard}";
				}

				extResult += $"\n\nCoverLines (p:Parallel x:Cross){Exo.stCoverLines}";
				//extResult += $"\n {Exo.stCrossCoverLineB}";

				string g7HTML = extResult + "";
				foreach( var st in extResultLst ){ if( st.Contains("Rule") )  g7HTML += $"\n{st}"; }
				ePZL.g7HTML = g7HTML;		
				
				extResult += $"\n\n{new string('-',80)}\n Explanation of candidate digits exclusion\n";
				string stE = string.Join( "\n", extResultLst );
					int n1=stE.Length, n2;
					do{
						stE = stE.Replace("@\n@","@");
						if( n1==(n2=stE.Length) ) break;
						n1 = n2;
					}while(true);
				extResult += stE.Replace("+\n","+").Replace("@","\n").Replace("\n\n","\n").Replace("\n","\n  ");
				extResult = extResult.Replace("Exocet_Exocet_","Exocet_");
					if(debugPrint)  WriteLine( "@@"+extResult );
			}
			catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }

			return;		
		}



		private void HTML_output_on( UExocetA Exo ){	}


		private void Get_BOARD_BitMap(){
		    BitmapEncoder enc = new PngBitmapEncoder(); // JpegBitmapEncoder(); BmpBitmapEncoder();
			bool G6_sNoAssist = G6.sNoAssist;
			bool G6_sWhiteBack = G6.sWhiteBack;
			G6.sNoAssist  = true;
			G6.sWhiteBack = false;

			RenderTargetBitmap  bmpGZeroA = new ( 338, 338, 96,96, PixelFormats.Default );
			var bmp = pGNPX_App.gnpxGrp.GBoardPaint( bmpGZeroA, pBOARD,  sNoAssist:G6.sNoAssist, whiteBack:G6.sWhiteBack );
            var bmf = BitmapFrame.Create(bmp);
							//enc.Frames.Add(bmf);
							//try {
							//	Clipboard.SetData(DataFormats.Bitmap,bmf);
							//}
							//catch(System.Runtime.InteropServices.COMException){  }

            if( !Directory.Exists( pRes.folder_GNPX_HTML_image) ){ Directory.CreateDirectory(pRes.folder_GNPX_HTML_image); }																					  
            string fName = DateTime.Now.ToString("yyyyMMdd_HHmmss")+".png";
            using( Stream stream = File.Create(pRes.fldSuDoKuImages+"/"+fName) ){
                enc.Save(stream);
            }    
							//texb_bitmapPath.Text = "Path : "+ioPath.GetFullPath( pRes.fldSuDoKuImages+"/"+fName);
		}

	}
}