using GIDOO_space;
using GNPX_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Policy;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;

using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// Generate an object on each CrossLine

	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		

		private IEnumerable<TapleUCL> IE_Exocet_Object( UExocetA Exo, bool debugPrint=false ){
			var (h0,h1,h2,h3,h4) = Exo.h012A;
			Exo.ExG0=null; Exo.ExG1=null; Exo.ExG2=null;  
				// The target generation order is (h0-h1), (h0-h2), (h1-h2). Eliminate duplicate target generation.			

			//debugPrint = true;

			int		b0=Exo.rcStem.B();		
			UInt128 Limited_Junior = Exo.Band81 & ~Exo.Escape81;										// for JE1. JE2 ... Object is limited within the Band.
			UInt128 Limited_Senior = qMaxB81    & ~(House_81[b0+18] | Exo.Escape81 | Exo.Band81Cross);	// Object is located anywhere other than CrossBand.
				if(debugPrint) G6_SF.__MatrixPrint( Flag:Exo.Base81, Limited_Junior, Limited_Senior, "Limited_Junior, Limited_Senior" );

			switch(Exo.ExoMtdName){
				case "Exocet_JE2":
			    case "Exocet_JE2P":		// JE2+, JE2++ If JE2++ is possible, Not have a solution at this moment((v6.1).
					foreach( var EXG3 in IE_Generate_Object_Exocet( Exo, Limited_Junior) ){	yield return EXG3; _BaseObj_=Exo.Base81; }
					break;

				case "Exocet":
				case "Exocet_FM":
				case "Exocet_Complex":
					foreach( var EXG3 in IE_Generate_Object_Exocet( Exo, Limited_Senior) ){	yield return EXG3; _BaseObj_=Exo.Base81; }
					break;

			// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
				case "Exocet_JE1":
					foreach( var EXG3 in IE_Generate_Object_Single( Exo, Limited_Junior) ){	yield return EXG3; _BaseObj_=Exo.Base81; }
					break;

				case "Exocet_Single":
				case "Exocet_FM_Single":
					foreach( var EXG3 in IE_Generate_Object_Single( Exo, Limited_Senior) ){	yield return EXG3; _BaseObj_=Exo.Base81; }
					break;

				case "Exocet_SingleBase":
				case "Exocet_FM_SingleBase":
					foreach( var EXG3 in IE_Generate_Object_SingleBase( Exo, Limited_Senior) ){	yield return EXG3; _BaseObj_=Exo.Base81; }
					break;

				default:
					string stException = $"\n\n ExoMtdName : \"{Exo.ExoMtdName}\" "
									   + "... Next development. Next development. Next development. Next development.\n"
									   + Environment.StackTrace;
					WriteLine( $"\n\n {stException}" );
					throw new Exception( $"Operation Error. Exo.ExoMtdName : {Exo.ExoMtdName}");

			}
			yield break;
		}
		// ==================================================================================================================================

		private bool Object_BasicTest( UExocetA Exo, UCrossLine ExGM ){
			if( (ExGM.Object81 & BOARD_Free81) == qZero )  return true;
			int f = ExGM.Object81.Get_FreeB_or();
			return (f & Exo.FreeB).BitCount() >= 2;
		}


		private IEnumerable<TapleUCL> IE_Generate_Object_Exocet( UExocetA Exo, UInt128 LimitedArea, bool debugPrint=false ){
			var (h0,h1,h2,h3,h4) = Exo.h012A;

			UInt128  CL0=House_81[h0], CL1=House_81[h1], CL2=House_81[h2];
					if(debugPrint) G6_SF.__MatrixPrint( Flag:Exo.Base81, Exo.Band81, CL0, CL1, CL2, "Exo.Band81, CL0, CL1, CL2," );

			Exo.ExG0 = new( Exo, 0, h0 );

			foreach( UCrossLine ExG1 in IEGet_Object_on_CrossLine(Exo, sq:1, hno:h1, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){
				if( Object_BasicTest(Exo, ExG1) is false )  continue;
				if( (Exo.CrossLine_Overlap & ExG1.Object81) != qZero )  continue;   // No objects in overlapping cells of CrossLines

				foreach( UCrossLine ExG2 in IEGet_Object_on_CrossLine(Exo, sq:2, hno:h2, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){

					if( ExG1.ObjectBBlockNo == ExG2.ObjectBBlockNo )		continue;	// ExG1 and ExG2 cannot overlap in CrossLine area.
					if( (Exo.CrossLine_Overlap & ExG2.Object81) != qZero )  continue;   // No objects in overlapping cells of CrossLines
					if( Object_BasicTest(Exo, ExG2) is false )  continue;
				    if( Exo.ExoMtdName=="Exocet_JE2P" && (ExG1.Object81.BitCount()+ExG2.Object81.BitCount())<=2 )  continue;   // JE2 does not allow either target to be a single cell.

					if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL0, ExG1.Object81, ExG2.Object81, "Exo.Band81, CL0, UCL1.Object81(WC), UCL2.Object81" );
					yield return (Exo.ExG0,ExG1,ExG2);
				}
			}

			if( Exo.ExoMtdName == "Exocet" ){  // Search for cases where the target is on the CrossLine_b.
				UInt128 LimitedArea_h0 = House_81[h0] &~House_81[Exo.rcStem.B()+18];
				foreach( UCrossLine ExG0 in IEGet_Object_on_CrossLine(Exo, sq:0, hno:h0, LimitedArea_h0).Where(P=>(P.Object81 & ~LimitedArea_h0)== qZero) ){
					if( Object_BasicTest(Exo, ExG0) is false )  continue;
					foreach( UCrossLine ExG1 in IEGet_Object_on_CrossLine(Exo, sq:1, hno:h1, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){
						if( ExG0.ObjectBBlockNo == ExG1.ObjectBBlockNo )  continue; // ExG0 and ExG1 cannot be in the same block.
						if( (Exo.CrossLine_Overlap & ExG1.Object81) != qZero )  continue;   // No objects in overlapping cells of CrossLines
						if( Object_BasicTest(Exo, ExG1) is false )  continue;
						//debugPrint = true;
						if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL2, ExG0.Object81, ExG1.Object81, "Exo.Band81, CL2, ExG0.Object81, ExG1.Object811" );
						yield return (new UCrossLine(Exo,2,h2), ExG0,ExG1); 
					}

					foreach( UCrossLine ExG2 in IEGet_Object_on_CrossLine(Exo, sq:2, hno:h2, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){
						if( ExG0.ObjectBBlockNo == ExG2.ObjectBBlockNo )  continue; // ExG0 and ExG1 cannot be in the same block.
						if( (Exo.CrossLine_Overlap & ExG2.Object81) != qZero )  continue;   // No objects in overlapping cells of CrossLines
						if( Object_BasicTest(Exo, ExG2) is false )  continue;
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL1, ExG2.Object81, ExG0.Object81, "Exo.Band81, CL1, ExG2.Object81, ExG0.Object81" );
						yield return (new UCrossLine(Exo,1,h1), ExG2,ExG0);
					}
				}
			}

			yield break;
		}

		private IEnumerable<TapleUCL> IE_Generate_Object_Single( UExocetA Exo, UInt128 LimitedArea, bool debugPrint=false ){
			var (h0,h1,h2,h3,h4) = Exo.h012A;

			UInt128  CL0=House_81[h0], CL1=House_81[h1], CL2=House_81[h2];
					if(debugPrint) G6_SF.__MatrixPrint( Flag:Exo.Base81, Exo.Band81, CL0, CL1, CL2, "Exo.Band81, CL0, CL1, CL2," );

			foreach( UCrossLine ExG2 in IESet_Object_on_CrossLine_Fixed(Exo, sq:2, hno:h2, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){	
				if( Object_BasicTest(Exo, ExG2) is false )  continue;
				foreach( UCrossLine ExG1 in IEGet_Object_on_CrossLine(Exo, sq:1, hno:h1, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){
					if( Object_BasicTest(Exo, ExG1) is false )  continue;
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL0, ExG1.Object81, ExG2.Object81, "Exo.Band81, CL0, UCL1.Object81, UCL2.Object81(WC)" );		
					yield return (new UCrossLine(Exo,0,h0), ExG1,ExG2);
				}

				if( Exo.ExoMtdName == "Exocet_Single" ){	// not JE1
					foreach( UCrossLine ExG0 in IEGet_Object_on_CrossLine(Exo, sq:0, hno:h0, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){
						if( Object_BasicTest(Exo, ExG2) is false )  continue;
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL1, ExG0.Object81, ExG2.Object81, "Exo.Band81, CL1, UCL0.Object81, UCL2.Object81(WC)" );		
						yield return (new UCrossLine(Exo,1,h1), ExG2,ExG0);
					}
				}
			}

			foreach( UCrossLine ExG1 in IESet_Object_on_CrossLine_Fixed(Exo, sq:1, hno:h1, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){
				if( Object_BasicTest(Exo, ExG1) is false )  continue;
				foreach( UCrossLine ExG2 in IEGet_Object_on_CrossLine(Exo, sq:2, hno:h2, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){
					if( Object_BasicTest(Exo, ExG2) is false )  continue;
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL0, ExG1.Object81, ExG2.Object81, "Exo.Band81, CL0, UCL1.Object81(WC), UCL2.Object81" );
					yield return (new UCrossLine(Exo,0,h0), ExG1,ExG2);
				}
				if( Exo.ExoMtdName == "Exocet_Single" ){	// not JE1
					foreach( UCrossLine ExG0 in IEGet_Object_on_CrossLine(Exo, sq:0, hno:h0, LimitedArea).Where(P=>(P.Object81 & ~LimitedArea)== qZero) ){
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL2, ExG1.Object81, ExG0.Object81, "Exo.Band81, CL2, ExG1.Object81(WC), ExG0.Object81" );		
						yield return (new UCrossLine(Exo,2,h2), ExG0,ExG1);
					}
				}
			}

			yield break;
		}


		private IEnumerable<TapleUCL> IE_Generate_Object_SingleBase( UExocetA Exo, UInt128 LimitedArea, bool debugPrint=false ){
			var (h0,h1,h2,h3,h4) = Exo.h012A;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    

			UInt128  CL0=House_81[h0], CL1=House_81[h1], CL2=House_81[h2];
					if(debugPrint) G6_SF.__MatrixPrint( Flag:Exo.Base81, Exo.Band81, CL0, CL1, CL2, "Exo.Band81, CL0, CL1, CL2," );

			int FreeB = Exo.FreeB;		

			// Non-wildcard objects are single cells, and the object candidate contains the BaseDigits in its entirety.
			foreach( UCrossLine ExG2 in IESet_Object_on_CrossLine_Fixed(Exo, sq:2, hno:h2, LimitedArea) ){			
				if( Object_BasicTest(Exo, ExG2) is false )  continue;
				foreach( UCrossLine ExG1 in IEGet_Object_on_CrossLine(Exo, sq:1, hno:h1, LimitedArea) ){
					if( Object_BasicTest(Exo, ExG1) is false )  continue;
					if( ExG1.Object81.BitCount()!=1 || (FreeB&~ExG1.FreeB_Object)!=0 )  continue;	
						if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL0, ExG1.Object81, ExG2.Object81, "Exo.Band81, CL0, UCL1.Object81, UCL2.Object81(WC)" );		
					yield return (new UCrossLine(Exo,0,h0), ExG1,ExG2);
				}

				foreach( UCrossLine ExG0 in IEGet_Object_on_CrossLine(Exo, sq:0, hno:h0, LimitedArea) ){
					if( Object_BasicTest(Exo, ExG0) is false )  continue;
					if( ExG0.Object81.BitCount()!=1 || (FreeB&~ExG0.FreeB_Object)!=0 )  continue;	
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL1, ExG0.Object81, ExG2.Object81, "Exo.Band81, CL1, UCL0.Object81, UCL2.Object81(WC)" );		
					yield return (new UCrossLine(Exo,1,h1), ExG0,ExG2);
				}
			}

			foreach( UCrossLine ExG1 in IESet_Object_on_CrossLine_Fixed(Exo, sq:1, hno:h1, LimitedArea) ){
				if( Object_BasicTest(Exo, ExG1) is false )  continue;
				foreach( UCrossLine ExG2 in IEGet_Object_on_CrossLine(Exo, sq:2, hno:h2, LimitedArea) ){
					if( Object_BasicTest(Exo, ExG2) is false )  continue;
					if( ExG2.Object81.BitCount()!=1 || (FreeB&~ExG2.FreeB_Object)!=0 )  continue;
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL0, ExG1.Object81, ExG2.Object81, "Exo.Band81, CL0, UCL1.Object81(WC), UCL2.Object81" );
					yield return (new UCrossLine(Exo,0,h0),ExG2,ExG1);
				}

				foreach( UCrossLine ExG0 in IEGet_Object_on_CrossLine(Exo, sq:0, hno:h0, LimitedArea) ){
					if( Object_BasicTest(Exo, ExG0) is false )  continue;
					if( ExG0.Object81.BitCount()!=1 || (FreeB&~ExG0.FreeB_Object)!=0 )  continue;	
							if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Band81, CL2, ExG1.Object81, ExG0.Object81, "Exo.Band81, CL2, UCL1.Object81(WC), UCL0.Object81" );		
					yield return (new UCrossLine(Exo,2,h2), ExG1,ExG0);
				}
			}

			yield break;
		}


		private IEnumerable<UCrossLine> IEGet_Object_on_CrossLine( UExocetA Exo, int sq, int hno, UInt128 LimitedArea ){
			int	  FreeB0 = Exo.FreeB;
			UInt128 obj81;	

			UInt128 UCL = House_81[hno];
			UInt128 Allowed = UCL & LimitedArea & Board81_Free_with_FreeB;

			int Block_Object = Allowed.IEGet_rc().Aggregate(0, (a,rc) => a | 1<<rc.B() );

			// @@@ If size 2 or more is possible with the Standard Exocet, it will be enlarged.
			// @@@ The conditions for this cannot be found.
			bool JuniorB = (Allowed & ~Exo.Band81) == qZero;

			foreach( var blk in Block_Object.IEGet_BtoNo() ){
				var rcL = Allowed.IEGet_rc().Where(rc=>rc.B()==blk).ToArray();
				int size_rcL = rcL.Count();
				if( size_rcL <= 0 ) continue;

				// <<< Target >>>
				for( int k=0; k<size_rcL; k++ ){
					obj81 = qOne<<rcL[k]; 
					if( _Test_ExocetObject(2,Exo,obj81) )  yield return (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81) );
				}
			
 				// <<< Object >>>
				if( JuniorB && Exo.ExoMtdName=="Exocet_JE2P"){		// @@@ Is it possible senior-type Object ?
					if( size_rcL == 2 ){
						obj81 = qOne<<rcL[0] | qOne<<rcL[1]; 
						if( _Test_ExocetObject(2,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81));	
					}

					else if( size_rcL == 3 ){
						obj81 = qOne<<rcL[0] | qOne<<rcL[1]; 
						if( _Test_ExocetObject(2,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81));

						obj81 = qOne<<rcL[1] | qOne<<rcL[2]; 
						if( _Test_ExocetObject(2,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81));

						obj81 = qOne<<rcL[2] | qOne<<rcL[0];  
						if( _Test_ExocetObject(2,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81));
				
						 obj81 = qOne<<rcL[0] | qOne<<rcL[1] | qOne<<rcL[2];// The validity of size=3 has not been verified.  @@@ sollution /Exocet_examples2B.txt/ Puzzle 05/ step2
						if( _Test_ExocetObject(3,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81));
					}
				}
 
			}
			yield break;

					bool _Test_ExocetObject( int sz, UExocetA Exo, UInt128 obj ){	// Testing the basic properties of "Object".	
						int f = obj.Get_FreeB_or();
						return (Exo.FreeB & f)!=0;
					}
		}

		private IEnumerable<UCrossLine> IESet_Object_on_CrossLine_Fixed( UExocetA Exo, int sq, int hno, UInt128 LimitedArea, bool debugPrint=false ){
			int	  FreeB0 = Exo.FreeB;
			UInt128 obj81;	

			// <<< Object >>>
			UInt128 UCL = House_81[hno];
			UInt128 Allowed  = UCL & LimitedArea & Board81_Fixed_with_nonFreeB;
			UInt128 AllowedT = UCL & LimitedArea;
					if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Allowed, AllowedT, "Allowed, AllowedT" );

			int Block_Object = Allowed.IEGet_rc().Aggregate(0, (a,rc) => a | 1<<rc.B() );
			foreach( var blk in Block_Object.IEGet_BtoNo() ){
				var rcL = Allowed.IEGet_rc().Where(rc=>rc.B()==blk).ToArray();	
				int sz = rcL.Count();

				if( sz==2 ){// <<< Object >>>
					obj81 = qOne<<rcL[0] | qOne<<rcL[1]; 
					if( _Test_ExocetObject(2,Exo,obj81) )  yield return (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81) );
				}

				else if( sz==3 ){	// The validity of size=3 has not been verified.  @@@ sollution /Exocet_examples2B.txt/ Puzzle 05/ step2
					obj81 = qOne<<rcL[0] | qOne<<rcL[1]; 
					if( _Test_ExocetObject(2,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81) );

					obj81 = qOne<<rcL[1] | qOne<<rcL[2]; 
					if( _Test_ExocetObject(2,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81) );

					obj81 = qOne<<rcL[2] | qOne<<rcL[0];  
					if( _Test_ExocetObject(2,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object: obj81) );

					obj81 = qOne<<rcL[0] | qOne<<rcL[1] | qOne<<rcL[2];
					if( _Test_ExocetObject(3,Exo,obj81) )  yield return  (new(Exo, sq:sq, hno:hno, CrossLine:UCL, Object:obj81) );
				}
			}
			yield break;

					bool _Test_ExocetObject(int sz, UExocetA Exo, UInt128 obj) => (obj & Board81_Fixed_with_FreeB) == qZero; // All Fixed and non-BaseDigits
		}
	}
}