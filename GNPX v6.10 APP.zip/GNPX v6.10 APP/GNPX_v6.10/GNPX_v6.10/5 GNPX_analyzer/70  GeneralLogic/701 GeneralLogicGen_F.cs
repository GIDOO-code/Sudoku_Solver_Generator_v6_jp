using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Channels;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{

    //Copy below line and paste on 9x9 grid of GNPX. 
	// The selection range when copying can be rough.
    // 1..4....8.9.1...5.....63.....13.5.79..3...8..76.2.94.....75.....1...6.4.8....4..2  
	// 81.....32.2783149.......7182963481..478.1.369..1796824182.....3.4512.98.....8.241

	// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	//
	//    GNPX v6.1... Currently considering the algorithm construction policy.
	//
	// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::



	public partial class GeneralLogicGen: GeneralLogicGen_base{
		private bool SeriesMode=false;
		public  GeneralLogicGen( GNPX_AnalyzerMan pAnMan ): base( pAnMan ){ }


		public bool GeneralLogic() => GeneralLogic_Func_Series( );
		public bool GeneralLogic_120() => GeneralLogic_Func( noBSize:1, GLMaxSize:2, GLMaxRank:0 );
        public bool GeneralLogic_130() => GeneralLogic_Func( noBSize:1, GLMaxSize:3, GLMaxRank:0 );
        public bool GeneralLogic_131() => GeneralLogic_Func( noBSize:1, GLMaxSize:3, GLMaxRank:1 );


		public bool GeneralLogic_Func_Series(){
			int GLMaxSize = G6.nud_GenLogMaxSize;
			int GLMaxRank = G6.nud_GenLogMaxRank;
			SeriesMode = true;

			GeneralLogic_Prepare( );

			for( int rank=0; rank<=GLMaxRank; rank++ ){		

				for( int noBSize=1; noBSize<=GLMaxSize-1; noBSize++ ) {

					// ============ Select BaseSet ============
					foreach( var basSet in IE_GL_BaseSet( noBSize, GLMaxSize, rank, debugPrint:false) ){	//debugPrint ) ){

						// ============ Select CoverSet ============
						foreach( var bcvSet  in IE_GL_CoverSet( basSet, debugPrint ) ){

							// ============ Evaluate Result ============
							GeneralLogicResult( bcvSet, debugPrint );
							SolCode = 2;
							if( !pAnMan.IsContinueAnalysis() )  return true;	// @is Valid
							pBOARD.ForEach( UC => UC.ECrLst=null );             // Clear Cell's ECrLst to avoid the influence on the next loop of GL.
						}			
						foreach( var UC in pBOARD.Where(p=>p.No!=0) ) UC.CancelB=0;
					}
				}	
				//--------------------------------------------
			}
			return (SolCode>0);
		}


		public bool GeneralLogic_Func( int noBSize, int GLMaxSize, int GLMaxRank ){		
			SeriesMode = false;
			G6.nud_GenLogMaxSize = GLMaxSize;
			G6.nud_GenLogMaxRank = GLMaxRank;

			GeneralLogic_Prepare( );

			// ============ Select BaseSet ============
			foreach( var basSet in IE_GL_BaseSet( noBSize, GLMaxSize, GLMaxRank, debugPrint:false) ){	//debugPrint ) ){

				// ============ Select CoverSet ============
				foreach( var bcvSet  in IE_GL_CoverSet( basSet, debugPrint ) ){

					// ============ Evaluate Result ============
					GeneralLogicResult( bcvSet, debugPrint );
					SolCode = 2;
					if( !pAnMan.IsContinueAnalysis() )  return true;	// @is Valid
					pBOARD.ForEach( UC => UC.ECrLst=null );             // Clear Cell's ECrLst to avoid the influence on the next loop of GL.
				}			
				foreach( var UC in pBOARD.Where(p=>p.No!=0) ) UC.CancelB=0;
			}	
			//--------------------------------------------

            return (SolCode>0);
        }



		private void GeneralLogicResult( UBasCovSet bcSet, bool debugPrint=false ){
			foreach( var P in pBOARD ){
				var (b9,c9,e9) = _Get_noBEval(P.rc, bcSet );
				if( b9>0 )   P.Set_CellColorBkgColor_noBit( b9, clr:AttCr, clrBkg:SolBkCr2 );
				int c9C = c9.DifSet(b9);
				if( c9C>0 )  P.Set_CellColorBkgColor_noBit( c9, clr:AttCr, clrBkg:SolBkCr );
				if( e9>0  )  P.CancelB = P.FreeB&e9;
			}

			string st=$"GeneralLogicF \n     size:{bcSet.GLsize} rank:{bcSet.GLrank}";
			string msgB = bcSet.baseSet.Aggregate("",  (a,b) => a+$" {b.GL_ToString()}" ).Trim();
			string msgC = bcSet.coverSet.Aggregate("", (a,b) => a+$" {b.GL_ToString()}" ).Trim();

			string msgE= "";

			for( int no=0; no<9; no++ ){
				if( bcSet.elim9[no] == UInt128.Zero ){ continue; }
				msgE += $"{bcSet.elim9[no].ToRCStringComp()} #{no+1}";
			}

            Result = $"GL S/R:{bcSet.GLsize}/{bcSet.GLrank} / B:{msgB} / C:{msgC} / E:{msgE}";			
            ResultLong = $"{st}\r  BaseSet: {msgB}\r CoverSet: {msgC}\r  Exclude: {msgE}";
			extResult = ResultLong;
			return;

					(int,int,int)  _Get_noBEval( int rc, UBasCovSet bcSet ){
						UInt128x9 usedBas9=bcSet.usedBas9, usedCov9=bcSet.usedCov9, elim9=bcSet.elim9;	// �������� // ��������
						int  b9=0, c9=0, e9=0;
						for( int no=0; no<9; no++ ){
							int noB = 1<<no;
							if( usedBas9[no].IsHit(rc) )  b9 |= noB;	// ��������
							if( usedCov9[no].IsHit(rc) )  c9 |= noB;	// ��������
							if(    elim9[no].IsHit(rc) )  e9 |= noB;
						}
						return (b9,c9,e9);
					}
		}






		public class UBasCovSet{
			public int GLsize;
			public int GLrank;
			public int GLsizeRank;

			// ----- BaseSet -----
			public int			 noB9sel;
			public List<ULogical_Node> baseSet;
			public UInt128x9	 usedBas9;			// ��������
			
		  // ----- coverSet -----
		  	public List<ULogical_Node> coverSet;
			public UInt128x9	 usedCov9;
			public UInt128x9	 elim9;

			public UBasCovSet( int noB9sel, int GLsize, int GLrank, List<ULogical_Node> baseSet, UInt128x9 usedBas9 ){ // ��������
				this.GLsize=GLsize; this.GLrank=GLrank; this.GLsizeRank=GLsize+GLrank;

				this.baseSet=baseSet; this.usedBas9=usedBas9;	// �������� // ��������
				this.noB9sel = noB9sel;
			}

			public void SetCoverSet( List<ULogical_Node> coverSet, UInt128x9 usedCov9, UInt128x9 elim9 ){
				this.coverSet=coverSet; this.usedCov9=usedCov9; this.elim9=elim9;
			}

			public override string ToString( ){
				string st = $"\nbaseSet:  no:#{noB9sel.TBScmp()}";
				foreach( int no in noB9sel.IEGet_BtoNo() )  st += $"\n   usedBas9[#{no+1}]:{usedBas9[no].ToBitString81N()}";	// ��������


				int kx=0; baseSet.ForEach( P => st += $"  {kx} {P.b081.ToString81()}" );

				st = $"coverSet:  no:#{noB9sel.TBScmp()}";
				foreach( int no in noB9sel.IEGet_BtoNo() )  st += $"\n   usedCov9[#{no+1}]:{usedCov9[no].ToBitString81N()}";
				kx=0; coverSet.ForEach( P => st += $"  {kx} {P.b081.ToString81()}" );
				return  st;
			}
		}
	}
}