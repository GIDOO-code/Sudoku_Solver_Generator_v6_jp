﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using GNPX_space;
using System.Windows.Input;
using System.Security.Policy;

namespace GNPX_space{

    //Copy below line and paste on 9x9 grid of GNPX.
	// The selection range when copying does not have to be exact.
	// 81.....32.2783149.......7182963481..478.1.369..1796824182.....3.4512.98.....8.241 

	public partial class GeneralLogicGen_base: AnalyzerBaseV2{
		static public  int          GLtrialCC;
		protected int				stageNoPMemo = -9;
		public List<ULogical_Node>	ULG_List;

		protected int				GLMaxSize => G6.nud_GenLogMaxSize;
		protected int				GLMaxRank => G6.nud_GenLogMaxRank;
		public List<ULogical_Node>	ULG_ListSel;

		protected bool				debugPrint = false;

        static  GeneralLogicGen_base( ){ }

        public  GeneralLogicGen_base( GNPX_AnalyzerMan pAnMan ): base( pAnMan ){ }


		protected bool GeneralLogic_Prepare(  ){
			if( stageNoP!=stageNoPMemo || ULG_List==null ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();

				ULG_List = new();
				ULG_List.AddRange( _Generate_links_betwine_cells( debugPrint:false ) );
				ULG_List.AddRange( _Generate_links_inside_cell( szNMax:3, debugPrint:false) );

				ULG_List = ULG_List.DistinctBy( p=> p.matchKey2 ).ToList();		 							
				int ID0=0; ULG_List.ForEach( p=> p.ID=ID0++);

				if(debugPrint)  ULG_List.ForEach( P=> WriteLine(P) );
			}
			return true;

					// ... Row/Column/Block link
					List<ULogical_Node>	_Generate_links_betwine_cells( bool debugPrint=false ){					
						List<ULogical_Node>	 ULG_ListTmp = new();

						for( int no=0; no<9; no++ ){
							UInt128 qBOARD9 = BOARD_Free81B9[no];
							if( qBOARD9==null || qBOARD9==qZero )  continue;
							for( int h=0; h<27; h++ ){	
								UInt128 h128 = qBOARD9 & House_81[h];
								if( h128 == qZero )  continue;
								int rcb = h128.Ceate_rcbFrameAnd();

								ULogical_Node ULG = new( noB9:1<<no, b081:h128, lkType:1, ID:h );
									if(debugPrint)  WriteLine( $"{rcb.HouseToString()} * {rcb.ToBitString27rcb(digitB:false)}" );
								ULG_ListTmp.Add(ULG);
							}
						}
						
						ULG_ListTmp.Sort( (a,b)=>a.CompareToA(b) );
						return ULG_ListTmp;
					}

					// ... inside cell
					List<ULogical_Node>	_Generate_links_inside_cell( int szNMax=3, bool debugPrint=false ){	
						List<ULogical_Node>	 ULG_ListTmp = new();

						foreach( var UC in pBOARD.Where(p=>p.FreeB>0) ){
								if(debugPrint)  WriteLine( $"UC:{UC}" );
							int houseB = UC.rc.rcbFrame_Value(); 

							ULogical_Node ULG = new( noB9:UC.FreeB, b081:UInt128.One<<UC.rc, lkType:2 );
								if(debugPrint)  WriteLine( $" ULG:{ULG}   noB:{UC.FreeB.ToBitString(9)}" );
							ULG_ListTmp.Add(ULG);
						}

						ULG_ListTmp.Sort( (a,b)=>a.CompareToA(b) );
						return ULG_ListTmp;
					}
		}


		public class UInt128x9{
			public UInt128[] UI9;
			public UInt128 this[int no]{ get=>UI9[no]; set=>UI9[no]=value; }

			public UInt128x9( ){ this.UI9 = new UInt128[9]; }
			public UInt128x9( UInt128[] UI9 ){ this.UI9=UI9; }

			public bool Add_if_New( ULogical_Node ULG ){
				for( int no=0; no<9; no++ ){
					if( (UI9[no]&ULG.b081) > UInt128.Zero )  return false;	// Already contained
					UI9[no] |= ULG.b081;
				}
				return true;
			}

			public void Or( ULogical_Node ULG ){ for( int no=0; no<9; no++ )  UI9[no] |= ULG.b081; }

			public bool IsCovered( UInt128x9 cov9 ){ 
				for( int no=0; no<9; no++ ){ if( (UI9[no] & ~cov9.UI9[no]) != UInt128.Zero ) return false; }
				return true;
			}
		}
	}
}
