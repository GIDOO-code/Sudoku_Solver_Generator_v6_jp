using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Channels;
using static System.Diagnostics.Debug;
using static System.Math;

namespace GNPX_space{

    //Copy below line and paste on 9x9 grid of GNPX. 
	// The selection range when copying can be rough.
    // 1..4....8.9.1...5.....63.....13.5.79..3...8..76.2.94.....75.....1...6.4.8....4..2  
	// 81.....32.2783149.......7182963481..478.1.369..1796824182.....3.4512.98.....8.241



	public partial class GeneralLogicGen: GeneralLogicGen_base{

	#region BaseSet
		private IEnumerable<UBasCovSet> IE_GL_BaseSet( int noBSize, int GLMaxSize, int rank, bool finned=false, bool debugPrint=false ){
			List<ULogical_Node> baseSet = new();
			int nxt=0;

			int noB9_BOARD = pBOARD.Aggregate(0,(w,u)=> w| u.FreeB );
					if(debugPrint) WriteLine( $"noB9_BOARD : #{noB9_BOARD.ToBitString(9)}" );

			// ========== [1] Setting element conditions ==========
			foreach( var (noB9sel,GLsize) in _IE_GL_Condition3( noBSize, GLMaxSize, noB9_BOARD, debugPrint:true ) ){
						if(debugPrint) WriteLine( $" GLsize:{GLsize} B: #{noB9sel.ToBitString(9)} ({noB9sel})" ) ;  

				// ========== [2] Selecting elements using the digits axis(noB9sel). ==========		
				ULG_ListSel = ULG_List.FindAll(P=> (P.noB9 & noB9sel) > 0);	
				if( ULG_ListSel==null || ULG_ListSel.Count<GLsize ) continue;
							if(debugPrint){ WriteLine("\nUGL_ListSel"); ULG_ListSel.ForEach( p=> WriteLine(p) ); } 

				// ========== [3] Selecting elements using RCB axis ==========
				Combination cmbBas = new( ULG_ListSel.Count, GLsize );
				nxt=9;
				while( cmbBas.Successor(nxt) ){
					baseSet.Clear();

					UInt128x9 usedBas9 = new( );		// ��������
					long rcbnFrame=0;
					UInt128[] gridRCN=new UInt128[10];

					for( int k=0; k<GLsize; nxt=++k ){
						nxt=k;
						ULogical_Node P = ULG_ListSel[ cmbBas.Index[k] ];
						if( usedBas9.Add_if_New(P) is false )  goto LcmbBasNxt;   // ��������

						rcbnFrame |= P.rcbnFrame;
						var (sizeRCBN,sizeL) = _func_sizeCheck4( rcbnFrame, printB:(k==GLsize) );
						if( sizeRCBN > GLsize )  goto LcmbBasNxt;				
								if(debugPrint) WriteLine( $" --- ULogical_Node [{k}] {P}" );
						baseSet.Add(P);
					}
					if( _IsWholeConnected(baseSet) is false )  goto LcmbBasNxt;

					UBasCovSet basCovSet = new UBasCovSet( noB9sel, GLsize, rank, baseSet, usedBas9 );	// ��������

							 if(debugPrint){
								baseSet.ForEach( P=>  WriteLine( $" ID:{P.ID,3}  {P.rcbFrame.ToBitString27rcb(digitB: false)}   {P}") );
							 }

					yield return basCovSet;

				 LcmbBasNxt:
					continue;
				}

			}
			yield break;
			
						// ===== inner function =====
						IEnumerable<(int,int)> _IE_GL_Condition3( int noBSize, int GLMaxSize, int noB9, bool finned=false, bool debugPrint=false ){
							int NoB9Max = Min( noB9.BitCount(), 3 );
							int GLsz = GLMaxSize - noBSize;
							if( GLsz < 1 )  yield break;
						
							Combination_9B cmb9 = new( noB9.BitCount(), noBSize, noB9 );
							while( cmb9.Successor() ) yield return ( cmb9.noB9, GLsz );
							
							yield break;
						}

						IEnumerable<(int,int)> _IE_GL_Condition2( int GLMaxSize, int noB9, bool finned=false, bool debugPrint=false ){
							int NoB9Max = Min( noB9.BitCount(), 3 );
							for( int cmbsz=1; cmbsz<=NoB9Max; cmbsz++ ){		// Limit the number of digits to 3 or less
								Combination_9B cmb9 = new( noB9.BitCount(), cmbsz, noB9 );
								while( cmb9.Successor() ){
									for( int GLsz=1; GLsz<=GLMaxSize; GLsz++ ){
										if( GLsz>GLMaxSize )  continue;
										 yield return ( cmb9.noB9, GLsz );
									}
								}
							}
							yield break;
						}

						(int,List<int>) _func_sizeCheck4( long RCBNframe, bool printB=false ){
							var sizeL = new List<int>();
							int noBL = ((int)(RCBNframe&0x1FF)).BitCount();
							int n = (int)(RCBNframe&0x1FF);
							int r = ((int)(RCBNframe>>9))&0x1FF;  sizeL.Add( r.BitCount() );
							int c = ((int)(RCBNframe>>18))&0x1FF; sizeL.Add( c.BitCount() );
							int b = ((int)(RCBNframe>>27))&0x1FF; sizeL.Add( b.BitCount() );
						
							sizeL.Sort();
							sizeL.Add( n.BitCount() );
							int sizeRCBN = sizeL[0];// + n.BitCount();	// sizeL[0] is the minimum of r,c,b.
																		// If sizeL[0]+n.BitCount() > GLsize, it is impossible to cover the base set with GLsize cover set.
							if(printB){
								string st = printB? "_func_sizeCheck4: " + string.Join( " ", sizeL ): "";
								WriteLine( $"{st} {sizeL[3]} =>{sizeRCBN}" );
							}

							return (sizeRCBN,sizeL);
						}

						bool _IsWholeConnected( List<ULogical_Node> basSet ){
							if( basSet.Count<=1 ) return true;

							List<ULogical_Node> connected = new();
							List<ULogical_Node> basSetRemain = new();

							connected.Add(basSet[0]);
							basSetRemain.AddRange( basSet.Skip(1) );

							bool changed = true;
							while( basSetRemain.Count>0 && changed ){
								changed = false;

								foreach( var P in basSetRemain ){
									P.markTmp = false;
									if( connected.Any(Q => (P.b081&Q.b081)>0 && (P.noB9&Q.noB9)>0) ){ P.markTmp=true; changed=true; }
								}
								if( changed ){
									foreach( var P in basSetRemain.Where(p=>p.markTmp) ){
										connected.Add(P);
										basSetRemain.Remove(P);
									}
								}
							}
							return	(basSetRemain.Count==0);
						}
		}

	#endregion BaseSet


	#region CoverSet  //=====================================================================================
		private  IEnumerable<UBasCovSet> IE_GL_CoverSet( UBasCovSet basCovSet, bool debugPrint=false ){					
			int GLsize = basCovSet.GLsize, GLsizeRank=basCovSet.GLsizeRank ;
			UInt128x9 usedBas9 = basCovSet.usedBas9;
			List<ULogical_Node> BaseSetLst = basCovSet.baseSet;
			int noB9sel = basCovSet.noB9sel;

			// Only links that overlap with the BaseSet are candidates for the CoverSet.
			List<ULogical_Node>	UGL_List_4CoverSet = ULG_ListSel.FindAll( P=> IsNotBaseSet(P) && IsContactWith2Cell(P) );
						bool IsNotBaseSet( ULogical_Node P ) => BaseSetLst.All(q => q.ID!=P.ID);		// Not included in the BaseSet
						bool IsContactWith2Cell( ULogical_Node P ) {                                    // Contact with 2 or more link in the BaseSet
							int nc =  noB9sel.IEGet_BtoNo().Sum( no => (P.b081&usedBas9[no]).BitCount() );	// ��������
							return  nc>=2;
						}
			if( UGL_List_4CoverSet.Count < GLsizeRank )  yield break;	// Insufficient CoverSets
					if(debugPrint){
						foreach( int no in noB9sel.IEGet_BtoNo() ){
							WriteLine( $"\n   IE_GL_CoverSet no:#{no+1}" );
							UGL_List_4CoverSet.ForEach( P=> WriteLine( $"   ID:{P.ID,3}  {P.rcbFrame.ToBitString27rcb(digitB:false)} {P}") );
						}
					}


			List<ULogical_Node> CovSet = new();
			int nxt=0;
			Combination cmbCov = new(UGL_List_4CoverSet.Count, GLsizeRank );
			while( cmbCov.Successor(nxt) ){
				CovSet.Clear();

				// --- Check for overlap in the CoverSet
				UInt128x9 usedCov9 = new();
				nxt = 0;
				for( int k=0; k<GLsizeRank; nxt=++k ){
					ULogical_Node P = UGL_List_4CoverSet[ cmbCov.Index[k] ];
					foreach( int no in noB9sel.IEGet_BtoNo() ){
						if( (usedCov9[no]&P.b081) > 0 )  goto LcmbCovNxt;	// CoverSet has overlap
						usedCov9[no] |= P.b081;
					}
					CovSet.Add(P);
				}

				// --- Check if the coverSet completely covers the baseSet
				bool IsCovered = noB9sel.IEGet_BtoNo().All( no => (usedBas9[no] & ~usedCov9[no]) == qZero );	// ��������
				if( !IsCovered )  goto LcmbCovNxt;
					
				// --- Exclude elements
				UInt128x9 Elim9 = new();
				bool anyExcluded = false;
				foreach( int no in noB9sel.IEGet_BtoNo() ){
					Elim9[no] = usedCov9[no] & ~usedBas9[no];		// ��������
					if( Elim9[no] != qZero )  anyExcluded = true;
				}

				if( !anyExcluded )  goto LcmbCovNxt;
						if(debugPrint){
							foreach( int no in noB9sel.IEGet_BtoNo() ){
								if( Elim9[no] > qZero )   WriteLine( $"#Elim[#{no+1}]  {Elim9[no].ToBitString81()}" );
							}
						}

				basCovSet.SetCoverSet( CovSet, usedCov9, Elim9 );
				yield return basCovSet;

		   LcmbCovNxt:
				continue;
			}
			yield break;
		}
	#endregion CoverSet
	}
}