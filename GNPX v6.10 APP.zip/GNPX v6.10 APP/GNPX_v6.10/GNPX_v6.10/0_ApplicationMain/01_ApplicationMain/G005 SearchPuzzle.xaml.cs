﻿using GIDOO_space;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Xml.Linq;
using Windows.Devices.Power;

namespace GNPX_space{
	using ioPath = System.IO.Path;
	using pGPGC = GNPX_Puzzle_Global_Control;
	using pRes = Properties.Resources;
	using sysWin = System.Windows;


    public partial class GNPX_SearchPuzzle: Window{
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 
		static private G6_Base G6 => GNPX_App_Man.G6;
		private PuzzleFile_IO  fPuzzleFile_IO => pGNPX_App.PuzzleFile_IO;

        private GNPX_win	   pGNP00win;
		       
		private GNPX_App_Man   pGNPX_App;
		private List<UPuzzle>  pGNPX_PUZZLE_List => pGPGC.GNPX_Puzzle_List;
		private List<string>   stPzls;

		private string		   pfName;

        public GNPX_SearchPuzzle( GNPX_win pGNP00win ){
			this.pGNP00win = pGNP00win;
            pGNPX_App = pGNP00win.GNPX_App;
			InitializeComponent();		

            this.MouseLeftButtonDown += (sender, e) => this.DragMove();
			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man ); 
        }

		private void btn_Cancel_Click(object sender, RoutedEventArgs e) => this.Close();


		private void devWin_Loaded(object sender, RoutedEventArgs e) {
			pfName = G6.Dir_SDK_Methods_XMLFileName;
			txb_PuzzleFileName.Text = G6.GNPX_PuzzleFileName;
			// pGNPX_App.SolverList_App = pGNPX_App.ReadXMLFile_AnalysisConditions_MethodList();

			btn_Search_Puzzle.IsEnabled = false;
			if( pGNPX_PUZZLE_List!=null && pGNPX_PUZZLE_List.Count>0 )  Show_PuzzleList();
		}

		private void Show_PuzzleList(){
			stPzls = new List<string>();
			foreach( var (p,nx) in pGNPX_PUZZLE_List.WithIndex() ){
				string stx = $"{nx+1,3}: {p.stPZL_withSP}  dif:{p.difficultyLevel} {p.Name}";
				stPzls.Add(stx);
			}
			PuzzleList.ItemsSource = stPzls;
			if( stPzls==null || stPzls.Count==0 )   return;
			btn_Search_Puzzle.IsEnabled = true;
		}

		private void btn_OpenPuzzleFile_Click(object sender, RoutedEventArgs e) {
            var OpenFDlog = new OpenFileDialog(){
				Multiselect = false,
				Title  = pRes.filePuzzleFile,
				Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
			};
			
			if( (bool)OpenFDlog.ShowDialog() ){
                string fName = OpenFDlog.FileName;
				G6.Dir_SDK_Methods_XMLFileName = fName;
				txb_PuzzleFileName.Text = fName;
				var PZL_List = fPuzzleFile_IO.GNPX_PuzzleFile_Read( fName );
				pGPGC.Set_GNPX_Puzzle_List( PZL_List ); 

				if( pGNPX_PUZZLE_List!=null && pGNPX_PUZZLE_List.Count>0 ) Show_PuzzleList();
				
				Gidoo_EventHandler se2 = new Gidoo_EventHandler( eName:"SetPuzzle_no", ePara0:1 );  //Report
				Send_Command_to_GNPXwin( this, se2 );
			}
		}


		private void btn_Search_Puzzle_Click(object sender, RoutedEventArgs e) {
			if( stPzls==null || stPzls.Count==0 )  return;
			string key = txb_Seach_Key.Text.Trim();

			StringComparison StringComparison = StringComparison.OrdinalIgnoreCase;

			var matchList = stPzls.FindAll(p=> p.Contains(key,StringComparison) ).ToList();
			PuzzleList.ItemsSource = matchList;
			lbl_SearchResult.Content = $"{matchList.Count} / {pGNPX_PUZZLE_List.Count} found";
		}

		private void btn_Search_Reset_Click(object sender, RoutedEventArgs e) {
			txb_Seach_Key.Text = "";
			Show_PuzzleList();
		}

		private void PuzzleList_SelectionChanged(object sender, sysWin.Controls.SelectionChangedEventArgs e) {
			if( sender == null )  return;
			var Q = (string)PuzzleList.SelectedItem;
            if( Q is null )  return;
			int n = Q.IndexOf(":");
			int nx = int.Parse(Q.Substring(0,n));

			Gidoo_EventHandler se2 = new Gidoo_EventHandler( eName:"SetPuzzle_no", ePara0:nx );  //Report
			Send_Command_to_GNPXwin( this, se2 );
		}

		private void txb_Seach_Key_PreviewKeyDown(object sender, sysWin.Input.KeyEventArgs e ){
			if( e.Key == sysWin.Input.Key.Enter )		 btn_Search_Puzzle_Click(sender,null);
			else if( e.Key == sysWin.Input.Key.Escape )  btn_Search_Reset_Click(sender,null);
		}

		private void txb_Seach_Key_PreviewMouseDown(object sender, sysWin.Input.MouseButtonEventArgs e) {
			if( txb_Seach_Key.Text == "Search key" )  txb_Seach_Key.Text = "";
		}
	}
}
