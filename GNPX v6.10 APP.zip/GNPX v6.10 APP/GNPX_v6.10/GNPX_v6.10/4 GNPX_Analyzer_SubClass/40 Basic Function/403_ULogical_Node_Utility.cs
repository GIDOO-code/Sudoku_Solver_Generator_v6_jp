using System;
using System.Linq;
using System.Collections.Generic;
using static System.Diagnostics.Debug;
using System.Globalization;

using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Input;

using System.Resources;
using System.Runtime.InteropServices;
using System.Diagnostics; 
using GNPX_space;

namespace GIDOO_space{
    static public class ULogical_Node_Utility{     
		static private readonly int[]   _rcbFrame_Value;

        static public int ToRCBFrame( this int rc) => (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9);
		static public int rcbFrame_Value( this int rc) => _rcbFrame_Value[rc];
        static public int Ceate_rcbFrameAnd( this UInt128 b081 )  => b081.IEGet_rc().Aggregate( 0x7FFFFFF, (p,q) => p& rcbFrame_Value(q) );
        static public int Ceate_rcbFrameOr( this UInt128 b081 )   => b081.IEGet_rc().Aggregate( 0, (p,q) => p| rcbFrame_Value(q) );

		static public int Get_rcbFrame( this int rcbFrame, int type ) => (type==0)? rcbFrame&0x1FF: (type==1)? (rcbFrame>>9)&0x1FF: (rcbFrame>>18)&0x1FF;

		static ULogical_Node_Utility(){
			_rcbFrame_Value = new int[81];
			for( int rc=0; rc<81; rc++ )  _rcbFrame_Value[rc] = ToRCBFrame(rc);
		}
	}

}