using GIDOO_space;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Windows.Threading;
using static System.Diagnostics.Debug;
using static System.Math;


namespace GNPX_space{
    public partial class GNPX_Engin{                        // This class-object is unique in the system.
		static public event GNPX_EventHandler Send_Command_to_GNPXwin; 

		static public bool		 MltAnsSearch;
        static public bool       SolInfoB;    
        static public int        eng_retCode;						// result
        static public UAlgMethod AnalyzingMethod;
		static public string     AdditionalMessage;
        static public TimeSpan   SdkExecTime;  
        static public bool       SolverBusy=false;
		static public UAlgMethod method_maxDiffcult0;
		static private int		 __GCC__=0;

        public  GNPX_App_Man     pGNPX_App;							// main control     
		public  GNPX_win         pGNP00win => pGNPX_App.pGNP00win;
		private G6_Base			 G6 => GNPX_App_Man.G6;
		private G7_Base			 G7 => GNPX_App_Man.G7;


        public  GNPX_AnalyzerMan AnMan;								// analyzer(methods)
		public  Research_trial   RTrial;

        private bool             __ChkPritnt_SolverMethod = false;	//### For debug, display the method.



		
		public  UPuzzle          PZL_Initial;

        public  UPuzzle          ePZL = new(); // Puzzle to analyze
        private int              stageNo{ get  => ePZL.stageNo; }
        private  int             stageNo100; 
        public  int              Add_stageNo() => stageNo100 +=100;    

        public int               stageNoP{ get => stageNo100 + stageNo; }
     
		private Stopwatch		 AnalyzerLap;
		private string			 stNotSolved="", stNotSolvedJP="";
//		private  GNPX_Graphics	 gnpxGrp;

		public  bool			 AnalysisResult = false;
        private List<UAlgMethod> SolverList_GNPX_eng{ get{ return pGNPX_App.SolverList_GNPX; } }  // List of algorithms to be applied.
		public  int				 SolverList_Count => SolverList_GNPX_eng.Count;
		public GNPX_Engin( GNPX_App_Man  pGNPX_App ){           //Execute once at GNPX startup.
            this.pGNPX_App = pGNPX_App; 
            AnMan = new GNPX_AnalyzerMan(this);
			RTrial = new(AnMan);	
			
			this.ePZL = new UPuzzle();
//			gnpxGrp = new GNPX_Graphics(pGNPX_App);

			AnalyzerLap = new Stopwatch();

			stNotSolved = "\n This is a Sudoku Puzzle,\n There is no algorithm that can solve this.";
			stNotSolved += "\n\n It is necessary to adjust the difficulty level or\n develop a new algorithm.";

			stNotSolvedJP = "\n ����͐��Ƃ̖��ł��B\n �w��̃A���S���Y���ł͉����܂���B";
			stNotSolvedJP += "\n\n �A���S���Y���̓�x�𒲐����邩�A\n �V���ȃA���S���Y���̊J�����K�v�ł��B";

			Send_Command_to_GNPXwin += new GNPX_EventHandler( pGNP00win.GNPX_Event_Handling_man );  
        }



      #region Puzzle management
        public void Clear_0(){
            ePZL.ToInitial( ); // Clear all.
            AnMan.Update_CellsState( ePZL.BOARD, setAllCandidates:true );
        }
        public bool IsSolved() => ePZL.BOARD.All(p=> p.No!=0);

		// <<< Use TandE to find the solution >>>
		public (bool,string) IsValidPuzzle(){
			List<int>  _intBoard = ePZL.BOARD.ConvertAll(P=>Max(P.No,0));
			bool ret = false;
			try{
				List<string>  stList = RTrial.TrialAndErrorApp( _intBoard, filePutB:true, upperLimit:99999 );	//2 );
					//this.sol_int81 = RTrial.RT_Get_Solution_iArray; //RTrial.RT_Get_Solution_iAbs;

					this.sol_int81 = new int[0];
					try{
						var RTS = RTrial.RT_Get_SolList;
						if( RTS!=null && RTS.Count>0 ) this.sol_int81 = RTS[0].stringToInt().ToArray();
					}
					catch(Exception ex){
						WriteLine( $"GNPX_Engin error. Not yet confirmed." );
						throw new Exception( $"GNPX_Engin error. Not yet confirmed.");
					}


				ePZL.SolCode = 0;	// Cancel the�gSolCode=1�hsetted by TrialAndErrorApp.
				ret = (RTrial.RT_Get_SolList.Count==1);
			}
			catch(Exception ex){
				// ... not a latin square
				//    Index was out of range. at "991 GNPZ_An99_Research_trial.cs:line 83"
				ret = false;
				RTrial.Result = $"Invalid Puzzle\n  not a latin square";
				WriteLine( $"Invalid Puzzle\n{ex.Message}\n{ex.StackTrace}" );
			}
			return (ret,RTrial.Result);
		}

        public void Set_NewPuzzle( UPuzzle aPZL ){   
            this.PZL_Initial = aPZL;
			if( aPZL.BOARD == null )  return;

				//WriteLine( $"##### Set_NewPuzzle ePZL:{ePZL.ToString_check(aPZL)}" );
				//WriteLine( $"##### Set_NewPuzzle aPZL:{aPZL.ToString_check(aPZL)}" );

            ePZL = aPZL.Copy();
            ePZL.selectedIX = -1;
        }



        public void Set_selectedChild( int selX ){
            int cnt = ePZL.Child_PZLs.Count;
            if( selX<0  || cnt<=0 || selX>=cnt ) return;
            ePZL = ePZL.Child_PZLs[ selX ];
        }
		public bool Adjust_Candidates(  ){   //Cell true/false setting processing  
			if( ePZL.SolCode<0 ) return true;				// ... Already initialized. No Adjust process is required.

			var (codeX,eNChk) = AnMan.Execute_Fix_Eliminate( ePZL.BOARD );
						// codeX = 0 : Complete. Go to next stage.
						//         1 : Solved. 
						//        -1 : Error. Conditions are broken.

				if( codeX==-1 && ePZL.SolCode==-9119 ){
					string st="";
					for(int h=0; h<27; h++ ){
						if(eNChk[h]!=0x1FF){
							st+= "Candidate #"+(eNChk[h]^0x1ff).ToBitStringNZ(9)+" disappeared in "+_ToHouseName(h)+"\r";
							AnMan.SetBG_OnError(h);
						}
					}

					//txbxAnalyzerResult.Text=st;
					ePZL.SolCode = ePZL.SolCode;
					return false;
				}
				if( ePZL.SolCode==-999 )  ePZL.SolCode = -1;


			var (confirmedAll,nP,nZ,nM) = AnMan.Aggregate_CellsPZM( ePZL.BOARD );
			if( nZ==0 ){ AnMan.SolCode=0; return true; }
			return true;

						// ---------------------------------------------------
						string _ToHouseName( int h ){
							string st="";
							switch(h/9){
								case 0: st="row";    break;
								case 1: st="Column"; break;
								case 2: st="block";  break;
							}
							st += ((h%9)+1).ToString();
							return st;
						}
		}


		// <<< Stage Management >>>
		public string Set_NextStage( int _stageNo=-1, bool skip_valid_check=false ){      // update the state and create the next stage.
      
			if( AnMan is null )  return "AnMan is null";
			if( ePZL  is null )  return "ePZL is null";
			if( ePZL.BOARD.All( p=> p.No!=0 ) )  return "solved";


			if( stageNo == 0 ){ AnMan.Update_CellsState( ePZL.BOARD, setAllCandidates:true ); }
			else{ 
				int nIX = ePZL.selectedIX;
				if( nIX<0 || ePZL.Child_PZLs==null || nIX>=ePZL.Child_PZLs.Count )  return "solved";
				ePZL = ePZL.Child_PZLs[nIX];
			}


			UPuzzle PZL_nextStage   = ePZL.Copy();
			PZL_nextStage.pre_PZL   = ePZL;
			PZL_nextStage.stageNo   = ePZL.stageNo+1;	
			//PZL_nextStage.BOARD.ForEach( P=> P.ECrLst=null );


			if( stageNo > 0 ){
				var (codeX,_) = AnMan.Execute_Fix_Eliminate( PZL_nextStage.BOARD );
					// codeX  0:Complete. Go to next stage.  1:Solved.   -1:Error. Conditions are broken.
				if( codeX == 1 )  return "solved";
				if( codeX < 0 ){  eng_retCode = -1; return "Error. Conditions are broken."; }
			}


            PZL_nextStage.Child_PZLs = new List<UPuzzle>();
			ePZL = PZL_nextStage;

            return "";            //"No problem, continue"  
        }


        public void ReturnToInitial(){
            if( PZL_Initial is null )  PZL_Initial = ePZL;
            
            this.ePZL = PZL_Initial.Copy();
            this.ePZL.stageNo = 0;
            this.Add_stageNo();
			this.ePZL.ToInitial( ); //to initial stage
		}
      #endregion Puzzle management


      #region Methods_for_Solving functions
        public void MethodLst_Run__Reset_UsedCC(){
            Add_stageNo();

            SolverList_GNPX_eng.ForEach(P=>P.UsedCC=0);
			GNPX_Engin.method_maxDiffcult0 = null;
        } 

        public string DGView_MethodCounterToString(){
            var Q = SolverList_GNPX_eng.Where(p=>p.UsedCC>0).ToList();
            return Q.Aggregate("",(a,q) => a+$" {q.MethodName}[{q.UsedCC}]" );
        }

        public void AnalyzerCounterReset(){
			if( SolverList_GNPX_eng==null )  return;
			SolverList_GNPX_eng.ForEach(P=>P.UsedCC=0);  //Clear the algorithm counter. 
		}

        public (int,string)  Get_difficultyLevel( ){
            int DifL=0;
            string pzlName="";
            if( SolverList_GNPX_eng.Any(P=>(P.UsedCC>0) )){
                DifL = SolverList_GNPX_eng.Where(P=>P.UsedCC>0).Max(P=>Abs(P.difficultyLevel));
                var R = SolverList_GNPX_eng.FindLast(Q=>(Q.UsedCC>0)&&(Abs(Q.difficultyLevel)==DifL));
                pzlName = (R!=null)? R.MethodName: "";
            }
            return (DifL,pzlName);
        }
      #endregion Methods_for_Solving functions






	  // ######################################################
      #region Analyzer


		
        public string GNPX_Solver_SolveUp( CancellationToken cts ){

			string stRet = "";
            eng_retCode =0;

            var (_,nP,nZ,nM) = AnMan.Aggregate_CellsPZM(ePZL.BOARD);
            eng_retCode = nZ;
			if( nZ==0 ){ stRet="SolveUp"; return stRet; }		// <<< Already solved >>>

			stRet = "--";
            try{
				ePZL = PZL_Initial.Copy();
                ePZL.stageNo = 0;

				AnalyzerLap.Reset();
				AnalyzerLap.Start();    

					// <<<<< Repeatedly apply the SingleStage solver. >>>>> 
					int RestFreeBC=1;
					while( RestFreeBC>0 ){  
								if( cts.IsCancellationRequested ){ stRet="Canceled"; break; }

						string retST = Set_NextStage(PZL_Initial.stageNo);		// ePZL.stageNo counts up here.
						if( retST == "solved" && ePZL.BOARD.Sum(P=>P.FreeBC) == 0 ){ stRet="SolveUp"; break; }			
						if( retST != "" ){ eng_retCode=-3; stRet="Not Sudoku"; break; }	

						// ================================================
						GNPX_App_Man.MultiSolve_StartTime = DateTime.Now;	// bag fix v5.96

						var (ret,ret2) = GNPX_Solver_SingleStage( cts:cts, SolInfoB:false ); // <<< 1-step solver >>>
						if( ret2 == "SolveUp" ){ stRet="SolveUp"; break; }
						if( !ret ){ eng_retCode=-3; stRet=ret2; break; }

						RestFreeBC = ePZL.BOARD.Sum(p=>p.FreeBC);
					}
					// -----------------------------------------------------

                AnalyzerLap.Stop();     
				SdkExecTime = AnalyzerLap.Elapsed;
            }
			catch(Exception e){
				string message = $"{e.Message} \r{e.StackTrace}";
				WriteLine( $"---{DateTime.Now} {message}" );
			//	if( !message.Contains("canceled") ){
			//		Utility_Display.GNPX_StreamWriter_WithTime( fName:"Exception_GNPX_Solver_SolveUp.txt", message:message );//, append:true );
			//	}
			}

			// If the solution is successful, return "SolveUp".
			return stRet;
        }



		private int debugCC=0;

        // 1-step solver
        public (bool,string) GNPX_Solver_SingleStage( CancellationToken cts, bool SolInfoB ){
				//::::::::::::::::::::::: GC ::::::::::::::::::::::::::::
				if( ((++__GCC__)%10000)==0 ){ GC.Collect(); __GCC__=0; }     //Is it necessary? Is it effective?
				string    stResult="";

				bool Sel_Mark_Break = (G6.PG6Mode=="Func_SolveMulti" || G6.PG6Mode=="Func_SelectPuzzle");

				DateTime  MltAnsTimer = DateTime.Now;

				#region Prepare
					int nonFixed = ePZL.BOARD.Count(p=>(p.FreeB!=0));
								if(__ChkPritnt_SolverMethod){
									int Undetermined = ePZL.BOARD.Sum(p=> (p.No==0)? p.FreeBC: 0);
									WriteLine( $"\n=== {G6.PatternCC}  stageNo:{stageNo}  unsolved:{nonFixed} cells   Total Undetermined {Undetermined}" );
									if( nonFixed==0 ){ WriteLine( $"zeroCC:{nonFixed}" ); stResult="SolveUp"; }
								}
					if( nonFixed==0 ){ stResult="SolveUp"; goto LProcessEnd; }

				  #region Initialize, set search conditions
					if( stageNo == 0 ){
						ePZL.method_MostDiffcult = null;
						PZL_Initial.pMethod		 = null;
						PZL_Initial.difficultyLevel = 0;
					}

					// --- Initialize global ---
					G6.stResult			= "...";
					G6.Canceled			= "";
					G6.Found_level_Solution = false;
					ePZL.Sol_ResultLong = "";
					ePZL.extResult		= "";
					AdditionalMessage   = "";
					ePZL.SolCode		= -1;

					AnalysisResult		= false;

					// --- set search conditions ---
					var (_,Puzzle_LevelHigh) = _Set_AcceptableLevel( );
							(int,int) _Set_AcceptableLevel( ){
								int _lvlLow=1, _lvlHgh=15;
								switch(G6.PG6Mode){	
									case "Func_CreateAuto":	 _lvlLow=G6.Puzzle_LevelLow; _lvlHgh=G6.Puzzle_LevelHigh; break;	
									case "Func_SolveMulti":  _lvlLow=1;					 _lvlHgh=G6.MSlvr_MaxLevel; break;	
								}
									//WriteLine( $" * * * Set_AcceptableLevel {G6.PG6Mode} : {_lvlLow} - {_lvlHgh}" );
								return (_lvlLow,_lvlHgh);
							}
				  #endregion

  					// ---  Verify Puzzle ---
					if( ePZL.BOARD.All(p=>(p.FreeB==0)) ){ AnalysisResult=true;  stResult="SolveUp"; goto LProcessEnd; } // All cells confirmed.
					if( !AnMan.Verify_Puzzle_Roule() ){ AnalysisResult=false; stResult="no solution"; goto LProcessEnd; }  
				#endregion Prepare
				

			// <<< Search for one stage >>>
						if(__ChkPritnt_SolverMethod)  WriteLine( $" <<< SolverList_GNPX_eng:{SolverList_GNPX_eng.Count()}" );

			AnalyzerLap.Reset();
			AnalyzerLap.Start();	
			if( G6.PG6Mode == "Func_CreateAuto" )  SolverList_GNPX_eng.RemoveAll(P=> P.GenLogB);	 // In "Func_CreateAuto", "GeneralLogic" is excluded.

			double  ts0=0, ts1;
//			G7.Sel_mark_Solved = false;
			foreach( var (MTHD,MTHD_idx) in SolverList_GNPX_eng.WithIndex() ){					   // Sequentially execute analysis algorithms
				if( MTHD.IsChecked is false )  continue;  // Is the method enabled?

				if( cts.IsCancellationRequested ){ _PostProcessing(); return (false,"canceled"); } // Was the task canceled? 
				G6.stopped_StatusMessage = "";
				MTHD.SuccessfulB = false;
				MTHD.ErrorB = false;
					//WriteLine( $"pID:{MTHD.pID} {MTHD.NameM}" );
					//if( MTHD.mark_Sel )  WriteLine( $"MTHD:{MTHD.NameM}  mark_Sel:{MTHD.mark_Sel}" );

				#region  Determining the suitability of a method
					//WriteLine( MTHD );
					
					if( G6.zPowerUserCC>0 && !G6.GeneralLogic_StopSearch ){}
					else{
						if( G6.GeneralLogic_on && !MTHD.ID_caseGL )  continue;
						if( !G6.GeneralLogic_on && MTHD.GenLogB )    continue;
					}
					// Execution/interruption of analysis method by difficulty 
					if( G6.chk_analysisStop_at_levels_2 > 0 ){
						if( G6.Found_level_Solution && Abs(MTHD.difficultyLevel)>2 )  break;	//Break if there is a solution with a difficulty level of 2 or less.
					}

					int lvl = MTHD.difficultyLevel;
					if( G6.PG6Mode!="Func_SolveMulti" && lvl<0 )  continue;     // The negative level algorithm is used only with multiple soluving. 				
					
					// In "Func_CreateAuto" or "Func_SolveMulti",
					// Puzzles that require the specified difficulty or higher method are invalid.
					// Therefore, the method is excluded.

					if( G6.PG6Mode=="Func_CreateAuto" || G6.PG6Mode=="Func_SolveMulti" ){
						if( Abs(lvl)>Puzzle_LevelHigh )  continue;
					}
			
					if( G6.PG6Mode == "Func_SelectPuzzle" ){	
						// The algorithm being screened raises the upper bound to increase the probability of detecting errors.

#if DEBUG
						G6.MSlvr_MaxNoAlgorithm = MTHD.developB? 10: 1;
#else
						G6.MSlvr_MaxNoAlgorithm = MTHD.Sel_mark? 10: 1;	
#endif
					}

					//if( G6.AnalyzerMode == "SolveUpDev" ){ if( !MTHD.method_valid ) continue; }	// In future versions, change to "method_valid" judgment.
				#endregion
					
					//if(__ChkPritnt_SolverMethod)  WriteLine( $"   --- {MTHD_idx} {MTHD.NameM}" );  //###@@@

				#region Algorithm execution
							if(__ChkPritnt_SolverMethod){
								ts1 = AnalyzerLap.Elapsed.TotalMilliseconds;
								string stStep = $"--->GNPX_Solver_SingleStage/debugCC:{debugCC++:00} stageNo:{stageNo}";
									   stStep += $"  difficultyLevel:{MTHD.difficultyLevel}";
									   stStep += $"  (lap time: {(ts1-ts0): 0.0} msec)";
									   stStep += $"  method: {(MTHD_idx)} - {MTHD.MethodName}";
									   if( MTHD.Sel_mark )  stStep += $"    MTHD.mark_Sel:����{MTHD.Sel_mark}";
									   stStep += $" @@:{G6.stopped_StatusMessage}  "; 
								WriteLine( stStep );
								ts0 = ts1;
							}

							try{	
								// *==* Execute *==*==*==*==*==*==*==*==*==*==*
								GNPX_Engin.AnalyzingMethod = MTHD;

								ePZL.BOARD.ForEach( u=> {u.CancelB=0; u.FixedNo=0; u.ECrLst=null; } );	//Crear All.

								AnalysisResult = MTHD.Method();		// <<< excute method >>>

								if( ePZL.BOARD.Any(u=> u.ECrLst!=null && u.ECrLst.Count>=2) )  WriteLine( $"MTHD:{MTHD.MethodName}" );  //XY_Wing, ALS_DeathBlossom 2026

								if( MTHD.ErrorB || (MTHD.SuccessfulB && MTHD.Sel_mark) )  Set_SelectedMark(MTHD,ePZL);
								if( MTHD.SuccessfulB )  G6.LastSuccessfullMethod = $"Lv.{MTHD.difficultyLevel} {MTHD.MethodName}";
								if( G6.stopped_StatusMessage!="" )  break; // "time over"...
								// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*
							}
				    
					catch(Exception e){
						string stException = e.Message + "\r" + e.StackTrace;
						WriteLine( stException );
						G6.stopped_StatusMessage = stException;
						Utility_Display.GNPX_StreamWriter_WithTime(fName:"Solver_Exception.txt", message:stException, append:true );
						_PostProcessing();
						return (false,"Exception occurred");
					}
				
				#endregion  Algorithm execution

				if( ePZL.Child_PZLs.Count>0 ){
					int diffLevel = Abs(MTHD.difficultyLevel);			// method difficult level
					if( diffLevel <= 1 )  G6.Found_level_Solution = true;
				}
				if( AnalysisResult ){ // Solved
							if(__ChkPritnt_SolverMethod) WriteLine($"                  ========================> solved  @@{MTHD}");
					_AnalysisSuccessful(MTHD);
					if( GNPX_Engin.MltAnsSearch is false )  break;		// *** In simple search, end here. ***
				}

				if( Sel_Mark_Break && ePZL.Child_PZLs.Any(p=>p.pMethod.Sel_mark) ){ G7.Sel_mark_Solved=true; break; }
			}

		  LProcessEnd:

			{
				var ePZL_Child_PZLz = ePZL.Child_PZLs;
				if(  stResult=="SolveUp" ){ AnalysisResult=true; }
				else if( ePZL_Child_PZLz!=null && ePZL_Child_PZLz.Count>0 ){  // solution found
					ePZL.selectedIX=0; ePZL=ePZL_Child_PZLz[0]; 
					AnalysisResult=true;
					if( stResult != "SolveUp" )  stResult="Solved";
				}
				else{
					AnalysisResult=false; stResult="Unsolved";
					string culture = App_Environment.culture;
					ePZL.Sol_Result = (culture=="ja-JP")? stNotSolvedJP: stNotSolved;
				}
			}

			_PostProcessing();
						void _PostProcessing(){
							G6.AnalysisResult = AnalysisResult;
							G6.stResult = stResult;

							var ePZL_Child_PZLz = ePZL.Child_PZLs;
							if( ePZL_Child_PZLz!=null && ePZL_Child_PZLz.Count>0 ){	ePZL.selectedIX=0; ePZL=ePZL_Child_PZLz[0]; } // solution found
							SdkExecTime = AnalyzerLap.Elapsed;	
							AnalyzerLap.Stop();
						}   

			return (AnalysisResult,stResult);
			// ======================================================================================================		

						void _AnalysisSuccessful( UAlgMethod MTHD ){			// ###... This code needs to be rebuilt
							// @@ Basic solutions were applied. No advanced solutions were applied to the multiple solution search.
							int diffLevel = Abs(MTHD.difficultyLevel);			// method difficult level
							if( diffLevel <= 2 )  G6.Found_level_Solution = true;

							if( (G6.PG6Mode=="Func_SolveMulti" || G6.PG6Mode=="Func_SelectPuzzle") && MTHD.Sel_mark )  G7.Sel_mark_Solved=true;

							// for Create Puzzle
							if( diffLevel >= PZL_Initial.difficultyLevel ){
								PZL_Initial.difficultyLevel = diffLevel;	// Record the difficulty of the puzzle
								PZL_Initial.pMethod = MTHD;					// Record the Method
							}

							switch(G6.PG6Mode){
								case "Func_SolveMulti":
								case "Func_SelectPuzzle":
									if( MTHD.Sel_mark )  G7.Sel_mark_Solved = true;
									break;
							}

							// for SolveUp
							MTHD.UsedCC++;			// Counter for the number of times the algorithm has been applied.
							ePZL.pMethod = MTHD;	// Methods applied to the analysis phase of the puzzle.
						}

						void Set_SelectedMark( UAlgMethod MTHD, UPuzzle aPZL ){
							if(MTHD.SuccessfulB){
								PZL_Initial.g7MarkA = true;		//##@@ Needs organization and confirmation
								G7.g7MarkA0 = true;             // Record what was solved using the marked method

								if( G7.g7MarkA_MLst0 == null ) G7.g7MarkA_MLst0 = new();							
								G7.g7MarkA_MLst0.Add($"{stageNo}-{MTHD.MethodName}");
							  //PZL_Initial.Name = $"sq:{PZL_Initial.ID} {MTHD.MethodName}";

								if( PZL_Initial.BaseName.Contains("ID:") ){
									int na = PZL_Initial.BaseName.IndexOf(" ");
									PZL_Initial.Name = PZL_Initial.BaseName.Substring(0,na) + $" {MTHD.MethodName}";
								}
								else if( PZL_Initial.BaseName == "" )	PZL_Initial.Name = MTHD.MethodName;

								PZL_Initial.difficultyLevel = MTHD.difficultyLevel;
							}
							if(MTHD.ErrorB){
								WriteLine( $" Error {ePZL.stPZL_withSP}" );

								PZL_Initial.g7MarkA = true;		//##@@ Needs organization and confirmation
								G7.g7Error = true;                // Record what was solved using the marked method

								if( G7.g7MarkA_MLst0 == null ) G7.g7MarkA_MLst0 = new();
								G7.g7MarkA_MLst0.Add($"{stageNo}-{MTHD.MethodName}");
							}
						}

		}
		#endregion Analyzer
	}
}