using GIDOO_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Windows.Devices.Power;
using static GNPX_space.GNPX_App_Ctrl;
using static System.Diagnostics.Debug;
using static System.Math;


namespace GNPX_space{
	using pGPGC = GNPX_Puzzle_Global_Control;

    public partial class GNPX_App_Ctrl{
		
		public void Queue_Solving_A( CancellationTokenSource ctsAPQ ){
			do{
				if( ctsAPQ.IsCancellationRequested )  break;
				// If LS_Queue is empty, it will sleep temporarily,
				//  and if it is not empty, it will perform analysis using GNPX.

				if( QuePuzzle.Count<=0 ) Thread.Sleep(10);
				else{
					lock(obj){ 
						G7.g7_GNPX_Solving = true;
						LatinSquare_9x9  LSQ_PZL = QuePuzzle.Dequeue();	
						if( LSQ_PZL == null )  continue;
						G6.LS_Queue = LSQ_PZL.stSolX9.Replace(" ","\n");

							try{ CreateAuto_SolveUp_A2( LSQ_PZL, ctsAPQ ); }
							catch( Exception ex ){ WriteLine( ex.Message+"\r"+ex.StackTrace ); }

						if( G6.SolutionCounter >= G6.NoOfPuzzlesToCreate )  break;
						G7.g7_GNPX_Solving = false;
					}
				}

			}while( !ctsAPQ.IsCancellationRequested );
			return;
		}
			private void CreateAuto_SolveUp_A2( LatinSquare_9x9 LSQ_PZL, CancellationTokenSource ctsAPQ ){
				int rc = 0;
				List<UCell> BDLa = LSQ_PZL.SolX.ToList().ConvertAll( p=> new UCell(rc++,p) );
				UPuzzle qPZL = new UPuzzle( BDLa );               // Create new UPuzzle

				pGNPX_Eng.Set_NewPuzzle( qPZL );                    // Set Puzzle to Engin

				// <2> Solve Puzzle =======================
				pGNPX_Eng.AnalyzerCounterReset();			// (Not necessary)       
				string stRet = pGNPX_Eng.GNPX_Solver_SolveUp(ctsAPQ.Token);	// Apply algorithms
				if( ctsAPQ.Token.IsCancellationRequested ) return;
		



				//  <3> Solved =======================
				if( stRet == "SolveUp" ){
					var PZL000 = pGNPX_Eng.PZL_Initial;

					// <<< The difficulty of the puzzle is acceptable? >>>
					int diffLvl = PZL000.difficultyLevel;
						if( diffLvl<G6.Puzzle_LevelLow || G6.Puzzle_LevelHigh<diffLvl )  return;

					// randomize
					if( G6.Digits_Randomize )  qPZL.BOARD = _Randomize_PuzzleDigits(qPZL);
						

					// <<< Save Puzzle >>>
					qPZL.pMethod = PZL000.pMethod;
					qPZL.difficultyLevel = diffLvl;
					qPZL.Name = qPZL.pMethod.MethodName;
					qPZL.TimeStamp = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
					qPZL.solMessage = pGNPX_Eng.DGView_MethodCounterToString();
					qPZL.BOARD.ForEach( p=>p.Reset_All() );

					// Info messages
						G6.LS_P_P1 = 0;	// Reset "no-Puzzle" counter.
						G6.Info_CreateMessage2 = "";
						G6.Info_CreateMessage3 = "";

					pGPGC.GNPX_Puzzle_List_Add( qPZL );										
				
					if( G6.Save_CreatedPuzzle ) pGNPX_App.Save_CreatedPuzzle_ToFile(qPZL);                                                            
						
					G6.SolutionCounter++;
					Gidoo_EventHandler se = new Gidoo_EventHandler( eName:"PuzzleCreated", ePara0:G6.NoOfPuzzlesToCreate, G6.SolutionCounter );
					Send_Command_to_FCreateAuto( this, se );

					// Forced pattern LS change
					if( ++G6.LS_P_P0 >= G6.LS_Pattern_Cntrl_P0 ){
						Send_Command_to_FCreateAuto( this, new Gidoo_EventHandler(eName:"Force_ChangePattern") );
						QuePuzzle.Clear();
						G6.LS_P_P0 = 0;
					  //Thread.Sleep(100);
					}
					
					// ================================================
					if( !G6.Search_AllSolutions && G6.SolutionCounter>=G6.NoOfPuzzlesToCreate )  return; // The required No. of solutions has been found			
					if( G6.CbxNextLSpattern )  rxCTRL=0;      //Change LS pattern at next puzzle generation
				}	
				return;	

						List<UCell> _Randomize_PuzzleDigits( UPuzzle qPZL ){
							List<int> ranNum = new List<int>();
							for(int no=0; no<9; no++)  ranNum.Add( GNPX_Random.Next(0,9)*10+no );
							ranNum.Sort((x,y) => (x-y));
							for(int no=0; no<9; no++) ranNum[no] %= 10;

							int[] P = new int[81];
							for( int rc=0; rc<81; rc++){
								int no = qPZL.BOARD[rc].No;
								if( no>0 ) P[rc] = ranNum[no-1]+1;
							}

							int rcX = 0;
							List<UCell> Board = P.ToList().ConvertAll( q => new UCell(rcX++,q) );
							return  Board;
						}	


			}


		// ==============================================================
        public void task_GNPX_PuzzleCreaterAuto_QueB( Func_CreateAuto _fCreateAuto, CancellationTokenSource ctsAPQ ){
						//WriteLine( $" --1 task_GNPX_PuzzleCreaterAuto_1" );
			if( FCreateAuto == null ){
				this.FCreateAuto = _fCreateAuto;
				Send_Command_to_FCreateAuto += new GNPX_EventHandler( FCreateAuto.GNPX_Event_Handling_man );  
			}

            AnalyzerBaseV2.__SimpleAnalyzerB__ = true;
            G6.SolutionCounter = 0;

			try{
				G6.LS_P_P0 = 0;
				G6.LS_P_P1 = 0;
				do {
					if( ctsAPQ.IsCancellationRequested )  break;

					GNPX_Creator_LS_Parallel_3( ctsAPQ, G6.LS_Pattern_Cntrl_P2 );		
					if( G6.SolutionCounter >= G6.NoOfPuzzlesToCreate )  return;
					if( G6.LS_PatternChangeCommand ){
						QuePuzzle.Clear();
						G6.LS_PatternChangeCommand=false;
					}

					else if( ++G6.LS_P_P1<=G6.LS_Pattern_Cntrl_P1 ){  // Force pattern change
						Send_Command_to_FCreateAuto( this, new Gidoo_EventHandler(eName:"Force_ChangePattern") );
						G6.LS_P_P0 = 0;
						G6.LS_P_P1 = 0;
					}
					else  break;
				}while( !ctsAPQ.IsCancellationRequested );
            }
            catch(TaskCanceledException){ WriteLine("...Canceled by user."); }
            catch(Exception ex){ WriteLine(ex.Message+"\r"+ex.StackTrace); }    
			return;
		}

    }
}
