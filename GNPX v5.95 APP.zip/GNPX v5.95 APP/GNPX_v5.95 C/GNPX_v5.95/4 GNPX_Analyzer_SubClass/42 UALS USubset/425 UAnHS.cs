using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using System.Xml.Serialization;

using GIDOO_space;
using GNPX_space.Properties;

namespace GNPX_space {
    //AHS(Almost Locked Set) 
    // AHS is a state where there are "n candidate digits" in "n+1 cells" belonging to the same house. 
    // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page26.html

	// *==*==*==*==*==*==*==*==*==*
	//		version 5.1 
	// *==*==*==*==*==*==*==*==*==*

    public class UAnHS: IComparable{
		public int  ID;
        public readonly int  CellSize;
		public readonly int  noBSize;
        public readonly int  Level;         //CellsSize-FreeDigits
		public readonly int  hno;
		public readonly int  FreeB;
		public readonly UInt128 AHS_B81;
		public readonly UInt128 rcB_FreeB_key;
		public string   stFreeB => FreeB.TBScmp();

        public UAnHS(){ }

        public UAnHS( int ID, int noBSize, int FreeB, UInt128 AHS_B81, int hno ){
		    this.CellSize  = AHS_B81.BitCount();
			this.noBSize   = noBSize;
            this.Level     = CellSize - noBSize;
			this.FreeB	   = FreeB;
			this.hno	   = hno;
			this.AHS_B81   = AHS_B81;

			this.rcB_FreeB_key = ((UInt128)FreeB)<<100 | AHS_B81;
		}


		public int CompareTo( object obj ){  // for IComparable. ... don't delete
            UAnHS UB = obj as UAnHS;
			if( this.noBSize!=UB.noBSize )    return (this.noBSize-UB.noBSize);
            if( this.Level!=UB.Level )		  return (this.Level-UB.Level);
            if( this.FreeB!=UB.FreeB )		  return (this.FreeB-UB.FreeB);
            return  (this.AHS_B81==UB.AHS_B81)? 0: (this.AHS_B81>UB.AHS_B81)? 1: -1;
        }


		// UAnHS << ID:0 >>  noBSize:1 Level:0 hno:)  FreeB:#3  UC81List:r1c45
		public override string ToString(){
            string st = $"  UAnHS << ID:{ID} >>  noBSize:{noBSize} Level:{Level} hno:{hno.HouseToString(noSt:"")}({hno})";
            st += $"  UC81List:{AHS_B81.TBScmp()}  FreeB:#{FreeB.TBScmp()}";
            return st;
        }
	}

}
