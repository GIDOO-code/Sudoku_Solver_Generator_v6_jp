﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using GNPX_space;

namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{


		private bool SLine_Covering( UExocetA Exo, bool debugPrint=false ){
			UCrossLine  ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;
			int			FreeB = Exo.FreeB;

			UInt128		Base_Object = Exo.Base81 | Exo.Object81_AB;
						if(debugPrint) _Information_4_Debugging(Exo);

			Exo.CoverStatusList = new UCoverStatus[9];
			Exo.CL_bySize_noB   = new int[10];							// $$$@@@ For cases where there are multiple extended SLines
			int h_SLine0_100 = ExG0.hno + 100;

			UInt128 SLine1=Exo.SLineList[1], SLine2=Exo.SLineList[2];

			// ======== Covering ========
				bool ExoCovered = true;
				List<int> house_CL = _Generate_CoverLines_Houses_A( Exo );	// List of CoverLine candidate houses
				foreach( var no in FreeB.IEGet_BtoNo() ){
					int noB = 1<<no;
					UInt128 SLine_no = Exo.SLine012e & BOARD_FreeOrFixed81B9[no];	// Test SLine for #no
							if(debugPrint){ 
								G6_SF.__MatrixPrint( Flag:Base_Object, BOARD_FreeOrFixed81B9[no], Exo.SLine012e, SLine_no, 
													 $"BOARD_FreeOrFixed81B9[#{no+1}] SLine012e(#{no+1}) SLine_no(#{no+1})" );
							}

					if( SLine_no==qZero ){ Exo.CL_bySize_noB[0] |= noB; }

					else{	
						UCoverStatus UCL = _Get_CoverLine_Ext( Exo, no, SLine_no, house_CL, debugPrint:false );	// <<< _Get_CoverLine	
						if( UCL == null )  continue;
						if( UCL.CLH_List.Any(h=> h==h_SLine0_100) ){
							// @@@1022 BaseDigits on SLIne0 are covered by Parallel_CoverLine.
							//	   If they are only covered by Cross_CoverLine, they do not meet the requirements of EXocet.
							//	   EXocet is not established.
							ExoCovered=false;  continue; 
						}  // invalid Covering ! 

						if( UCL != null ){ 
							Exo.CoverStatusList[no] = UCL; 
							Exo.CL_bySize_noB[UCL.sz] |= noB;		// sz=3 ... Wildcard or ... Type:Extension
						}		
					}
				}
			// -------- Covering --------

			int szCL = Exo.SLineList.Count()-1;			// $$$@@@ Complex @@@
			int FreeB_Covered_CL = Exo.CL_bySize_noB[szCL];	//　[Att]  Bird　Doc. Rule-1
						if(debugPrint){ 
							string  stCoverLines = Exo.CoverStatusList.Where(p=>p!=null).Aggregate(" ",(a,ch)=> a+ $"\n {ch}");
							WriteLine( $"\nCoverLines\n{stCoverLines}" );

							WriteLine( $"FreeB_Covered_2CLtest2:{FreeB_Covered_CL.TBS()}" );
							foreach( var (P,kx) in Exo.CL_bySize_noB.WithIndex() ) WriteLine( $"  Exo.CL_bySize_noB[{kx}] : {P.TBS()}" );
						} 

			int[] CL_bySize_Count = Exo.CL_bySize_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();

			return  ExoCovered;
		// ======================================================================================================================

							void  _Information_4_Debugging( UExocetA Exo ){
								UCrossLine  ExG1=Exo.ExG1, ExG2=Exo.ExG2;

								// =========================================
									string st = $"\n Exo_0 dir:{Exo.dir} rcStem:{Exo.rcStem}  baseCells:{Exo.Base81.TBScmp()}" ;
									st += $"  Object 1-2 : {ExG1.stObject} - {ExG2.stObject}";
									WriteLine( st );

								// =========================================
									string[]  Marks = new string[81];
									var (rcB1,rcB2) = Exo.Base81. BitToTupple();
									if( rcB1>=0 ) Marks[rcB1] = "b"; 
									if( rcB2>=0 ) Marks[rcB2] = "b"; 
									foreach( var rc in ExG1.Object81.IEGet_rc() )  Marks[rc] = "t1";
									foreach( var rc in ExG2.Object81.IEGet_rc() )  Marks[rc] = "t2";

									//pBOARD.__CellsPrint_withFrame( Marks,  "SEBase,ExG1,ExG2" );
									pBOARD._Dynmic_CellsPrint_withFrame( Marks,  "***" );

								// =========================================
									WriteLine( $"\n dir:{Exo.dir}  Base:{Exo.stBase}  T1:{Exo.ExG1.stObject}  T2:{Exo.ExG2.stObject}" );
									UInt128 _Flag = Exo.Base81 | ExG1.Object81 | ExG2.Object81;
				
									G6_SF.__MatrixPrint( Flag:_Flag, Exo.CrossLine_012, Exo.SLine012e, "CrossLine_012, SLine_012_Ext" );
								// =========================================
							}



				List<int> _Generate_CoverLines_Houses_A( UExocetA Exo, bool debugPrint=false ){
					int _func_house( int dir, int rc) => (dir==0)? (rc/9): (rc%9+9);
					
					int  dir=Exo.dir, hCL0=Exo.ExG0.hno+100;;
					int rcbHouse_1827 =  (Exo.ExoMtdName.Contains("Complex") || Exo.ExoMtdName.Contains("FM") )? 0x7FFFFFF: 0x3FFFF;	
						// Type="FM,Commplex":  the Block_CoverLIne(h=19-27) is also checked.
					
					// Generate a list of cover lines (houses) from the distribution of candidate/determined values ​​on SLine.				
					int  rcbFrame = (Exo.SLine012e & BOARD_FreeB9_noB(Exo.FreeB)) .Ceate_rcbFrameOr() & rcbHouse_1827;				// Frame of FreeCells
					rcbFrame |= (Exo.SLine012e & BOARD_Fixed81).IEGet_rc() .Aggregate( 0, (a,rc) => a| (1<<_func_house(dir,rc) ) );	// Frame of FixedCells	

					List<int> house_CL = rcbFrame.IEGet_BtoHouse27().ToList();	// List of CoverLLine candidate houses
					house_CL = house_CL.FindAll(p => p!=hCL0);					// @@@ CL0 is excluded from the cover line
					house_CL = house_CL.ConvertAll( cl => (cl<18 && (cl/9)!=dir)? cl+100: ((cl%100)>=18)? cl+200: cl );	// @@@  +100:Cross-CoverLine  +200:Brock-CoverLine
					house_CL.Sort();	// Sort to prioritize searching for Parallrel CoverLine.

						if(debugPrint){
							string st = $"rcbFrame{rcbFrame.ToBitString27rcb()}  house_CL:{string.Join( " ",house_CL)}";
							WriteLine( $"_Generate_CoverLines_Houses_Ast: {st}" );
						}
					return house_CL;
				}

				UCoverStatus _Get_CoverLine_Ext( UExocetA Exo, int no, UInt128 SLine_no, List<int> house_CL, bool debugPrint=false  ){
					int nxt=9;
					UInt128 SLine012e = Exo.SLine012e;
					UInt128 hclSel = SLine_no & BOARD_FreeOrFixed81B9[no];
					int hCL0 = Exo.ExG0.hno+100;	
					List<int> HCL_List = house_CL.FindAll( h => (House_81[h%100]&hclSel)!=qZero );

					// :::::::::: 1-CoverLine :::::::::: ====================================================================================
					foreach( int h0 in HCL_List.Where(h=>h<100) ){
						UInt128 CLH = House_81[h0];
						if( __CoveredCount_B1(SLine012e,h0,CLH,no) <= 0 )  continue;
						if( (SLine_no & ~CLH) == qZero ) return  new UCoverStatus( no, 1, h0, -1, -1 ); // covered by one CoverLine.
					}

					// :::::::::: 2-CoverLine :::::::::: ====================================================================================
					bool FMorComplex = Exo.ExoMtdName.Contains("Complex") || Exo.ExoMtdName.Contains("FM");
					Combination cmb2 = new(HCL_List.Count,2);
					while( cmb2.Successor(skip:nxt) ){
						int h0=HCL_List[cmb2.Index[0]], h1=HCL_List[cmb2.Index[1]];

						// : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :
						if( !FMorComplex && h0>=100 )  break;	// If not FM or not Complex, two Cross-CoverLine is ineligible.
						// : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

						nxt=0;
						UInt128 CLH0 = House_81[h0%100];
						if( (SLine_no & CLH0) == qZero ){  continue; }
						if( __CoveredCount_B1(SLine012e,h0,CLH0,no) <= 0 )  continue;

						nxt = 1;
						UInt128 CLH1 = House_81[h1%100];
						if( __CoveredCount_B1(SLine012e,h1,CLH1,no) <= 0 )  continue;

						if( (SLine_no & ~(CLH0|CLH1)) == qZero ) return  new UCoverStatus( no, 2, h0, h1, -1 );	// covered by 2 CoverLines.
					}

					// :::::::::: 3-CoverLine :::::::::: ====================================================================================
					//	if(  Exo.ExoType=="Complex" & HCL_List.Count()>=3 ){
					if( HCL_List.Count()>=3 ){
						Combination cmb3 = new(HCL_List.Count,3);
						while( cmb3.Successor(skip:nxt) ){
							int h0=HCL_List[cmb3.Index[0]], h1=HCL_List[cmb3.Index[1]], h2=HCL_List[cmb3.Index[2]];
									
							nxt=0;
							UInt128 CLH0 = House_81[h0%100];
							if( (SLine_no & CLH0) == qZero )  continue;
							if( __CoveredCount_B1(SLine012e,h0,CLH0,no) <= 0 )  continue;
							
							nxt=1;
							UInt128 CLH1 = House_81[h1%100];
							if( (SLine_no & CLH1) == qZero )  continue;
							if( __CoveredCount_B1(SLine012e,h1,CLH1,no) <= 0 )  continue;

							nxt=2;
							UInt128 CLH2 = House_81[h2%100];
							if( (SLine_no & CLH2) == qZero )  continue;
							if( __CoveredCount_B1(SLine012e,h2,CLH2,no) <= 0 )  continue;

							if( (SLine_no & ~(CLH0|CLH1|CLH2)) == qZero ) return  new UCoverStatus( no, 3, h0, h1, h2 );	// covered by 3 CoverLines.
						}
					}
					Exo.CL_bySize_noB[9] |= (1<<no);

					return  null;
						
						int __CoveredCount_B1( UInt128 SLine012, int hx, UInt128 CLH, int no ){
							UInt128  CLH_SLine = CLH & SLine012;
							if( (BOARD_Fixed81B9[no] & CLH_SLine) > 0 )  return 1;		// In the case of "fixed Digit cell"
							int CLcount = (BOARD_Free81B9[no] & CLH_SLine).BitCount();
							
							// The following code is not necessary. Incorrect. The shape of an abnormal phenomenon is beginning to emerge.
							//if( hx<100 && CLcount>0 )  CLcount--;	// Parallel CoverLines with one element are excluded.  @@@1022	
							return  CLcount;
						}
				}
		}	

		private bool Test_SLine_Covering( UExocetA Exo ){
/*
			if( _BaseDigits_Distribution_on_SLine_0(Exo) is false )  return false;  // SLine0 must cover all BaseDigits.

			int noB_Sline1_Valid = Exo.FreeB & ~_BaseDigits_Distribution_Invalid_on_SLine_12(Exo,1);
			int noB_Sline2_Valid = Exo.FreeB & ~_BaseDigits_Distribution_Invalid_on_SLine_12(Exo,2);
			if( noB_Sline1_Valid==0 || noB_Sline2_Valid==0 ) return false;
*/
			return true;

				int Get_Fixed_noB( UInt128 U) => U.IEGet_UCell(pBOARD).Aggregate(0,(a,u) => a | (u.No!=0? (1<<Abs(u.No)-1): 0)); 

				bool _BaseDigits_Distribution_on_SLine_0( UExocetA Exo ){
					UInt128 SLine0 = Exo.SLineList[0];
					int noBX = Get_Fixed_noB( SLine0 & Board81_Fixed_with_FreeB );
					noBX |= __Find_noB_for_SLine0(Exo, 0 );
					return (Exo.FreeB & ~noBX)==0;

					int __Find_noB_for_SLine0( UExocetA Exo, int SLX ){
						UInt128 SLineX = Exo.SLineList[SLX];
						int noBX = 0;
						foreach( int no in Exo.FreeB.IEGet_BtoNo() ){
							int noCC  = (SLineX & BOARD_Free81B9[no]).BitCount();
							if( noCC==1 || noCC==2 ) noBX |= (1<<no);
						}
						return  noBX;
					}
				}

				int _BaseDigits_Distribution_Invalid_on_SLine_12( UExocetA Exo, int SLx ){
					UInt128 SLineX = Exo.SLineList[SLx];
					int noInvalid = Get_Fixed_noB( SLineX & Board81_Fixed_with_FreeB );	// Find Invalid no
					noInvalid |= __Find_Invalid_noB(Exo, SLx );							
					return  noInvalid;			
						
					int __Find_Invalid_noB( UExocetA Exo, int SLx ){
						UInt128 SLineX = Exo.SLineList[SLx];
						int noBX = 0;
						foreach( int no in Exo.FreeB.IEGet_BtoNo() ){
							int noCC  = (SLineX & BOARD_Free81B9[no]).BitCount();
							if( noCC>=3 ) noBX |= (1<<no);
						}
						return  noBX;
					}
				}
		}



		private bool Check_SLine_Condition( UExocetA Exo, bool debugPrint=false ){
			int[] CL_noB = Exo.CL_bySize_noB;
			int[] CL_bySize_Count = CL_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();
			UCrossLine  ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;

			// The SLIne coverage have been checked. The Base Digits are completely covered by [CL1+Cl2+CL3].

			int FreeB_Covered123 = CL_noB[1] | CL_noB[2] | CL_noB[3];
			if( (Exo.FreeB & ~FreeB_Covered123) > 0 )  return false;	// If not full coverage, it's not eligible.

			if( Test_SLine_Covering(Exo) is false ) return false;	// @@@ 1022

			switch(Exo.ExoMtdName){
				case "Exocet_JE2":	
				case "Exocet_JE2P":	
				case "Exocet":		 		// ... SE_Standard, SE_FM		// ... JE2, JE2+, JE2++
				case "Exocet_SingleBase":	// ... SE_SingleBase
					if( CL_bySize_Count[1]>0  || CL_bySize_Count[2]<2 || CL_noB[3]>0 )  return false;	
					break;

				case "Exocet_JE1":			// ... JE1
				case "Exocet_Single":		// ... SE_Single
					int sz2 = (Exo.FreeB&~Exo.wildcard_noB).BitCount();		// Number of BaseDigits excluding wildcard.
					if( CL_bySize_Count[1]>0 ||	CL_bySize_Count[2]!=sz2 || CL_bySize_Count[3]!=1 )  return false;				
					if( _test_Wildcard(Exo,ExG1,ExG2) is false ) return false;
					break;


				case "Exocet_FM":			// 	... Almost correct
					if( CL_bySize_Count[1]>0  || CL_bySize_Count[2]<2 || CL_noB[3]>0 )  return false;
					if( _Test_overlapping_SLines_ExoFM_Complex(Exo) is false )  return false;		
					break;


				case "Exocet_Complex":			// 	... Almost correct
					if( CL_bySize_Count[1]>0 || CL_bySize_Count[2]>0 || CL_bySize_Count[3]<2 )  return false;
					if( _Test_overlapping_SLines_ExoFM_Complex(Exo) is false )  return false;		
					break;

				// :::::::::::: Algorithm Error ::::::::::::::::::::::::::::::::::::::::::
				default:
					WriteLine( $"\n\n ExoMtdName : {Exo.ExoMtdName} ... \n\n {System.Environment.StackTrace}" );
					throw new Exception( $"Operation Error. Exo.ExoMtdName : {Exo.ExoMtdName}");
			}
			return true;

					bool _test_Wildcard( UExocetA Exo, UCrossLine UCLA, UCrossLine UCLB ){
						int FreeB = Exo.FreeB, w=Exo.wildcard_noB;
						if( UCLA.wildcardB ){ 
							int Fixed_ObjectA = (UCLA.Object81&BOARD_Fixed81).IEGet_UCell(pBOARD).Aggregate(0,(a,uc)=>a|(1<<uc.No-1) );
							if( (FreeB&Fixed_ObjectA) != 0 )  return false;
							if( ((FreeB&~w) & ~UCLB.FreeB_Object) > 0 )  return false;	// @@@ All except wildcard are covered.

							if( (Exo.FreeB & ~UCLB.SLine.Get_FreeB_or()) > 0 )  return false;	// @@@
						}

						else if( UCLB.wildcardB ){
							int Fixed_ObjectB = (UCLB.Object81&BOARD_Fixed81).IEGet_UCell(pBOARD).Aggregate(0,(a,uc)=>a|(1<<uc.No-1) );
							if( (FreeB&Fixed_ObjectB) != 0 )  return false;
							if( ((FreeB&~w) & ~UCLA.FreeB_Object) > 0 )  return false;	// @@@ All except wildcard are covered.

							if( (Exo.FreeB & ~UCLA.SLine.Get_FreeB_or()) > 0 )  return false;	// @@@
						}
						return true;
					}

					bool _Test_overlapping_SLines_ExoFM_Complex( UExocetA Exo ){
						// Is there a Base in the overlapping area of ​​the Slines?
						if(	Exo.ExoMtdName!="Exocet_FM" && Exo.ExoMtdName!="Exocet_Complex" )  return true;


						UInt128  SLine_Overlap = qZero;
						int nc = Exo.SLineList.Count(p=>p!=qZero);
						Combination cmb = new(nc,2);
						while( cmb.Successor() ){
							SLine_Overlap |= Exo.SLineList[ cmb.Index[0] ] & Exo.SLineList[ cmb.Index[1] ];
						}
						Exo.SLine_Overlap = SLine_Overlap;

							if(debugPrint){
								G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.SLineList[0], Exo.SLineList[1], Exo.SLineList[2], Exo.SLineList[3], "SLine_Overlap[0], [1], [2], [3]" );
								G6_SF.__MatrixPrint( Flag:_BaseObj_, SLine_Overlap, "SLine_Overlap" );
							}
					

						if( (Exo.ExG1.Object81&Exo.SLine_Overlap)!=qZero || (Exo.ExG2.Object81&Exo.SLine_Overlap)!=qZero )  return false; 
						return	(SLine_Overlap & Board81_Free_with_FreeB) == qZero;
					}
		}


/*
		UCrossLine  ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;
						UInt128		SLine0=ExG0.SLine, SLine1=ExG1.SLine, SLine2=ExG2.SLine;

						if(	Exo.ExoMtdName=="Exocet_FM" ||& Exo.ExoMtdName!="Exocet_Complex" ){
							if( _Test_overlapping_Slines_Sub( Exo, SLine1, SLine2) is false )  return false;
							if( _Test_overlapping_Slines_Sub( Exo, SLine0, SLine1) is false )  return false;
							if( _Test_overlapping_Slines_Sub( Exo, SLine0, SLine2) is false )  return false;

						return true;

							bool _Test_overlapping_Slines_Sub( UExocetA Exo, UInt128 SLineA, UInt128 SLineB ){
								UInt128 SL = SLineA & SLineB & Board81_Free_with_FreeB;
								return	(SL==qZero);
							}
					}	
*/
/*
					bool _Test_Object_Escape( UExocetA Exo ){
						// @@@ The logic needs to be examined. @@@1022
						// Sometimes the Object does not have a Base number. Exocet is not established.

						UCrossLine  ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;

						foreach( int no in Exo.FreeB.IEGet_BtoNo() ){
							int  noB = 1<<no;
							if( (Exo.SLine012e & BOARD_Fixed81B9[no]).BitCount() < 2 )  continue;

							if( (ExG1.SLine & BOARD_FreeOrFixed81B9[no]).BitCount() == 0 ){
								int F = (ExG1.CrossLine&Exo.Escape81).Get_FreeB_or();
								if( (ExG1.FreeB_Object & noB)>0 && (F&noB)>0 )  return false;	// is not established.
							}

							if( (ExG2.SLine & BOARD_FreeOrFixed81B9[no]).BitCount() == 0 ){
								int F = (ExG2.CrossLine&Exo.Escape81).Get_FreeB_or();
								if( (ExG1.FreeB_Object & noB)>0 && (F&noB)>0 )  return false;	// is not established.
							}
						}
						return true;
					}
*/

//#if Eocet_FM //@@@ FM
				// ==============================================================================================
	/*
				int SE_ph45_Check_ExtendCondition( UExocetA Exo, bool debugPrint=false ){
					UInt128 Base_Object = Exo.Base81 | Exo.ExG1.Object81 |Exo.ExG2.Object81;
					//debugPrint = true;

					int vno1 = _SE_ph45_Check_ExtendConditionsub(Exo,Exo.ExG1,debugPrint:debugPrint);
					int vno2 = _SE_ph45_Check_ExtendConditionsub(Exo,Exo.ExG2,debugPrint:debugPrint);

					return  (vno1|vno2);
				
						int _SE_ph45_Check_ExtendConditionsub( UExocetA Exo, UCrossLine ExGM, bool debugPrint=false ){
							UInt128 SLN = Exo.SLine012e & House_81[ExGM.hno];	
									if(debugPrint) G6_SF.__MatrixPrint( Flag:Base_Object, Exo.SLine012e, House_81[ExGM.hno], SLN, $"Exo.SLine012e, House_81[ExGM.hno], SLN_#" );

							int noValid = 0;
							foreach( int no in Exo.FreeB.IEGet_BtoNo() ){
								UInt128 SB = SLN & BOARD_FreeOrFixed81B9[no];
										if(debugPrint) G6_SF.__MatrixPrint( Flag:Base_Object, SLN, BOARD_FreeOrFixed81B9[no], SB, $"SLN, BOARD_FreeOrFixed81B9[no], SB_#{no+1}" );
								if( SB.BitCount() <= 2 )  noValid |= 1<<no;
							}
							return (noValid & ExGM.FreeB_Object81);
						}
				}
	*/			
			

			
//#endif




	}
}