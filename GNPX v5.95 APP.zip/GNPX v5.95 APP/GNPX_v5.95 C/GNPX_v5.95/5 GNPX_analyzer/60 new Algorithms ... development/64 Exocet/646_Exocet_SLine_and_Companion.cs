﻿using GIDOO_space;
using GNPX_space;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq; 
using System.Security.AccessControl;
using System.Security.Policy;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;

using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;
using static System.Math;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{

	// ===== Companion ==================================================================================================== 
		private bool Set_Companion_and_Test( UExocetA Exo, bool debugPrint=false ){  // Companion is the core element of the Exocet,	
			UCrossLine ExG0=Exo.ExG0, ExG1=Exo.ExG1, ExG2=Exo.ExG2;

				//debugPrint = true;  // *******************

			UInt128  CL_Overlap_with_FreeB = __CL_Overlap_with_FreeB_sub(Exo.h012B);
						UInt128 __CL_Overlap_with_FreeB_sub( int h012B ){
							UInt128 OLr = (h012B&0x1FF).IEGet_BtoNo(9).Aggregate(qZero, (a,h)=> a | House_81[h] );
							UInt128 OLc = (h012B&(0x1FF<<9)).IEGet_BtoNo(18).Aggregate(qZero, (a,h)=> a | House_81[h] );
							UInt128 OLb = (h012B&(0x1FF<<18)).IEGet_BtoNo(27).Aggregate(qZero, (a,h)=> a | House_81[h] );
							UInt128 OL  = (OLr&OLc) | (OLc&OLb) | (OLb&OLr);
							UInt128 OLF  = OL & Board81_Fixed_with_FreeB;	// OL & [Cells of fixed ​​Base digits]
								if(debugPrint){
									WriteLine( h012B.ToBitString27rcb() );
									G6_SF.__MatrixPrint( Flag:_BaseObj_, OLr, OLc, OLb, OL, "OLr, OLc, OLb, OL" );
									G6_SF.__MatrixPrint( Flag:_BaseObj_, OL, Board81_Fixed_with_FreeB, OLF, "OL, Board81_Fixed_with_FreeB, OLF" );
								}
							return  OLF;
						}

					if( Exo.ExoMtdName is "Exocet_JE2P" ) { // ... Not yet clearly explained
						if( _Test_Object_Unity_Condition(Exo,ExG1.Object81) is false )  return false;
						if( _Test_Object_Unity_Condition(Exo,ExG2.Object81) is false )  return false;
				
							bool _Test_Object_Unity_Condition( UExocetA Exo, UInt128 obj81 ){
								if( obj81.BitCount() == 1 )  return true;
								var (single,more) = obj81.Get_FreeB_Single_More();
								return ( (more&Exo.FreeB)==0 );
							}
					}

			UInt128 CompanionBaseX = (_Func_Companion_object(Exo.ExG1) | _Func_Companion_object(Exo.ExG2)) | CL_Overlap_with_FreeB;
			CompanionBaseX &= ~(Exo.Escape81 | Exo.Object81_AB);
			Exo.Companion_base = CompanionBaseX;

				UInt128 _Func_Companion_object( UCrossLine ExGM ) => ExGM.Object81.IEGet_rc().Aggregate(qZero, (a,rc) => a| _Func_Companion_basic(ExGM.hno,rc) );
				UInt128 _Func_Companion_basic( int h, int rc ) => (h<18)? (House_81[rc/9+rc%9+9-h] | (House_81[h] & House_81[rc.B()+18])):	// Exocet(Standard)
																		((House_81[rc/9] | House_81[rc%9+9])) & House_81[h];				// Exocet_FM																																		

			var (CL0, CL1, CL2, CL3, CL4) = Exo.CL012A;		// Invalid houses(h<0) are all-zero
			UInt128 CrossLine = CL0 | CL1 | CL2 | CL3 | CL4; 
			Exo.Companion = CompanionBaseX & CrossLine;
				if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Companion_base, Exo.Companion, CrossLine, "Exo.Companion_base, Exo.Companion, CrossLine" );

			int FreeB_Companion = Exo.Companion .Get_FixedFreeB();

			return  (Exo.FreeB & FreeB_Companion)==0;
		}





	// ===== SLine ==========================================================================================================
		private bool Set_SLine_and_Test( UExocetA Exo, bool debugPrint=false ){  // ... for Junior/Senior Exocet 
			UInt128     Exclude_3Elements = Exo.Escape81 | Exo.Companion_base | Exo.Object81_AB;
				if(debugPrint)  G6_SF.__MatrixPrint( Flag:_BaseObj_, Exo.Escape81, Exo.Companion_base, Exo.Object81_AB, Exclude_3Elements,
											"Exo.Escape81, Exo.Companion_base, Exo.Object81_AB, Exclude_3Elements," );

			var (h0,h1,h2,h3,h4) = Exo.h012A;
			UCrossLine  ExG1=Exo.ExG1, ExG2=Exo.ExG2;

			Exo.h_expand = -1;
			// ::: SLine
			var (CL0, CL1, CL2, CL3, CL4) = Exo.CL012A;	// Invalid houses(h<0) are all-zero
			UInt128 SLine0 = CL0 & ~Exclude_3Elements;
			UInt128 SLine1 = CL1 & ~Exclude_3Elements;
			UInt128 SLine2 = CL2 & ~Exclude_3Elements;

			UInt128 SLine3 = CL3 & ~Exclude_3Elements;
			UInt128 SLine4 = CL4 & ~Exclude_3Elements;

				if(debugPrint){
					G6_SF.__MatrixPrint( Flag:_BaseObj_, CL0, CL1, CL2, Exclude_3Elements, "CL0, CL1, CL2, Exclude_3Elements" );
					G6_SF.__MatrixPrint( Flag:_BaseObj_, SLine0, SLine1, SLine2, Exo.Companion_base, "SLine0, SLine1, SLine2, Exo.Companion_base" );
					G6_SF.__MatrixPrint( Flag:_BaseObj_, CL3, CL4, SLine3, SLine4, Exclude_3Elements, "CL3, CL4, SLine3, SLine4, Exclude_3Elements" );
				}
					
			var SLineList = (new []{SLine0, SLine1, SLine2, SLine3, SLine4}).ToList();
			Exo.SLineList = SLineList;

			if( CL3!=qZero && SLine3==qZero )  return false;  // Object is at the intersection of CrossLine.
			if( CL4!=qZero && SLine4==qZero )  return false;
			else if( SLine4==qZero )  Exo.h_expand =-1;
	
			return true;
		}

	}
}