
using System;
using System.IO;
using System.Linq;
using System.Windows;

using GIDOO_space;
using GNPX_space;

using static GNPX_space.Exocet_TechGen;
using static System.Diagnostics.Debug;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCrossLine,UCrossLine,UCrossLine);

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		private IEnumerable<UExocetA?> IE_Exocet_BasicForm( string ExoMtdName, bool debugPrint=false ){
			// dir, StemCell => BaseCells, FreeB, SLine0, block1, block2

			for( int dir=0; dir<2; dir++ ){	// direction  0:row 1:column
				foreach( int rcStem in Enumerable.Range(0,81) ){

					// ... Base cells
					int     h_Base = (dir,rcStem).DirRCtoHouse( );	// Row/Column house no.
					UInt128 Base81 = (House_81[h_Base] & House_81[rcStem.B()+18]) & ~(qOne<<rcStem) & BOARD_Free81;
					
					// Exocet_SingleBase : Base is a single-cell and bivalue.  @@@ BIVALUE |||
					if( ExoMtdName == "Exocet_SingleBase" ){	
					    foreach( UCell UC in Base81.IEGet_UCell(pBOARD).Where(uc=>uc.FreeBC==2) ){	// ##### FreeBC==2 
							UExocetA? Exo = _Create_UExocet( ExoMtdName, dir, rcStem, qOne<<UC.rc, UC.FreeB );
							if( Exo != null )  yield return Exo;
						}
						continue;
					}

					// Standard type Exocet : JE2, JE1, Exocet, Exocet_Single, FM
					else if( Base81.BitCount() == 2 ){	// ... The number of Base cells is 2 and the Base cells are not fixed.
						int FreeB  = Base81.Get_FreeB_or();		// ... Base candidates
						int FreeBC = FreeB.BitCount();
						if( FreeBC<3 || FreeBC>6 )  continue;	// Base Cells contain 3 or 6 Candidates.  (Number of Ccandidate Digits is expanded to 6)		

						UExocetA? Exo = _Create_UExocet( ExoMtdName, dir, rcStem, Base81, FreeB );
						if( Exo != null )  yield return Exo;
					}
				}
			}
			yield break;

					// ------------------------------------------------------------------------------------------------------------------------
					UExocetA? _Create_UExocet( string ExoMtdName, int dir, int rcStem, UInt128 Base81A,int FreeB ){
						UInt128 CrossLine0  =  House_81[(1-dir,rcStem).DRCHf()] & ~House_81[rcStem.B()+18];
						if( (CrossLine0 & BOARD_Free81) == qZero )  return null;	// There is nothing free on CrossLine_b

						UExocetA Exo = new( ExoMtdName, dir, rcStem, Base81A, FreeB, BOARD_Free81 );	
								if(debugPrint) WriteLine( $" CrossLine0:{CrossLine0.TBS()}" );

						return Exo;
					}
		}
	}

}