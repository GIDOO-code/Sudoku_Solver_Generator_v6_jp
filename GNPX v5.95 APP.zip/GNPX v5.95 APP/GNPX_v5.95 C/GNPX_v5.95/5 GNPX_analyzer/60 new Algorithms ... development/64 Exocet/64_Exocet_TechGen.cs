using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;

using GIDOO_space;

namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6) ...  Not very elegant. Needs some code cleanup.
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	using G6_SF = G6_staticFunctions;

    public partial class Exocet_TechGen: AnalyzerBaseV2{

		static private readonly string  spX		= new string(' ',10); 
		static private readonly string  sp5		= new string(' ',5); 

		private int			  stageNoPMemo = -9;
		private List<string>  extResultLst = new();

		private UInt128		  _BaseObj_;			// Used for debugging function (G6_SF.__MatrixPrint)

		public  Exocet_TechGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }



		public void Prepare_Exocet_TechGen(bool printB ){
			G6_staticFunctions.pBOARD = base.pBOARD;
			UExocetA.qBOARD			  = base.pBOARD;
			UCrossLine.qBOARD		  = base.pBOARD;
		}

		private int Get_LockedHouse( UInt128 Cells81, int no ){  // need
			// Find House where #n in cells "Cells81" is locked.
			// Output is the bit representation of the House number.

			UInt128 BOARD_No = BOARD_Free81B9[no];
			int hFrame = Cells81.ToRCBFrame();
			int h_locked = 0;
			foreach( int h in hFrame.IEGet_BtoNo(27) ){
				UInt128  bh = BOARD_No & House_81[h];
				if( (BOARD_No & House_81[h]) == Cells81 )  h_locked |= 1<<h;
			}
			return h_locked;
		}	


	}
}